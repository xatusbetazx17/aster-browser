#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT="${1:-$ROOT_DIR/build/Aster-Browser-Merged-Linux-v15.sh}"
TMP_DIR="$(mktemp -d)"
cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT
mkdir -p "$(dirname "$OUT")"
TAR="$TMP_DIR/aster-browser.tar.gz"
tar --exclude='./build' --exclude='./.git' --exclude='__pycache__' --exclude='*.pyc' -czf "$TAR" -C "$ROOT_DIR" .
cat > "$OUT" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_ID="org.aster.Browser"
APP_NAME="Aster Browser"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
APPS_HOME="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
INSTALL_ROOT="$DATA_HOME/aster-browser-portable"
INSTALL_DIR="$INSTALL_ROOT/app"
RUNTIME_DIR="$INSTALL_ROOT/runtime"
STATE_DIR="$INSTALL_ROOT/state"
LAUNCHER="$INSTALL_ROOT/aster-launch.sh"
DESKTOP_FILE="$APPS_HOME/$APP_ID.desktop"
ICON_DEST="$DATA_HOME/icons/hicolor/scalable/apps/$APP_ID.svg"
ASSUME_YES=0
NO_SYSTEM_DEPS=0
EXTRACT_ONLY=""
RUN_AFTER_INSTALL=0
REFRESH_CA=1
RESET_NETWORK_STATE=0
# Never touch protected browser certificate databases; some systems lock them
# behind a password/PIN and can loop on prompts during installation.
SKIP_NSS_DB_REFRESH=1

msg() { printf '[Aster Installer] %s\n' "$*"; }
die() { printf '[Aster Installer] %s\n' "$*" >&2; exit 1; }

usage() {
  cat <<'USAGE'
Aster Browser merged Linux installer

Options:
  --install-root DIR   Install into DIR instead of ~/.local/share/aster-browser-portable
  --no-system-deps    Do not try to install missing distro packages
  --extract-only DIR  Extract the bundled app source into DIR and exit
  --run               Start Aster after installation
  --refresh-ca        Refresh system CA trust using update-ca-certificates/update-ca-trust only (default)
  --no-refresh-ca     Skip system CA trust refresh
  --reset-network-state Clear Aster WebEngine cache/security state after install
  --uninstall         Remove the portable install and desktop entries
  -y, --yes           Non-interactive mode for supported package managers
  -h, --help          Show this help
USAGE
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install-root)
        [[ $# -ge 2 ]] || die "Missing value for --install-root"
        INSTALL_ROOT="$2"; INSTALL_DIR="$INSTALL_ROOT/app"; RUNTIME_DIR="$INSTALL_ROOT/runtime"; STATE_DIR="$INSTALL_ROOT/state"; LAUNCHER="$INSTALL_ROOT/aster-launch.sh"; shift 2 ;;
      --no-system-deps) NO_SYSTEM_DEPS=1; shift ;;
      --extract-only)
        [[ $# -ge 2 ]] || die "Missing value for --extract-only"
        EXTRACT_ONLY="$2"; shift 2 ;;
      --run) RUN_AFTER_INSTALL=1; shift ;;
      --refresh-ca) REFRESH_CA=1; shift ;;
      --no-refresh-ca) REFRESH_CA=0; shift ;;
      --reset-network-state) RESET_NETWORK_STATE=1; shift ;;
      --uninstall) uninstall; exit 0 ;;
      -y|--yes) ASSUME_YES=1; shift ;;
      -h|--help) usage; exit 0 ;;
      *) die "Unknown option: $1" ;;
    esac
  done
}

payload_line() {
  awk '/^__ASTER_PAYLOAD_BELOW__$/ {print NR + 1; exit 0}' "$0"
}

extract_payload() {
  local target="$1"
  local line="$(payload_line)"
  [[ -n "$line" ]] || die "Installer payload was not found."
  mkdir -p "$target"
  tail -n +"$line" "$0" | base64 -d | tar -xz -C "$target"
}

choose_sudo() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    printf ''
  elif command -v sudo >/dev/null 2>&1; then
    printf 'sudo'
  else
    return 1
  fi
}

apt_installed() { dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q 'install ok installed'; }
rpm_installed() { rpm -q "$1" >/dev/null 2>&1; }
pacman_installed() { pacman -Qq "$1" >/dev/null 2>&1; }
zypper_installed() { rpm -q "$1" >/dev/null 2>&1; }

install_missing_with() {
  local manager="$1"; shift
  local -a packages=("$@") missing=()
  local pkg=""
  for pkg in "${packages[@]}"; do
    case "$manager" in
      apt) apt_installed "$pkg" || missing+=("$pkg") ;;
      dnf|yum) rpm_installed "$pkg" || missing+=("$pkg") ;;
      pacman) pacman_installed "$pkg" || missing+=("$pkg") ;;
      zypper) zypper_installed "$pkg" || missing+=("$pkg") ;;
    esac
  done
  [[ ${#missing[@]} -eq 0 ]] && return 0
  local sudo_cmd=""
  sudo_cmd="$(choose_sudo || true)"
  [[ "${EUID:-$(id -u)}" -eq 0 || -n "$sudo_cmd" ]] || { msg "Missing packages: ${missing[*]}"; msg "Install them manually or rerun with sudo available."; return 0; }
  msg "Installing missing system packages: ${missing[*]}"
  case "$manager" in
    apt)
      $sudo_cmd apt-get update
      if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd apt-get install -y "${missing[@]}"; else $sudo_cmd apt-get install "${missing[@]}"; fi ;;
    dnf)
      if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd dnf install -y "${missing[@]}"; else $sudo_cmd dnf install "${missing[@]}"; fi ;;
    yum)
      if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd yum install -y "${missing[@]}"; else $sudo_cmd yum install "${missing[@]}"; fi ;;
    pacman)
      if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd pacman -S --needed --noconfirm "${missing[@]}"; else $sudo_cmd pacman -S --needed "${missing[@]}"; fi ;;
    zypper)
      if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd zypper --non-interactive install "${missing[@]}"; else $sudo_cmd zypper install "${missing[@]}"; fi ;;
  esac
}

ensure_system_deps() {
  [[ $NO_SYSTEM_DEPS -eq 1 ]] && { msg "Skipping system dependency installation."; return 0; }
  msg "Checking system packages only; skipping protected browser certificate database refresh."
  if command -v apt-get >/dev/null 2>&1; then
    install_missing_with apt python3 python3-venv python3-pip libxcb-cursor0 libxkbcommon-x11-0 libnss3 libxcomposite1 libxdamage1 libxrandr2 libegl1 libgl1 libopengl0 libfontconfig1 libdbus-1-3 libpulse0 ca-certificates openssl p11-kit
  elif command -v dnf >/dev/null 2>&1; then
    install_missing_with dnf python3 python3-pip python3-virtualenv xcb-util-cursor libxkbcommon-x11 nss libXcomposite libXdamage libXrandr mesa-libEGL mesa-libGL libglvnd-opengl fontconfig dbus-libs pulseaudio-libs ca-certificates openssl p11-kit p11-kit-trust
  elif command -v yum >/dev/null 2>&1; then
    install_missing_with yum python3 python3-pip python3-virtualenv xcb-util-cursor libxkbcommon-x11 nss libXcomposite libXdamage libXrandr mesa-libEGL mesa-libGL fontconfig dbus-libs pulseaudio-libs ca-certificates openssl p11-kit p11-kit-trust
  elif command -v pacman >/dev/null 2>&1; then
    install_missing_with pacman python python-pip python-virtualenv xcb-util-cursor libxkbcommon-x11 nss libxcomposite libxdamage libxrandr mesa fontconfig dbus libpulse ca-certificates ca-certificates-utils openssl p11-kit qt6-wayland
  elif command -v zypper >/dev/null 2>&1; then
    install_missing_with zypper python3 python3-pip python3-virtualenv xcb-util-cursor libxkbcommon-x11-0 mozilla-nss libXcomposite1 libXdamage1 libXrandr2 Mesa-libEGL1 Mesa-libGL1 fontconfig dbus-1 libpulse0 ca-certificates openssl p11-kit
  else
    msg "No supported distro package manager found. Continuing with Python package install only."
  fi
}

refresh_system_ca_trust() {
  [[ $REFRESH_CA -eq 1 ]] || return 0
  local sudo_cmd=""
  sudo_cmd="$(choose_sudo || true)"
  if [[ "${EUID:-$(id -u)}" -ne 0 && -z "$sudo_cmd" ]]; then
    msg "Cannot refresh system CA trust without sudo/root. Continuing."
    return 0
  fi
  msg "Refreshing system CA trust only. NSS user certificate databases will not be touched."
  if [[ -x "$INSTALL_DIR/tools/refresh_ca_trust.sh" ]]; then
    "$INSTALL_DIR/tools/refresh_ca_trust.sh" --auto || true
  elif command -v update-ca-certificates >/dev/null 2>&1; then
    $sudo_cmd update-ca-certificates || true
  elif command -v update-ca-trust >/dev/null 2>&1; then
    $sudo_cmd update-ca-trust extract || true
  elif command -v trust >/dev/null 2>&1; then
    $sudo_cmd trust extract-compat || true
  else
    msg "No supported CA trust refresh command found. Continuing."
  fi
}

choose_python() {
  local candidate=""
  for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
      if "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        printf '%s' "$candidate"
        return 0
      fi
    fi
  done
  return 1
}

install_app_files() {
  local tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN
  extract_payload "$tmp"
  mkdir -p "$INSTALL_ROOT" "$STATE_DIR"
  if [[ -d "$INSTALL_DIR" ]]; then
    local backup="$INSTALL_ROOT/app.backup.$(date +%Y%m%d-%H%M%S)"
    msg "Existing app found. Backing up to $backup"
    mv "$INSTALL_DIR" "$backup"
  fi
  mkdir -p "$INSTALL_DIR"
  cp -a "$tmp"/. "$INSTALL_DIR"/
}

install_runtime() {
  local python_cmd="$1"
  if [[ ! -x "$RUNTIME_DIR/bin/python" ]]; then
    msg "Creating private Python runtime."
    "$python_cmd" -m venv "$RUNTIME_DIR" || die "Failed to create Python venv. Install python3-venv and rerun."
  fi
  msg "Installing/updating Python packages."
  "$RUNTIME_DIR/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
  "$RUNTIME_DIR/bin/python" -m pip install --upgrade pip wheel setuptools
  "$RUNTIME_DIR/bin/python" -m pip install -r "$INSTALL_DIR/requirements-lock.txt"
}

install_launcher() {
  mkdir -p "$INSTALL_ROOT"
  cat > "$LAUNCHER" <<EOF2
#!/usr/bin/env bash
set -euo pipefail
export ASTER_PORTABLE=1
export ASTER_PORTABLE_ROOT="$STATE_DIR"
mkdir -p "$STATE_DIR"
export NSS_DEFAULT_DB_TYPE="${NSS_DEFAULT_DB_TYPE:-sql}"
# Help Qt WebEngine/Python find the distro trust store without touching protected NSS databases.
if [[ -z "\${SSL_CERT_FILE:-}" ]]; then
  for ca_file in /etc/ssl/certs/ca-certificates.crt /etc/pki/tls/certs/ca-bundle.crt /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem /etc/ssl/ca-bundle.pem /var/lib/ca-certificates/ca-bundle.pem /etc/ssl/cert.pem; do
    if [[ -f "\$ca_file" ]]; then export SSL_CERT_FILE="\$ca_file" REQUESTS_CA_BUNDLE="\$ca_file" CURL_CA_BUNDLE="\$ca_file"; break; fi
  done
fi
if [[ -z "\${SSL_CERT_DIR:-}" ]]; then
  for ca_dir in /etc/ssl/certs /etc/pki/tls/certs /etc/pki/ca-trust/extracted/pem; do
    if [[ -d "\$ca_dir" ]]; then export SSL_CERT_DIR="\$ca_dir"; break; fi
  done
fi
export QTWEBENGINE_CHROMIUM_FLAGS="\${QTWEBENGINE_CHROMIUM_FLAGS:-} --ozone-platform-hint=auto"
cd "$INSTALL_DIR"
exec "$RUNTIME_DIR/bin/python" "$INSTALL_DIR/run_aster.py" "\$@"
EOF2
  chmod +x "$LAUNCHER"
}

reset_network_state() {
  [[ $RESET_NETWORK_STATE -eq 1 ]] || return 0
  msg "Clearing Aster WebEngine cache/security state under $STATE_DIR"
  if [[ -x "$INSTALL_DIR/tools/reset_aster_network_state.sh" ]]; then
    ASTER_INSTALL_ROOT="$INSTALL_ROOT" ASTER_PORTABLE_ROOT="$STATE_DIR" "$INSTALL_DIR/tools/reset_aster_network_state.sh" || true
  else
    for state_root in "$STATE_DIR" "$INSTALL_DIR/data" "$INSTALL_DIR/cache"; do
      [[ -d "$state_root" ]] || continue
      find "$state_root" -type d \( -name Cache -o -name 'Code Cache' -o -name GPUCache -o -name DawnCache -o -name ShaderCache -o -name GrShaderCache \) -prune -exec rm -rf {} + 2>/dev/null || true
      find "$state_root" -type f \( -name 'Network Persistent State' -o -name TransportSecurity -o -name CertificateRevocation -o -name 'Trust Tokens' -o -name 'Trust Tokens-journal' -o -name 'Reporting and NEL' -o -name 'Reporting and NEL-journal' \) -delete 2>/dev/null || true
    done
  fi
}

install_desktop_entry() {
  mkdir -p "$APPS_HOME" "$(dirname "$ICON_DEST")"
  local icon_source="$INSTALL_DIR/packaging/linux/aster.svg"
  if [[ -f "$icon_source" ]]; then
    cp "$icon_source" "$ICON_DEST"
  fi
  cat > "$DESKTOP_FILE" <<EOF2
[Desktop Entry]
Type=Application
Name=Aster Browser
GenericName=Web Browser
Comment=Low-memory browser shell with internal assistant and multilingual web preferences
Exec=$LAUNCHER %U
Icon=$APP_ID
Categories=Network;WebBrowser;
MimeType=text/html;text/xml;application/xhtml+xml;x-scheme-handler/http;x-scheme-handler/https;
Terminal=false
StartupNotify=true
EOF2
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_HOME" >/dev/null 2>&1 || true
}

uninstall() {
  msg "Removing $INSTALL_ROOT"
  rm -rf "$INSTALL_ROOT"
  rm -f "$DESKTOP_FILE" "$ICON_DEST"
  msg "Uninstalled Aster Browser portable files. User config in ~/.config/aster-browser is left untouched."
}

main() {
  parse_args "$@"
  if [[ -n "$EXTRACT_ONLY" ]]; then
    extract_payload "$EXTRACT_ONLY"
    msg "Extracted bundled app source to $EXTRACT_ONLY"
    exit 0
  fi
  ensure_system_deps
  local python_cmd=""
  python_cmd="$(choose_python || true)"
  [[ -n "$python_cmd" ]] || die "Python 3.10+ is required and was not found."
  install_app_files
  refresh_system_ca_trust
  install_runtime "$python_cmd"
  reset_network_state
  install_launcher
  install_desktop_entry
  msg "Installed $APP_NAME."
  msg "Launcher: $LAUNCHER"
  msg "Desktop entry: $DESKTOP_FILE"
  if [[ $RUN_AFTER_INSTALL -eq 1 ]]; then
    exec "$LAUNCHER"
  fi
}

main "$@"
exit 0
__ASTER_PAYLOAD_BELOW__
SCRIPT
base64 "$TAR" >> "$OUT"
chmod +x "$OUT"
printf 'Created %s\n' "$OUT"
