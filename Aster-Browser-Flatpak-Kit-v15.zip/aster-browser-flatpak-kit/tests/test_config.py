import os
import unittest
from unittest.mock import patch

from aster_browser.config import coerce_browser_config


class ConfigOverrideTests(unittest.TestCase):
    def test_env_overrides_memory_and_ai(self):
        with patch.dict(
            os.environ,
            {
                'ASTER_MAX_LIVE_TABS': '4',
                'ASTER_SOFT_MEMORY_BUDGET_MB': '900',
                'ASTER_ALLOW_AI_ACTIONS': '1',
                'ASTER_AI_PROVIDER': 'ollama',
                'ASTER_AI_MODEL': 'qwen3:1.7b',
                'ASTER_AI_BASE_URL': 'http://127.0.0.1:11434',
                'ASTER_DRM_MODE': 'external_only',
                'ASTER_FORCE_SOFTWARE_RENDERING': '1',
                'ASTER_EXTENSION_BACKEND': 'native_when_available',
            },
            clear=False,
        ):
            cfg = coerce_browser_config({})
        self.assertEqual(cfg.max_live_tabs, 4)
        self.assertEqual(cfg.soft_memory_budget_mb, 900)
        self.assertTrue(cfg.allow_ai_actions)
        self.assertEqual(cfg.ai.provider, 'ollama')
        self.assertEqual(cfg.ai.model, 'qwen3:1.7b')
        self.assertEqual(cfg.ai.base_url, 'http://127.0.0.1:11434')
        self.assertEqual(cfg.drm_mode, 'external_only')
        self.assertTrue(cfg.force_software_rendering)
        self.assertEqual(cfg.extension_backend, 'native_when_available')

    def test_defaults_prefer_qtwebengine_capsule_and_safe_extensions(self):
        cfg = coerce_browser_config({})
        self.assertEqual(cfg.drm_mode, 'qtwebengine_capsule')
        self.assertEqual(cfg.extension_backend, 'safe')
        self.assertEqual(cfg.theme, 'black_arc')


if __name__ == '__main__':
    unittest.main()
