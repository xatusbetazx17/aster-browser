from __future__ import annotations

import os
import shlex
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse


@dataclass(frozen=True)
class ServiceRule:
    label: str
    hosts: tuple[str, ...]
    path_tokens: tuple[str, ...] = ()
    requires_drm: bool = True
    prefer_external: bool = True


_STREAMING_RULES: tuple[ServiceRule, ...] = (
    ServiceRule("Prime Video", ("primevideo.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Prime Video", ("amazon.com",), path_tokens=("/gp/video", "/video"), requires_drm=True, prefer_external=True),
    ServiceRule("Netflix", ("netflix.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Disney+", ("disneyplus.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Max", ("max.com", "hbomax.com"), requires_drm=True, prefer_external=True),
    ServiceRule("Hulu", ("hulu.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Peacock", ("peacocktv.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Paramount+", ("paramountplus.com",), requires_drm=True, prefer_external=True),
    ServiceRule("YouTube TV", ("tv.youtube.com",), requires_drm=True, prefer_external=True),
    ServiceRule("Apple TV+", ("tv.apple.com",), requires_drm=False, prefer_external=False),
    ServiceRule("YouTube", ("youtube.com", "youtu.be"), requires_drm=False, prefer_external=False),
    ServiceRule("Crunchyroll", ("crunchyroll.com",), requires_drm=False, prefer_external=False),
)

_COMMON_WIDEVINE_PATHS = [
    "{env}",
    "/opt/google/chrome/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
    "/opt/google/chrome/libwidevinecdm.so",
    "/opt/google/chrome-beta/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
    "/opt/google/chrome-unstable/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
    "/usr/lib/chromium/libwidevinecdm.so",
    "/usr/lib/chromium-browser/libwidevinecdm.so",
    "/usr/lib64/chromium/libwidevinecdm.so",
    "~/.var/app/com.google.Chrome/config/google-chrome/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
]


@dataclass
class StreamingSupport:
    widevine_path: str | None
    external_browser_command: str
    drm_mode: str = "internal_preferred"

    def internal_drm_available(self) -> bool:
        return bool(self.widevine_path)

    def render(self) -> str:
        service_names = ", ".join(rule.label for rule in _STREAMING_RULES)
        lines = [f"DRM mode: {self.drm_mode}", f"Known streaming services: {service_names}"]
        lines.append("Native compatibility engine: Qt WebEngine/PyQt6-WebEngine embedded Chromium runtime")
        if self.widevine_path:
            lines.append(f"Widevine detected: {self.widevine_path}")
            lines.append("Aster can try protected playback inside the browser for supported services because Widevine was detected.")
        else:
            lines.append("Widevine not detected for Qt WebEngine.")
            lines.append("Protected DRM streaming may still require a licensed Widevine/proprietary-codec path, but users do not need system Chromium for ordinary modern sites.")
        lines.append(f"Capsule/browser override command: {self.external_browser_command or 'auto-detect'}")
        return "\n".join(lines)


def _rule_matches(rule: ServiceRule, url: str) -> bool:
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    path = parsed.path or "/"
    for candidate in rule.hosts:
        candidate = candidate.lower()
        if host == candidate or host.endswith(f".{candidate}"):
            if not rule.path_tokens:
                return True
            return any(token in path for token in rule.path_tokens)
    return False


def matching_service_rule(url: str) -> ServiceRule | None:
    for rule in _STREAMING_RULES:
        if _rule_matches(rule, url):
            return rule
    return None


def known_streaming_service(url: str) -> str | None:
    rule = matching_service_rule(url)
    return rule.label if rule else None


def known_drm_service(url: str) -> str | None:
    rule = matching_service_rule(url)
    if rule and rule.requires_drm:
        return rule.label
    return None


def is_streaming_service(url: str) -> bool:
    return matching_service_rule(url) is not None


def streaming_service_names() -> list[str]:
    return [rule.label for rule in _STREAMING_RULES]


def widevine_candidates() -> list[Path]:
    env_path = os.environ.get("ASTER_WIDEVINE_PATH", "").strip() or os.environ.get("WIDEVINE_PATH", "").strip()
    candidates: list[Path] = []
    for raw in _COMMON_WIDEVINE_PATHS:
        text = raw.format(env=env_path) if raw == "{env}" else raw
        if not text:
            continue
        path = Path(text).expanduser()
        if path not in candidates:
            candidates.append(path)
    return candidates


def find_widevine() -> str | None:
    for path in widevine_candidates():
        if path.is_file():
            return str(path)
    return None


def default_external_browser_command() -> str:
    env = os.environ.get("ASTER_DRM_BROWSER", "").strip()
    if env:
        return env
    for command in (
        "google-chrome-stable",
        "google-chrome",
        "microsoft-edge-stable",
        "brave-browser",
        "chromium",
        "chromium-browser",
        "firefox",
        "xdg-open",
    ):
        if shutil.which(command):
            return command
    return "xdg-open"


def detect_streaming_support(drm_mode: str = "internal_preferred", external_browser_command: str = "") -> StreamingSupport:
    browser_command = external_browser_command.strip() or default_external_browser_command()
    return StreamingSupport(find_widevine(), browser_command, drm_mode=drm_mode)


def should_redirect_externally(url: str, support: StreamingSupport) -> bool:
    rule = matching_service_rule(url)
    if rule is None or not rule.requires_drm:
        return False
    mode = (support.drm_mode or "internal_preferred").strip().lower()
    if mode == "qtwebengine_capsule":
        return False
    if mode == "external_only":
        return True
    if mode == "internal_only":
        return False
    if mode == "internal_preferred":
        return not support.internal_drm_available()
    if rule.prefer_external:
        return True
    return not support.internal_drm_available()


def compatibility_reason(url: str, support: StreamingSupport) -> str:
    rule = matching_service_rule(url)
    if rule is None:
        return "This site was opened in a managed streaming capsule."
    mode = (support.drm_mode or "internal_preferred").strip().lower()
    if mode == "qtwebengine_capsule":
        return f"{rule.label} was routed to Aster Native compatibility mode using the bundled Qt WebEngine runtime."
    if mode == "external_only":
        return f"{rule.label} was routed to a managed streaming capsule because Aster is set to external_only for protected streaming sites."
    if mode == "internal_preferred" and not support.internal_drm_available():
        return (
            f"{rule.label} was routed to a managed streaming capsule because Aster is set to prefer internal playback, "
            f"but no Widevine CDM was detected for Qt WebEngine."
        )
    if rule.prefer_external:
        return (
            f"{rule.label} was routed to a managed streaming capsule because services like this usually expect a mainstream supported browser "
            f"or DRM runtime and often fail inside embedded or custom browser engines."
        )
    if rule.requires_drm and not support.internal_drm_available():
        return (
            f"{rule.label} needs DRM playback support. Aster did not find a usable Widevine path for Qt WebEngine, so this site was routed "
            f"to a managed streaming capsule."
        )
    return f"{rule.label} was opened in a managed streaming capsule."


def build_qtwebengine_flags(
    existing: str = "",
    hardware_acceleration: bool = True,
    widevine_path: str | None = None,
    force_software: bool = False,
) -> str:
    parts = [part for part in shlex.split(existing or "") if part.strip()]
    wanted: list[str] = []
    if hardware_acceleration and not force_software:
        wanted.extend(["--enable-gpu-rasterization", "--enable-zero-copy", "--ignore-gpu-blocklist"])
    if force_software:
        wanted.extend(["--disable-gpu", "--disable-gpu-compositing"])
    if widevine_path:
        wanted.append(f"--widevine-path={widevine_path}")
    seen: set[str] = set()
    merged: list[str] = []
    for item in [*parts, *wanted]:
        if item not in seen:
            seen.add(item)
            merged.append(item)
    return " ".join(merged).strip()


def open_external(url: str, command_template: str = "") -> bool:
    command_template = command_template.strip() or default_external_browser_command()
    try:
        if "{url}" in command_template:
            command = shlex.split(command_template.format(url=url))
        else:
            command = [*shlex.split(command_template), url]
        subprocess.Popen(command)
        return True
    except Exception:
        return False


def redirect_reason(url: str, support: StreamingSupport) -> str:
    return compatibility_reason(url, support)
