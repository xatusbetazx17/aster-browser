from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from .paths import capsules_dir
from .streaming import matching_service_rule, streaming_service_names


@dataclass(frozen=True)
class CapsuleRuntime:
    label: str
    argv_prefix: tuple[str, ...]
    family: str
    source: str
    supports_app_mode: bool
    supports_profile_dir: bool
    flatpak_app_id: str = ""
    placeholder_url: bool = False


@dataclass(frozen=True)
class CapsuleLaunchResult:
    ok: bool
    service_label: str
    runtime_label: str
    command: tuple[str, ...]
    profile_dir: str | None
    note: str

    def command_text(self) -> str:
        return " ".join(shlex.quote(part) for part in self.command)


_CHROMIUM_NATIVE: tuple[tuple[str, str], ...] = (
    ("google-chrome-stable", "Google Chrome"),
    ("google-chrome", "Google Chrome"),
    ("microsoft-edge-stable", "Microsoft Edge"),
    ("brave-browser", "Brave"),
    ("chromium", "Chromium"),
    ("chromium-browser", "Chromium"),
)

_FIREFOX_NATIVE: tuple[tuple[str, str], ...] = (
    ("firefox", "Firefox"),
)

_FLATPAK_APPS: tuple[tuple[str, str, str, bool, bool], ...] = (
    ("com.google.Chrome", "Google Chrome", "chromium", True, True),
    ("org.chromium.Chromium", "Chromium", "chromium", True, True),
    ("com.brave.Browser", "Brave", "chromium", True, True),
    ("com.microsoft.Edge", "Microsoft Edge", "chromium", True, True),
    ("org.mozilla.firefox", "Firefox", "firefox", False, False),
)


class StreamingCapsuleManager:
    def __init__(self, command_override: str = "", forced_runtime: CapsuleRuntime | None = None) -> None:
        self.command_override = command_override.strip()
        self.forced_runtime = forced_runtime
        self._cached_runtime: CapsuleRuntime | None = None

    def detect_runtime(self) -> CapsuleRuntime:
        if self.forced_runtime is not None:
            return self.forced_runtime
        if self._cached_runtime is not None:
            return self._cached_runtime
        self._cached_runtime = self._detect_runtime_uncached()
        return self._cached_runtime

    def _detect_runtime_uncached(self) -> CapsuleRuntime:
        override = self.command_override.strip()
        if override:
            return self._runtime_from_override(override)

        for command, label in _CHROMIUM_NATIVE:
            path = shutil.which(command)
            if path:
                return CapsuleRuntime(
                    label=label,
                    argv_prefix=(path,),
                    family="chromium",
                    source="native",
                    supports_app_mode=True,
                    supports_profile_dir=True,
                )

        for command, label in _FIREFOX_NATIVE:
            path = shutil.which(command)
            if path:
                return CapsuleRuntime(
                    label=label,
                    argv_prefix=(path,),
                    family="firefox",
                    source="native",
                    supports_app_mode=False,
                    supports_profile_dir=True,
                )

        if shutil.which("flatpak"):
            for app_id, label, family, supports_app_mode, supports_profile_dir in _FLATPAK_APPS:
                try:
                    result = subprocess.run(
                        ["flatpak", "info", app_id],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=False,
                        timeout=6,
                    )
                except Exception:
                    continue
                if result.returncode == 0:
                    return CapsuleRuntime(
                        label=f"{label} (Flatpak)",
                        argv_prefix=("flatpak", "run", app_id),
                        family=family,
                        source="flatpak",
                        supports_app_mode=supports_app_mode,
                        supports_profile_dir=supports_profile_dir,
                        flatpak_app_id=app_id,
                    )

        xdg = shutil.which("xdg-open") or "xdg-open"
        return CapsuleRuntime(
            label="Desktop default opener",
            argv_prefix=(xdg,),
            family="generic",
            source="fallback",
            supports_app_mode=False,
            supports_profile_dir=False,
        )

    def _runtime_from_override(self, override: str) -> CapsuleRuntime:
        parts = shlex.split(override)
        if not parts:
            return CapsuleRuntime(
                label="Custom capsule command",
                argv_prefix=("xdg-open",),
                family="generic",
                source="override",
                supports_app_mode=False,
                supports_profile_dir=False,
            )
        name = os.path.basename(parts[0]).lower()
        family = "generic"
        supports_app_mode = False
        supports_profile_dir = False
        if any(token in name for token in ("chrome", "chromium", "edge", "brave")):
            family = "chromium"
            supports_app_mode = True
            supports_profile_dir = True
        elif "firefox" in name:
            family = "firefox"
            supports_profile_dir = True
        return CapsuleRuntime(
            label="Custom capsule command",
            argv_prefix=tuple(parts),
            family=family,
            source="override",
            supports_app_mode=supports_app_mode,
            supports_profile_dir=supports_profile_dir,
            placeholder_url="{url}" in override,
        )

    @staticmethod
    def _slugify(text: str) -> str:
        cleaned = re.sub(r"[^a-z0-9]+", "-", text.strip().lower())
        return cleaned.strip("-") or "service"

    def _profile_base_dir(self, runtime: CapsuleRuntime) -> Path:
        if runtime.source == "flatpak" and runtime.flatpak_app_id:
            return Path.home() / ".var" / "app" / runtime.flatpak_app_id / "data" / "aster-browser-capsules"
        return capsules_dir()

    def capsule_profile_dir(self, service_label: str) -> Path:
        runtime = self.detect_runtime()
        profile_dir = self._profile_base_dir(runtime) / self._slugify(service_label)
        profile_dir.mkdir(parents=True, exist_ok=True)
        manifest = profile_dir / "capsule.json"
        payload = {
            "service": service_label,
            "runtime": runtime.label,
            "runtime_source": runtime.source,
            "updated_at": int(time.time()),
        }
        try:
            existing: dict[str, object] = {}
            if manifest.exists():
                loaded = json.loads(manifest.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    existing = loaded
            existing.update(payload)
            if "created_at" not in existing:
                existing["created_at"] = int(time.time())
            manifest.write_text(json.dumps(existing, indent=2, sort_keys=True), encoding="utf-8")
        except Exception:
            pass
        return profile_dir

    def reset_capsule_profile(self, service_label: str) -> bool:
        target = self.capsule_profile_dir(service_label)
        if not target.exists():
            return False
        try:
            shutil.rmtree(target)
        except Exception:
            return False
        return True

    def build_launch_command(self, url: str) -> tuple[list[str], str | None, str]:
        runtime = self.detect_runtime()
        rule = matching_service_rule(url)
        service_label = rule.label if rule else ((urlparse(url).hostname or "site").lower())
        profile_dir: str | None = None

        if runtime.source == "override" and runtime.placeholder_url:
            command = [part.replace("{url}", url) for part in runtime.argv_prefix]
            return command, None, service_label

        if runtime.family == "chromium":
            command = list(runtime.argv_prefix)
            if runtime.supports_profile_dir:
                profile_dir = str(self.capsule_profile_dir(service_label))
                command.append(f"--user-data-dir={profile_dir}")
            command.append("--autoplay-policy=no-user-gesture-required")
            if runtime.supports_app_mode and rule and rule.requires_drm:
                command.append(f"--app={url}")
            else:
                command.extend(["--new-window", url])
            return command, profile_dir, service_label

        if runtime.family == "firefox":
            command = list(runtime.argv_prefix)
            if runtime.supports_profile_dir:
                profile_dir = str(self.capsule_profile_dir(service_label))
                command.extend(["--new-instance", "--profile", profile_dir])
            command.extend(["--new-window", url])
            return command, profile_dir, service_label

        command = list(runtime.argv_prefix)
        command.append(url)
        return command, profile_dir, service_label

    def launch(self, url: str) -> CapsuleLaunchResult:
        command, profile_dir, service_label = self.build_launch_command(url)
        runtime = self.detect_runtime()
        try:
            subprocess.Popen(command)
        except Exception as exc:
            return CapsuleLaunchResult(
                ok=False,
                service_label=service_label,
                runtime_label=runtime.label,
                command=tuple(command),
                profile_dir=profile_dir,
                note=f"Capsule launch failed: {exc}",
            )
        return CapsuleLaunchResult(
            ok=True,
            service_label=service_label,
            runtime_label=runtime.label,
            command=tuple(command),
            profile_dir=profile_dir,
            note=(
                f"Opened {service_label} in a managed streaming capsule using {runtime.label}. "
                f"This keeps premium streaming playback separated from Aster Native while preserving the main browser UI."
            ),
        )

    def service_names(self) -> list[str]:
        return streaming_service_names()

    def render(self) -> str:
        runtime = self.detect_runtime()
        services = ", ".join(self.service_names())
        lines = [
            "Streaming capsules: enabled",
            f"Capsule runtime: {runtime.label}",
            f"Runtime family: {runtime.family}",
            f"Runtime source: {runtime.source}",
            f"Capsule profiles root: {self._profile_base_dir(runtime)}",
            f"Known streaming services: {services}",
            "Premium DRM services are routed to managed capsules by default. Standard HTML5/MSE video sites stay inside Aster Native.",
        ]
        return "\n".join(lines)
