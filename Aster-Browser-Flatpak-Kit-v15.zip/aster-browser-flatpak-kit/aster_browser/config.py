from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .localization import normalize_language_code
from .paths import config_path, ensure_directories


@dataclass
class AIConfig:
    provider: str = "internal"
    model: str = "aster-internal"
    base_url: str = ""
    api_key_env: str = ""
    persona: str = "dr_light_lab"
    reasoning_mode: str = "balanced"
    system_prompt: str = (
        "You are Aster Assistant in Dr. Light Lab mode: a calm engineering mentor inspired by "
        "helpful robot-lab assistants, not a fictional character clone. Be practical, safety-aware, "
        "and precise. Use Problem → Diagnosis → Fix → Verify when debugging. When the user asks "
        "about the current page, use the provided page excerpt instead of inventing details."
    )


@dataclass
class BrowserConfig:
    homepage: str = "aster:newtab"
    search_engine: str = "https://duckduckgo.com/?q={query}"
    language_code: str = "system"
    adblock_enabled: bool = True
    strict_adblock: bool = False
    adblock_mode: str = "balanced"
    adblock_custom_rules: str = ""
    adblock_allow_hosts: list[str] = field(default_factory=list)
    adblock_block_hosts: list[str] = field(default_factory=list)
    adblock_streaming_allowlist: bool = True
    security_mode: str = "balanced"
    max_live_tabs: int = 6
    soft_memory_budget_mb: int = 1200
    auto_park: bool = True
    parked_tabs_persist: bool = True
    parked_camel_animation: bool = True
    default_container: str = "default"
    hardware_acceleration: bool = True
    force_software_rendering: bool = False
    containers: list[str] = field(default_factory=lambda: ["default", "work", "media", "banking"])
    drm_mode: str = "qtwebengine_capsule"
    external_browser_cmd: str = ""
    allow_ai_actions: bool = False
    ai_page_context_chars: int = 10000
    theme: str = "black_arc"
    qt_style: str = "fusion"
    background_transparency_percent: int = 10
    default_zoom_percent: int = 100
    accent_color: str = "#3b82f6"
    ui_density: str = "comfortable"
    tab_position: str = "top"
    toolbar_text: bool = False
    window_corner_radius: int = 18
    show_status_bar: bool = True
    show_home_button: bool = True
    show_new_tab_button: bool = True
    show_container_selector: bool = True
    show_progress_bar: bool = True
    custom_page_css_enabled: bool = False
    custom_page_css: str = ""
    active_tab_left_click_menu: bool = True
    extension_backend: str = "safe"
    trust_system_ca: bool = True
    https_auto_update_ca: bool = True
    certificate_exception_hosts: list[str] = field(default_factory=list)
    tts_engine: str = "system"
    tts_system_voice_name: str = ""
    tts_piper_voice_name: str = ""
    tts_rate_percent: int = 0
    tts_volume_percent: int = 100
    tts_pitch_percent: int = 100
    tts_custom_command: str = ""
    tts_reference_audio_path: str = ""
    ai: AIConfig = field(default_factory=AIConfig)


_ALLOWED_DRM_MODES = {"auto", "internal_preferred", "internal_only", "external_only", "qtwebengine_capsule"}
_ALLOWED_AI_PROVIDERS = {"disabled", "internal", "ollama", "openai", "openai_compatible"}
_ALLOWED_THEMES = {"black_arc", "aster_dark", "system"}
_ALLOWED_EXTENSION_BACKENDS = {"safe", "native_when_available"}
_ALLOWED_TTS_ENGINES = {"off", "system", "piper", "custom_command"}
_ALLOWED_UI_DENSITIES = {"compact", "comfortable", "spacious"}
_ALLOWED_TAB_POSITIONS = {"top", "bottom", "left", "right"}
_ALLOWED_ADBLOCK_MODES = {"off", "balanced", "strict", "custom"}
_ALLOWED_AI_PERSONAS = {"dr_light_lab", "browser_helper", "concise", "network_engineer", "cyber_guardian"}
_ALLOWED_AI_REASONING_MODES = {"fast", "balanced", "deep"}
_TRUTHY = {"1", "true", "yes", "on"}
_FALSEY = {"0", "false", "no", "off"}
_HEX_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def normalize_hex_color(value: str | None, default: str = "#3b82f6") -> str:
    clean = str(value or "").strip()
    if clean.startswith("0x") and len(clean) == 8:
        clean = "#" + clean[2:]
    if clean and not clean.startswith("#"):
        clean = "#" + clean
    if _HEX_COLOR_RE.match(clean):
        return "#" + clean[1:].lower()
    return default


def _split_hosts(value: Any) -> list[str]:
    if isinstance(value, list):
        raw_items = value
    else:
        raw_items = str(value or "").replace("\n", ",").split(",")
    hosts: list[str] = []
    for item in raw_items:
        host = str(item or "").strip().lower().strip(".")
        if not host:
            continue
        host = host.replace("https://", "").replace("http://", "").split("/", 1)[0]
        if host and host not in hosts:
            hosts.append(host)
    return hosts


def _merge_ai(data: dict[str, Any]) -> AIConfig:
    base = asdict(AIConfig())
    if isinstance(data, dict):
        data = dict(data)
        # Compatibility with older experimental settings.
        if "personality" in data and "persona" not in data:
            personality = str(data.get("personality") or "").strip().lower()
            data["persona"] = "cyber_guardian" if personality == "security" else "dr_light_lab"
        base.update({k: v for k, v in data.items() if k in base})
    provider = str(base.get("provider", "internal") or "internal").strip().lower()
    if provider not in _ALLOWED_AI_PROVIDERS:
        provider = "internal"
    base["provider"] = provider
    base["persona"] = str(base.get("persona", "dr_light_lab") or "dr_light_lab").strip().lower()
    if base["persona"] not in _ALLOWED_AI_PERSONAS:
        base["persona"] = "dr_light_lab"
    base["reasoning_mode"] = str(base.get("reasoning_mode", "balanced") or "balanced").strip().lower()
    if base["reasoning_mode"] not in _ALLOWED_AI_REASONING_MODES:
        base["reasoning_mode"] = "balanced"
    base["system_prompt"] = str(base.get("system_prompt", AIConfig().system_prompt) or AIConfig().system_prompt)
    return AIConfig(**base)


def _env_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except Exception:
        return default
    return max(minimum, min(maximum, value))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if raw in _TRUTHY:
        return True
    if raw in _FALSEY:
        return False
    return default


def _apply_env_overrides(base: dict[str, Any]) -> dict[str, Any]:
    base["max_live_tabs"] = _env_int("ASTER_MAX_LIVE_TABS", int(base.get("max_live_tabs", 6) or 6), minimum=1, maximum=100)
    base["soft_memory_budget_mb"] = _env_int(
        "ASTER_SOFT_MEMORY_BUDGET_MB",
        int(base.get("soft_memory_budget_mb", 1200) or 1200),
        minimum=256,
        maximum=32768,
    )
    base["allow_ai_actions"] = _env_bool("ASTER_ALLOW_AI_ACTIONS", bool(base.get("allow_ai_actions", False)))
    base["force_software_rendering"] = _env_bool("ASTER_FORCE_SOFTWARE_RENDERING", bool(base.get("force_software_rendering", False)))
    base["active_tab_left_click_menu"] = _env_bool("ASTER_ACTIVE_TAB_LEFT_CLICK_MENU", bool(base.get("active_tab_left_click_menu", True)))
    base["toolbar_text"] = _env_bool("ASTER_TOOLBAR_TEXT", bool(base.get("toolbar_text", False)))
    base["show_status_bar"] = _env_bool("ASTER_SHOW_STATUS_BAR", bool(base.get("show_status_bar", True)))
    base["show_home_button"] = _env_bool("ASTER_SHOW_HOME_BUTTON", bool(base.get("show_home_button", True)))
    base["show_new_tab_button"] = _env_bool("ASTER_SHOW_NEW_TAB_BUTTON", bool(base.get("show_new_tab_button", True)))
    base["show_container_selector"] = _env_bool("ASTER_SHOW_CONTAINER_SELECTOR", bool(base.get("show_container_selector", True)))
    base["show_progress_bar"] = _env_bool("ASTER_SHOW_PROGRESS_BAR", bool(base.get("show_progress_bar", True)))
    base["trust_system_ca"] = _env_bool("ASTER_TRUST_SYSTEM_CA", bool(base.get("trust_system_ca", True)))
    base["https_auto_update_ca"] = _env_bool("ASTER_HTTPS_AUTO_UPDATE_CA", bool(base.get("https_auto_update_ca", True)))
    base["parked_tabs_persist"] = _env_bool("ASTER_PARKED_TABS_PERSIST", bool(base.get("parked_tabs_persist", True)))
    base["parked_camel_animation"] = _env_bool("ASTER_PARKED_CAMEL_ANIMATION", bool(base.get("parked_camel_animation", True)))
    base["adblock_streaming_allowlist"] = _env_bool("ASTER_ADBLOCK_STREAMING_ALLOWLIST", bool(base.get("adblock_streaming_allowlist", True)))
    adblock_mode = os.environ.get("ASTER_ADBLOCK_MODE", "").strip().lower()
    if adblock_mode in _ALLOWED_ADBLOCK_MODES:
        base["adblock_mode"] = adblock_mode

    drm_mode = os.environ.get("ASTER_DRM_MODE", "").strip().lower()
    if drm_mode in _ALLOWED_DRM_MODES:
        base["drm_mode"] = drm_mode
    external_browser_cmd = os.environ.get("ASTER_EXTERNAL_BROWSER", "").strip()
    if external_browser_cmd:
        base["external_browser_cmd"] = external_browser_cmd
    language_code = os.environ.get("ASTER_LANGUAGE", "").strip()
    if language_code:
        base["language_code"] = normalize_language_code(language_code)
    theme = os.environ.get("ASTER_THEME", "").strip().lower()
    if theme in _ALLOWED_THEMES:
        base["theme"] = theme
    qt_style = os.environ.get("ASTER_QT_STYLE", "").strip().lower()
    if qt_style:
        base["qt_style"] = qt_style
    accent_color = os.environ.get("ASTER_ACCENT_COLOR", "").strip()
    if accent_color:
        base["accent_color"] = normalize_hex_color(accent_color, str(base.get("accent_color", "#3b82f6")))
    density = os.environ.get("ASTER_UI_DENSITY", "").strip().lower() or os.environ.get("ASTER_TOOLBAR_DENSITY", "").strip().lower()
    if density in _ALLOWED_UI_DENSITIES:
        base["ui_density"] = density
    tab_position = os.environ.get("ASTER_TAB_POSITION", "").strip().lower()
    if tab_position in _ALLOWED_TAB_POSITIONS:
        base["tab_position"] = tab_position
    cert_hosts = os.environ.get("ASTER_CERTIFICATE_EXCEPTION_HOSTS", "").strip()
    if cert_hosts:
        base["certificate_exception_hosts"] = _split_hosts(cert_hosts)
    allow_hosts = os.environ.get("ASTER_ADBLOCK_ALLOW_HOSTS", "").strip()
    if allow_hosts:
        base["adblock_allow_hosts"] = _split_hosts(allow_hosts)
    block_hosts = os.environ.get("ASTER_ADBLOCK_BLOCK_HOSTS", "").strip()
    if block_hosts:
        base["adblock_block_hosts"] = _split_hosts(block_hosts)

    base["background_transparency_percent"] = _env_int(
        "ASTER_BACKGROUND_TRANSPARENCY_PERCENT",
        int(base.get("background_transparency_percent", 10) or 10),
        minimum=0,
        maximum=60,
    )
    base["default_zoom_percent"] = _env_int(
        "ASTER_DEFAULT_ZOOM_PERCENT",
        int(base.get("default_zoom_percent", 100) or 100),
        minimum=50,
        maximum=300,
    )
    base["window_corner_radius"] = _env_int(
        "ASTER_WINDOW_CORNER_RADIUS",
        int(base.get("window_corner_radius", 18) or 18),
        minimum=0,
        maximum=40,
    )
    extension_backend = os.environ.get("ASTER_EXTENSION_BACKEND", "").strip().lower()
    if extension_backend in _ALLOWED_EXTENSION_BACKENDS:
        base["extension_backend"] = extension_backend

    ai_data = base.get("ai")
    if not isinstance(ai_data, AIConfig):
        ai_data = _merge_ai(ai_data if isinstance(ai_data, dict) else {})
    provider = os.environ.get("ASTER_AI_PROVIDER", "").strip().lower()
    if provider in _ALLOWED_AI_PROVIDERS:
        ai_data.provider = provider
    model = os.environ.get("ASTER_AI_MODEL", "").strip()
    if model:
        ai_data.model = model
    base_url = os.environ.get("ASTER_AI_BASE_URL", "").strip()
    if base_url or provider == "internal":
        ai_data.base_url = base_url
    api_key_env = os.environ.get("ASTER_AI_KEY_ENV", "").strip()
    if api_key_env or provider == "internal":
        ai_data.api_key_env = api_key_env
    persona = os.environ.get("ASTER_AI_PERSONA", "").strip().lower()
    if persona in _ALLOWED_AI_PERSONAS:
        ai_data.persona = persona
    reasoning_mode = os.environ.get("ASTER_AI_REASONING_MODE", "").strip().lower()
    if reasoning_mode in _ALLOWED_AI_REASONING_MODES:
        ai_data.reasoning_mode = reasoning_mode
    base["ai"] = ai_data
    return base


def coerce_browser_config(data: dict[str, Any]) -> BrowserConfig:
    base = asdict(BrowserConfig())
    if isinstance(data, dict):
        data = dict(data)
        # Compatibility with earlier v9 keys.
        if "toolbar_density" in data and "ui_density" not in data:
            data["ui_density"] = data.get("toolbar_density")
        if "certificate_error_policy" in data and "certificate_exception_hosts" not in data:
            data["certificate_exception_hosts"] = []
        base.update({k: v for k, v in data.items() if k in base and k != "ai"})
        base["ai"] = _merge_ai(data.get("ai", {}))
    else:
        base["ai"] = AIConfig()

    if not isinstance(base.get("containers"), list) or not base["containers"]:
        base["containers"] = ["default", "work", "media", "banking"]
    base["containers"] = [str(item).strip() for item in base["containers"] if str(item).strip()] or ["default"]
    if base.get("default_container") not in base["containers"]:
        base["default_container"] = base["containers"][0]

    drm_mode = str(base.get("drm_mode", "qtwebengine_capsule") or "qtwebengine_capsule").strip().lower()
    if drm_mode not in _ALLOWED_DRM_MODES:
        drm_mode = "qtwebengine_capsule"
    base["drm_mode"] = drm_mode

    try:
        base["ai_page_context_chars"] = int(base.get("ai_page_context_chars", 10000) or 10000)
    except Exception:
        base["ai_page_context_chars"] = 10000
    base["ai_page_context_chars"] = max(1000, min(40000, base["ai_page_context_chars"]))

    base["theme"] = str(base.get("theme", "black_arc") or "black_arc").strip().lower()
    if base["theme"] not in _ALLOWED_THEMES:
        base["theme"] = "black_arc"
    base["qt_style"] = str(base.get("qt_style", "fusion") or "fusion").strip().lower() or "fusion"
    base["accent_color"] = normalize_hex_color(str(base.get("accent_color", "#3b82f6") or "#3b82f6"))
    base["ui_density"] = str(base.get("ui_density", "comfortable") or "comfortable").strip().lower()
    if base["ui_density"] not in _ALLOWED_UI_DENSITIES:
        base["ui_density"] = "comfortable"
    base["tab_position"] = str(base.get("tab_position", "top") or "top").strip().lower()
    if base["tab_position"] not in _ALLOWED_TAB_POSITIONS:
        base["tab_position"] = "top"
    base["toolbar_text"] = bool(base.get("toolbar_text", False))
    try:
        base["window_corner_radius"] = int(base.get("window_corner_radius", 18) or 18)
    except Exception:
        base["window_corner_radius"] = 18
    base["window_corner_radius"] = max(0, min(40, base["window_corner_radius"]))
    base["show_status_bar"] = bool(base.get("show_status_bar", True))
    base["show_home_button"] = bool(base.get("show_home_button", True))
    base["show_new_tab_button"] = bool(base.get("show_new_tab_button", True))
    base["show_container_selector"] = bool(base.get("show_container_selector", True))
    base["show_progress_bar"] = bool(base.get("show_progress_bar", True))
    base["custom_page_css_enabled"] = bool(base.get("custom_page_css_enabled", False))
    base["custom_page_css"] = str(base.get("custom_page_css", "") or "")[:20000]
    base["adblock_mode"] = str(base.get("adblock_mode", "balanced") or "balanced").strip().lower()
    if base["adblock_mode"] not in _ALLOWED_ADBLOCK_MODES:
        base["adblock_mode"] = "balanced"
    base["adblock_custom_rules"] = str(base.get("adblock_custom_rules", "") or "")[:50000]
    base["adblock_allow_hosts"] = _split_hosts(base.get("adblock_allow_hosts", []))
    base["adblock_block_hosts"] = _split_hosts(base.get("adblock_block_hosts", []))
    base["adblock_streaming_allowlist"] = bool(base.get("adblock_streaming_allowlist", True))
    base["parked_tabs_persist"] = bool(base.get("parked_tabs_persist", True))
    base["parked_camel_animation"] = bool(base.get("parked_camel_animation", True))
    base["trust_system_ca"] = bool(base.get("trust_system_ca", True))
    base["https_auto_update_ca"] = bool(base.get("https_auto_update_ca", True))
    base["certificate_exception_hosts"] = _split_hosts(base.get("certificate_exception_hosts", []))

    try:
        base["background_transparency_percent"] = int(base.get("background_transparency_percent", 10) or 10)
    except Exception:
        base["background_transparency_percent"] = 10
    base["background_transparency_percent"] = max(0, min(60, base["background_transparency_percent"]))
    try:
        base["default_zoom_percent"] = int(base.get("default_zoom_percent", 100) or 100)
    except Exception:
        base["default_zoom_percent"] = 100
    base["default_zoom_percent"] = max(50, min(300, base["default_zoom_percent"]))
    base["language_code"] = normalize_language_code(str(base.get("language_code", "system") or "system"))
    base["extension_backend"] = str(base.get("extension_backend", "safe") or "safe").strip().lower()
    if base["extension_backend"] not in _ALLOWED_EXTENSION_BACKENDS:
        base["extension_backend"] = "safe"
    base["tts_engine"] = str(base.get("tts_engine", "system") or "system").strip().lower()
    if base["tts_engine"] not in _ALLOWED_TTS_ENGINES:
        base["tts_engine"] = "system"
    base["tts_system_voice_name"] = str(base.get("tts_system_voice_name", "") or "").strip()
    base["tts_piper_voice_name"] = str(base.get("tts_piper_voice_name", "") or "").strip()
    try:
        base["tts_rate_percent"] = int(base.get("tts_rate_percent", 0) or 0)
    except Exception:
        base["tts_rate_percent"] = 0
    base["tts_rate_percent"] = max(-100, min(100, base["tts_rate_percent"]))
    try:
        base["tts_volume_percent"] = int(base.get("tts_volume_percent", 100) or 100)
    except Exception:
        base["tts_volume_percent"] = 100
    base["tts_volume_percent"] = max(0, min(200, base["tts_volume_percent"]))
    try:
        base["tts_pitch_percent"] = int(base.get("tts_pitch_percent", 100) or 100)
    except Exception:
        base["tts_pitch_percent"] = 100
    base["tts_pitch_percent"] = max(50, min(200, base["tts_pitch_percent"]))
    base["tts_custom_command"] = str(base.get("tts_custom_command", "") or "").strip()
    base["tts_reference_audio_path"] = str(base.get("tts_reference_audio_path", "") or "").strip()
    base["force_software_rendering"] = bool(base.get("force_software_rendering", False))
    base = _apply_env_overrides(base)
    return BrowserConfig(**base)


def load_config(path: Path | None = None) -> BrowserConfig:
    ensure_directories()
    path = path or config_path()
    if not path.exists():
        cfg = coerce_browser_config({})
        save_config(cfg, path)
        return cfg
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        cfg = coerce_browser_config({})
        save_config(cfg, path)
        return cfg
    return coerce_browser_config(data)


def save_config(config: BrowserConfig, path: Path | None = None) -> None:
    ensure_directories()
    path = path or config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(config)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
