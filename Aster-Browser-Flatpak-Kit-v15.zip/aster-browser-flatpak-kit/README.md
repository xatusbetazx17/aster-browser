
## v15 highlights

- Uses bundled PyQt6-WebEngine / Qt WebEngine compatibility tabs by default, so users do not need system Chromium installed for normal modern websites.
- Adds persistent parked tabs that stay parked across restarts until the user explicitly unparks them.
- Adds a lightweight camel parked-tab animation that stops when hidden.
- Adds personalized adblock modes, allow hosts, block hosts, custom rules, and streaming/CDN protection.
- Adds safe Linux CA trust refresh helper without touching NSS user certificate databases.
- Adds Android Lite source kit under `packaging/android/aster-android-lite`.

# Aster Browser Merged Build

Aster Browser is a Linux-first experimental browser that combines a Qt WebEngine full-web mode, Aster Lite low-memory reading mode, tab parking, ad/tracker blocking, container profiles, extension management, streaming compatibility helpers, text-to-speech tools, and an internal assistant.

This merged build combines the full source package with the update/install scripts from the companion package and adds cross-platform packaging files for Linux, Flatpak, and Windows.

## What is included

- **Merged app source** in `aster_browser/`
- **Linux self-extracting installer builder** in `packaging/linux/build-self-extracting.sh`
- **Flatpak manifest and builder** in `packaging/flatpak/`
- **Windows PowerShell install/build kit** in `packaging/windows/`
- **Legacy update scripts from the older package** in `tools/legacy-update-scripts/`
- **Language support update** through Settings and the `ASTER_LANGUAGE` environment variable

## New language support

Open **Settings → General → Language** and choose a language. The list includes common languages, and the field is editable so a user can type any valid BCP-47 language tag, for example:

```text
es-MX
pt-BR
ar-SA
hi-IN
zh-Hant
ja-JP
```

Aster applies the selected language to browser profiles with Qt WebEngine's web language preference, so websites can return the preferred language. Aster also includes starter translations for common UI labels in English, Spanish, Turkish, Portuguese, French, German, Arabic, Chinese, Japanese, and Korean.

Environment override:

```bash
export ASTER_LANGUAGE="es-MX"
```

## Linux install

Use the generated self-extracting installer:

```bash
chmod +x Aster-Browser-Merged-Linux-v15.sh
./Aster-Browser-Merged-Linux-v15.sh -y --reset-network-state
```

The installer auto-detects common Linux package managers, installs missing system packages when possible, creates a private Python virtual environment, installs Python packages, and creates a desktop launcher.

Useful options:

```bash
./Aster-Browser-Merged-Linux-v15.sh --run
./Aster-Browser-Merged-Linux-v15.sh --no-system-deps
./Aster-Browser-Merged-Linux-v15.sh --refresh-ca
./Aster-Browser-Merged-Linux-v15.sh --no-refresh-ca
./Aster-Browser-Merged-Linux-v15.sh --install-root "$HOME/Apps/AsterBrowser"
./Aster-Browser-Merged-Linux-v15.sh --uninstall
```

To rebuild the `.sh` installer from source:

```bash
./packaging/linux/build-self-extracting.sh build/Aster-Browser-Merged-Linux-v15.sh
```

## Flatpak build

```bash
./packaging/flatpak/build-flatpak.sh
```

The local Flatpak bundle will be created at:

```text
build/Aster-Browser.flatpak
```

## Windows install and build

Install from source into `%LOCALAPPDATA%\AsterBrowser`:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1 -UseWinget
```

Build a Windows executable with PyInstaller:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\build_windows_exe.ps1
```

Then use `packaging/windows/AsterBrowser.nsi` with NSIS to create `Aster-Browser-Setup.exe`.

## Run from source

```bash
python -m pip install -r requirements.txt
python run_aster.py
```

## Important limitations

Aster is still an alpha-style project. Modern web rendering depends on Qt WebEngine, protected streaming depends on Widevine/codecs/drivers/service checks, and native Manifest V3 extension behavior depends on Qt/PyQt6 WebEngine behavior. The Windows package is a source/install/build kit; build the `.exe` installer on Windows.

## Useful shortcuts

- `Ctrl+L` focus address bar
- `Ctrl+T` new tab
- `Ctrl+W` close tab
- `Ctrl+Shift+L` Lite mode
- `Ctrl+Shift+P` park background tabs
- `Ctrl+Shift+K` park current tab
- `Ctrl+Shift+E` Extensions
- `Ctrl+Shift+A` add extension from current page
- `Ctrl+,` Settings

## License

This project is MIT licensed. Dependencies and optional runtime components have their own licenses and distribution rules.


## Aster Browser v15 HTTPS note

For Linux HTTPS label fixes after a valid OpenSSL check, run `./Aster-Browser-Merged-Linux-v15.sh -y --refresh-ca --reset-network-state --run`. The CA refresh updates the OS trust store only and does not touch locked NSS user certificate databases.
