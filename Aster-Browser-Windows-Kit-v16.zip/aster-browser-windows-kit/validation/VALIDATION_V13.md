# Validation v13

Commands run in the packaging environment:

```bash
python3 -m compileall -q aster_browser tests
python3 -m unittest discover -s tests
bash -n packaging/linux/build-self-extracting.sh
bash -n tools/diagnose_https.sh
bash -n tools/reset_aster_network_state.sh
```

Result: Python compilation passed, 54 unit tests passed, and shell syntax checks passed.

The Flatpak and Windows kits are build kits. They were packaged and ZIP-tested here; the actual Flatpak/Windows installer builds require a Linux system with flatpak-builder or a Windows/NSIS environment.
