# Validation for Aster Browser WebExtensions build

This build was validated in the container with these checks:

- Python source compilation succeeded across the project.
- The non-GUI unit test suite passed.
- The one-file installer extracted correctly with `--extract-only`.
- Added tests specifically for WebExtension import/compatibility classification and command routing.

What was **not** validated in this container:

- Live GUI interaction, because PyQt6 / Qt WebEngine are not installed in this environment.
- Real Qt native Manifest V3 loading through `QWebEngineExtensionManager`, because that needs a live Qt 6.10+ runtime.
- Live browser playback on DRM services.

Files:

- `validation/compile_check_webextensions.txt`
- `validation/test_output_webextensions.txt`
- `validation/installer_smoke_test_webextensions.txt`
