# v12 validation

Validated in the sandbox:

- Python syntax compile for the `aster_browser` package.
- Unit tests: 54 tests passed.
- Linux self-extracting installer shell syntax.
- Linux self-extracting installer payload extraction with `--extract-only`.
- Flatpak build script shell syntax.
- ZIP integrity for source, Flatpak kit, and Windows kit.

Manual target-system testing still recommended:

- Open `https://hipertextual.com` in Aster and then run Tools → Diagnose current page security.
- Verify certificate details on the user's Linux desktop because Qt WebEngine trust-store behavior can depend on distro packages, NSS, p11-kit, and Flatpak sandboxing.
- Build actual Flatpak/Windows bundles on systems with flatpak-builder/Windows/NSIS installed.
