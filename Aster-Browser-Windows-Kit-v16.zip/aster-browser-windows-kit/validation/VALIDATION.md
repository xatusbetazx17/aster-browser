# Validation

Validated in this container:

- Python source compiles cleanly with `python -m compileall`
- Headless unit tests pass for:
  - adblock logic
  - memory governor
  - AI command routing and intent routing
  - streaming service detection and redirect logic
  - streaming capsule runtime command building
  - config coercion
  - Lite mode parsing logic
- `tools/auto_setup_local_ai_and_capsules.sh` passes `bash -n`

Not validated in this container:

- live PyQt6 GUI launch, because PyQt6 / Qt WebEngine are not installed here
- real DRM playback against Prime Video, Netflix, or other services
- live Ollama installation and model pull, because that requires internet access on the target machine
- Flatpak runtime launching, because Flatpak is not installed in this container

The streaming-capsule layer is implemented as a practical, testable Linux approach:
Aster keeps ordinary browsing and non-DRM video in its main browser shell, while premium protected-streaming sites are routed into isolated managed capsules with service-specific profiles.
