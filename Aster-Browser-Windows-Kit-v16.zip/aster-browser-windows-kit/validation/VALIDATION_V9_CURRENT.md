# v9 current validation

Completed in sandbox on 2026-05-02:

- `python3 -m unittest discover -s tests -v`: 54 tests passed.
- `bash -n /mnt/data/Aster-Browser-Merged-Linux-v9.sh`: installer shell syntax OK.
- `Aster-Browser-Merged-Linux-v9.sh --extract-only`: payload extraction OK.
- `python3 -m py_compile` on extracted `aster_browser/*.py`: syntax OK.
- `zip -T` on source, Flatpak kit, and Windows kit: archive integrity OK.

Limitations:

- Full Qt WebEngine visual and certificate behavior cannot be tested inside this headless sandbox.
- Flatpak Builder and NSIS/Windows are not installed here, so those kits are generated but not compiled into final platform bundles.
