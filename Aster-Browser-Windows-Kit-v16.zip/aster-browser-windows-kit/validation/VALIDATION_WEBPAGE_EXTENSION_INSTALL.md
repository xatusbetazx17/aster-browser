# Aster webpage extension install validation

What was added:
- Add to Aster in-page button on supported extension pages
- Ctrl+Shift+A action to scan the current page for a direct extension package
- direct download + install flow for .xpi, .zip, and .crx packages exposed on the current page
- Chrome Web Store detection with an explanatory message instead of a fake Add to Chrome flow
- `/install-extension-page` command for the internal assistant

What was validated in this environment:
- `python -m compileall aster_browser run_aster.py`
- `python -m unittest discover -s tests -v`
- installer `--extract-only` smoke test
- direct HTTP download test for a remote `.xpi` package via a local test server

What was not live-verified here:
- Qt GUI rendering of the in-page Add to Aster button
- live installation from addons.mozilla.org or other public extension pages in a running GUI session
- Chrome Web Store direct installation, which is intentionally not implemented
