# Validation v16

- Python files compiled with `python3 -m py_compile`.
- Unit tests: `python3 -m unittest discover -s tests -v` → 58 tests OK.
- Linux self-extracting installer generated as `Aster-Browser-Merged-Linux-v16.sh`.
- Optional Chromium DRM capsule source added under `packaging/electron-drm-capsule`.
- Optional capsule setup scripts added for Linux and Windows.
- Shell syntax checked for Linux builder and capsule helper scripts.

The actual CastLabs/Electron runtime is not embedded in this sandbox output because it must be downloaded/updated by npm on the user's machine. The Linux installer supports `--with-drm-capsule` to install it during setup when internet access and node/npm are available.
