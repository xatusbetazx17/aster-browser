# Linux installer v8 validation

Fix: the Linux installer does not refresh or modify protected browser certificate databases. This avoids password/PIN prompt loops during installation.

Expected behavior:
- Installs or checks distro packages such as `ca-certificates` and `libnss3` where needed.
- Does not modify user/browser certificate databases.
- Does not ask repeatedly for a certificate database password/PIN.
