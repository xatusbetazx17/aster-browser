# v9 validation

Validated in the sandbox:

- Python syntax compile for the `aster_browser` package.
- Linux self-extracting installer payload extraction.
- Shell syntax for Linux installer builder and Flatpak launcher.
- Unit tests: 54 tests passed.

Notes:

- The sandbox cannot run a GUI browser session, so full Qt WebEngine visual/HTTPS behavior must be tested on the target Linux desktop.
- The sandbox does not include Flatpak Builder or Windows/NSIS, so those build kits are generated but not compiled into final platform bundles here.
