from __future__ import annotations

import base64
import json
import mimetypes
import os
import shutil
import socket
import time
from datetime import date, timedelta
from pathlib import Path
from typing import Any, cast
from urllib.parse import parse_qs, unquote, unquote_to_bytes, urlparse

from PyQt6.QtCore import QEvent, QPoint, QRect, QRectF, QSize, QTimer, QUrl, Qt
from PyQt6.QtGui import QAction, QCloseEvent, QColor, QDesktopServices, QKeySequence, QPainter, QPen
from PyQt6.QtWidgets import QApplication, QFileDialog, QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QProgressBar, QStatusBar, QTabWidget, QToolBar, QComboBox, QToolButton, QWidget, QSizePolicy, QWidgetAction
from PyQt6.QtWebEngineCore import QWebEnginePage
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtGui import QShortcut, QKeySequence
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWebEngineCore import QWebEnginePage

from .adblock import AdblockInterceptor, AdblockRuleset
from .ai import AIBroker, AIContext, CommandRouter, IntentRouter, build_search_url
from .capsules import CapsuleLaunchResult, StreamingCapsuleManager
from .extensions import WebExtensionRegistry
from .config import DEFAULT_ACCENT, BrowserConfig, load_config, save_config
from .containers import ContainerManager
from .memory import MemoryGovernor
from .models import TabState
from .network import WireGuardHelper
from .paths import bundled_plugins_dir, cache_dir, containers_dir, data_dir, downloads_dir, rules_dir, session_path, user_plugins_dir
from .plugins import AppAPI, PluginManager
from .security import apply_security_profile
from .tls import configure_certificate_environment, probe_https
from .streaming import StreamingSupport, detect_streaming_support, is_streaming_service, known_drm_service, open_external, redirect_reason, should_redirect_externally
from .widgets import AddressLineEdit, AIDockWidget, AsterTabBar, AsterTitleBar, CompatibilityRedirectWidget, ErrorPageWidget, ExtensionManagerDialog, LitePageWidget, MobileViewWidget, NewTabWidget, ParkedTabWidget, SettingsPageWidget, SpeechToolsDialog, StreamingCapsuleWidget, FlagsPageWidget, TaskManagerWidget
from .internal_pages import AwarenessPageWidget, BookmarksPageWidget, DownloadsPageWidget, HistoryPageWidget, MenuDashboardPopup, FocusNotification
from .icons import svg_icon
from .local_assistant import LocalAssistant
from .local_index import BookmarkResult, HistoryResult, LocalIndex
from .theme import apply_qt_style, stylesheet_for, window_translucency_allowed
from .tts import SpeechManager
from .localization import accept_language_for, interface_language_label, normalize_interface_language, set_ui_language, tr



class BrowserPage(QWebEnginePage):
    def __init__(self, browser: "BrowserWindow", container_name: str, profile, parent=None) -> None:
        super().__init__(profile, parent)
        self.browser = browser
        self.container_name = container_name

    def createWindow(self, _type):  # type: ignore[override]
        state = self.browser.open_web_tab("about:blank", container=self.container_name, background=False)
        view = self.browser._extract_web_view(state.widget)
        if view is not None:
            return view.page()
        return cast(QWebEnginePage, super().createWindow(_type))

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):  # type: ignore[override]
        try:
            parsed = urlparse(url.toString())
        except Exception:
            parsed = None
        if parsed is not None and parsed.scheme == "aster" and parsed.netloc == "install-extension":
            params = parse_qs(parsed.query)
            source = unquote((params.get("source") or [""])[0])
            label = unquote((params.get("label") or [""])[0])
            self.browser.install_extension_from_web_url(source, label)
            return False
        return super().acceptNavigationRequest(url, nav_type, is_main_frame)


_BROWSER_WINDOWS: list["BrowserWindow"] = []


def browser_windows() -> list["BrowserWindow"]:
    """Acik Aster pencereleri (sekme surukleyerek tasima icin kayit defteri)."""
    return list(_BROWSER_WINDOWS)


class BrowserWindow(QMainWindow):
    def __init__(self, primary: bool = True) -> None:
        super().__init__()
        # Ikincil pencereler (koparilan sekmeler icin) ana sayfa acmaz, park
        # edilmis sekmeleri geri yuklemez, acilis mesajlarini tekrarlamaz.
        self._is_primary = bool(primary)
        self._native_icon_handles: list[int] = []
        self._corner_region_key = None
        _BROWSER_WINDOWS.append(self)
        self.config: BrowserConfig = load_config()
        set_ui_language(getattr(self.config, "interface_language", "system"))
        if bool(getattr(self.config, "trust_system_ca", True)):
            configure_certificate_environment()
        self.ruleset = self._build_adblock_ruleset()
        self.containers = ContainerManager(self.config.containers, self._make_interceptor, self._handle_download)
        self.governor = MemoryGovernor(self.config.soft_memory_budget_mb, self.config.max_live_tabs)
        self.streaming_support: StreamingSupport = detect_streaming_support(self.config.drm_mode, self.config.external_browser_cmd)
        self.capsules = StreamingCapsuleManager(self.config.external_browser_cmd)
        self.local_index = LocalIndex()
        self.extensions = WebExtensionRegistry()
        self.speech = SpeechManager(self.config, self)
        self.tab_states: dict[str, TabState] = {}
        self._profile_sync_generation: dict[int, int] = {}
        self._certificate_errors: dict[str, str] = {}
        self._main_frame_certificate_error_hosts: set[str] = set()
        self._subresource_certificate_errors: dict[str, str] = {}
        self._verified_https_hosts: dict[str, float] = {}
        self.previous_tab_id: str | None = None
        self.last_current_tab_id: str | None = None
        self._lite_toggle_guard_until = 0.0
        self._connectivity_cache: tuple[float, bool] | None = None
        self._speech_dialog: SpeechToolsDialog | None = None
        self._dashboard_popup: MenuDashboardPopup | None = None
        self._screen_time_usage_seconds: dict[str, int] = {}
        self._screen_time_limit_minutes = 120
        self._screen_time_dirty = 0
        self._load_screen_time_state()
        self.setObjectName("AsterWindow")
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self._sync_window_transparency()
        self.setWindowTitle("Aster Browser")
        ico_path = os.path.join(os.path.dirname(__file__), "assets", "icons", "aster.ico")
        if not os.path.exists(ico_path):
            ico_path = os.path.join(os.path.dirname(__file__), "assets", "icons", "aster_logo.svg")
        if os.path.exists(ico_path):
            from PyQt6.QtGui import QIcon
            self.setWindowIcon(QIcon(ico_path))
        # Kenarlardan boyutlandirma bandi. QWebEngineView kendi NATIVE alt
        # penceresini olusturuyor; pencerenin en kenarina kadar uzandiginda
        # WM_NCHITTEST'i o yutuyor ve imlec kenarlarda hic degismiyor. Ince bir
        # bant birakinca kenar noktalari yeniden ust pencereye ait oluyor.
        # Ust kenarda banda gerek yok: baslik/arac/sekme cubugu native degil.
        self.setContentsMargins(self._RESIZE_BORDER - 1, 0,
                                self._RESIZE_BORDER - 1, self._RESIZE_BORDER - 1)
        # 1120x760 minimum, tipik bir calisma alaninin neredeyse tamami
        # oldugu icin pencere pratikte kucultulemiyordu.
        self.setMinimumSize(640, 480)
        self.resize(1400, 900)
        self._setup_ui()
        self._setup_menus()
        self._setup_ai_and_plugins()
        self._start_screen_time_tracking()
        self.speech.status.connect(lambda message: self.show_message(message, 7000))
        self.speech.voices_changed.connect(self._refresh_speech_controls)
        self._prime_webengine_surface()
        if self._is_primary:
            self._show_startup_status()
            self.open_target(self.config.homepage)
            QTimer.singleShot(0, self._restore_persisted_parked_tabs)
        self._native_icon_handles: list[int] = []
        QTimer.singleShot(0, self._apply_native_window_icon)
        QTimer.singleShot(0, self._enable_native_resize_border)
        QTimer.singleShot(0, self._apply_window_corner_region)
        QTimer.singleShot(0, lambda: self._focus_tab_content(self.current_state()))

    def _add_toolbar_gap(self, toolbar, width: int = 10) -> None:
        """Arac cubugunda ayrac cizgisi yerine gorunmez bosluk birakir.

        QSS ile saydamlastirmak yeterli degil: bazi Qt temalari ayraci stil
        ilkeliyle ciziyor. Ayraci hic olusturmayinca hicbir tema cizemiyor.
        """
        spacer = QWidget(toolbar)
        spacer.setFixedWidth(width)
        spacer.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        spacer.setStyleSheet("background: transparent; border: none;")
        toolbar.addWidget(spacer)

    def _position_add_tab_button(self):
        """Yeni sekme butonunu son sekmenin hemen sagina dikey ortalayarak tasir."""
        if not hasattr(self, 'add_tab_button') or self.tabs.count() == 0:
            return
            
        tab_bar = self.tabs.tabBar()
        last_tab_rect = tab_bar.tabRect(self.tabs.count() - 1)
        bar_geo = tab_bar.geometry()
        
        new_x = bar_geo.x() + last_tab_rect.right() + 4
        new_y = bar_geo.y() + last_tab_rect.y() + (last_tab_rect.height() - self.add_tab_button.height()) // 2
        
        max_x = self.tabs.width() - self.add_tab_button.width() - 5
        if new_x > max_x:
            new_x = max_x
            
        self.add_tab_button.move(new_x, max(0, new_y))
        self.add_tab_button.raise_()
    def _handle_fullscreen(self, request, view):
        if request.toggleOn():
            if self.isFullScreen() and getattr(self, '_in_custom_fullscreen', False):
                request.accept()
                return
            self._was_maximized = self.isMaximized()
            self._in_custom_fullscreen = True
            self.title_bar.hide()
            self.toolbar.hide()
            self.status.hide()
            self.tabs.tabBar().hide()
            self.showFullScreen()
            
            if not hasattr(self, '_fs_notif'):
                self._fs_notif = QLabel(tr("Press ESC to exit full screen"), self)
                self._fs_notif.setStyleSheet("background: rgba(0, 0, 0, 0.85); color: white; padding: 10px 18px; border-radius: 6px; font-weight: bold; font-size: 13px;")
                self._fs_notif.adjustSize()
                self._fs_timer = QTimer(self)
                self._fs_timer.setSingleShot(True)
                self._fs_timer.timeout.connect(self._fs_notif.hide)
                self._fs_esc_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
            
            try:
                self._fs_esc_shortcut.activated.disconnect()
            except Exception:
                pass
            self._fs_esc_shortcut.activated.connect(lambda: view.page().triggerAction(QWebEnginePage.WebAction.ExitFullScreen))
            self._fs_notif.move(self.width() - self._fs_notif.width() - 20, 20)
            self._fs_notif.show()
            self._fs_notif.raise_()
            self._fs_timer.start(3000)
            request.accept()
        else:
            if not getattr(self, '_in_custom_fullscreen', False) and not self.isFullScreen():
                request.accept()
                return
            self._in_custom_fullscreen = False
            self.title_bar.show()
            self.toolbar.show()
            self.status.hide()
            self.tabs.tabBar().show()
            
            if getattr(self, '_was_maximized', False):
                self.showMaximized()
            else:
                self.showNormal()
                
            if hasattr(self, '_fs_notif'):
                self._fs_notif.hide()
                try:
                    self._fs_esc_shortcut.activated.disconnect()
                except Exception:
                    pass
            request.accept()
    def _setup_ui(self) -> None:
        self.title_bar = AsterTitleBar(self)
        self.title_bar.logo_button.setToolTip(tr("Open home page"))
        self.title_bar.logo_button.clicked.connect(lambda: self.open_target(self.config.homepage))
        self.setMenuWidget(self.title_bar)

        self.status = QStatusBar(self)
        self.status.setObjectName("AsterStatusBar")
        self.status.setSizeGripEnabled(False)
        self.setStatusBar(self.status)
        self.status.hide()
        self.page_status_label = QLabel(tr("Ready"), self)
        self.page_status_label.setObjectName("StatusInfoLabel")
        self.security_status_label = QLabel(tr("Security —"), self)
        self.security_status_label.setObjectName("StatusInfoLabel")
        self.zoom_status_label = QLabel(f"Zoom {getattr(self.config, 'default_zoom_percent', 100)}%", self)
        self.zoom_status_label.setObjectName("StatusInfoLabel")
        self.memory_status_label = QLabel(tr("Memory —"), self)
        self.memory_status_label.setObjectName("StatusInfoLabel")
        self.status.addPermanentWidget(self.page_status_label, 1)
        self.status.addPermanentWidget(self.security_status_label)
        self.status.addPermanentWidget(self.zoom_status_label)
        self.status.addPermanentWidget(self.memory_status_label)
        self.status_metrics_timer = QTimer(self)
        self.status_metrics_timer.setInterval(2500)
        self.status_metrics_timer.timeout.connect(self._refresh_status_metrics)
        self.status_metrics_timer.start()

        self.tabs = QTabWidget(self)
        self.tabs.setObjectName("AsterTabs")
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tab_bar = AsterTabBar(self.tabs)
        self.tab_bar.set_active_tab_left_click_menu_enabled(getattr(self.config, "active_tab_left_click_menu", True))
        self.tab_bar.quick_actions_requested.connect(self._show_tab_quick_actions_menu)
        self.tab_bar.tab_detach_requested.connect(self._handle_tab_detach)
        self.tabs.setTabBar(self.tab_bar)
        self.tab_bar.tabCloseRequested.connect(self._close_tab_index)
        self.tabs.tabCloseRequested.connect(self._close_tab_index)
        self.tabs.currentChanged.connect(self._on_current_tab_changed)
        self.setCentralWidget(self.tabs)
        # --- Yeni Sekme (+) Butonu ---
        self.add_tab_button = QToolButton(self.tabs)
        self.add_tab_button.setObjectName("NewTabButton")
        self.add_tab_button.setIcon(svg_icon("new_tab")) 
        self.add_tab_button.setIconSize(QSize(12, 12))
        self.add_tab_button.setFixedSize(22, 22)
        self.add_tab_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_tab_button.setToolTip(tr("New tab (Ctrl+T)"))
        self.add_tab_button.clicked.connect(lambda: self.open_target(self.config.homepage))
        
        self.tabs.currentChanged.connect(lambda _: QTimer.singleShot(10, self._position_add_tab_button))

        toolbar = QToolBar("Navigation", self)
        self.toolbar = toolbar
        toolbar.setObjectName("AsterToolbar")
        toolbar.setMovable(False)
        toolbar.setFloatable(False)
        toolbar.setIconSize(QSize(16, 16))
        toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
        self.addToolBar(toolbar)

        self.back_action = QAction(svg_icon("arrow_back"), tr("Back"), self)
        self.back_action.setToolTip(tr("Back"))
        self.back_action.triggered.connect(lambda: self._with_current_web_view(lambda view: view.back()))

        self.forward_action = QAction(svg_icon("arrow_forward"), tr("Forward"), self)
        self.forward_action.setToolTip(tr("Forward"))
        self.forward_action.triggered.connect(lambda: self._with_current_web_view(lambda view: view.forward()))

        self.reload_action = QAction(svg_icon("reload"), tr("Reload"), self)
        self.reload_action.setToolTip(tr("Reload"))
        self.reload_action.triggered.connect(lambda: self._with_current_web_view(lambda view: view.reload()))

        self.home_action = QAction(svg_icon("home"), tr("Home"), self)
        self.home_action.setToolTip(tr("Home"))
        self.home_action.triggered.connect(lambda: self.open_target(self.config.homepage))

        self.new_tab_action = QAction(svg_icon("new_tab"), tr("New Tab"), self)
        self.new_tab_action.setToolTip(tr("New tab"))
        self.new_tab_action.triggered.connect(lambda: self.open_target(self.config.homepage, background=False))

        self.park_action = QAction(svg_icon("park"), tr("Park"), self)
        self.park_action.setToolTip(tr("Park background tabs"))
        self.park_action.triggered.connect(self.park_background_tabs)

        self.park_current_action = QAction(svg_icon("park"), tr("Park Current"), self)
        self.park_current_action.setToolTip(tr("Park the current tab for later"))
        self.park_current_action.triggered.connect(self.park_current_tab)

        self.lite_action = QAction(svg_icon("lite"), tr("Lite"), self)
        self.lite_action.setToolTip(tr("Open Lite mode"))
        self.lite_action.triggered.connect(self.open_lite_current)

        self.mobile_action = QAction(svg_icon("mobile"), tr("Mobile view"), self)
        self.mobile_action.setToolTip(tr("Open the current page in mobile view"))
        self.mobile_action.triggered.connect(self.open_mobile_current)

        self.add_from_page_action = QAction(svg_icon("add_page"), tr("Add from page"), self)
        self.add_from_page_action.setToolTip(tr("Install extension from current page"))
        self.add_from_page_action.triggered.connect(self.install_extension_from_current_page)

        self.extensions_action = QAction(svg_icon("extensions"), tr("Extensions"), self)
        self.extensions_action.setToolTip(tr("Open extensions manager"))
        self.extensions_action.triggered.connect(self.open_extension_manager_dialog)

        self.settings_action = QAction(svg_icon("settings"), tr("Settings"), self)
        self.settings_action.setToolTip(tr("Open settings"))
        self.settings_action.triggered.connect(self.open_settings_dialog)

        self.zoom_in_action = QAction(tr("Zoom in"), self)
        self.zoom_in_action.setShortcut(QKeySequence("Ctrl+="))
        self.zoom_in_action.triggered.connect(self.zoom_in_current)
        self.zoom_out_action = QAction(tr("Zoom out"), self)
        self.zoom_out_action.setShortcut(QKeySequence("Ctrl+-"))
        self.zoom_out_action.triggered.connect(self.zoom_out_current)
        self.zoom_reset_action = QAction(tr("Reset zoom"), self)
        self.zoom_reset_action.setShortcut(QKeySequence("Ctrl+0"))
        self.zoom_reset_action.triggered.connect(self.zoom_reset_current)

        self.new_tab_action.setShortcut(QKeySequence("Ctrl+T"))
        self.park_action.setShortcut(QKeySequence("Ctrl+Shift+P"))
        self.park_current_action.setShortcut(QKeySequence("Ctrl+Shift+K"))
        self.lite_action.setShortcut(QKeySequence("Ctrl+Shift+L"))
        self.mobile_action.setShortcut(QKeySequence("Ctrl+Shift+M"))
        self.add_from_page_action.setShortcut(QKeySequence("Ctrl+Shift+A"))
        self.extensions_action.setShortcut(QKeySequence("Ctrl+Shift+E"))
        self.settings_action.setShortcut(QKeySequence("Ctrl+,"))
        self.primary_toolbar_actions = [self.back_action, self.forward_action, self.reload_action, self.home_action]
        self.secondary_toolbar_actions = [self.park_action, self.park_current_action, self.lite_action, self.mobile_action, self.add_from_page_action, self.extensions_action, self.settings_action]
        self.compactable_toolbar_actions = [self.home_action, self.new_tab_action, self.park_action, self.park_current_action, self.lite_action, self.mobile_action, self.add_from_page_action, self.extensions_action, self.settings_action]

        # 1. SOL TARAF: Navigasyon ve Sekme Butonları
        for act in self.primary_toolbar_actions:
            toolbar.addAction(act)
        self._add_toolbar_gap(toolbar)

        # 2. MERKEZ: Genişleyen URL Çubuğu (Tüm boşluğu kaplar)
        self.url_bar = AddressLineEdit(self)
        self.url_bar.setObjectName("AddressBar")
        self.url_bar.setFixedHeight(30)
        self.url_bar.setPlaceholderText(tr("Search or enter address"))
        self.url_bar.returnPressed.connect(self.go_from_address_bar)
        self.url_bar.setClearButtonEnabled(True)
        # Qt's own clear icon is a filled disc with a cross punched out of it,
        # which reads as a button sitting inside the address bar rather than as
        # part of it. Aster's own cross matches the rest of the toolbar. Qt 6
        # leaves that button unnamed, and it is the only one in the field until
        # the buttons below are added, so it is found by type.
        for clear_button in self.url_bar.findChildren(QToolButton):
            clear_button.setIcon(svg_icon("close"))
        self.url_bar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.url_bar.setMinimumWidth(240)
        toolbar.addWidget(self.url_bar)

        # 3. SAĞ TARAF: Profil Menüsü ve Diğer Butonlar
        self.container_combo = QComboBox(self)
        self.container_combo.setObjectName("ContainerCombo")
        self.container_combo.setFixedHeight(30)
        self.container_combo.addItems(self.containers.available())
        self.container_combo.setCurrentText(self.config.default_container)
        self.container_combo.setFixedWidth(100)
        toolbar.addWidget(self.container_combo)
        self._add_toolbar_gap(toolbar)
        toolbar.addAction(self.park_action)
        toolbar.addAction(self.park_current_action)
        toolbar.addAction(self.lite_action)
        toolbar.addAction(self.mobile_action)
        toolbar.addAction(self.add_from_page_action)
        toolbar.addAction(self.extensions_action)
        toolbar.addAction(self.settings_action)

        self.load_progress = QProgressBar(self)
        self.load_progress.setObjectName("LoadProgress")
        self.load_progress.setRange(0, 100)
        self.load_progress.setValue(0)
        self.load_progress.setVisible(False)
        self.load_progress.setFixedHeight(14)
        self.load_progress.setFixedWidth(100)
        toolbar.addWidget(self.load_progress)

        self.toolbar_overflow_button = QToolButton(self)
        self.toolbar_overflow_button.setObjectName("ToolbarOverflowButton")
        self.toolbar_overflow_button.setIcon(svg_icon("menu_more"))
        self.toolbar_overflow_button.setIconSize(QSize(16, 16))
        self.toolbar_overflow_button.setToolTip(tr("Menu"))
        self.toolbar_overflow_button.clicked.connect(self.open_dashboard_menu)
        toolbar.addWidget(self.toolbar_overflow_button)
        self.title_bar.set_context_text(tr("Aster is ready"))
        self._update_compact_ui()
        self._apply_responsive_density()

        focus_url_action = QAction(self)
        focus_url_action.setShortcut(QKeySequence("Ctrl+L"))
        focus_url_action.triggered.connect(
            lambda: self.url_bar.setFocus(Qt.FocusReason.ShortcutFocusReason)
        )
        self.addAction(focus_url_action)

        close_tab_action = QAction(self)
        close_tab_action.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_action.triggered.connect(self.close_current_tab)
        self.addAction(close_tab_action)
        self.addAction(self.zoom_in_action)
        self.addAction(self.zoom_out_action)
        self.addAction(self.zoom_reset_action)
        self._apply_customization_config()
        self._refresh_status_metrics()

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._update_compact_ui()
        self._apply_responsive_density()
        self._apply_window_corner_region()
        QTimer.singleShot(0, self._position_add_tab_button)

    def changeEvent(self, event) -> None:  # type: ignore[override]
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange:
            self.title_bar.sync_window_state()
            # Maximize/tam ekranda koseler kare, geri alininca yuvarlak.
            self._corner_region_key = None
            self._apply_window_corner_region()
            QTimer.singleShot(0, self._update_compact_ui)
            QTimer.singleShot(0, self._apply_responsive_density)
            QTimer.singleShot(0, self._position_add_tab_button)

    def _tab_position_enum(self):
        position = str(getattr(self.config, "tab_position", "top") or "top").strip().lower()
        if position == "bottom":
            return QTabWidget.TabPosition.South
        if position == "left":
            return QTabWidget.TabPosition.West
        if position == "right":
            return QTabWidget.TabPosition.East
        return QTabWidget.TabPosition.North

    def _toolbar_density_name(self) -> str:
        density = str(getattr(self.config, "ui_density", getattr(self.config, "toolbar_density", "comfortable")) or "comfortable").strip().lower()
        return density if density in {"compact", "comfortable", "spacious"} else "comfortable"

    def _apply_customization_config(self) -> None:
        try:
            self.tabs.setTabPosition(self._tab_position_enum())
        except Exception:
            pass
        try:
            self.status.hide()
        except Exception:
            pass
        try:
            self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon if bool(getattr(self.config, "toolbar_text", False)) else Qt.ToolButtonStyle.ToolButtonIconOnly)
        except Exception:
            pass
        try:
            self.add_tab_button.setVisible(True)
        except Exception:
            pass
        self._update_compact_ui()
        self._apply_responsive_density()

    def open_file_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, tr("Open File"), "", tr("HTML Files (*.html *.htm);;All Files (*.*)"))
        if path:
            self.open_target(f"file:///{path}")

    def save_current_page_dialog(self) -> None:
        state = self.current_state()
        if not state:
            return
        suggested = self._suggest_download_filename(state.url or "page.html", "page.html")
        dest, _ = QFileDialog.getSaveFileName(self, tr("Save Page As"), str(downloads_dir() / suggested), tr("HTML Files (*.html *.htm);;All Files (*.*)"))
        if dest:
            view = self.current_web_view()
            if view:
                try:
                    view.page().save(dest)
                    self.show_message(tr("Saved page to {path}").format(path=dest))
                except Exception as e:
                    self.show_message(tr("Save failed: {error}").format(error=e))

    def print_current_page(self) -> None:
        view = self.current_web_view()
        if view:
            try:
                from PyQt6.QtPrintSupport import QPrintDialog, QPrinter
                printer = QPrinter()
                dlg = QPrintDialog(printer, self)
                if dlg.exec():
                    view.print(printer)
            except Exception:
                self.show_message(tr("Printing is not available on this view."))

    def open_new_window(self) -> None:
        try:
            import subprocess, sys
            subprocess.Popen([sys.executable, sys.argv[0]])
        except Exception:
            self.open_target(self.config.homepage, background=False)

    def toggle_fullscreen_view(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def _view_current_page_source(self) -> None:
        view = self.current_web_view()
        if view:
            try:
                view.triggerPageAction(QWebEnginePage.WebAction.ViewSource)
            except Exception:
                self.show_message(tr("View source is not available for this page."))

    def _setup_menus(self) -> None:
        file_menu = self.title_bar.file_menu
        view_menu = self.title_bar.view_menu
        tools_menu = self.title_bar.tools_menu
        file_menu.clear()
        view_menu.clear()
        tools_menu.clear()

        # --- FILE MENU (Firefox / Modern Browser Standard) ---
        new_tab = QAction(tr("New Tab"), self)
        new_tab.setShortcut(QKeySequence("Ctrl+T"))
        new_tab.triggered.connect(lambda: self.open_target(self.config.homepage))
        file_menu.addAction(new_tab)

        new_window = QAction(tr("New Window"), self)
        new_window.setShortcut(QKeySequence("Ctrl+N"))
        new_window.triggered.connect(self.open_new_window)
        file_menu.addAction(new_window)

        file_menu.addSeparator()

        open_file_act = QAction(tr("Open File..."), self)
        open_file_act.setShortcut(QKeySequence("Ctrl+O"))
        open_file_act.triggered.connect(self.open_file_dialog)
        file_menu.addAction(open_file_act)

        save_page_act = QAction(tr("Save Page As..."), self)
        save_page_act.setShortcut(QKeySequence("Ctrl+S"))
        save_page_act.triggered.connect(self.save_current_page_dialog)
        file_menu.addAction(save_page_act)

        print_act = QAction(tr("Print..."), self)
        print_act.setShortcut(QKeySequence("Ctrl+P"))
        print_act.triggered.connect(self.print_current_page)
        file_menu.addAction(print_act)

        file_menu.addSeparator()

        close_tab_act = QAction(tr("Close Tab"), self)
        close_tab_act.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_act.triggered.connect(self.close_current_tab)
        file_menu.addAction(close_tab_act)

        close_window_act = QAction(tr("Close Window"), self)
        close_window_act.setShortcut(QKeySequence("Ctrl+Shift+W"))
        close_window_act.triggered.connect(self.close)
        file_menu.addAction(close_window_act)

        file_menu.addSeparator()

        quit_act = QAction(tr("Exit"), self)
        quit_act.setShortcut(QKeySequence("Ctrl+Q"))
        quit_act.triggered.connect(self.close)
        file_menu.addAction(quit_act)

        # --- VIEW MENU (Display, Zoom, Source) ---
        fullscreen_action = QAction(tr("Full Screen"), self)
        fullscreen_action.setShortcut(QKeySequence("F11"))
        fullscreen_action.triggered.connect(self.toggle_fullscreen_view)
        view_menu.addAction(fullscreen_action)

        view_menu.addSeparator()

        view_menu.addAction(self.zoom_in_action)
        view_menu.addAction(self.zoom_out_action)
        view_menu.addAction(self.zoom_reset_action)

        view_menu.addSeparator()

        reload_act = QAction(tr("Reload Page"), self)
        reload_act.setShortcut(QKeySequence("Ctrl+R"))
        reload_act.triggered.connect(self.reload_current)
        view_menu.addAction(reload_act)

        view_menu.addSeparator()

        view_menu.addAction(tr("Mobile View"), self.open_mobile_current)
        view_menu.addAction(tr("Desktop View"), self.open_desktop_current)
        view_menu.addAction(tr("Lite Mode"), self.open_lite_current)

        view_menu.addSeparator()

        view_source_act = QAction(tr("View Page Source"), self)
        view_source_act.setShortcut(QKeySequence("Ctrl+U"))
        view_source_act.triggered.connect(self._view_current_page_source)
        view_menu.addAction(view_source_act)

        # --- TOOLS MENU (Tools, Utilities, Settings) ---
        downloads_act = QAction(tr("Downloads"), self)
        downloads_act.setShortcut(QKeySequence("Ctrl+J"))
        downloads_act.triggered.connect(self.open_downloads_page_from_menu)
        tools_menu.addAction(downloads_act)

        history_act = QAction(tr("History"), self)
        history_act.setShortcut(QKeySequence("Ctrl+H"))
        history_act.triggered.connect(self.open_history_page_from_menu)
        tools_menu.addAction(history_act)

        bookmarks_act = QAction(tr("Bookmarks"), self)
        bookmarks_act.setShortcut(QKeySequence("Ctrl+Shift+O"))
        bookmarks_act.triggered.connect(self.open_bookmarks_page_from_menu)
        tools_menu.addAction(bookmarks_act)

        extensions_action = QAction(tr("Extensions"), self)
        extensions_action.setShortcut(QKeySequence("Ctrl+Shift+E"))
        extensions_action.triggered.connect(self.open_extension_manager_dialog)
        tools_menu.addAction(extensions_action)

        tools_menu.addSeparator()

        awareness_act = QAction(tr("Awareness Features"), self)
        awareness_act.triggered.connect(self.open_awareness_page_from_menu)
        tools_menu.addAction(awareness_act)

        read_page_act = QAction(tr("Read Page Aloud"), self)
        read_page_act.setShortcut(QKeySequence("Ctrl+Shift+R"))
        read_page_act.triggered.connect(self.read_page_aloud)
        tools_menu.addAction(read_page_act)

        tools_menu.addSeparator()

        clear_data_act = QAction(tr("Clear Browsing Data..."), self)
        clear_data_act.setShortcut(QKeySequence("Ctrl+Shift+Delete"))
        clear_data_act.triggered.connect(self.clear_web_security_state)
        tools_menu.addAction(clear_data_act)

        tools_menu.addSeparator()

        settings_act = QAction(tr("Settings"), self)
        settings_act.setShortcut(QKeySequence("Ctrl+,"))
        settings_act.triggered.connect(self.open_settings_dialog)
        tools_menu.addAction(settings_act)

        self.title_bar._rebuild_compact_menu()

    def _show_startup_status(self) -> None:
        if self.config.drm_mode == "chromium_drm_capsule":
            self.show_message(tr("Aster Chromium DRM capsule mode is enabled. Use --with-drm-capsule or tools/setup_chromium_drm_capsule.sh to install the bundled runtime; Chrome is not required."), 10000)
        elif self.config.drm_mode == "qtwebengine_capsule":
            self.show_message(tr("Aster compatibility mode is enabled: Qt WebEngine is bundled, so system Chromium is not required."), 9000)
        elif self.config.drm_mode == "internal_preferred" and not self.streaming_support.internal_drm_available():
            self.show_message(tr("Widevine was not detected. Protected streaming can still fall back to Aster's compatibility path."), 9000)
        elif self.config.drm_mode == "internal_preferred":
            self.show_message(tr("Widevine detected. Aster will try protected playback inside the browser first."), 7000)

    def _should_use_translucent_window(self) -> bool:
            return False

    def _sync_window_transparency(self) -> None:
        allow = self._should_use_translucent_window()
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, allow)
        except Exception:
            pass
        try:
            self.setAutoFillBackground(not allow)
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _screen_time_state_path(self) -> Path:
        root = data_dir()
        root.mkdir(parents=True, exist_ok=True)
        return root / "awareness_state.json"

    def _prune_screen_time_usage(self) -> None:
        cutoff = date.today() - timedelta(days=30)
        cleaned: dict[str, int] = {}
        for key, value in list(self._screen_time_usage_seconds.items()):
            try:
                day = date.fromisoformat(str(key))
            except Exception:
                continue
            if day >= cutoff:
                cleaned[day.isoformat()] = max(0, int(value or 0))
        self._screen_time_usage_seconds = cleaned

    def _load_screen_time_state(self) -> None:
        self._screen_time_usage_seconds = {}
        self._screen_time_limit_minutes = 120
        self._screen_time_dirty = 0
        path = self._screen_time_state_path()
        if path.exists():
            try:
                payload = json.loads(path.read_text())
                usage = payload.get('usage_seconds', {}) if isinstance(payload, dict) else {}
                if isinstance(usage, dict):
                    self._screen_time_usage_seconds = {str(key): max(0, int(value or 0)) for key, value in usage.items()}
                limit_value = payload.get('daily_limit_minutes', 120) if isinstance(payload, dict) else 120
                self._screen_time_limit_minutes = max(60, min(24 * 60, int(limit_value or 120)))
            except Exception:
                self._screen_time_usage_seconds = {}
                self._screen_time_limit_minutes = 120
        self._prune_screen_time_usage()

    def _save_screen_time_state(self) -> None:
        self._prune_screen_time_usage()
        payload = {
            'daily_limit_minutes': int(self._screen_time_limit_minutes),
            'usage_seconds': self._screen_time_usage_seconds,
        }
        try:
            self._screen_time_state_path().write_text(json.dumps(payload, indent=2, sort_keys=True))
            self._screen_time_dirty = 0
        except Exception:
            pass

    def _start_screen_time_tracking(self) -> None:
        self._screen_time_timer = QTimer(self)
        self._screen_time_timer.setInterval(1000)
        self._screen_time_timer.timeout.connect(self._tick_screen_time)
        self._screen_time_timer.start()

    def _tick_screen_time(self) -> None:
        app = QApplication.instance()
        if app is None:
            return
        active = app.applicationState() == Qt.ApplicationState.ApplicationActive and self.isVisible() and not self.isMinimized()
        if not active:
            return
        key = date.today().isoformat()
        self._screen_time_usage_seconds[key] = int(self._screen_time_usage_seconds.get(key, 0)) + 1
        self._screen_time_dirty += 1
        if self._screen_time_dirty >= 15:
            self._save_screen_time_state()

    def screen_time_snapshot(self) -> dict[str, int]:
        self._prune_screen_time_usage()
        today = date.today()
        today_key = today.isoformat()
        weekly = 0
        for offset in range(7):
            key = (today - timedelta(days=offset)).isoformat()
            weekly += int(self._screen_time_usage_seconds.get(key, 0) or 0)
        return {
            'today_seconds': int(self._screen_time_usage_seconds.get(today_key, 0) or 0),
            'weekly_seconds': int(weekly),
            'weekly_average_seconds': int(round(weekly / 7.0)),
            'daily_limit_minutes': int(self._screen_time_limit_minutes),
        }

    def set_daily_screen_limit_minutes(self, minutes: int) -> None:
        self._screen_time_limit_minutes = max(60, min(24 * 60, int(minutes or 120)))
        self._save_screen_time_state()

    def _window_surface_color(self) -> QColor:
        theme = str(getattr(self.config, 'theme', 'black_arc') or 'black_arc').strip().lower()
        try:
            transparency = int(getattr(self.config, 'background_transparency_percent', 10) or 10)
        except Exception:
            transparency = 0
        transparency = max(0, min(100, transparency))
        if theme == 'system':
            color = self.palette().window().color()
            color.setAlpha(255)
            return color
        base = QColor('#000000')
        alpha = 255 if not self._should_use_translucent_window() else max(228, int(round(255 * (100 - transparency) / 100)))
        base.setAlpha(alpha)
        return base

    def _window_border_color(self) -> QColor:
        theme = str(getattr(self.config, 'theme', 'black_arc') or 'black_arc').strip().lower()
        if theme == 'system':
            color = self.palette().mid().color()
            color.setAlpha(255)
            return color
        return QColor(42, 47, 57, 230)

    def paintEvent(self, event) -> None:  # type: ignore[override]
        super().paintEvent(event)
        # Eskiden burada 20px yuvarlatilmis, 1px kenarlikli bir dikdortgen
        # ciziliyordu. Pencere opak ve kare oldugu icin yuvarlak yolun disinda
        # boyanmamis kose bolgeleri kaliyordu ("yuvarlatilmis ama
        # yuvarlatilamamis" gorunumu) ve kenarlardaki ince cizgi de bu
        # kenarliktan geliyordu. Pencereyi duz ve kenarliksiz boyuyoruz;
        # yuvarlatmayi _apply_window_corner_region kirpma ile yapiyor.
        painter = QPainter(self)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self._window_surface_color())
        painter.drawRect(self.rect())

    # Kenar yakalama bandi (mantiksal piksel).
    _RESIZE_BORDER = 6

    @staticmethod
    def _is_win32_msg(event_type) -> bool:
        # Qt bunu QByteArray olarak veriyor; str() ile karsilastirmak sessizce
        # hep False donerdi.
        try:
            return bytes(event_type) == b"windows_generic_MSG"
        except Exception:
            return False

    def nativeEvent(self, event_type, message):  # type: ignore[override]
        """Cercevesiz pencerede kenarlardan boyutlandirmayi acar.

        WS_THICKFRAME tek basina yetmiyor: Qt'nin frameless penceresi
        WM_NCHITTEST'e her yer icin HTCLIENT donduruyor, dolayisiyla Windows
        hicbir kenari boyutlandirma sinirina saymiyor. Yalnizca hit-test'i
        yanitliyoruz; geometri hesabina (WM_NCCALCSIZE) DOKUNMUYORUZ, ona
        mudahale etmek Qt'yi cokertiyor.
        """
        try:
            if (
                self._is_win32_msg(event_type)
                and not self.isMaximized()
                and not self.isFullScreen()
            ):
                import ctypes
                from ctypes import wintypes

                msg = wintypes.MSG.from_address(int(message))
                if msg.message == 0x0084:  # WM_NCHITTEST
                    lp = int(msg.lParam)
                    x = ctypes.c_short(lp & 0xFFFF).value
                    y = ctypes.c_short((lp >> 16) & 0xFFFF).value
                    hit = self._resize_hit_test(x, y)
                    if hit is not None:
                        return True, hit
        except Exception:
            pass
        # super().nativeEvent() CAGIRMIYORUZ: PyQt6'da taban uygulamayi Python
        # tarafindan cagirmak sureci cokertiyor.
        return False, 0

    def _resize_hit_test(self, global_x: int, global_y: int) -> int | None:
        """Ekran koordinatini kenar bandina gore HT* koduna cevirir."""
        HTLEFT, HTRIGHT, HTTOP = 10, 11, 12
        HTTOPLEFT, HTTOPRIGHT = 13, 14
        HTBOTTOM, HTBOTTOMLEFT, HTBOTTOMRIGHT = 15, 16, 17

        frame = self.frameGeometry()
        ratio = self.devicePixelRatioF() or 1.0
        left = frame.left() * ratio
        top = frame.top() * ratio
        right = (frame.right() + 1) * ratio
        bottom = (frame.bottom() + 1) * ratio
        border = self._RESIZE_BORDER * ratio

        on_left = left <= global_x < left + border
        on_right = right - border < global_x <= right
        on_top = top <= global_y < top + border
        on_bottom = bottom - border < global_y <= bottom

        if on_top and on_left:
            return HTTOPLEFT
        if on_top and on_right:
            return HTTOPRIGHT
        if on_bottom and on_left:
            return HTBOTTOMLEFT
        if on_bottom and on_right:
            return HTBOTTOMRIGHT
        if on_left:
            return HTLEFT
        if on_right:
            return HTRIGHT
        if on_top:
            return HTTOP
        if on_bottom:
            return HTBOTTOM
        return None

    def _enable_native_resize_border(self) -> None:
        """Pencereye WS_THICKFRAME ekler (boyutlandirma sinirini Windows yurutur)."""
        import sys

        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            GWL_STYLE = -16
            WS_THICKFRAME = 0x00040000
            SWP_NOMOVE, SWP_NOSIZE = 0x0002, 0x0001
            SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED = 0x0004, 0x0010, 0x0020

            if ctypes.sizeof(ctypes.c_void_p) == 8:
                get_style, set_style = user32.GetWindowLongPtrW, user32.SetWindowLongPtrW
                get_style.restype = ctypes.c_longlong
                set_style.restype = ctypes.c_longlong
                set_style.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_longlong]
            else:
                get_style, set_style = user32.GetWindowLongW, user32.SetWindowLongW
                get_style.restype = ctypes.c_long
                set_style.restype = ctypes.c_long
                set_style.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
            get_style.argtypes = [wintypes.HWND, ctypes.c_int]
            user32.SetWindowPos.restype = wintypes.BOOL
            user32.SetWindowPos.argtypes = [
                wintypes.HWND, wintypes.HWND,
                ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT,
            ]

            hwnd = wintypes.HWND(int(self.winId()))
            style = get_style(hwnd, GWL_STYLE)
            if not (style & WS_THICKFRAME):
                set_style(hwnd, GWL_STYLE, style | WS_THICKFRAME)
                user32.SetWindowPos(
                    hwnd, wintypes.HWND(0), 0, 0, 0, 0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED,
                )
            self._apply_dwm_window_chrome(hwnd)
        except Exception:
            pass

    def _apply_dwm_window_chrome(self, hwnd) -> None:
        """DWM yuvarlatmasini kapatir ve kenardaki ince cizgiyi kaldirir.

        Yuvarlatmayi DWM yapmiyor cunku yalnizca iki sabit yaricap sunuyor
        (ROUND ~8px, ROUNDSMALL ~4px). Daha buyuk yaricap icin pencereyi
        kendimiz bir bolgeye kirpiyoruz; iki mekanizma catismasin diye DWM
        kare biraktik.
        """
        try:
            import ctypes
            from ctypes import wintypes

            dwmapi = ctypes.WinDLL("dwmapi", use_last_error=True)
            dwmapi.DwmSetWindowAttribute.restype = ctypes.c_long
            dwmapi.DwmSetWindowAttribute.argtypes = [
                wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
            ]
            DWMWA_WINDOW_CORNER_PREFERENCE, DWMWA_BORDER_COLOR = 33, 34
            DWMWCP_DONOTROUND = 1
            DWMWA_COLOR_NONE = 0xFFFFFFFE

            corner = ctypes.c_int(DWMWCP_DONOTROUND)
            dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_WINDOW_CORNER_PREFERENCE,
                ctypes.byref(corner), ctypes.sizeof(corner),
            )
            color = ctypes.c_uint(DWMWA_COLOR_NONE)
            dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_BORDER_COLOR, ctypes.byref(color), ctypes.sizeof(color),
            )
        except Exception:
            pass

    def _corner_radius(self) -> int:
        try:
            radius = int(getattr(self.config, "window_corner_radius", 18) or 18)
        except Exception:
            radius = 18
        return max(0, min(40, radius))

    def _apply_window_corner_region(self) -> None:
        """Pencereyi yuvarlatilmis bir bolgeye kirpar.

        SetWindowRgn kirpmayi pencere yoneticisi duzeyinde yaptigi icin
        QWebEngineView'in native alt penceresi de kirpiliyor; koselerde
        boyanmamis alan kalmiyor ve istedigimiz yaricapi kullanabiliyoruz.
        Maximize ve tam ekranda bolge KALDIRILIR: koseler kare olmali.
        """
        import sys

        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
            user32.SetWindowRgn.restype = ctypes.c_int
            user32.SetWindowRgn.argtypes = [wintypes.HWND, wintypes.HANDLE, wintypes.BOOL]
            gdi32.CreateRoundRectRgn.restype = wintypes.HANDLE
            gdi32.CreateRoundRectRgn.argtypes = [ctypes.c_int] * 6

            handle = int(self.winId())
            hwnd = wintypes.HWND(handle)
            radius = self._corner_radius()
            if self.isMaximized() or self.isFullScreen() or radius <= 0:
                user32.SetWindowRgn(hwnd, None, True)
                self._corner_region_key = None
                return

            ratio = self.devicePixelRatioF() or 1.0
            width = max(1, int(round(self.width() * ratio)))
            height = max(1, int(round(self.height() * ratio)))
            diameter = max(0, int(round(radius * ratio))) * 2
            # Tanitici da anahtarin parcasi: pencere gosterilirken Qt native
            # pencereyi yeniden olusturabiliyor ve eski tanitici uzerindeki
            # bolge kayboluyor. Sadece boyuta bakan onbellek yeniden uygulamayi
            # engelliyordu.
            key = (handle, width, height, diameter)
            if getattr(self, "_corner_region_key", None) == key:
                return
            region = gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, diameter, diameter)
            if region:
                # Bolgenin sahipligi sisteme gecer; elle silmiyoruz.
                user32.SetWindowRgn(hwnd, region, True)
                self._corner_region_key = key
        except Exception:
            pass

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        # Pencere gosterilene kadar native tanitici degisebiliyor; kenar bandi
        # stilini ve yuvarlatma bolgesini burada (tekrar) uyguluyoruz.
        self._enable_native_resize_border()
        self._corner_region_key = None
        self._apply_window_corner_region()

    def _speech_choices(self) -> tuple[list[str], list[str], str]:
        return (
            self.speech.available_system_voice_names(),
            self.speech.installed_piper_voice_names(),
            self.speech.current_reference_audio_path(),
        )

    def _refresh_speech_controls(self) -> None:
        system_voices, piper_voices, reference_audio = self._speech_choices()
        for state in self.tab_states.values():
            widget = state.widget
            if isinstance(widget, SettingsPageWidget):
                try:
                    widget.refresh_speech_choices(system_voices, piper_voices, reference_audio)
                except Exception:
                    pass
        if self._speech_dialog is not None:
            try:
                self._speech_dialog.set_installed_piper_voices(piper_voices, getattr(self.config, "tts_piper_voice_name", ""))
                self._speech_dialog.set_reference_audio_path(reference_audio)
            except Exception:
                pass

    def _mode_badge_text(self) -> str:
            # Eski kod: return f"DRM: {self.config.drm_mode} | Ext: {self.config.extension_backend}"
            return f"Ext: {self.config.extension_backend}"

    def _extension_backend_native_enabled(self) -> bool:
        return self.config.extension_backend == "native_when_available"

    def _sync_profile_extensions(self, profile: Any) -> None:
        key = id(profile)
        desired_generation = self.extensions.generation() * 10 + (1 if self._extension_backend_native_enabled() else 0)
        if self._profile_sync_generation.get(key) == desired_generation:
            return
        self.extensions.sync_profile(profile, notifier=self.show_message, native_enabled=self._extension_backend_native_enabled())
        self._profile_sync_generation[key] = desired_generation

    def _sync_profile_language(self, profile: Any) -> None:
        try:
            profile.setHttpAcceptLanguage(accept_language_for(getattr(self.config, "language_code", "system")))
        except Exception:
            pass

    def _extension_overlay_allowed(self, url: str) -> bool:
        try:
            host = (urlparse(url).hostname or "").lower()
        except Exception:
            return False
        if host.endswith("addons.mozilla.org") or host.endswith("open-vsx.org") or host.endswith("github.com") or host.endswith("gitlab.com") or host.endswith("codeberg.org"):
            return True
        return any(token in url.lower() for token in (".xpi", ".crx", ".zip", "extension", "addon"))

    def _extract_web_view(self, widget: QWidget | None) -> QWebEngineView | None:
        if isinstance(widget, QWebEngineView):
            return widget
        if hasattr(widget, 'web_view'):
            try:
                candidate = widget.web_view()
            except Exception:
                candidate = None
            if isinstance(candidate, QWebEngineView):
                return candidate
        return None

    def _focus_tab_content(self, state) -> None:
        """Give the keyboard to the page itself rather than the address bar."""
        widget = getattr(state, "widget", None)
        if widget is None:
            return
        view = self._extract_web_view(widget)
        if view is not None:
            view.setFocus(Qt.FocusReason.OtherFocusReason)
            return
        focus_search = getattr(widget, "focus_search", None)
        if callable(focus_search):
            focus_search()
            return
        widget.setFocus(Qt.FocusReason.OtherFocusReason)

    def _release_address_bar(self, state) -> None:
        """Hand focus to a page the user has just navigated to.

        Only ever takes focus off the address bar, and only while it still shows
        that page's own URL - if the user has started typing somewhere new, the
        keystrokes stay where they put them.
        """
        if not self.url_bar.hasFocus():
            return
        if self.tabs.currentWidget() is not getattr(state, "widget", None):
            return
        if self.url_bar.text().strip() != str(getattr(state, "url", "") or "").strip():
            return
        self._focus_tab_content(state)

    def _responsive_scale(self) -> float:
        width = max(960, self.width())
        scale = 1.0
        if width >= 1500:
            scale = 1.16
        elif width >= 1320:
            scale = 1.10
        elif width <= 1160:
            scale = 0.97
        if self.isMaximized():
            scale += 0.03
        return max(0.95, min(scale, 1.22))

    def _apply_responsive_density(self) -> None:
        scale = self._responsive_scale()
        density = self._toolbar_density_name()
        base_icon = {"compact": 16, "comfortable": 16, "spacious": 18}.get(density, 16)
        address_height = {"compact": 28, "comfortable": 30, "spacious": 34}.get(density, 30)
        add_tab_size = {"compact": 20, "comfortable": 22, "spacious": 24}.get(density, 22)
        icon_px = max(16, int(round(base_icon * scale)))
        self.toolbar.setIconSize(QSize(icon_px, icon_px))
        self.toolbar_overflow_button.setIconSize(QSize(icon_px, icon_px))
        self.url_bar.setFixedHeight(address_height)
        self.container_combo.setFixedHeight(address_height)
        self.add_tab_button.setFixedSize(add_tab_size, add_tab_size)
        self.title_bar.apply_visual_scale(scale)
        for index in range(self.tabs.count()):
            widget = self.tabs.widget(index)
            if isinstance(widget, NewTabWidget):
                widget.apply_density_for_width(widget.width() or self.tabs.width() or self.width())

    def _set_action_widget_visible(self, action: QAction, visible: bool) -> None:
        widget = self.toolbar.widgetForAction(action)
        if widget is not None:
            widget.setVisible(visible)

    def _rebuild_toolbar_overflow_menu(self, actions: list[QAction]) -> None:
        self._toolbar_hidden_actions = list(actions)
        try:
            self.toolbar_overflow_menu.clear()
        except Exception:
            pass
        self.toolbar_overflow_button.setVisible(True)

    def _replaceable_internal_tab_id(self) -> str | None:
        state = self.current_state()
        if state and state.kind == "internal" and state.url.startswith("aster:"):
            return state.tab_id
        return None

    def _ensure_dashboard_popup(self) -> MenuDashboardPopup:
        if self._dashboard_popup is None:
            popup = MenuDashboardPopup(self.dashboard_metrics, self)
            popup.history_requested.connect(self.open_history_page_from_menu)
            popup.bookmarks_requested.connect(self.open_bookmarks_page_from_menu)
            popup.settings_requested.connect(self.open_settings_dialog)
            popup.downloads_requested.connect(self.open_downloads_page_from_menu)
            popup.awareness_requested.connect(self.open_awareness_page_from_menu)
            popup.extensions_requested.connect(self.open_extension_manager_dialog)
            popup.ai_requested.connect(self.open_ai_panel)
            self._dashboard_popup = popup
        return self._dashboard_popup

    def open_dashboard_menu(self) -> None:
        popup = self._ensure_dashboard_popup()
        if popup.isVisible():
            popup.close()
            return
        popup.refresh_stats()
        popup.adjustSize()
        anchor = self.toolbar_overflow_button.mapToGlobal(QPoint(self.toolbar_overflow_button.width() - popup.width(), self.toolbar_overflow_button.height() + 8))
        screen = QApplication.screenAt(anchor) if hasattr(QApplication, 'screenAt') else QApplication.primaryScreen()
        if screen is None:
            screen = QApplication.primaryScreen()
        if screen is not None:
            geom = screen.availableGeometry()
            x = max(geom.left() + 10, min(anchor.x(), geom.right() - popup.width() - 10))
            y = max(geom.top() + 10, min(anchor.y(), geom.bottom() - popup.height() - 10))
        else:
            x = anchor.x()
            y = anchor.y()
        popup.move(x, y)
        popup.show()
        popup.raise_()

    def _apply_native_window_icon(self) -> None:
        """Gorev cubugunda pythonw.exe ikonu yerine Aster ikonu gorunsun.

        Uygulama yorumlayici uzerinden calistigi icin gorev cubugu pencere
        ikonu yerine surec imajinin ikonunu secebiliyor; ikonu ayrica
        WM_SETICON ile dogrudan pencereye de gonderiyoruz.
        """
        import sys

        if sys.platform != "win32":
            return
        ico_path = os.path.join(os.path.dirname(__file__), "assets", "icons", "aster.ico")
        if not os.path.exists(ico_path):
            return
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.LoadImageW.restype = wintypes.HANDLE
            user32.LoadImageW.argtypes = [
                wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
                ctypes.c_int, ctypes.c_int, wintypes.UINT,
            ]
            user32.SendMessageW.restype = wintypes.LPARAM
            user32.SendMessageW.argtypes = [
                wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM,
            ]
            user32.GetSystemMetrics.restype = ctypes.c_int
            user32.GetSystemMetrics.argtypes = [ctypes.c_int]

            IMAGE_ICON, LR_LOADFROMFILE, WM_SETICON = 1, 0x0010, 0x0080
            ICON_SMALL, ICON_BIG = 0, 1
            SM_CXICON, SM_CYICON, SM_CXSMICON, SM_CYSMICON = 11, 12, 49, 50

            self._apply_taskbar_identity(ico_path)
            hwnd = wintypes.HWND(int(self.winId()))
            for which, metrics in (
                (ICON_BIG, (SM_CXICON, SM_CYICON)),
                (ICON_SMALL, (SM_CXSMICON, SM_CYSMICON)),
            ):
                cx = user32.GetSystemMetrics(metrics[0]) or 32
                cy = user32.GetSystemMetrics(metrics[1]) or 32
                handle = user32.LoadImageW(None, ico_path, IMAGE_ICON, cx, cy, LR_LOADFROMFILE)
                if not handle:
                    continue
                # Handle'lari saklıyoruz; pencere yasadigi surece yok edilmemeli.
                self._native_icon_handles.append(handle)
                user32.SendMessageW(
                    hwnd, WM_SETICON, wintypes.WPARAM(which), wintypes.LPARAM(int(handle)),
                )
        except Exception:
            pass

    def _apply_taskbar_identity(self, ico_path: str) -> bool:
        """Gorev cubugu ikonunu pencere ozelliklerinden zorlar.

        Surece ozel bir AppUserModelID atandiginda Windows, gorev cubugu
        dugmesinin ikonunu bu kimlige bagli "relaunch" ozelliklerinden
        cozebiliyor. WM_SETICON'un yetmedigi durumun belgelenmis yolu bu.
        """
        import sys

        if sys.platform != "win32":
            return False
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                            ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]

            class PROPERTYKEY(ctypes.Structure):
                _fields_ = [("fmtid", GUID), ("pid", ctypes.c_uint32)]

            class PROPVARIANT(ctypes.Structure):
                _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort),
                            ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort),
                            ("p", ctypes.c_void_p), ("p2", ctypes.c_void_p)]

            iid = GUID(0x886d8eeb, 0x8cf2, 0x4446,
                       (ctypes.c_ubyte * 8)(0x8d, 0x02, 0xcd, 0xba, 0x1d, 0xbd, 0xcf, 0x99))
            fmtid = GUID(0x9F4C2855, 0x9F79, 0x4B39,
                         (ctypes.c_ubyte * 8)(0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3))

            shell32 = ctypes.WinDLL("shell32", use_last_error=True)
            shell32.SHGetPropertyStoreForWindow.restype = ctypes.c_long
            shell32.SHGetPropertyStoreForWindow.argtypes = [
                wintypes.HWND, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)
            ]

            store = ctypes.c_void_p()
            hwnd = wintypes.HWND(int(self.winId()))
            if shell32.SHGetPropertyStoreForWindow(hwnd, ctypes.byref(iid), ctypes.byref(store)) != 0:
                return False
            if not store:
                return False

            vtable = ctypes.cast(store, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
            set_value = ctypes.WINFUNCTYPE(
                ctypes.c_long, ctypes.c_void_p,
                ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT)
            )(vtable[6])
            commit = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vtable[7])
            release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtable[2])

            def write(pid: int, text: str) -> bool:
                key = PROPERTYKEY(fmtid, pid)
                var = PROPVARIANT()
                var.vt = 31  # VT_LPWSTR
                var.p = ctypes.cast(ctypes.c_wchar_p(text), ctypes.c_void_p)
                return set_value(store, ctypes.byref(key), ctypes.byref(var)) == 0

            results = [
                write(5, "org.aster.browser.desktop.v16"),  # AppUserModel.ID
                write(3, f"{ico_path},0"),                  # RelaunchIconResource
                write(4, "Aster Browser"),                  # RelaunchDisplayNameResource
            ]
            committed = commit(store) == 0
            release(store)
            return all(results) and committed
        except Exception:
            return False

    def _prime_webengine_surface(self) -> None:
        """Ilk web sekmesindeki tek seferlik "kapanip acilma" flasini onler.

        Pencere ilk QWebEngineView'i aldiginda yuzey tipi raster'dan OpenGL'e
        gectigi icin Qt native pencereyi yikip yeniden kuruyor. Pencere daha
        gosterilmeden kisa omurlu bir web view olusturup bu yeniden kurulumu
        gorunmez ana cekiyoruz.

        ASTER_DISABLE_WEBENGINE_PRIME=1 ile kapatilabilir.
        """
        self._webengine_primer = None
        if str(os.environ.get("ASTER_DISABLE_WEBENGINE_PRIME", "")).strip().lower() in {"1", "true", "yes", "on"}:
            return
        try:
            primer = QWebEngineView(self)
            primer.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            primer.setGeometry(0, 0, 1, 1)
            primer.show()
            primer.winId()
            self._webengine_primer = primer
            QTimer.singleShot(2500, self._dispose_webengine_primer)
        except Exception:
            self._webengine_primer = None

    def _dispose_webengine_primer(self) -> None:
        primer = getattr(self, "_webengine_primer", None)
        if primer is None:
            return
        self._webengine_primer = None
        try:
            primer.hide()
            primer.setParent(None)
            primer.deleteLater()
        except Exception:
            pass

    def _set_page_base_color(self, page, loading: bool) -> None:
        """Sayfanin taban rengini yukleme durumuna gore ayarlar.

        QWebEnginePage'in varsayilan arka plani BEYAZ; koyu temada view
        gorunur olur olmaz bu beyaz yuzey tum pencereyi bir kare kapliyor
        ("blinking"). Yuklenirken pencere yuzeyi rengi, yukleme bitince beyaz
        (arka planini kendi vermeyen sayfalar okunabilir kalsin).
        """
        if page is None:
            return
        if loading:
            color = self._window_surface_color()
            color.setAlpha(255)
        else:
            color = QColor(255, 255, 255)
        try:
            page.setBackgroundColor(color)
        except Exception:
            pass

    def _set_tab_page_base_color(self, tab_id: str, loading: bool) -> None:
        state = self.tab_states.get(tab_id)
        view = self._extract_web_view(state.widget if state else None)
        if view is None:
            return
        try:
            self._set_page_base_color(view.page(), loading)
        except Exception:
            pass

    def _sync_profile_scrollbar_style(self, profile) -> None:
        """Web sayfalarinin kaydirma cubugunu her zaman koyu tutar.

        Chromium, sayfa bir renk semasi bildirmediginde acik gri sistem
        kaydirma cubugunu ciziyor; koyu arayuzde beyaz bir seride benziyor.
        Stili profil duzeyinde ve belge olusurken enjekte ediyoruz.
        """
        script_name = "aster-dark-scrollbar"
        try:
            from PyQt6.QtWebEngineCore import QWebEngineScript
        except Exception:
            return
        try:
            scripts = profile.scripts()
            if scripts is None or scripts.find(script_name):
                return
        except Exception:
            return

        css = (
            "html{scrollbar-color:#15181d #05060a!important;scrollbar-width:thin!important;}"
            "::-webkit-scrollbar{width:12px!important;height:12px!important;background:#05060a!important;}"
            "::-webkit-scrollbar-track{background:#05060a!important;}"
            "::-webkit-scrollbar-thumb{background:#2a2f38!important;"
            "border:3px solid #05060a!important;border-radius:8px!important;}"
            "::-webkit-scrollbar-thumb:hover{background:#3a414d!important;}"
            "::-webkit-scrollbar-corner{background:#05060a!important;}"
        )
        payload = json.dumps(css)
        source = (
            "(() => { const apply = () => {"
            " try {"
            "  const root = document.head || document.documentElement;"
            "  if (!root) return;"
            "  let node = document.getElementById('aster-dark-scrollbar');"
            "  if (!node) {"
            "   node = document.createElement('style');"
            "   node.id = 'aster-dark-scrollbar';"
            "   root.appendChild(node);"
            "  }"
            "  node.textContent = " + payload + ";"
            " } catch (error) {} };"
            " apply();"
            " document.addEventListener('DOMContentLoaded', apply);"
            "})();"
        )
        try:
            script = QWebEngineScript()
            script.setName(script_name)
            script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
            script.setRunsOnSubFrames(False)
            try:
                script.setWorldId(int(QWebEngineScript.ScriptWorldId.ApplicationWorld))
            except Exception:
                pass
            script.setSourceCode(source)
            scripts.insert(script)
        except Exception:
            pass

    def _process_cpu_share(self) -> float | None:
        """psutil olmadan surecin CPU payini (0..1) olcer.

        Eski yedek yol os.getloadavg() kullaniyordu; bu fonksiyon Windows'ta
        yok, dolayisiyla CPU hep "-" gorunuyordu.
        """
        import sys
        import time as _time

        if sys.platform != "win32":
            try:
                load = os.getloadavg()[0]
                return max(0.0, min(1.0, load / max(1, os.cpu_count() or 1)))
            except Exception:
                return None
        try:
            import ctypes
            from ctypes import wintypes

            class FILETIME(ctypes.Structure):
                _fields_ = [("dwLowDateTime", wintypes.DWORD),
                            ("dwHighDateTime", wintypes.DWORD)]

            def to_int(ft):
                return (ft.dwHighDateTime << 32) | ft.dwLowDateTime

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.GetProcessTimes.restype = wintypes.BOOL
            kernel32.GetProcessTimes.argtypes = [
                wintypes.HANDLE, ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME),
                ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME),
            ]
            creation, exit_t, kernel_t, user_t = FILETIME(), FILETIME(), FILETIME(), FILETIME()
            if not kernel32.GetProcessTimes(
                kernel32.GetCurrentProcess(),
                ctypes.byref(creation), ctypes.byref(exit_t),
                ctypes.byref(kernel_t), ctypes.byref(user_t),
            ):
                return None

            busy = (to_int(kernel_t) + to_int(user_t)) / 1e7  # 100ns -> saniye
            now = _time.monotonic()
            previous = getattr(self, "_cpu_sample", None)
            self._cpu_sample = (now, busy)
            if previous is None:
                return None
            elapsed = now - previous[0]
            if elapsed <= 0.05:
                return getattr(self, "_cpu_last_share", None)
            cores = max(1, os.cpu_count() or 1)
            share = max(0.0, min(1.0, (busy - previous[1]) / (elapsed * cores)))
            self._cpu_last_share = share
            return share
        except Exception:
            return None

    def dashboard_metrics(self) -> dict:
        """Dashboard pop-up'inin grafiklerini besleyen olcum verisi."""
        rss = self.governor.process_rss_mb()
        cpu_text = "—"
        cpu_ratio = None
        try:
            import psutil  # type: ignore
            process = psutil.Process()
            if not hasattr(self, "_cpu_percent_initialized"):
                process.cpu_percent(None)
                self._cpu_percent_initialized = True
            cpu_value = max(0.0, float(process.cpu_percent(None)))
            cpu_count = max(1, int(psutil.cpu_count() or 1))
            share = cpu_value / cpu_count / 100.0
            cpu_text = f"{share * 100:.0f}%"
            cpu_ratio = share
        except Exception:
            share = self._process_cpu_share()
            if share is None:
                cpu_text = "—"
                cpu_ratio = None
            else:
                cpu_text = f"{share * 100:.0f}%"
                cpu_ratio = share

        snap = self.screen_time_snapshot()
        decision = self.governor.plan(self.collect_snapshots())
        online = self._network_online()
        budget_mb = max(1, int(getattr(self.config, "soft_memory_budget_mb", 1024) or 1024))
        memory_ratio = (float(rss) / budget_mb) if rss is not None else None
        total_tabs = max(1, decision.live_tabs + decision.parked_tabs)
        today_minutes = max(0, int(round((snap.get("today_seconds", 0) or 0) / 60)))
        limit_minutes = max(1, int(snap.get("daily_limit_minutes", 120) or 120))

        return {
            "memory": {"label": tr("Memory"), "value": f"{rss} MB" if rss is not None else "—",
                       "ratio": memory_ratio, "detail": f"of {budget_mb} MB budget"},
            "cpu": {"label": tr("CPU"), "value": cpu_text, "ratio": cpu_ratio,
                    "detail": "process share"},
            "tabs": {"label": tr("Tabs"), "value": f"{decision.live_tabs}/{total_tabs}",
                     "ratio": decision.live_tabs / total_tabs,
                     "detail": f"{decision.live_tabs} live / {decision.parked_tabs} parked"},
            "screen": {"label": tr("Screen"), "value": f"{today_minutes} min",
                       "ratio": today_minutes / limit_minutes,
                       "detail": f"of {limit_minutes} min limit"},
            "network": {"online": bool(online),
                        "value": tr("Online") if online else tr("Offline")},
        }

    def dashboard_metrics_text(self) -> str:
        rss = self.governor.process_rss_mb()
        cpu_text = "—"
        try:
            import psutil  # type: ignore
            process = psutil.Process()
            if not hasattr(self, '_cpu_percent_initialized'):
                process.cpu_percent(None)
                self._cpu_percent_initialized = True
            cpu_value = max(0.0, float(process.cpu_percent(None)))
            cpu_count = max(1, int(psutil.cpu_count() or 1))
            cpu_text = f"{cpu_value / cpu_count:.0f}%"
        except Exception:
            try:
                cpu_text = f"load {os.getloadavg()[0]:.2f}"
            except Exception:
                cpu_text = "—"
        snap = self.screen_time_snapshot()
        decision = self.governor.plan(self.collect_snapshots())
        network_text = tr("online") if self._network_online() else tr("offline")
        memory_text = f"{rss} MB" if rss is not None else "—"
        return (
            tr("Memory usage: {memory}").format(memory=memory_text) + "\n"
            + tr("CPU usage: {cpu}").format(cpu=cpu_text) + "\n"
            + tr("Tabs: {live} live / {parked} parked").format(live=decision.live_tabs, parked=decision.parked_tabs) + "\n"
            + tr("Network: {network} · Today screen time: {minutes} min").format(network=network_text, minutes=max(0, int(round((snap.get("today_seconds", 0) or 0) / 60))))
        )

    def open_ai_panel(self) -> None:
        self.ai_dock.show()
        self.ai_dock.raise_()
        try:
            self.ai_dock.entry.setFocus()
        except Exception:
            pass

    def _update_compact_ui(self) -> None:
        width = self.width()
        overflow: list[QAction] = []
        if width < 1320:
            overflow.extend([self.add_from_page_action, self.extensions_action, self.settings_action])
        if width < 1160:
            overflow.extend([self.park_action, self.lite_action, self.mobile_action])
        if width < 980:
            overflow.extend([self.home_action, self.new_tab_action])
        overflow_ids = {id(action) for action in overflow}
        hidden_by_pref = set()
        if not bool(getattr(self.config, "show_home_button", True)):
            hidden_by_pref.add(id(self.home_action))
        if not bool(getattr(self.config, "show_new_tab_button", True)):
            hidden_by_pref.add(id(self.new_tab_action))
        for action in self.compactable_toolbar_actions:
            self._set_action_widget_visible(action, id(action) not in overflow_ids and id(action) not in hidden_by_pref)
        self._rebuild_toolbar_overflow_menu(overflow)
        self.container_combo.setVisible(width >= 940 and bool(getattr(self.config, "show_container_selector", True)))
        if hasattr(self, 'add_tab_button'):
            self.add_tab_button.setVisible(bool(getattr(self.config, "show_new_tab_button", True)))
        self.title_bar.apply_compact_mode(width < 1120)

    def _show_tab_quick_actions_menu(self, index: int, global_pos: QPoint) -> None:
        state = self._state_for_index(index)
        if state is None:
            return
        self.tabs.setCurrentIndex(index)
        menu = QMenu(self)
        
        # 1. Başlık
        heading = menu.addSection(state.title or state.url or f"Tab {index + 1}")
        heading.setEnabled(False)
        
        # --- 2. YENİ: Kapatma Seçenekleri En Üstte ---
        close_action = menu.addAction(tr("Close tab"))
        close_others_action = menu.addAction(tr("Close other tabs"))
        menu.addSeparator()
        # ---------------------------------------------
        
        # 3. Görünüm ve Ses Ayarları
        view = self._extract_web_view(state.widget)
        is_muted = state.audio_muted
        if view is not None:
            try:
                is_muted = bool(view.page().isAudioMuted())
            except Exception:
                is_muted = state.audio_muted
                
        mute_action = menu.addAction("Unmute sound" if is_muted else "Mute sound")
        mute_action.setEnabled(view is not None)
        
        reload_action = menu.addAction(tr("Reload"))
        reload_action.setEnabled(view is not None)
        
        duplicate_action = menu.addAction(tr("Duplicate tab"))
        
        mobile_action = menu.addAction("Return to desktop view" if state.mobile_mode else "Open mobile view")
        mobile_action.setEnabled(state.kind == "web")
        
        lite_action = menu.addAction(tr("Open in Lite mode"))
        if state.kind == 'parked' or state.kind == 'internal':
            lite_action.setEnabled(False)
            
        park_action = menu.addAction(tr("Park this tab"))
        park_action.setEnabled(state.kind == 'web' and not state.mobile_mode)
        
        menu.addSeparator()
        
        # 4. Sol Tık Menüsü Ayarı
        left_click_label = "Disable left-click tab menu" if getattr(self.config, "active_tab_left_click_menu", True) else "Enable left-click tab menu"
        left_click_toggle_action = menu.addAction(left_click_label)
        
        # Seçimi Yakala
        chosen = menu.exec(global_pos)
        
        # --- EYLEM TETİKLEYİCİLERİ ---
        if chosen == close_action:
            self.close_tab_by_id(state.tab_id)
        elif chosen == close_others_action:
            self.tabs.setCurrentIndex(index)
            self.close_other_tabs()
        elif chosen == mute_action:
            self.toggle_tab_audio(state.tab_id)
        elif chosen == reload_action and view is not None:
            view.reload()
        elif chosen == duplicate_action:
            self.tabs.setCurrentIndex(index)
            self.duplicate_current_tab()
        elif chosen == mobile_action:
            if state.mobile_mode:
                self._open_desktop_for_tab(state.tab_id)
            else:
                self.open_mobile_for_tab(state.tab_id)
        elif chosen == lite_action:
            self.open_lite_for_tab(state.tab_id)
        elif chosen == park_action:
            self._park_tab(state.tab_id, "parked from tab quick actions", allow_visible=True)
            self._refresh_visibility()
            self.show_message(tr("Tab parked for later. It will stay parked until you unpark it."), 9000)
        elif chosen == left_click_toggle_action:
            next_value = not bool(getattr(self.config, "active_tab_left_click_menu", True))
            self.config.active_tab_left_click_menu = next_value
            save_config(self.config)
            self.tab_bar.set_active_tab_left_click_menu_enabled(next_value)
            self.show_message(tr("Enabled active-tab left-click menu.") if next_value else tr("Disabled active-tab left-click menu."))

    def toggle_tab_audio(self, tab_id: str) -> bool:
        state = self.tab_states.get(tab_id)
        if state is None:
            return False
        view = self._extract_web_view(state.widget)
        if view is None:
            return False
        try:
            next_value = not bool(view.page().isAudioMuted())
        except Exception:
            next_value = not state.audio_muted
        try:
            view.page().setAudioMuted(next_value)
        except Exception:
            return False
        state.audio_muted = next_value
        index = self.tabs.indexOf(state.widget)
        if index >= 0:
            self.tabs.setTabText(index, self._tab_label(state))
        self.show_message((tr("Muted tab: {label}") if next_value else tr("Unmuted tab: {label}")).format(label=state.title or state.url))
        return True

    def open_mobile_current(self) -> bool:
        state = self.current_state()
        if state is None or not state.url or state.url == 'aster:newtab':
            return False
        self.open_web_tab(state.url, state.container, replace_tab_id=state.tab_id, mobile_mode=True)
        return True

    def open_mobile_for_tab(self, tab_id: str) -> bool:
        state = self.tab_states.get(tab_id)
        if state is None or not state.url or state.url == 'aster:newtab':
            return False
        current = self.current_state()
        background = current is not None and current.tab_id != tab_id
        self.open_web_tab(state.url, state.container, background=background, replace_tab_id=tab_id, mobile_mode=True)
        return True

    def _open_desktop_for_tab(self, tab_id: str) -> bool:
        state = self.tab_states.get(tab_id)
        if state is None or not state.url or state.url == 'aster:newtab':
            return False
        current = self.current_state()
        background = current is not None and current.tab_id != tab_id
        self.open_web_tab(state.url, state.container, background=background, replace_tab_id=tab_id, mobile_mode=False)
        return True

    def open_desktop_current(self) -> bool:
        state = self.current_state()
        if state is None:
            return False
        return self._open_desktop_for_tab(state.tab_id)

    def _setup_ai_and_plugins(self) -> None:
        actions = {
            "open_url": lambda url: self.open_target(url),
            "open_in_current": self.open_in_current_tab,
            "open_external": self.open_external_target,
            "open_capsule": self.open_capsule_target,
            "search": self.search,
            "find_in_page": self.find_in_page,
            "search_local_documents": self.search_local_documents,
            "search_local_pdfs": self.search_local_pdfs,
            "search_history": self.search_history,
            "open_downloads": self.open_downloads_folder,
            "summarize_selection_or_page": self.summarize_selection_or_page,
            "compare_tabs": self.compare_tabs,
            "list_tabs": self.list_tabs,
            "switch_tab": self.switch_tab,
            "close_current_tab": self.close_current_tab_action,
            "close_tabs_matching": self.close_tabs_matching,
            "close_other_tabs": self.close_other_tabs,
            "bookmark_current_page": self.bookmark_current_page,
            "search_bookmarks": self.search_bookmarks,
            "open_first_bookmark": self.open_first_bookmark,
            "open_first_document": self.open_first_document,
            "open_first_pdf": self.open_first_pdf,
            "list_page_links": self.list_page_links,
            "open_page_link": self.open_page_link,
            "navigate_back": self.navigate_back,
            "navigate_forward": self.navigate_forward,
            "reload_current": self.reload_current,
            "duplicate_current_tab": self.duplicate_current_tab,
            "park_background_tabs": self.park_background_tabs,
            "park_current_tab": self.park_current_tab,
            "open_lite_current": self.open_lite_current,
            "open_mobile_current": self.open_mobile_current,
            "open_desktop_current": self.open_desktop_current,
            "get_current_container": self.active_container,
            "set_container": self.set_active_container,
            "stats": self.stats_text,
            "streaming_status": self.streaming_status_text,
            "capsule_status": self.capsule_status_text,
            "wireguard_status": self.wireguard_status,
            "list_extensions": self.list_extensions_text,
            "install_extension": self.install_extension_path,
            "install_extension_from_page": self.install_extension_from_current_page_command,
            "toggle_extension": self.toggle_extension_query,
            "remove_extension": self.remove_extension_query,
            "reload_extensions": self.reload_extensions_runtime,
            "diagnose_current_page": self.diagnose_current_page,
        }
        self.command_router = CommandRouter(actions)
        self.intent_router = IntentRouter(actions)
        self.ai_dock = AIDockWidget(self.current_broker, self.command_router, self.intent_router, self.current_ai_context, self.config.allow_ai_actions, self)
        self.ai_dock.setObjectName("AsterAIDock")
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.ai_dock)
        self.ai_dock.hide()

        api = AppAPI({"show_message": self.show_message, "open_url": lambda url, background=False: self.open_target(url, background=background), "park_background_tabs": self.park_background_tabs}, self.command_router)
        self.plugin_manager = PluginManager([bundled_plugins_dir(), user_plugins_dir()], api)
        loaded = self.plugin_manager.load_all()
        if loaded:
            self.show_message(tr("Loaded {count} plugin(s).").format(count=len(loaded)))

    def current_broker(self) -> AIBroker:
        ai_cfg = self.config.ai
        return AIBroker(
            ai_cfg.provider,
            ai_cfg.model,
            ai_cfg.base_url,
            ai_cfg.api_key_env,
            ai_cfg.system_prompt,
            getattr(ai_cfg, "persona", "dr_light_lab"),
            getattr(ai_cfg, "reasoning_mode", "balanced"),
        )

    def current_ai_context(self) -> AIContext:
        state = self.current_state()
        if not state:
            return AIContext()
        selected_text = self._current_selected_text()
        previous_title = ''
        previous_url = ''
        previous_page_text = ''
        if self.previous_tab_id and self.previous_tab_id in self.tab_states:
            previous_state = self.tab_states[self.previous_tab_id]
            previous_title = previous_state.title
            previous_url = previous_state.url
            previous_page_text = previous_state.page_text
        return AIContext(
            url=state.url,
            title=state.title,
            container=state.container,
            page_text=state.page_text,
            page_links=state.page_links,
            selected_text=selected_text,
            previous_title=previous_title,
            previous_url=previous_url,
            previous_page_text=previous_page_text,
        )

    def _build_adblock_ruleset(self) -> AdblockRuleset:
        return AdblockRuleset.from_sources(
            rules_dir() / "default_blocklist.txt",
            strict=bool(getattr(self.config, "strict_adblock", False)),
            mode=str(getattr(self.config, "adblock_mode", "balanced") or "balanced"),
            custom_rules=str(getattr(self.config, "adblock_custom_rules", "") or ""),
            allow_hosts=list(getattr(self.config, "adblock_allow_hosts", []) or []),
            block_hosts=list(getattr(self.config, "adblock_block_hosts", []) or []),
            streaming_allowlist=bool(getattr(self.config, "adblock_streaming_allowlist", True)),
        )

    def _adblock_enabled_now(self) -> bool:
        mode = str(getattr(self.config, "adblock_mode", "balanced") or "balanced").strip().lower()
        return bool(getattr(self.config, "adblock_enabled", True)) and mode != "off"

    def _make_interceptor(self) -> AdblockInterceptor:
        return AdblockInterceptor(self.ruleset, enabled=self._adblock_enabled_now())

    def _sync_adblock_interceptors(self) -> None:
        for interceptor in getattr(self.containers, "_interceptors", {}).values():
            try:
                interceptor.ruleset = self.ruleset
                interceptor.enabled = self._adblock_enabled_now()
            except Exception:
                pass

    def active_container(self) -> str:
        text = self.container_combo.currentText().strip()
        return text or self.config.default_container

    def set_active_container(self, name: str) -> None:
        name = self.containers.ensure(name)
        if self.container_combo.findText(name) < 0:
            self.container_combo.addItem(name)
        self.container_combo.setCurrentText(name)
        if name not in self.config.containers:
            self.config.containers.append(name)
            save_config(self.config)

    def _resolve_target(self, text: str) -> tuple[str, str]:
        text = text.strip()
        if not text:
            return ("internal", self.config.homepage)
        lowered = text.lower()
        if lowered in {"aster:newtab", "about:newtab", "newtab"}:
            return ("internal", "aster:newtab")
        if lowered in {"aster:settings", "settings"}:
            return ("internal", "aster:settings")
        if lowered == "aster:history":
            return ("internal", "aster:history")
        if lowered == "aster:bookmarks":
            return ("internal", "aster:bookmarks")
        if lowered == "aster:downloads":
            return ("internal", "aster:downloads")
        if lowered == "aster:awareness":
            return ("internal", "aster:awareness")
        if lowered in {"aster:flags", "about:flags", "flags"}:
            return ("internal", "aster:flags")
        if lowered in {"aster:taskmgr", "about:taskmgr", "taskmgr"}:
            return ("internal", "aster:taskmgr")
        if lowered == "about:blank":
            return ("web", text)
        if "://" in text or text.startswith("file://"):
            return ("web", text)
        if " " not in text and "." in text:
            return ("web", f"https://{text}")
        return ("search", text)

    def open_target(self, target: str, background: bool = False, replace_tab_id: str | None = None, container: str | None = None, bypass_drm_redirect: bool = False) -> TabState:
        kind, value = self._resolve_target(target)
        if kind == "internal":
            if value == "aster:settings":
                return self.open_settings_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:history":
                return self.open_history_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:bookmarks":
                return self.open_bookmarks_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:downloads":
                return self.open_downloads_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:awareness":
                return self.open_awareness_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:flags":
                return self.open_flags_tab(background=background, replace_tab_id=replace_tab_id)
            if value == "aster:taskmgr":
                return self.open_taskmgr_tab(background=background, replace_tab_id=replace_tab_id)
            return self.open_new_tab_page(background=background, replace_tab_id=replace_tab_id)
        url = build_search_url(self.config.search_engine, value) if kind == "search" else value
        selected_container = container or self.active_container()
        if not bypass_drm_redirect:
            redirected = self._maybe_redirect_streaming(url, selected_container, background, replace_tab_id)
            if redirected is not None:
                return redirected
        return self.open_web_tab(url, selected_container, background, replace_tab_id)

    def _maybe_redirect_streaming(self, url: str, container: str, background: bool, replace_tab_id: str | None) -> TabState | None:
        service = known_drm_service(url)
        if not service:
            return None
        mode = str(getattr(self.config, "drm_mode", "chromium_drm_capsule") or "chromium_drm_capsule").strip().lower()
        if mode == "chromium_drm_capsule":
            launch = self.capsules.launch(url)
            if launch.ok:
                self.show_message(tr("Opened {service} in Aster Chromium DRM capsule. Chrome is not required.").format(service=service), 10000)
            else:
                self.show_message(launch.note, 10000)
            reason = (
                f"{service} was routed to Aster's Chromium DRM capsule. "
                "This is a separate profile/runtime inside the Aster package path, designed for DRM streaming and cloud-gaming compatibility without installing Chrome. "
                "If the runtime is not installed yet, run tools/setup_chromium_drm_capsule.sh or reinstall with --with-drm-capsule."
            )
            return self.open_capsule_tab(url, container, reason, launch, background, replace_tab_id)
        if mode == "qtwebengine_capsule":
            reason = (
                f"{service} was opened in Aster's built-in Qt WebEngine compatibility capsule. "
                "This uses the PyQt6-WebEngine Chromium runtime bundled by Aster, so the user does not need system Chromium installed. "
                "Protected DRM playback can still require Widevine/proprietary codec support from the platform."
            )
            self.show_message(tr("Opened {service} in Aster compatibility mode.").format(service=service), 9000)
            return self.open_compatibility_web_tab(url, container, reason, background, replace_tab_id)
        if not should_redirect_externally(url, self.streaming_support):
            return None
        launch = self.capsules.launch(url)
        if launch.ok:
            self.show_message(tr("Opened {service} in a managed streaming capsule.").format(service=service))
        else:
            self.show_message(launch.note)
        reason = redirect_reason(url, self.streaming_support)
        return self.open_capsule_tab(url, container, reason, launch, background, replace_tab_id)

    def open_external_target(self, url: str | None = None) -> bool:
        target = (url or "").strip()
        if not target:
            state = self.current_state()
            target = state.url if state else ""
        if not target or target == "aster:newtab":
            return False
        opened = open_external(target, self.streaming_support.external_browser_command)
        if opened:
            self.show_message(tr("Opened externally: {target}").format(target=target))
        else:
            self.show_message(tr("Could not open externally: {target}").format(target=target))
        return opened

    def open_capsule_target(self, url: str | None = None) -> bool:
        target = (url or "").strip()
        state = self.current_state()
        if not target and state is not None:
            target = state.url
        if not target or target == "aster:newtab":
            return False
        container = state.container if state else self.active_container()
        launch = self.capsules.launch(target)
        self.show_message(launch.note)
        replace_tab_id = state.tab_id if state and state.url == target else None
        reason = "Opened manually in a managed streaming capsule."
        self.open_capsule_tab(target, container, reason, launch, background=False, replace_tab_id=replace_tab_id)
        return launch.ok
    
    def open_flags_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = FlagsPageWidget()
        state = TabState(kind="internal", title=tr("Aster Experiments"), url="aster:flags", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=8)
        self._insert_state(state, background, replace_tab_id)
        return state
    
    def _get_taskmgr_stats(self) -> dict:
        rss = self.governor.process_rss_mb()
        network = "Online" if self._network_online() else "Offline"
        decision = self.governor.plan(self.collect_snapshots())
        return {
            "rss": rss if rss else "—",
            "network": network,
            "live": decision.live_tabs,
            "parked": decision.parked_tabs
        }

    def _get_taskmgr_tabs(self) -> list[dict]:
        tabs = []
        for state in self._ordered_states():
            tabs.append({
                "id": state.tab_id,
                "title": state.title or "Untitled",
                "url": state.url,
                "kind": state.kind,
                "memory": state.estimated_cost_mb or 0
            })
        # En çok RAM harcayan en üstte olsun diye sıralıyoruz
        tabs.sort(key=lambda x: x["memory"], reverse=True)
        return tabs

    def open_taskmgr_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = TaskManagerWidget(
            get_tabs_cb=self._get_taskmgr_tabs,
            close_tab_cb=self.close_tab_by_id,
            get_stats_cb=self._get_taskmgr_stats
        )
        state = TabState(kind="internal", title=tr("Task Manager"), url="aster:taskmgr", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=10)
        self._insert_state(state, background, replace_tab_id)
        return state
    
    def search(self, query: str) -> None:
        self.open_target(build_search_url(self.config.search_engine, query))

    def search_local_documents(self, query: str) -> str:
        assistant = LocalAssistant(self.local_index)
        return assistant.search_documents(query)

    def search_local_pdfs(self, query: str) -> str:
        assistant = LocalAssistant(self.local_index)
        return assistant.search_documents(query, pdf_only=True)

    def search_history(self, query: str) -> str:
        assistant = LocalAssistant(self.local_index)
        return assistant.search_history(query)

    def list_extensions_text(self) -> str:
        records = self.extensions.list_records()
        native_supported = False
        for profile in self.containers.profiles():
            if self.extensions.supports_native_loader(profile):
                native_supported = True
                break
        prefix = "Extension runtime: native MV3 loader available.\n" if native_supported else "Extension runtime: native MV3 loader not detected yet; Aster will still use fallback content scripts when possible.\n"
        return prefix + self.extensions.summary_text()

    def install_extension_path(self, source: str) -> str:
        source = (source or '').strip()
        if not source:
            return 'Usage: provide a path to an unpacked extension directory, .zip, .xpi, or .crx file.'
        try:
            record = self.extensions.install(source)
            self._sync_extensions_to_profiles()
            return f'Installed extension: {record.name} ({record.runtime_kind})'
        except Exception as exc:
            return f'Extension install failed: {exc}'

    def toggle_extension_query(self, query: str) -> str:
        query = (query or '').strip()
        if not query:
            return 'Usage: provide an extension name or ID.'
        record = self.extensions.find_record(query)
        if record is None:
            return f'No extension matched "{query}".'
        updated = self.extensions.set_enabled(record.ext_id, not record.enabled)
        if updated is None:
            return f'No extension matched "{query}".'
        self._sync_extensions_to_profiles()
        state = 'enabled' if updated.enabled else 'disabled'
        return f'{updated.name} is now {state}.'

    def remove_extension_query(self, query: str) -> str:
        query = (query or '').strip()
        if not query:
            return 'Usage: provide an extension name or ID.'
        removed = self.extensions.remove(query)
        if removed is None:
            return f'No extension matched "{query}".'
        self._sync_extensions_to_profiles()
        return f'Removed extension: {removed.name}'

    def reload_extensions_runtime(self) -> str:
        self._sync_extensions_to_profiles()
        return 'Reloaded extension runtime across open profiles.'

    def install_extension_from_web_url(self, source_url: str, label: str = "") -> str:
        target = (source_url or "").strip()
        if not target:
            message = "This page did not expose a direct extension package yet."
            self.show_message(message)
            return message
        reply = QMessageBox.question(
            self,
            tr("Install extension into Aster"),
            f"Install this extension into Aster?\n\n{target}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if reply != QMessageBox.StandardButton.Yes:
            message = "Extension install cancelled."
            self.show_message(message)
            return message
        try:
            record = self.extensions.install_from_url(target, suggested_name=label)
            self._sync_extensions_to_profiles()
            message = f"Installed extension from web: {record.short_label}"
            self.show_message(message)
            return message
        except Exception as exc:
            message = f"Extension web install failed: {exc}"
            self.show_message(message)
            return message

    def install_extension_from_current_page(self) -> bool:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if not state or view is None:
            self.show_message(tr("Open a webpage first, then use Add from page."))
            return False
        view.page().runJavaScript(self._extension_candidate_script(), self._handle_extension_candidate_result)
        return True

    def install_extension_from_current_page_command(self) -> str:
        ok = self.install_extension_from_current_page()
        return "Checking this page for an installable extension package…" if ok else "Open a webpage first, then try Add from page."

    def _handle_extension_candidate_result(self, result: Any) -> None:
        if isinstance(result, dict) and result.get("unsupported") == "chrome_web_store":
            message = (
                "Chrome Web Store pages cannot be installed directly in Aster. Use a downloaded .crx/unpacked extension, "
                "or use a site that exposes a direct .zip/.xpi/.crx package."
            )
            QMessageBox.information(self, tr("Chrome Web Store"), message)
            self.show_message(message)
            return
        if not isinstance(result, dict) or not str(result.get("href", "")).strip():
            message = "No direct .zip/.xpi/.crx extension package was found on this page."
            self.show_message(message)
            return
        self.install_extension_from_web_url(str(result.get("href", "")), str(result.get("label", "")))

    def _extension_candidate_script(self) -> str:
        return r"""
(() => {
  const trim = (value) => String(value || '').trim();
  const lower = (value) => trim(value).toLowerCase();
  const host = lower(location.hostname);
  
  // --- CHROME WEB STORE ÖZEL DESTEĞİ ---
  if (host === 'chromewebstore.google.com' || host.endsWith('.chromewebstore.google.com') || host.endsWith('.chrome.google.com')) {
    // Uzantı sayfalarındaki 32 karakterlik ID'yi yakalar (örn: cjpalhdlnbpafiamejdnhcphjbkeiagm)
    const match = location.pathname.match(/\/detail\/([^\/]+\/)?([a-z]{32})/);
    if (match && match[2]) {
      const extId = match[2];
      // Google'ın gizli API'sini kullanarak doğrudan .crx indirme linki oluşturur
      const crxUrl = `https://clients2.google.com/service/update2/crx?response=redirect&prodversion=120.0.0.0&acceptformat=crx2,crx3&x=id%3D${extId}%26uc`;
      return { supported: true, href: crxUrl, kind: 'crx', label: trim(document.title || 'Chrome Extension') };
    }
    return null; // Mağazanın ana sayfasındaysa işlem yapma
  }
  // ----------------------------------------
  
  const anchors = Array.from(document.querySelectorAll('a[href]'));
  let best = null;
  let bestScore = -1;
  for (const anchor of anchors) {
    const href = trim(anchor.href);
    if (!href) continue;
    const hrefLower = lower(href);
    const text = lower(anchor.innerText || anchor.textContent || anchor.getAttribute('aria-label') || '');
    let score = 0;
    let kind = '';
    if (hrefLower.endsWith('.xpi') || hrefLower.includes('.xpi?')) { score += 120; kind = 'xpi'; }
    if (hrefLower.endsWith('.crx') || hrefLower.includes('.crx?')) { score += 110; kind = kind || 'crx'; }
    if (hrefLower.endsWith('.zip') || hrefLower.includes('.zip?')) { score += 90; kind = kind || 'zip'; }
    if (host.includes('addons.mozilla.org') && hrefLower.includes('/downloads/file/')) { score += 95; kind = kind || 'xpi'; }
    if (text.includes('download file')) score += 70;
    if (text.includes('install') || text.includes('download') || text.includes('add to firefox')) score += 25;
    if (anchor.hasAttribute('download')) score += 20;
    if (score > bestScore) {
      bestScore = score;
      best = { href, text, kind, score };
    }
  }
  if (best && best.score >= 90) {
    return { supported: true, href: best.href, kind: best.kind || 'archive', label: trim(document.title || '') };
  }
  return null;
})()
""".strip()

    def _extension_overlay_script(self) -> str:
        detector = self._extension_candidate_script()
        return rf"""
(() => {{
  const detector = () => ({detector});
  const rootId = '__aster-add-extension';
  const styleId = '__aster-add-extension-style';
  const removeExisting = () => {{
    const old = document.getElementById(rootId);
    if (old) old.remove();
  }};
  const ensureStyle = () => {{
    if (document.getElementById(styleId)) return;
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `#${{rootId}}{{position:fixed;top:18px;right:18px;z-index:2147483647;display:flex;gap:8px;align-items:center;font-family:sans-serif;}}
#${{rootId}} .aster-add-btn{{border:0;border-radius:999px;padding:10px 14px;font-weight:700;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.25);background:#ffffff;color:#0c0e12;}}
#${{rootId}} .aster-add-note{{border-radius:999px;padding:8px 12px;background:rgba(17,24,39,.92);color:#fff;font-size:12px;box-shadow:0 4px 18px rgba(0,0,0,.25);max-width:420px;}}`;
    (document.head || document.documentElement).appendChild(style);
  }};
  const render = () => {{
    const result = detector();
    removeExisting();
    if (!result) return;
    ensureStyle();
    const root = document.createElement('div');
    root.id = rootId;
    if (result.unsupported === 'chrome_web_store') {{
      const note = document.createElement('div');
      note.className = 'aster-add-note';
      note.textContent = 'Chrome Web Store direct install is not available in Aster. Use a direct package download instead.';
      root.appendChild(note);
    }} else if (result.href) {{
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'aster-add-btn';
      button.textContent = 'Add to Aster';
      button.addEventListener('click', (event) => {{
        event.preventDefault();
        event.stopPropagation();
        location.href = 'aster://install-extension?source=' + encodeURIComponent(String(result.href || '')) + '&label=' + encodeURIComponent(String(document.title || ''));
      }});
      root.appendChild(button);
    }}
    (document.body || document.documentElement).appendChild(root);
  }};
  try {{
    if (window.__asterAddExtObserver) {{
      try {{ window.__asterAddExtObserver.disconnect(); }} catch (e) {{}}
    }}
    const observer = new MutationObserver(() => {{
      clearTimeout(window.__asterAddExtTimer);
      window.__asterAddExtTimer = setTimeout(render, 250);
    }});
    observer.observe(document.documentElement || document, {{ childList: true, subtree: true }});
    window.__asterAddExtObserver = observer;
  }} catch (e) {{}}
  render();
  return true;
}})()
""".strip()

    def install_extension_file_dialog(self) -> str:
        chosen, _ = QFileDialog.getOpenFileName(
            self,
            tr('Install browser extension'),
            str(Path.home()),
            tr('Browser extensions (*.zip *.xpi *.crx);;All files (*)'),
        )
        if not chosen:
            return 'Extension install cancelled.'
        return self.install_extension_path(chosen)

    def install_extension_folder_dialog(self) -> str:
        chosen = QFileDialog.getExistingDirectory(self, 'Install unpacked browser extension', str(Path.home()))
        if not chosen:
            return 'Extension install cancelled.'
        return self.install_extension_path(chosen)

    def open_extension_manager_dialog(self) -> None:
        dialog = ExtensionManagerDialog(
            self.extensions.list_records,
            self.install_extension_file_dialog,
            self.install_extension_folder_dialog,
            self.toggle_extension_query,
            self.remove_extension_query,
            self.reload_extensions_runtime,
            self,
        )
        dialog.exec()

    def _sync_extensions_to_profiles(self) -> None:
        self._profile_sync_generation.clear()
        for profile in self.containers.profiles():
            try:
                self._sync_profile_extensions(profile)
            except Exception as exc:
                self.show_message(f'Extension sync failed: {exc}')

    def list_tabs(self) -> str:
        if self.tabs.count() == 0:
            return "No tabs are open."
        current = self.current_state()
        lines = ["Open tabs:"]
        for index in range(self.tabs.count()):
            state = self._state_for_index(index)
            if not state:
                continue
            marker = "*" if current and state.tab_id == current.tab_id else " "
            label = (state.title or state.url or "Tab").strip()
            kind = state.kind
            lines.append(f"{index + 1}. {marker} {label} [{kind} | {state.container}]")
        return "\n".join(lines)

    def _ordered_states(self) -> list[TabState]:
        ordered: list[TabState] = []
        for index in range(self.tabs.count()):
            state = self._state_for_index(index)
            if state is not None:
                ordered.append(state)
        return ordered

    def switch_tab(self, target: str) -> str:
        target = (target or '').strip()
        ordered = self._ordered_states()
        if not ordered:
            return 'No tabs are open.'
        if target.isdigit():
            index = int(target) - 1
            if 0 <= index < len(ordered):
                self.tabs.setCurrentIndex(index)
                state = ordered[index]
                return f'Switched to tab {index + 1}: {state.title or state.url}'
            return f'No tab numbered {target}.'
        lowered = target.lower()
        best_index = -1
        best_score = -1
        best_state: TabState | None = None
        for index, state in enumerate(ordered):
            haystack = f"{state.title} {state.url}".lower()
            score = 0
            if lowered == (state.title or '').lower() or lowered == state.url.lower():
                score = 100
            elif lowered and lowered in (state.title or '').lower():
                score = 80
            elif lowered and lowered in state.url.lower():
                score = 60
            elif lowered:
                terms = [term for term in lowered.split() if term]
                score = sum(8 for term in terms if term in haystack)
            if score > best_score:
                best_score = score
                best_state = state
                best_index = index
        if best_state is None or best_score <= 0:
            return f'No open tab matched "{target}".'
        self.tabs.setCurrentIndex(best_index)
        return f'Switched to tab {best_index + 1}: {best_state.title or best_state.url}'

    def close_current_tab_action(self) -> bool:
        state = self.current_state()
        if state is None:
            return False
        self.close_tab_by_id(state.tab_id)
        return True

    def close_tabs_matching(self, query: str) -> int:
        query = (query or '').strip().lower()
        if not query:
            return 0
        current = self.current_state()
        to_close: list[str] = []
        for state in self._ordered_states():
            haystack = f"{state.title} {state.url}".lower()
            if query in haystack and (current is None or state.tab_id != current.tab_id):
                to_close.append(state.tab_id)
        for tab_id in to_close:
            self.close_tab_by_id(tab_id)
        return len(to_close)

    def close_other_tabs(self) -> int:
        current = self.current_state()
        if current is None:
            return 0
        to_close = [state.tab_id for state in self._ordered_states() if state.tab_id != current.tab_id]
        for tab_id in to_close:
            self.close_tab_by_id(tab_id)
        return len(to_close)

    def history_entries(self, query: str = "") -> list[HistoryResult]:
        query = (query or "").strip()
        if query:
            return self.local_index.search_history(query, limit=200)
        return self.local_index.list_history(limit=200)

    def bookmark_entries(self, query: str = "") -> list[BookmarkResult]:
        query = (query or "").strip()
        if query:
            return self.local_index.search_bookmarks(query, limit=200)
        return self.local_index.list_bookmarks(limit=200)

    def remove_bookmark_entry(self, url: str) -> bool:
        ok = self.local_index.remove_bookmark(url)
        self.show_message(tr("Removed bookmark.") if ok else tr("Bookmark was not found."))
        return ok
    
    def _handle_bookmark_action(self) -> None:
        message = self.bookmark_current_page()
        
        if "Saved" in message:
            self._bookmark_popup = FocusNotification(tr("Bookmark Saved"), message)
            self._bookmark_popup.adjustSize()
            
            # --- SAĞ ÜSTTEKİ MENÜ BUTONUNU HEDEF ALIYORUZ ---
            # toolbar_overflow_button sağ üstteki üç noktalı/menü ikonudur.
            target = self.toolbar_overflow_button
            
            # Butonun ekran üzerindeki gerçek pozisyonunu buluyoruz.
            # Menü butonunun sol alt köşesini referans alıyoruz ki pop-up tam altına hizalansın.
            anchor_pos = target.mapToGlobal(QPoint(0, target.height() + 5))
            
            # Pop-up'ın sağ kenarının butonun sağ kenarını aşmaması (ekrandan taşmaması) için 
            # X ekseninde pop-up'ın genişliği kadar geriye çekiyoruz.
            x_pos = target.mapToGlobal(QPoint(target.width(), 0)).x() - self._bookmark_popup.width()
            
            # Bulduğumuz X (sağa hizalı) ve Y (butonun 5px altı) noktalarına taşıyoruz
            self._bookmark_popup.move(x_pos, anchor_pos.y())
            # ------------------------------------------------
            
            self._bookmark_popup.show()
        else:
            self.show_message(message)

    def bookmark_current_page(self) -> str:
        state = self.current_state()
        if not state or not state.url or state.url == 'aster:newtab':
            return tr("There is no normal page open to bookmark right now.")
        self.local_index.add_bookmark(state.url, state.title)
        return tr("Saved bookmark: {label}").format(label=state.title or state.url)

    def search_bookmarks(self, query: str) -> str:
        assistant = LocalAssistant(self.local_index)
        return assistant.search_bookmarks(query)

    def open_first_bookmark(self, query: str) -> str:
        query = (query or '').strip()
        assistant = LocalAssistant(self.local_index)
        matches = assistant.bookmark_matches(query, limit=1)
        if not matches:
            return f'No saved bookmark matched "{query}".' if query else 'No saved bookmarks yet.'
        match = matches[0]
        self.local_index.touch_bookmark(match.url)
        self.open_target(match.url)
        return f'Opening bookmark: {match.title or match.url}'

    def open_first_document(self, query: str) -> str:
        query = (query or '').strip()
        assistant = LocalAssistant(self.local_index)
        matches = assistant.document_matches(query, limit=1, pdf_only=False)
        if not matches:
            return f'No local document matched "{query}".'
        match = matches[0]
        ok = bool(QDesktopServices.openUrl(QUrl.fromLocalFile(str(match.path.resolve()))))
        return f'Opened local document: {match.path}' if ok else f'Could not open local document: {match.path}'

    def open_first_pdf(self, query: str) -> str:
        query = (query or '').strip()
        assistant = LocalAssistant(self.local_index)
        matches = assistant.document_matches(query, limit=1, pdf_only=True)
        if not matches:
            return f'No local PDF matched "{query}".'
        match = matches[0]
        ok = bool(QDesktopServices.openUrl(QUrl.fromLocalFile(str(match.path.resolve()))))
        return f'Opened local PDF: {match.path}' if ok else f'Could not open local PDF: {match.path}'

    def list_page_links(self) -> str:
        assistant = LocalAssistant(self.local_index)
        return assistant.list_page_links(self.current_ai_context())

    def open_page_link(self, target: str) -> str:
        state = self.current_state()
        if not state or not state.page_links:
            return 'I could not find any readable links on the current page.'
        target = (target or '').strip()
        match_href = ''
        match_label = ''
        if target.isdigit():
            index = int(target) - 1
            if 0 <= index < len(state.page_links):
                match_label, match_href = state.page_links[index]
            else:
                return f'No page link numbered {target}.'
        else:
            lowered = target.lower()
            for label, href in state.page_links:
                label_text = (label or href).lower()
                href_text = href.lower()
                if lowered and (lowered in label_text or lowered in href_text):
                    match_label, match_href = label or href, href
                    break
        if not match_href:
            return f'No current-page link matched "{target}".'
        replace_tab_id = state.tab_id if state.kind == 'web' else None
        self.open_target(match_href, replace_tab_id=replace_tab_id, container=state.container)
        return f'Opening page link: {match_label or match_href}'

    def navigate_back(self) -> bool:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            view.back()
            return True
        return False

    def navigate_forward(self) -> bool:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            view.forward()
            return True
        return False

    def reload_current(self) -> bool:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            view.reload()
            return True
        return False

    def duplicate_current_tab(self) -> bool:
        state = self.current_state()
        if not state or not state.url or state.url == 'aster:newtab':
            return False
        self.open_target(state.url, background=True, container=state.container)
        return True

    def open_in_current_tab(self, target: str) -> str:
        state = self.current_state()
        replace_tab_id = state.tab_id if state is not None else None
        container = state.container if state is not None else None
        opened = self.open_target(target, replace_tab_id=replace_tab_id, container=container)
        return f'Opening {opened.url}'

    def open_downloads_folder(self) -> bool:
        target = downloads_dir()
        target.mkdir(parents=True, exist_ok=True)
        return bool(QDesktopServices.openUrl(QUrl.fromLocalFile(str(target.resolve()))))

    def summarize_selection_or_page(self) -> str:
        assistant = LocalAssistant(self.local_index)
        context = self.current_ai_context()
        if context.selected_text.strip():
            return assistant.summarize_selection(context)
        return assistant.summarize_page(context)

    def compare_tabs(self) -> str:
        assistant = LocalAssistant(self.local_index)
        context = self.current_ai_context()
        return assistant.ask('compare these two tabs', context)

    def _current_selected_text(self) -> str:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            try:
                return view.page().selectedText().strip()
            except Exception:
                return ''
        return ''

    def speak_text(self, text: str) -> bool:
        message = self.speech.speak_text(text)
        self.show_message(message, 7000)
        return "failed" not in message.lower() and "no " not in message.lower() if message else False

    def stop_speaking(self) -> bool:
        message = self.speech.stop()
        self.show_message(message, 5000)
        if self._speech_dialog is not None:
            try:
                self._speech_dialog.set_status(message)
            except Exception:
                pass
        return True

    def read_selection_aloud(self) -> bool:
        text = self._current_selected_text()
        if not text:
            self.show_message(tr("Select some text on the page first."))
            return False
        return self.speak_text(text)

    def read_page_aloud(self) -> bool:
        state = self.current_state()
        if state is None:
            self.show_message(tr("Open a page first."))
            return False
        if state.page_text.strip():
            return self.speak_text(state.page_text)
        view = self._extract_web_view(state.widget)
        if view is None:
            self.show_message(tr("Read page aloud works on full web tabs."))
            return False
        chars = max(1000, min(120000, int(getattr(self.config, "ai_page_context_chars", 6000) or 6000) * 8))
        script = f"(() => {{ try {{ return document.body ? document.body.innerText.slice(0, {chars}) : ''; }} catch (e) {{ return ''; }} }})()"
        view.page().runJavaScript(script, lambda text, rid=state.tab_id: self._speak_captured_page_text(rid, text))
        self.show_message(tr("Capturing page text for read-aloud…"))
        return True

    def _speak_captured_page_text(self, tab_id: str, text) -> None:
        state = self.tab_states.get(tab_id)
        payload = str(text or "").strip()
        if state is not None:
            state.page_text = payload
        if not payload:
            self.show_message(tr("There was no readable text on this page."))
            return
        self.speak_text(payload)

    def read_text_file_aloud(self) -> bool:
        chosen, _ = QFileDialog.getOpenFileName(
            self,
            tr("Choose a text file to read aloud"),
            str(Path.home()),
            tr("Text and markup files (*.txt *.md *.markdown *.rst *.log *.json *.csv *.html *.htm *.xml *.yml *.yaml);;All files (*)"),
        )
        if not chosen:
            return False
        try:
            payload = Path(chosen).read_text(encoding="utf-8", errors="ignore")
        except Exception as exc:
            self.show_message(tr("Could not open that file: {error}").format(error=exc))
            return False
        payload = payload.strip()
        if not payload:
            self.show_message(tr("That file does not contain readable text."))
            return False
        if len(payload) > 200000:
            payload = payload[:200000]
            self.show_message(tr("The file was long, so Aster is reading the first part only."), 7000)
        return self.speak_text(payload)

    def _persist_speech_config(self, message: str) -> None:
        self.speech.update_config(self.config)
        save_config(self.config)
        self._refresh_speech_controls()
        if self._speech_dialog is not None:
            try:
                self._speech_dialog.set_status(message)
            except Exception:
                pass
        self.show_message(message, 7000)

    def open_speech_tools_dialog(self) -> None:
        dialog = self._speech_dialog
        if dialog is not None:
            try:
                dialog.show()
                dialog.raise_()
                dialog.activateWindow()
                self._refresh_speech_controls()
                return
            except Exception:
                self._speech_dialog = None
        dialog = SpeechToolsDialog(self.config, self)
        dialog.install_piper_voice_requested.connect(self._install_piper_voice_from_dialog)
        dialog.remove_piper_voice_requested.connect(self._remove_piper_voice_from_dialog)
        dialog.import_reference_requested.connect(self._import_reference_audio_from_dialog)
        dialog.start_recording_requested.connect(self._start_reference_recording_from_dialog)
        dialog.stop_recording_requested.connect(self._stop_reference_recording_from_dialog)
        dialog.clear_reference_requested.connect(self._clear_reference_audio_from_dialog)
        dialog.read_file_requested.connect(self.read_text_file_aloud)
        dialog.speak_test_requested.connect(lambda text: self.speak_text(text))
        dialog.stop_speaking_requested.connect(self.stop_speaking)
        dialog.finished.connect(self._on_speech_dialog_finished)
        self._speech_dialog = dialog
        self._refresh_speech_controls()
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _on_speech_dialog_finished(self, _result: int) -> None:
        self._speech_dialog = None

    def _install_piper_voice_from_dialog(self, voice_name: str) -> None:
        message = self.speech.install_piper_voice(voice_name)
        clean = str(voice_name or "").strip()
        if clean:
            self.config.tts_piper_voice_name = clean
        self._persist_speech_config(message)

    def _remove_piper_voice_from_dialog(self, voice_name: str) -> None:
        message = self.speech.remove_piper_voice(voice_name)
        if self.config.tts_piper_voice_name.strip() == str(voice_name or "").strip():
            remaining = self.speech.installed_piper_voice_names()
            self.config.tts_piper_voice_name = remaining[0] if remaining else ""
        self._persist_speech_config(message)

    def _import_reference_audio_from_dialog(self) -> None:
        chosen, _ = QFileDialog.getOpenFileName(
            self,
            tr("Choose a reference audio file"),
            str(Path.home()),
            tr("Audio files (*.wav *.mp3 *.m4a *.ogg *.flac *.aac);;All files (*)"),
        )
        if not chosen:
            return
        message = self.speech.import_reference_audio(chosen)
        self.config.tts_reference_audio_path = self.speech.current_reference_audio_path()
        self._persist_speech_config(message)

    def _start_reference_recording_from_dialog(self) -> None:
        message = self.speech.start_reference_recording()
        self.config.tts_reference_audio_path = self.speech.current_reference_audio_path()
        self._persist_speech_config(message)

    def _stop_reference_recording_from_dialog(self) -> None:
        message = self.speech.stop_reference_recording()
        self.config.tts_reference_audio_path = self.speech.current_reference_audio_path()
        self._persist_speech_config(message)

    def _clear_reference_audio_from_dialog(self) -> None:
        message = self.speech.clear_reference_audio()
        self.config.tts_reference_audio_path = ""
        self._persist_speech_config(message)

    def find_in_page(self, text: str) -> None:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            view.findText(text)
            self.show_message(tr("Searching this page for: {text}").format(text=text))
        else:
            self.show_message(tr("Find-in-page only works on full web tabs."))

    def open_new_tab_page(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = NewTabWidget(self.stats_text)
        state = TabState(kind="internal", title=tr("New Tab"), url="aster:newtab", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=8)
        widget.open_requested.connect(lambda text, state=state: self.open_target(text, replace_tab_id=state.tab_id, container=state.container))
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_settings_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = SettingsPageWidget(self.config)
        widget.refresh_speech_choices(*self._speech_choices())
        state = TabState(kind="internal", title=tr("Settings"), url="aster:settings", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=10)
        widget.save_requested.connect(lambda cfg, rid=state.tab_id: self.apply_settings_from_page(cfg, rid))
        widget.cancel_requested.connect(lambda rid=state.tab_id: self.close_tab_by_id(rid))
        widget.manage_speech_requested.connect(self.open_speech_tools_dialog)
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_history_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = HistoryPageWidget(lambda: self.history_entries(""), self.history_entries)
        state = TabState(kind="internal", title=tr("History"), url="aster:history", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=9)
        widget.open_url_requested.connect(lambda target, rid=state.tab_id, cname=state.container: self.open_target(target, replace_tab_id=rid, container=cname))
        self._insert_state(state, background, replace_tab_id)
        return state

    def _bookmark_current_from_tab(self, widget: BookmarksPageWidget) -> None:
        self.show_message(self.bookmark_current_page())
        try:
            widget.refresh_results()
        except Exception:
            pass

    def open_bookmarks_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = BookmarksPageWidget(lambda: self.bookmark_entries(""), self.bookmark_entries)
        state = TabState(kind="internal", title=tr("Bookmarks"), url="aster:bookmarks", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=9)
        widget.open_url_requested.connect(lambda target, rid=state.tab_id, cname=state.container: self.open_target(target, replace_tab_id=rid, container=cname))
        widget.remove_requested.connect(self.remove_bookmark_entry)
        widget.save_current_requested.connect(lambda widget_ref=widget: self._bookmark_current_from_tab(widget_ref))
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_downloads_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = DownloadsPageWidget()
        state = TabState(kind="internal", title=tr("Downloads"), url="aster:downloads", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=8)
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_awareness_tab(self, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = AwarenessPageWidget(self.screen_time_snapshot, self.set_daily_screen_limit_minutes)
        state = TabState(kind="internal", title=tr("Awareness"), url="aster:awareness", container=self.active_container(), widget=widget, live=False, estimated_cost_mb=8)
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_compat_redirect_tab(self, url: str, container: str, reason: str, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = CompatibilityRedirectWidget(tr("Streaming compatibility mode"), url, reason)
        state = TabState(kind="internal", title=tr("Compatibility Mode"), url=url, container=container, widget=widget, live=False, estimated_cost_mb=8)
        widget.try_inside_requested.connect(lambda state=state, container_name=container: self.open_target(state.url, container=container_name, replace_tab_id=state.tab_id, bypass_drm_redirect=True))
        widget.open_external_requested.connect(lambda target=url: open_external(target, self.streaming_support.external_browser_command))
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_capsule_tab(self, url: str, container: str, reason: str, launch: CapsuleLaunchResult, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = StreamingCapsuleWidget(launch.service_label, url, reason, launch.runtime_label)
        self._apply_capsule_launch_result(widget, launch)
        state = TabState(kind="internal", title=tr("{service} Capsule").format(service=launch.service_label), url=url, container=container, widget=widget, live=False, estimated_cost_mb=8)
        widget.launch_requested.connect(lambda rid=state.tab_id: self._relaunch_capsule_for_tab(rid))
        widget.try_inside_requested.connect(lambda state=state, container_name=container: self.open_target(state.url, container=container_name, replace_tab_id=state.tab_id, bypass_drm_redirect=True))
        widget.reset_profile_requested.connect(lambda label=launch.service_label, widget_ref=widget: self._reset_capsule_profile(label, widget_ref))
        widget.open_raw_requested.connect(lambda target=url: open_external(target, self.streaming_support.external_browser_command))
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_error_tab(self, url: str, container: str, title: str, subtitle: str, details: list[str], background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = ErrorPageWidget(title, subtitle, url, details)
        state = TabState(kind="internal", title=title, url=url, container=container, widget=widget, live=False, estimated_cost_mb=8)
        widget.retry_requested.connect(lambda rid=state.tab_id, target=url, cname=container: self.open_target(target, replace_tab_id=rid, container=cname))
        widget.home_requested.connect(lambda rid=state.tab_id: self.open_target(self.config.homepage, replace_tab_id=rid, container=container))
        widget.external_requested.connect(lambda target=url: self.open_external_target(target))
        self._insert_state(state, background, replace_tab_id)
        return state

    def _certificate_host_for(self, url: str) -> str:
        try:
            return (urlparse(url).hostname or "").lower().strip(".")
        except Exception:
            return ""

    def _handle_certificate_error_signal(self, page: BrowserPage, certificate_error: object) -> None:
        url = ""
        try:
            err_url = getattr(certificate_error, "url", None)
            if callable(err_url):
                candidate = err_url()
                if hasattr(candidate, "toString"):
                    url = candidate.toString()
                else:
                    url = str(candidate)
        except Exception:
            url = ""
        if not url:
            try:
                url = page.url().toString()
            except Exception:
                url = ""
        self._record_certificate_error(url, certificate_error)
        host = self._certificate_host_for(url)
        exception_hosts = {self._certificate_host_for("https://" + item) for item in getattr(self.config, "certificate_exception_hosts", [])}
        exception_hosts.discard("")
        overridable = True
        try:
            method = getattr(certificate_error, "isOverridable", None)
            if callable(method):
                overridable = bool(method())
        except Exception:
            overridable = True
        if host and host in exception_hosts and overridable:
            try:
                certificate_error.acceptCertificate()
                self.show_message(tr("Accepted saved HTTPS certificate exception for {host}.").format(host=host), 7000)
                return
            except Exception:
                pass
        try:
            certificate_error.defer()
        except Exception:
            pass
        detail = self._certificate_error_detail_for(url) or "The certificate is not trusted by this Qt WebEngine runtime."
        if overridable:
            answer = QMessageBox.question(
                self,
                tr("HTTPS certificate warning"),
                f"Aster could not verify the HTTPS certificate for:\n\n{host or url}\n\n{detail}\n\nContinue only if you personally trust this network and site. This does not disable HTTPS checks globally.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer == QMessageBox.StandardButton.Yes:
                try:
                    certificate_error.acceptCertificate()
                    self.show_message(tr("Accepted this HTTPS certificate once for {host}.").format(host=host or url), 7000)
                    return
                except Exception:
                    pass
        try:
            certificate_error.rejectCertificate()
        except Exception:
            pass

    def _record_certificate_error(self, url: str, certificate_error: object) -> None:
        try:
            host = (urlparse(url).hostname or "").lower()
        except Exception:
            host = ""
        if not host:
            return
        is_main_frame = True
        try:
            method = getattr(certificate_error, "isMainFrame", None)
            if callable(method):
                is_main_frame = bool(method())
        except Exception:
            is_main_frame = True
        parts: list[str] = []
        for attr in ("description", "errorDescription"):
            method = getattr(certificate_error, attr, None)
            if callable(method):
                try:
                    value = str(method()).strip()
                    if value and value not in parts:
                        parts.append(value)
                except Exception:
                    pass
        for attr in ("type", "error", "url"):
            method = getattr(certificate_error, attr, None)
            if callable(method):
                try:
                    value = str(method()).strip()
                    if value and value not in parts:
                        parts.append(value)
                except Exception:
                    pass
        detail = (" | ".join(parts) or "Qt WebEngine reported a certificate error.")
        if is_main_frame:
            self._certificate_errors[host] = detail
            self._main_frame_certificate_error_hosts.add(host)
            self._verified_https_hosts.pop(host, None)
        else:
            self._subresource_certificate_errors[host] = detail
        self._update_security_indicator(url, loaded_ok=False)

    def _certificate_error_detail_for(self, url: str, *, main_frame_only: bool = False) -> str:
        try:
            host = (urlparse(url).hostname or "").lower()
        except Exception:
            host = ""
        if not host:
            return ""
        if main_frame_only:
            if host not in self._main_frame_certificate_error_hosts:
                return ""
            return self._certificate_errors.get(host, "")
        return self._certificate_errors.get(host, "") or self._subresource_certificate_errors.get(host, "")

    def _clear_certificate_error_for_url(self, url: str) -> None:
        try:
            host = (urlparse(url or "").hostname or "").lower()
        except Exception:
            host = ""
        if not host:
            return
        self._certificate_errors.pop(host, None)
        self._subresource_certificate_errors.pop(host, None)
        self._main_frame_certificate_error_hosts.discard(host)

    def _record_https_success(self, url: str) -> None:
        try:
            parsed = urlparse(url or "")
            host = (parsed.hostname or "").lower()
            scheme = (parsed.scheme or "").lower()
        except Exception:
            return
        if scheme != "https" or not host:
            return
        self._verified_https_hosts[host] = time.time()
        self._clear_certificate_error_for_url(url)

    def _security_indicator_text(self, url: str, *, loaded_ok: bool | None = None, details: dict[str, Any] | None = None) -> tuple[str, str]:
        parsed = urlparse(url or "")
        scheme = (parsed.scheme or "").lower()
        details = details or {}
        if not url or scheme in {"aster", "about"}:
            return "Aster", "Internal page"
        if scheme == "file":
            return "Local", "Local file; not a network HTTPS page"
        if scheme == "https":
            main_detail = self._certificate_error_detail_for(url, main_frame_only=True)
            sub_detail = self._certificate_error_detail_for(url) if not main_detail else ""
            if main_detail:
                return "HTTPS warning", f"Qt WebEngine reported a main-page certificate problem: {main_detail}"
            mixed_active = int(details.get("mixedActive") or 0) if isinstance(details, dict) else 0
            mixed_passive = int(details.get("mixedPassive") or 0) if isinstance(details, dict) else 0
            insecure_forms = int(details.get("insecureForms") or 0) if isinstance(details, dict) else 0
            secure_context = details.get("isSecureContext") if isinstance(details, dict) else None
            if mixed_active or insecure_forms:
                return "HTTPS mixed", f"Main page uses HTTPS, but {mixed_active} active HTTP resource(s) or {insecure_forms} insecure form(s) were detected."
            if sub_detail:
                return "HTTPS caution", f"Main page has no certificate error, but a subresource certificate warning was blocked: {sub_detail}"
            if mixed_passive:
                return "HTTPS mixed", f"Main page uses HTTPS; {mixed_passive} passive HTTP resource(s) were detected."
            if secure_context is False:
                return "HTTPS caution", "Main URL is HTTPS, but the page did not report a secure JavaScript context. Check mixed content, proxy, or renderer compatibility."
            if loaded_ok is False:
                return "HTTPS issue", "Main URL is HTTPS and no certificate error is recorded; the load failure is likely cache, DNS/proxy, renderer, JavaScript, adblock, or site compatibility."
            return "HTTPS secure", "Main page is encrypted and no current main-frame certificate error is recorded."
        if scheme == "http":
            return "HTTP not secure", "Plain HTTP is not encrypted."
        if scheme:
            return scheme.upper(), f"Custom scheme: {scheme}"
        return tr("Unknown"), "No page security information yet"

    def _update_security_indicator(self, url: str | None = None, *, loaded_ok: bool | None = None) -> None:
        state = self.current_state()
        target = url if url is not None else (state.url if state else "")
        details = getattr(state, "security_details", {}) if state else {}
        text, tooltip = self._security_indicator_text(target or "", loaded_ok=loaded_ok, details=details if isinstance(details, dict) else {})
        if hasattr(self, "security_status_label"):
            self.security_status_label.setText(text)
            self.security_status_label.setToolTip(tooltip)
        if state is not None:
            state.security_state = text
            state.security_note = tooltip

    def clear_web_security_state(self) -> None:
        removed = 0
        for profile in getattr(self.containers, "profiles", lambda: [])():
            try:
                profile.clearHttpCache()
            except Exception:
                pass
        security_file_names = {
            "Network Persistent State", "TransportSecurity", "CertificateRevocation",
            "Trust Tokens", "Trust Tokens-journal", "Reporting and NEL", "Reporting and NEL-journal",
        }
        for root in (containers_dir(), cache_dir()):
            try:
                if not root.exists():
                    continue
                for path in root.rglob("*"):
                    if path.is_file() and path.name in security_file_names:
                        path.unlink()
                        removed += 1
                    elif path.is_dir() and path.name in {"Cache", "Code Cache", "GPUCache", "DawnCache", "ShaderCache", "GrShaderCache"}:
                        shutil.rmtree(path, ignore_errors=True)
                        removed += 1
            except Exception as exc:
                append_msg = getattr(self, "show_message", None)
                if callable(append_msg):
                    append_msg(f"Skipped cache cleanup item: {exc}", 5000)
        self._certificate_errors.clear()
        self._subresource_certificate_errors.clear()
        self._main_frame_certificate_error_hosts.clear()
        self._verified_https_hosts.clear()
        self._update_security_indicator()
        QMessageBox.information(self, tr("Aster web state cleared"), tr("Cleared Aster HTTP/security cache items: {count}. Restart Aster, then reload the site.").format(count=removed))

    def refresh_ca_trust_help(self) -> str:
        helper = Path(__file__).resolve().parent.parent / "tools" / "refresh_ca_trust.sh"
        return (
            "Aster uses your operating system certificate store for HTTPS. The safe updater refreshes system CA packages only; "
            "it never touches your protected NSS user certificate database.\n\n"
            f"Linux helper:\n{helper} --auto\n\n"
            "Installer option:\n./Aster-Browser-Merged-Linux-v15.sh -y --refresh-ca\n\n"
            "If sudo/root is unavailable, the helper will print the manual package command for your distro. Aster will not bypass invalid certificates globally."
        )

    def diagnose_current_page(self) -> str:
        state = self.current_state()
        target = state.url if state and state.url else self.url_bar.text().strip()
        if not target:
            target = "https://example.com"
        lines = ["Aster security diagnostics", ""]
        lines.append(f"URL: {target}")
        bundle, ca_dir = configure_certificate_environment()
        lines.append(f"SSL_CERT_FILE: {bundle or 'not found'}")
        lines.append(f"SSL_CERT_DIR: {ca_dir or 'not found'}")
        if state is not None:
            lines.append(f"Aster security label: {getattr(state, 'security_state', '') or 'unknown'}")
            note = getattr(state, 'security_note', '') or ''
            if note:
                lines.append(f"Aster security note: {note}")
            details = getattr(state, 'security_details', {})
            if isinstance(details, dict) and details:
                lines.append("Page security context:")
                for key in ("isSecureContext", "mixedActive", "mixedPassive", "insecureForms", "error"):
                    if key in details:
                        lines.append(f"  {key}: {details.get(key)}")
                examples = details.get("httpResourceExamples")
                if isinstance(examples, list) and examples:
                    lines.append("  HTTP resource examples: " + ", ".join(str(x) for x in examples[:3]))
        main_cert_detail = self._certificate_error_detail_for(target, main_frame_only=True)
        sub_cert_detail = self._certificate_error_detail_for(target) if not main_cert_detail else ""
        if main_cert_detail:
            lines.append(f"Last Qt WebEngine MAIN-PAGE certificate error: {main_cert_detail}")
        if sub_cert_detail:
            lines.append(f"Last Qt WebEngine SUBRESOURCE certificate warning: {sub_cert_detail}")
        if str(target).lower().startswith("https://"):
            probe = probe_https(target, timeout=5.0)
            lines.extend(probe.as_lines())
            if probe.ok and not main_cert_detail:
                lines.append("Result: the main site certificate verifies with the system OpenSSL/Python trust store, and Aster has no current main-frame certificate error recorded.")
                lines.append("If the page still looks 'not secure', the likely causes are stale Qt WebEngine profile/security cache, mixed HTTP content, an insecure form, a proxy/VPN rule, or an old forced user-agent compatibility path.")
                lines.append("Safe fix: use Tools → Clear Aster web security/cache state, restart Aster, and reload the site. Do not use a global ignore-certificate-errors flag.")
            elif probe.ok and main_cert_detail:
                lines.append("Result: OpenSSL trusts the certificate, but Qt WebEngine still recorded a main-frame warning. Clear Aster web security/cache state and make sure libnss3/p11-kit/ca-certificates are installed.")
            else:
                lines.append("Result: the HTTPS problem is reproducible outside the page renderer. Check system date/time, DNS/VPN/proxy, and system CA packages.")
        else:
            lines.append("Result: this is not an HTTPS page, so browsers may correctly show it as not secure.")
        return "\n".join(lines)

    def _network_online(self) -> bool:
        now = time.monotonic()
        if self._connectivity_cache and now - self._connectivity_cache[0] < 6.0:
            return self._connectivity_cache[1]
        targets = [("1.1.1.1", 53), ("8.8.8.8", 53)]
        online = False
        for host, port in targets:
            try:
                with socket.create_connection((host, port), timeout=0.45):
                    online = True
                    break
            except OSError:
                continue
        self._connectivity_cache = (now, online)
        return online

    def _classify_error_page(self, url: str) -> tuple[str, str, list[str]]:
        lowered = (url or "").lower()
        online = self._network_online()
        if lowered.startswith("file://"):
            return (
                tr("Local file unavailable"),
                tr("Aster could not open this local file."),
                [tr("Check that the file still exists."), tr("Confirm you still have permission to read it."), tr("Open the parent folder and try again.")],
            )
        if not online:
            return (
                tr("No internet connection"),
                tr("Aster could not reach the network right now."),
                [tr("Check Wi-Fi or Ethernet."), tr("Turn off a broken VPN or proxy."), tr("Retry after the connection comes back.")],
            )
        if lowered.startswith("https://"):
            main_cert_detail = self._certificate_error_detail_for(url, main_frame_only=True)
            any_cert_detail = self._certificate_error_detail_for(url)
            details = [
                tr("Check your system date and time."),
                tr("Refresh/install ca-certificates, libnss3, and p11-kit if other browsers work but Aster does not."),
                tr("Aster does not bypass certificate errors automatically; this protects you from fake HTTPS pages."),
            ]
            if main_cert_detail:
                details.insert(0, tr("Qt WebEngine main-page certificate error: {detail}").format(detail=main_cert_detail))
            elif any_cert_detail:
                details.insert(0, tr("Qt WebEngine subresource certificate warning: {detail}").format(detail=any_cert_detail))
            probe = None
            try:
                probe = probe_https(url, timeout=2.5)
                details.extend(probe.as_lines())
            except Exception:
                probe = None
            if main_cert_detail or (probe is not None and not probe.ok):
                return (
                    tr("Secure connection failed"),
                    tr("Aster could not establish a trusted secure connection to the main page."),
                    details,
                )
            return (
                tr("Page load failed"),
                tr("The main HTTPS certificate appears trusted, so this looks like a renderer, DNS, proxy, stale profile-cache, mixed-content, adblock, or site-compatibility failure instead of an unsafe main page."),
                [
                    tr("The URL was HTTPS, but Aster did not record a main-page Qt certificate error."),
                    tr("Use Tools → Diagnose current page security to see mixed-content and CA/runtime details."),
                    tr("Use Tools → Clear Aster web security/cache state, restart Aster, then reload the site."),
                    tr("Do not enable a global ignore-certificate-errors flag for daily browsing."),
                ] + details,
            )
        return (
            tr("Page unreachable"),
            tr("Aster could not reach this address."),
            [tr("Check the URL for typing mistakes."), tr("The site may be down, moved, or blocked by network rules."), tr("Try again in a moment.")],
        )


    def _apply_capsule_launch_result(self, widget: StreamingCapsuleWidget, launch: CapsuleLaunchResult) -> None:
        widget.set_runtime_hint(launch.runtime_label)
        widget.set_profile_hint(launch.profile_dir or "shared/default")
        widget.set_status_text(launch.note)

    def _relaunch_capsule_for_tab(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        if not state:
            return
        launch = self.capsules.launch(state.url)
        if isinstance(state.widget, StreamingCapsuleWidget):
            self._apply_capsule_launch_result(state.widget, launch)
        self.show_message(launch.note)

    def _reset_capsule_profile(self, service_label: str, widget: StreamingCapsuleWidget) -> None:
        ok = self.capsules.reset_capsule_profile(service_label)
        if ok:
            widget.set_profile_hint("reset; relaunch to recreate")
            widget.set_status_text(f"Reset capsule profile for {service_label}.")
            self.show_message(tr("Reset capsule profile for {service}.").format(service=service_label))
        else:
            widget.set_status_text(f"Could not reset capsule profile for {service_label}.")
            self.show_message(tr("Could not reset capsule profile for {service}.").format(service=service_label))

    def open_compatibility_web_tab(self, url: str, container: str, reason: str = "", background: bool = False, replace_tab_id: str | None = None) -> TabState:
        state = self.open_web_tab(url, container, background=background, replace_tab_id=replace_tab_id, compatibility_mode=True)
        state.parked_reason = reason or "Aster compatibility mode"
        self.show_message(tr("Compatibility mode uses Aster's bundled Qt WebEngine runtime, not a system Chromium install."), 9000)
        return state

    def open_web_tab(self, url: str, container: str, background: bool = False, replace_tab_id: str | None = None, mobile_mode: bool = False, compatibility_mode: bool = False) -> TabState:
        # Ebeveyn olarak pencereyi VERMIYORUZ: pencerenin dogrudan cocugu
        # olarak yaratilirsa hemen native yuzey alip tum pencereyi kapliyor,
        # sekmeye tasinirken bu yuzey yikilip yeniden kuruluyor.
        view = QWebEngineView()
        profile = self.containers.profile(container, mobile=mobile_mode, compatibility=compatibility_mode)
        self._sync_profile_language(profile)
        self._sync_profile_scrollbar_style(profile)
        
        # Mobile mode uses a mobile UA. Desktop mode keeps Qt WebEngine's real
        # current UA instead of a stale fake Chrome string; old UAs can make
        # modern sites choose compatibility/security fallback paths.
        if mobile_mode:
            profile.setHttpUserAgent("Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36")
        
        try:
            self._sync_profile_extensions(profile)
        except Exception as exc:
            self.show_message(tr("Extension sync failed: {error}").format(error=exc))
        page = BrowserPage(self, container, profile, view)
        try:
            page.certificateError.connect(lambda certificate_error, p=page: self._handle_certificate_error_signal(p, certificate_error))
        except Exception:
            pass
        view.setPage(page)
        self._set_page_base_color(page, loading=True)
        try:
            view.setAutoFillBackground(True)
            palette = view.palette()
            palette.setColor(view.backgroundRole(), self._window_surface_color())
            view.setPalette(palette)
        except Exception:
            pass
        apply_security_profile(view.settings(), self.config.security_mode)
        default_zoom = self._default_zoom_factor()
        if mobile_mode:
            view.setZoomFactor(default_zoom * 0.92)
            wrapper = MobileViewWidget(view)
        else:
            view.setZoomFactor(default_zoom)
            wrapper = None
        state_widget = wrapper if wrapper is not None else view
        state = TabState(kind="web", title=url, url=url, container=container, widget=state_widget, live=True, estimated_cost_mb=MemoryGovernor.estimate_cost(url, "web"), mobile_mode=mobile_mode, compatibility_mode=compatibility_mode, zoom_factor=(default_zoom * 0.92 if mobile_mode else default_zoom))
        self._bind_web_tab_signals(state)
        self._insert_state(state, background, replace_tab_id)
        view.setUrl(QUrl(url))
        return state

    def _bind_web_tab_signals(self, state: TabState) -> None:
        """Bir web sekmesinin tum sinyallerini BU pencereye baglar.

        Sekme baska bir pencereye tasindiginda ayni fonksiyon hedef pencerede
        cagrilarak sinyaller yeniden baglanir; aksi halde tasinan sekme eski
        penceresine rapor vermeye devam ederdi.
        """
        view = self._extract_web_view(state.widget)
        if view is None:
            return
        page = view.page()
        wrapper = state.widget if state.widget is not view else None
        if wrapper is not None:
            try:
                wrapper.refresh_requested.connect(view.reload)
                wrapper.open_desktop_requested.connect(
                    lambda s=state: self._open_desktop_for_tab(s.tab_id)
                )
            except Exception:
                pass
        view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        view.customContextMenuRequested.connect(
            lambda pos, s=state, v=view: self._show_page_context_menu(v, s, pos)
        )
        view.urlChanged.connect(lambda qurl, s=state: self._on_url_changed(s.tab_id, qurl.toString()))
        view.titleChanged.connect(lambda title, s=state: self._on_title_changed(s.tab_id, title))
        view.loadStarted.connect(lambda s=state: self._on_load_started(s.tab_id))
        view.loadProgress.connect(lambda progress, s=state: self._on_load_progress(s.tab_id, progress))
        view.loadFinished.connect(lambda ok, s=state: self._on_load_finished(s.tab_id, ok))
        try:
            page.fullScreenRequested.connect(lambda request, v=view: self._handle_fullscreen(request, v))
        except Exception:
            pass
        try:
            page.recentlyAudibleChanged.connect(
                lambda audible, s=state: self._on_audible_changed(s.tab_id, audible)
            )
        except Exception:
            pass
        try:
            page.browser = self
        except Exception:
            pass

    def _unbind_web_tab_signals(self, state: TabState) -> None:
        """Sekmenin bu pencereye giden tum baglantilarini koparir."""
        view = self._extract_web_view(state.widget)
        if view is None:
            return
        page = view.page()
        wrapper = state.widget if state.widget is not view else None
        candidates = [
            getattr(view, "customContextMenuRequested", None),
            getattr(view, "urlChanged", None),
            getattr(view, "titleChanged", None),
            getattr(view, "loadStarted", None),
            getattr(view, "loadProgress", None),
            getattr(view, "loadFinished", None),
            getattr(page, "fullScreenRequested", None),
            getattr(page, "recentlyAudibleChanged", None),
        ]
        if wrapper is not None:
            candidates.append(getattr(wrapper, "refresh_requested", None))
            candidates.append(getattr(wrapper, "open_desktop_requested", None))
        for signal in candidates:
            if signal is None:
                continue
            try:
                signal.disconnect()
            except Exception:
                pass

    # --- Sekmeyi pencereler arasinda surukleyip tasima -------------------

    _MOVABLE_TAB_KINDS = ("web", "internal")

    def _window_under_cursor(self, global_pos: QPoint) -> "BrowserWindow | None":
        for window in browser_windows():
            if window is self or not window.isVisible():
                continue
            try:
                bar = window.tabs.tabBar()
                origin = bar.mapToGlobal(QPoint(0, 0))
                rect = QRect(origin, bar.size()).adjusted(-10, -16, 10, 16)
                if rect.contains(global_pos):
                    return window
            except Exception:
                continue
        return None

    def release_tab(self, tab_id: str) -> TabState | None:
        """Sekmeyi bu pencereden ayirir ama widget'i YOK ETMEZ."""
        state = self.tab_states.pop(tab_id, None)
        if state is None:
            return None
        self._unbind_web_tab_signals(state)
        index = self.tabs.indexOf(state.widget)
        if index >= 0:
            self.tabs.removeTab(index)
        try:
            state.widget.setParent(None)
        except Exception:
            pass
        if self.tabs.count() == 0:
            if len(browser_windows()) > 1 and not self._is_primary:
                QTimer.singleShot(0, self.close)
            else:
                self.open_target(self.config.homepage)
        else:
            self._refresh_visibility()
        QTimer.singleShot(10, self._position_add_tab_button)
        return state

    def adopt_tab(self, state: TabState) -> None:
        """Baska pencereden gelen sekmeyi devralir, sinyalleri yeniden baglar."""
        self.tab_states[state.tab_id] = state
        index = self.tabs.addTab(state.widget, self._tab_label(state))
        self._bind_web_tab_signals(state)
        self.tabs.setCurrentIndex(index)
        self._refresh_visibility()
        QTimer.singleShot(10, self._position_add_tab_button)

    def move_tab_to_window(self, tab_id: str, target: "BrowserWindow") -> bool:
        state = self.tab_states.get(tab_id)
        if state is None or target is self:
            return False
        if state.kind == "web":
            released = self.release_tab(tab_id)
            if released is None:
                return False
            target.adopt_tab(released)
        else:
            # Dahili sayfalarin sinyalleri kendi pencerelerine bagli; bunlari
            # tasimak yerine hedef pencerede adresinden yeniden aciyoruz.
            url = state.url
            self.close_tab_by_id(tab_id)
            target.open_target(url)
        try:
            target.raise_()
            target.activateWindow()
        except Exception:
            pass
        return True

    def detach_tab_to_new_window(self, tab_id: str, global_pos: QPoint) -> bool:
        state = self.tab_states.get(tab_id)
        if state is None:
            return False
        if self.tabs.count() <= 1 and len(browser_windows()) <= 1:
            return False
        window = BrowserWindow(primary=False)
        window.resize(max(640, self.width() - 60), max(480, self.height() - 60))
        window.move(max(0, global_pos.x() - 140), max(0, global_pos.y() - 30))
        window.show()
        if state.kind == "web":
            released = self.release_tab(tab_id)
            if released is None:
                window.close()
                return False
            window.adopt_tab(released)
        else:
            url = state.url
            self.close_tab_by_id(tab_id)
            window.open_target(url)
        try:
            window.raise_()
            window.activateWindow()
        except Exception:
            pass
        return True

    def _handle_tab_detach(self, index: int, global_pos: QPoint) -> None:
        state = self._state_for_index(index)
        if state is None:
            return
        if state.kind not in self._MOVABLE_TAB_KINDS:
            self.show_message("Only web and internal tabs can be moved between windows.", 5000)
            return
        target = self._window_under_cursor(global_pos)
        if target is not None:
            self.move_tab_to_window(state.tab_id, target)
        else:
            self.detach_tab_to_new_window(state.tab_id, global_pos)

    def open_lite_tab(self, url: str, container: str, background: bool = False, replace_tab_id: str | None = None) -> TabState:
        widget = LitePageWidget(url)
        state = TabState(kind="lite", title=f"Lite: {url}", url=url, container=container, widget=widget, live=False, estimated_cost_mb=MemoryGovernor.estimate_cost(url, "lite"))
        widget.open_full_requested.connect(lambda target, state=state, container_name=container: self.open_target(target, container=container_name, replace_tab_id=state.tab_id))
        widget.open_link_requested.connect(self.open_target)
        widget.title_changed.connect(lambda title, state=state: self._on_title_changed(state.tab_id, f"Lite: {title}"))
        widget.status_message.connect(self.show_message)
        self._insert_state(state, background, replace_tab_id)
        return state

    def open_lite_current(self) -> bool:
        now = time.monotonic()
        if now < self._lite_toggle_guard_until:
            return False
        self._lite_toggle_guard_until = now + 0.35
        state = self.current_state()
        if not state or state.url in {"aster:newtab", "aster:settings"}:
            return False
        if state.kind == "lite":
            self.open_target(state.url, replace_tab_id=state.tab_id, container=state.container)
            return True
        if state.kind not in {"web", "parked", "internal"}:
            return False
        self.open_lite_tab(state.url, state.container, replace_tab_id=state.tab_id)
        return True

    def go_from_address_bar(self) -> None:
        text = self.url_bar.text().strip()
        if not text:
            return
        state = self.current_state()
        current_view = self._extract_web_view(state.widget if state else None)
        if state and state.kind == "web" and current_view is not None:
            kind, value = self._resolve_target(text)
            if kind == "internal":
                if value == "aster:settings":
                    self.open_settings_tab(replace_tab_id=state.tab_id)
                else:
                    self.open_new_tab_page(replace_tab_id=state.tab_id)
            else:
                url = build_search_url(self.config.search_engine, value) if kind == "search" else value
                redirected = self._maybe_redirect_streaming(url, state.container, False, state.tab_id)
                if redirected is None:
                    state.url = url
                    state.estimated_cost_mb = MemoryGovernor.estimate_cost(url, "web", state.audible)
                    current_view.setUrl(QUrl(url))
            return
        replace = state.tab_id if state else None
        target_container = state.container if state else None
        self.open_target(text, replace_tab_id=replace, container=target_container)

    def _insert_state(self, state: TabState, background: bool = False, replace_tab_id: str | None = None) -> None:
        if replace_tab_id and replace_tab_id in self.tab_states:
            old_state = self.tab_states[replace_tab_id]
            index = self.tabs.indexOf(old_state.widget)
            state.tab_id = old_state.tab_id
            if index < 0:
                index = self.tabs.addTab(state.widget, self._tab_label(state))
                self.tabs.setCurrentIndex(index)
            else:
                # Yeni sekmeyi ONCE ekleyip eskisini SONRA kaldiriyoruz; tersi
                # sirada sekme kabi bir kare bos kaliyor ve cercevesiz pencere
                # "bir an acilip kapaniyor" gibi gorunuyor.
                self.tabs.insertTab(index, state.widget, self._tab_label(state))
                self.tabs.setCurrentIndex(index)
                self.tabs.removeTab(index + 1)
            try:
                old_state.widget.setParent(None); old_state.widget.deleteLater()
            except Exception:
                pass
            del self.tab_states[replace_tab_id]
            self.tab_states[state.tab_id] = state
        else:
            index = self.tabs.addTab(state.widget, self._tab_label(state))
            if not background:
                self.tabs.setCurrentIndex(index)
            self.tab_states[state.tab_id] = state
        self._refresh_visibility()
        if self.config.auto_park:
            QTimer.singleShot(200, self.park_background_tabs)

    def current_state(self) -> TabState | None:
        widget = self.tabs.currentWidget()
        for state in self.tab_states.values():
            if state.widget is widget:
                return state
        return None

    def _state_for_index(self, index: int) -> TabState | None:
        if index < 0:
            return None
        widget = self.tabs.widget(index)
        for state in self.tab_states.values():
            if state.widget is widget:
                return state
        return None

    def _tab_label(self, state: TabState) -> str:
        parts: list[str] = []
        if state.kind == "parked":
            parts.append("⏸")
        if getattr(state, "compatibility_mode", False):
            parts.append("🧩")
        if state.mobile_mode:
            parts.append("📱")
        if state.audio_muted:
            parts.append("🔇")
        prefix = (" ".join(parts) + " ") if parts else ""
        title = state.title or state.url or "Tab"
        return prefix + (title[:28] + "…" if len(title) > 29 else title)

    def _refresh_visibility(self) -> None:
        current = self.current_state()
        for state in self.tab_states.values():
            state.visible = state is current
            if state.visible:
                state.last_active = time.time()
        if current:
            self.url_bar.setText(current.url)
            is_web = (current.kind == "web")
            
            # 1. Butonları teknik olarak devre dışı bırak
            self.lite_action.setEnabled(is_web)
            self.mobile_action.setEnabled(is_web)
            self.add_from_page_action.setEnabled(is_web)
            self.park_action.setEnabled(is_web and not current.mobile_mode)
            self.park_current_action.setEnabled(is_web and not current.mobile_mode)
            
            # 2. Butonları görsel olarak soluklaştır (Opacity Effect)
            from PyQt6.QtWidgets import QGraphicsOpacityEffect
            
            for action in [self.lite_action, self.mobile_action, self.add_from_page_action, self.park_action, self.park_current_action]:
                widget = self.toolbar.widgetForAction(action)
                if widget is None:
                    continue
                # Efekti her cagrida yeniden kurmuyoruz: setGraphicsEffect widget'i
                # offscreen boyama yoluna sokup yeniden cizdiriyor ve her sekme
                # degisiminde arac cubugunda titremeye yol aciyordu.
                effect = widget.graphicsEffect()
                if not isinstance(effect, QGraphicsOpacityEffect):
                    effect = QGraphicsOpacityEffect(widget)
                    widget.setGraphicsEffect(effect)
                target = 1.0 if action.isEnabled() else 0.6
                if abs(effect.opacity() - target) > 0.001:
                    effect.setOpacity(target)
        self.tabs.setTabToolTip(self.tabs.currentIndex(), self.stats_text())
        self._refresh_status_metrics()
        QTimer.singleShot(10, self._position_add_tab_button)

    def collect_snapshots(self):
        for state in self.tab_states.values():
            state.estimated_cost_mb = MemoryGovernor.estimate_cost(state.url, state.kind, state.audible)
        return [state.snapshot() for state in self.tab_states.values()]

    def stats_text(self) -> str:
        decision = self.governor.plan(self.collect_snapshots())
        rss = self.governor.process_rss_mb()
        rss_text = tr(" | process RSS: {rss} MB").format(rss=rss) if rss is not None else ""
        return tr("Live tabs: {live} | Parked tabs: {parked} | Estimated live memory: {used} MB / {budget} MB").format(live=decision.live_tabs, parked=decision.parked_tabs, used=decision.estimated_live_mb, budget=self.governor.soft_budget_mb) + rss_text

    def streaming_status_text(self) -> str:
        self.streaming_support = detect_streaming_support(self.config.drm_mode, self.config.external_browser_cmd)
        self.capsules = StreamingCapsuleManager(self.config.external_browser_cmd)
        return self.streaming_support.render() + "\n\n" + self.capsules.render()

    def capsule_status_text(self) -> str:
        self.capsules = StreamingCapsuleManager(self.config.external_browser_cmd)
        return self.capsules.render()

    def show_message(self, message: str, timeout_ms: int = 5000) -> None:
        self.status.showMessage(message, timeout_ms)

    def wireguard_status(self) -> str:
        return WireGuardHelper.status().render()

    def _parked_tab_payloads(self) -> list[dict[str, Any]]:
        payloads: list[dict[str, Any]] = []
        seen: set[tuple[str, str]] = set()
        for state in self._ordered_states():
            if state.kind != "parked" or not state.url:
                continue
            key = (state.url, state.container)
            if key in seen:
                continue
            seen.add(key)
            payloads.append({
                "title": state.title or state.url,
                "url": state.url,
                "container": state.container,
                "reason": state.parked_reason or "parked for later",
                "mobile_mode": bool(getattr(state, "mobile_mode", False)),
                "saved_at": int(time.time()),
            })
        return payloads

    def _persist_parked_tabs(self) -> None:
        if not bool(getattr(self.config, "parked_tabs_persist", True)):
            return
        if not getattr(self, "_is_primary", True):
            return
        try:
            path = session_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            payload = {"version": 1, "parked_tabs": self._parked_tab_payloads()}
            path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        except Exception:
            pass

    def _restore_persisted_parked_tabs(self) -> None:
        if not bool(getattr(self.config, "parked_tabs_persist", True)):
            return
        try:
            path = session_path()
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            items = data.get("parked_tabs", []) if isinstance(data, dict) else []
        except Exception:
            return
        existing = {(state.url, state.container) for state in self.tab_states.values()}
        restored = 0
        for item in items:
            if not isinstance(item, dict):
                continue
            url = str(item.get("url", "") or "").strip()
            if not url or url.startswith("aster:"):
                continue
            container = str(item.get("container", self.config.default_container) or self.config.default_container)
            key = (url, container)
            if key in existing:
                continue
            existing.add(key)
            self.open_parked_tab(
                url=url,
                title=str(item.get("title", url) or url),
                container=container,
                reason=str(item.get("reason", "restored parked tab") or "restored parked tab"),
                background=True,
                mobile_mode=bool(item.get("mobile_mode", False)),
            )
            restored += 1
        if restored:
            self.show_message(tr("Restored {count} parked tab(s). They stay parked until you unpark them.").format(count=restored), 9000)

    def open_parked_tab(self, url: str, title: str, container: str, reason: str, background: bool = True, replace_tab_id: str | None = None, mobile_mode: bool = False) -> TabState:
        widget = ParkedTabWidget(title, url, container, reason, animated=bool(getattr(self.config, "parked_camel_animation", True)))
        state = TabState(kind="parked", title=title or url, url=url, container=container, widget=widget, live=False, estimated_cost_mb=MemoryGovernor.estimate_cost(url, "parked"), mobile_mode=mobile_mode, parked_reason=reason)
        widget.restore_requested.connect(lambda rid=state.tab_id: self.restore_tab(rid))
        widget.lite_requested.connect(lambda rid=state.tab_id: self.open_lite_for_tab(rid))
        widget.close_requested.connect(lambda rid=state.tab_id: self.close_tab_by_id(rid))
        self._insert_state(state, background=background, replace_tab_id=replace_tab_id)
        self._persist_parked_tabs()
        return state

    def park_background_tabs(self) -> int:
        decision = self.governor.plan(self.collect_snapshots())
        count = 0
        for tab_id in decision.park_tab_ids:
            if self._park_tab(tab_id, decision.reason):
                count += 1
        if count:
            self.show_message(tr("Parked {count} tab(s). They will stay parked until you unpark them. {stats}").format(count=count, stats=self.stats_text()), 9000)
            self._persist_parked_tabs()
        return count

    def park_current_tab(self) -> bool:
        state = self.current_state()
        if not state or state.kind != "web" or state.mobile_mode:
            self.show_message(tr("Only a full desktop web tab can be parked."), 5000)
            return False
        ok = self._park_tab(state.tab_id, "parked manually for later", allow_visible=True)
        if ok:
            self.show_message(tr("This tab is parked for later. It is saved and will not run web content until you unpark it."), 9000)
            self._persist_parked_tabs()
            self._refresh_visibility()
        return ok

    def _park_tab(self, tab_id: str, reason: str, allow_visible: bool = False) -> bool:
        state = self.tab_states.get(tab_id)
        if not state or state.kind != "web" or state.pinned or state.audible or state.mobile_mode:
            return False
        if state.visible and not allow_visible:
            return False
        index = self.tabs.indexOf(state.widget)
        if index < 0:
            return False
        parked_widget = ParkedTabWidget(state.title, state.url, state.container, reason, animated=bool(getattr(self.config, "parked_camel_animation", True)))
        parked_widget.restore_requested.connect(lambda rid=tab_id: self.restore_tab(rid))
        parked_widget.lite_requested.connect(lambda rid=tab_id: self.open_lite_for_tab(rid))
        parked_widget.close_requested.connect(lambda rid=tab_id: self.close_tab_by_id(rid))
        old_widget = state.widget
        was_current = self.tabs.currentIndex() == index
        state.widget = parked_widget
        state.kind = "parked"
        state.live = False
        state.parked_reason = reason
        state.estimated_cost_mb = MemoryGovernor.estimate_cost(state.url, "parked")
        self.tabs.removeTab(index)
        self.tabs.insertTab(index, parked_widget, self._tab_label(state))
        if was_current:
            self.tabs.setCurrentIndex(index)
        try:
            old_widget.setParent(None); old_widget.deleteLater()
        except Exception:
            pass
        self._persist_parked_tabs()
        return True

    def open_lite_for_tab(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        if not state or state.url in {"aster:newtab", "aster:settings"}:
            return
        if state.kind == "lite":
            self.open_target(state.url, replace_tab_id=tab_id, container=state.container)
            return
        self.open_lite_tab(state.url, state.container, replace_tab_id=tab_id)
        self._persist_parked_tabs()

    def restore_tab(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        if state:
            current = self.current_state(); background = current is not None and current.tab_id != tab_id
            self.open_web_tab(state.url, state.container, background=background, replace_tab_id=tab_id, mobile_mode=state.mobile_mode)
            self.show_message(tr("Unparked tab and restored full web mode."), 7000)
            QTimer.singleShot(200, self._persist_parked_tabs)

    def _on_current_tab_changed(self, index: int) -> None:
        state = self._state_for_index(index)
        if state and self.last_current_tab_id and self.last_current_tab_id != state.tab_id:
            self.previous_tab_id = self.last_current_tab_id
        self.last_current_tab_id = state.tab_id if state else None
        self._refresh_visibility()
        if not state:
            self.title_bar.set_context_text(tr("Aster is ready"))
            self._refresh_status_metrics()
            return
        self.url_bar.setText(state.url)
        self.title_bar.set_context_text(state.title or state.url)
        if state.kind == "parked":
            self.show_message(tr("This tab is parked and not using RAM-heavy web content. Click Unpark / restore full tab when ready."), 7000)
        elif state.kind == "internal" and hasattr(state.widget, "refresh_stats"):
            state.widget.refresh_stats()
        self._refresh_status_metrics()

    def _on_url_changed(self, tab_id: str, url: str) -> None:
        state = self.tab_states.get(tab_id)
        if state:
            state.url = url
            state.estimated_cost_mb = MemoryGovernor.estimate_cost(url, state.kind, state.audible)
            state.security_details = {}
            if state.visible:
                self.url_bar.setText(url)
                self._update_security_indicator(url)

    def _on_title_changed(self, tab_id: str, title: str) -> None:
        state = self.tab_states.get(tab_id)
        if state:
            state.title = title or state.url or "Tab"
            index = self.tabs.indexOf(state.widget)
            if index >= 0:
                self.tabs.setTabText(index, self._tab_label(state)); self.tabs.setTabToolTip(index, state.url)
                QTimer.singleShot(10, self._position_add_tab_button)
            if state.visible:
                self.title_bar.set_context_text(state.title or state.url)

    def _on_audible_changed(self, tab_id: str, audible: bool) -> None:
        state = self.tab_states.get(tab_id)
        if state:
            state.audible = audible
            state.estimated_cost_mb = MemoryGovernor.estimate_cost(state.url, state.kind, state.audible)
            index = self.tabs.indexOf(state.widget)
            if index >= 0:
                self.tabs.setTabText(index, self._tab_label(state))

    def _on_load_started(self, tab_id: str) -> None:
        # Sayfa gecislerinde beyaz flas olmasin diye taban yine koyuya alinir.
        self._set_tab_page_base_color(tab_id, loading=True)
        state = self.tab_states.get(tab_id)
        if state:
            state.title = tr("Loading…")
            state.security_details = {}
            state.last_load_ok = None
            state.last_load_error = ""
            self._on_title_changed(tab_id, state.title)
            self._update_security_indicator(state.url)
        self.load_progress.setVisible(bool(getattr(self.config, "show_progress_bar", True)))
        self.load_progress.setValue(0)
        self.page_status_label.setText(tr("Loading…"))

    def _on_load_progress(self, tab_id: str, progress: int) -> None:
        state = self.tab_states.get(tab_id)
        if state and state.visible:
            value = max(0, min(100, int(progress)))
            self.load_progress.setVisible(bool(getattr(self.config, "show_progress_bar", True)))
            self.load_progress.setValue(value)
            self.page_status_label.setText(tr("Loading {percent}%").format(percent=value))

    def _inject_custom_page_css(self, tab_id: str) -> None:
        if not bool(getattr(self.config, "custom_page_css_enabled", False)):
            return
        css = str(getattr(self.config, "custom_page_css", "") or "").strip()
        if not css:
            return
        state = self.tab_states.get(tab_id)
        if not state or str(state.url or "").startswith("aster:"):
            return
        view = self._extract_web_view(state.widget)
        if view is None:
            return
        payload = base64.b64encode(css.encode("utf-8", errors="ignore")).decode("ascii")
        script = f"""
(() => {{
  try {{
    const css = atob("{payload}");
    let node = document.getElementById("aster-user-css");
    if (!node) {{
      node = document.createElement("style");
      node.id = "aster-user-css";
      document.head.appendChild(node);
    }}
    node.textContent = css;
  }} catch (error) {{}}
}})();
"""
        try:
            view.page().runJavaScript(script)
        except Exception:
            pass

    def _on_load_finished(self, tab_id: str, ok: bool) -> None:
        state = self.tab_states.get(tab_id)
        if not state:
            return
        state.last_load_ok = bool(ok)
        state.last_load_error = "" if ok else "Qt WebEngine loadFinished(false)"
        # Icerik geldi: taban rengi tarayici varsayilanina (beyaz) doner.
        self._set_tab_page_base_color(tab_id, loading=False)
        self.load_progress.setValue(100)
        QTimer.singleShot(500, lambda: self.load_progress.setVisible(False))
        if ok:
            self._record_https_success(state.url)
            self._update_security_indicator(state.url, loaded_ok=True)
            self.plugin_manager.invoke("on_page_loaded", state.url, state.title)
            self.local_index.record_history(state.url, state.title)
            self._capture_page_context(tab_id)
            self._capture_page_security_context(tab_id)
            self._inject_extension_page_affordance(tab_id)
            self._inject_custom_page_css(tab_id)
            self._release_address_bar(state)
            self._refresh_status_metrics()
            if self.config.auto_park:
                QTimer.singleShot(500, self.park_background_tabs)
        else:
            self._update_security_indicator(state.url, loaded_ok=False)
            service = known_drm_service(state.url)
            if service and self.config.drm_mode != "internal_only":
                title = tr("{service} could not load inside Aster").format(service=service)
                subtitle = tr("Protected playback or site compatibility failed in the current runtime.")
                details = [
                    tr("Aster can still keep you in the same workflow, but this page may need a supported DRM/runtime path."),
                    tr("Current DRM mode: {mode}.").format(mode=self.config.drm_mode),
                    tr("Retry, adjust DRM mode, or use the compatibility path if needed."),
                ]
            else:
                title, subtitle, details = self._classify_error_page(state.url)
            self.open_error_tab(state.url, state.container, title, subtitle, details, replace_tab_id=tab_id)
            self.show_message(tr("Could not load {url}").format(url=state.url))
            self._refresh_status_metrics()

    def _capture_page_context(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        view = self._extract_web_view(state.widget if state else None)
        if not state or view is None:
            return
        chars = int(self.config.ai_page_context_chars)
        view.page().runJavaScript(f"(() => {{ try {{ return document.body ? document.body.innerText.slice(0, {chars}) : ''; }} catch (e) {{ return ''; }} }})()", lambda text, rid=tab_id: self._store_page_text(rid, text))
        view.page().runJavaScript("(() => { try { return Array.from(document.links).slice(0, 12).map(a => [String(a.innerText || a.textContent || '').trim().slice(0, 120), String(a.href || '')]); } catch (e) { return []; } })()", lambda links, rid=tab_id: self._store_page_links(rid, links))

    def _inject_extension_page_affordance(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        view = self._extract_web_view(state.widget if state else None)
        if not state or view is None:
            return
        if not self._extension_overlay_allowed(state.url):
            return
        view.page().runJavaScript(self._extension_overlay_script())

    def _store_page_text(self, tab_id: str, text) -> None:
        state = self.tab_states.get(tab_id)
        if state and isinstance(text, str):
            state.page_text = text.strip()

    def _store_page_links(self, tab_id: str, links) -> None:
        state = self.tab_states.get(tab_id)
        if not state:
            return
        cleaned = []
        if isinstance(links, list):
            for item in links[:12]:
                if isinstance(item, (list, tuple)) and len(item) == 2:
                    label = str(item[0]).strip(); href = str(item[1]).strip()
                    if href:
                        cleaned.append((label or href, href))
        state.page_links = cleaned

    def _capture_page_security_context(self, tab_id: str) -> None:
        state = self.tab_states.get(tab_id)
        view = self._extract_web_view(state.widget if state else None)
        if not state or view is None:
            return
        script = """
(() => {
  try {
    const entries = performance.getEntriesByType('resource') || [];
    const httpResources = entries
      .map(e => String(e.name || ''))
      .filter(name => name.startsWith('http://'));
    const activeTypes = new Set(['script', 'css', 'xmlhttprequest', 'fetch', 'iframe', 'document', 'worker']);
    const active = entries.filter(e => String(e.name || '').startsWith('http://') && activeTypes.has(String(e.initiatorType || '').toLowerCase()));
    const forms = Array.from(document.forms || [])
      .map(form => String(form.action || ''))
      .filter(action => action.startsWith('http://'));
    return {
      href: String(location.href || ''),
      protocol: String(location.protocol || ''),
      isSecureContext: Boolean(window.isSecureContext),
      mixedPassive: Math.max(0, httpResources.length - active.length),
      mixedActive: active.length,
      insecureForms: forms.length,
      httpResourceExamples: httpResources.slice(0, 5),
      insecureFormExamples: forms.slice(0, 3)
    };
  } catch (error) {
    return { error: String(error && error.message || error || 'unknown') };
  }
})()
"""
        try:
            view.page().runJavaScript(script, lambda details, rid=tab_id: self._store_page_security_details(rid, details))
        except Exception:
            pass

    def _store_page_security_details(self, tab_id: str, details) -> None:
        state = self.tab_states.get(tab_id)
        if not state:
            return
        if isinstance(details, dict):
            cleaned: dict[str, Any] = {}
            for key in (
                "href", "protocol", "isSecureContext", "mixedPassive", "mixedActive",
                "insecureForms", "httpResourceExamples", "insecureFormExamples", "error",
            ):
                if key in details:
                    cleaned[key] = details.get(key)
            state.security_details = cleaned
        else:
            state.security_details = {}
        if state.visible:
            self._update_security_indicator(state.url, loaded_ok=state.last_load_ok)

    def _with_current_web_view(self, callback) -> None:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is not None:
            callback(view)

    def _default_zoom_factor(self) -> float:
        percent = int(getattr(self.config, "default_zoom_percent", 100) or 100)
        return max(0.5, min(3.0, percent / 100.0))

    def _current_zoom_factor(self) -> float:
        state = self.current_state()
        view = self._extract_web_view(state.widget if state else None)
        if view is None:
            return self._default_zoom_factor()
        try:
            factor = float(view.zoomFactor())
        except Exception:
            factor = float(getattr(state, "zoom_factor", self._default_zoom_factor()) if state else self._default_zoom_factor())
        return max(0.5, min(3.0, factor))

    def _apply_zoom_factor(self, factor: float, *, state: TabState | None = None, announce: bool = True) -> bool:
        target_state = state or self.current_state()
        view = self._extract_web_view(target_state.widget if target_state else None)
        if view is None:
            return False
        factor = max(0.5, min(3.0, float(factor)))
        try:
            view.setZoomFactor(factor)
        except Exception:
            return False
        if target_state is not None:
            target_state.zoom_factor = factor
        self._refresh_status_metrics()
        if announce:
            self.show_message(tr("Page zoom: {percent}%").format(percent=int(round(factor * 100))))
        return True

    def zoom_in_current(self) -> bool:
        return self._apply_zoom_factor(self._current_zoom_factor() + 0.10)

    def zoom_out_current(self) -> bool:
        return self._apply_zoom_factor(self._current_zoom_factor() - 0.10)

    def zoom_reset_current(self) -> bool:
        return self._apply_zoom_factor(self._default_zoom_factor())

    def _copy_text_to_clipboard(self, text: str) -> None:
        clipboard = QApplication.clipboard()
        clipboard.setText(text or "")

    def _trigger_web_action(self, view: QWebEngineView, action_name: str) -> bool:
        try:
            action = getattr(QWebEnginePage.WebAction, action_name)
        except Exception:
            return False
        try:
            view.triggerPageAction(action)
            return True
        except Exception:
            return False

    def _suggest_download_filename(self, url: str, fallback: str = "download.bin") -> str:
        clean = str(url or "").strip()
        if clean.startswith('data:'):
            header = clean.split(',', 1)[0]
            mime = header[5:].split(';', 1)[0].strip()
            ext = mimetypes.guess_extension(mime) or '.bin'
            return f"download{ext}"
        parsed = urlparse(clean)
        name = Path(unquote(parsed.path)).name if parsed.path else ''
        if not name:
            name = fallback
        name = ''.join(ch for ch in name if ch not in '\0\r\n')
        return name or fallback

    def _write_data_url(self, data_url: str, target_path: Path) -> None:
        header, payload = data_url.split(',', 1)
        if ';base64' in header:
            content = base64.b64decode(payload)
        else:
            content = unquote_to_bytes(payload)
        target_path.write_bytes(content)

    def _download_direct_url(self, url: str, suggested_name: str | None = None) -> bool:
        clean = str(url or '').strip()
        if not clean:
            self.show_message(tr("No downloadable URL was found for this item."))
            return False
        if clean.startswith('blob:'):
            self.show_message(tr("This item uses a browser-only blob URL. Try the built-in page download action on this page."))
            return False
        downloads_dir().mkdir(parents=True, exist_ok=True)
        default_name = suggested_name or self._suggest_download_filename(clean)
        chosen, _ = QFileDialog.getSaveFileName(self, tr("Save file"), str(downloads_dir() / default_name))
        if not chosen:
            return False
        chosen_path = Path(chosen)
        try:
            if clean.startswith('data:'):
                self._write_data_url(clean, chosen_path)
            else:
                from urllib.request import Request, urlopen
                request = Request(clean, headers={"User-Agent": "AsterBrowser/1.0"})
                with urlopen(request, timeout=45) as response, open(chosen_path, 'wb') as output:
                    shutil.copyfileobj(response, output)
            self.show_message(tr("Saved {name}").format(name=chosen_path.name))
            return True
        except Exception as exc:
            self.show_message(tr("Direct download failed: {error}").format(error=exc))
            return False

    def _download_page_asset(self, view: QWebEngineView, url: str, web_action: str, fallback_name: str) -> bool:
        if self._trigger_web_action(view, web_action):
            return True
        return self._download_direct_url(url, fallback_name)

    def _context_menu_baseline(self, view: QWebEngineView) -> dict[str, str]:
        try:
            req = view.page().lastContextMenuRequest()
        except Exception:
            req = None
        link_url = ''
        media_url = ''
        media_type_name = ''
        selected_text = ''
        try:
            if req is not None and hasattr(req, 'linkUrl'):
                link_url = req.linkUrl().toString()
        except Exception:
            link_url = ''
        try:
            if req is not None and hasattr(req, 'mediaUrl'):
                media_url = req.mediaUrl().toString()
        except Exception:
            media_url = ''
        try:
            if req is not None and hasattr(req, 'mediaType'):
                media_type = req.mediaType()
                media_type_name = str(getattr(media_type, 'name', media_type) or '').strip().lower()
        except Exception:
            media_type_name = ''
        try:
            if req is not None and hasattr(req, 'selectedText'):
                selected_text = str(req.selectedText() or '')
            if not selected_text:
                selected_text = str(view.selectedText() or '')
        except Exception:
            selected_text = ''
        return {
            'link_url': link_url,
            'media_url': media_url,
            'media_type': media_type_name,
            'selected_text': selected_text,
        }

    def _context_target_script(self, pos: QPoint) -> str:
        return f"""
(() => {{
  const result = {{ link_url: '', image_url: '', media_url: '', media_type: '', selected_text: '' }};
  try {{
    result.selected_text = String((window.getSelection && window.getSelection().toString()) || '');
  }} catch (e) {{}}
  const x = {int(0)} + {int(pos.x())};
  const y = {int(0)} + {int(pos.y())};
  let node = document.elementFromPoint(x, y);
  const bgUrl = (value) => {{
    const match = String(value || '').match(/url\\((['"]?)(.*?)\\1\\)/i);
    return match && match[2] ? match[2] : '';
  }};
  while (node) {{
    try {{
      if (!result.link_url && node.href) result.link_url = String(node.href);
      if (!result.image_url) {{
        if ((node.tagName || '').toUpperCase() === 'IMG') result.image_url = String(node.currentSrc || node.src || '');
        if (!result.image_url) {{
          const bg = window.getComputedStyle(node).getPropertyValue('background-image');
          const candidate = bgUrl(bg);
          if (candidate) result.image_url = String(candidate);
        }}
      }}
      if (!result.media_url && ['VIDEO', 'AUDIO', 'SOURCE'].includes((node.tagName || '').toUpperCase())) {{
        result.media_url = String(node.currentSrc || node.src || '');
        result.media_type = String((node.tagName || '').toLowerCase());
      }}
    }} catch (e) {{}}
    node = node.parentElement;
  }}
  if (!result.media_url && result.image_url) {{
    result.media_url = result.image_url;
    result.media_type = 'image';
  }}
  return result;
}})()
""".strip()

    def _show_page_context_menu(self, view: QWebEngineView, state: TabState, pos: QPoint) -> None:
        baseline = self._context_menu_baseline(view)

        def _finish(result: Any) -> None:
            data = dict(baseline)
            if isinstance(result, dict):
                for key in ('link_url', 'image_url', 'media_url', 'media_type', 'selected_text'):
                    value = str(result.get(key, '') or '').strip()
                    if value:
                        data[key] = value
            self._show_page_context_menu_with_data(view, state, pos, data)

        try:
            view.page().runJavaScript(self._context_target_script(pos), _finish)
        except Exception:
            _finish({})

    def _show_page_context_menu_with_data(self, view: QWebEngineView, state: TabState, pos: QPoint, data: dict[str, str]) -> None:
        menu = QMenu(self)
        link_url = str(data.get('link_url', '') or '').strip()
        media_url = str(data.get('media_url', '') or '').strip()
        media_type_name = str(data.get('media_type', '') or '').strip().lower()
        image_url = str(data.get('image_url', '') or '').strip()
        selected_text = str(data.get('selected_text', '') or '').strip()
        is_image = bool(image_url) or 'image' in media_type_name or any(media_url.lower().endswith(ext) for ext in ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.avif'))
        if is_image and not image_url:
            image_url = media_url
        is_audio = 'audio' in media_type_name or any(media_url.lower().endswith(ext) for ext in ('.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'))
        is_video = 'video' in media_type_name or any(media_url.lower().endswith(ext) for ext in ('.mp4', '.webm', '.mkv', '.mov', '.m3u8'))

        open_link_action = None
        copy_link_action = None
        download_link_action = None
        open_image_action = None
        copy_image_action = None
        download_image_action = None
        open_media_action = None
        copy_media_action = None
        download_media_action = None
        copy_selection_action = None
        search_selection_action = None
        read_selection_action = None

        # HIYERARSI 1: Gorsel uzerindeyken gorsel eylemleri EN USTTE
        if is_image and image_url:
            open_image_action = menu.addAction(tr("Open image in new tab"))
            copy_image_action = menu.addAction(tr("Copy image address"))
            download_image_action = menu.addAction(tr("Download image"))
            menu.addSeparator()
            if link_url:
                open_link_action = menu.addAction(tr("Open link in new tab"))
                copy_link_action = menu.addAction(tr("Copy link address"))
                menu.addSeparator()

        # HIYERARSI 2: Medya (video/audio) uzerindeyken medya eylemleri EN USTTE
        elif (is_audio or is_video) and media_url:
            open_media_action = menu.addAction(tr("Open media in new tab"))
            copy_media_action = menu.addAction(tr("Copy media address"))
            download_media_action = menu.addAction(tr("Download media"))
            menu.addSeparator()
            if link_url:
                open_link_action = menu.addAction(tr("Open link in new tab"))
                copy_link_action = menu.addAction(tr("Copy link address"))
                menu.addSeparator()

        # HIYERARSI 3: Metin seciliyken metin eylemleri EN USTTE
        elif selected_text:
            copy_selection_action = menu.addAction(tr("Copy"))
            short_query = selected_text[:30] + ("…" if len(selected_text) > 30 else "")
            search_selection_action = menu.addAction(f"Search web for \"{short_query}\"")
            read_selection_action = menu.addAction(tr("Read aloud"))
            menu.addSeparator()

        # HIYERARSI 4: Yalnizca link uzerindeyken link eylemleri EN USTTE
        elif link_url:
            open_link_action = menu.addAction(tr("Open link in new tab"))
            copy_link_action = menu.addAction(tr("Copy link address"))
            download_link_action = menu.addAction(tr("Download linked file"))
            menu.addSeparator()

        read_page_action = menu.addAction(tr("Read page aloud"))
        stop_speech_action = menu.addAction(tr("Stop speaking"))
        menu.addSeparator()
        view_source_action = menu.addAction(tr("View page source"))
        inspect_text_action = menu.addAction(tr("Copy page title and URL"))

        chosen = menu.exec(view.mapToGlobal(pos))
        if chosen == open_link_action and link_url:
            self.open_target(link_url, background=True, container=state.container)
        elif chosen == copy_link_action and link_url:
            self._copy_text_to_clipboard(link_url)
            self.show_message(tr("Copied link address"))
        elif chosen == download_link_action and link_url:
            self._download_page_asset(view, link_url, 'DownloadLinkToDisk', self._suggest_download_filename(link_url, 'link-download.bin'))
        elif chosen == open_image_action and image_url:
            self.open_target(image_url, background=True, container=state.container)
        elif chosen == copy_image_action and image_url:
            self._copy_text_to_clipboard(image_url)
            self.show_message(tr("Copied image address"))
        elif chosen == download_image_action and image_url:
            self._download_page_asset(view, image_url, 'DownloadImageToDisk', self._suggest_download_filename(image_url, 'image.bin'))
        elif chosen == open_media_action and media_url:
            self.open_target(media_url, background=True, container=state.container)
        elif chosen == copy_media_action and media_url:
            self._copy_text_to_clipboard(media_url)
            self.show_message(tr("Copied media address"))
        elif chosen == download_media_action and media_url:
            self._download_page_asset(view, media_url, 'DownloadMediaToDisk', self._suggest_download_filename(media_url, 'media.bin'))
        elif chosen == copy_selection_action and selected_text:
            self._copy_text_to_clipboard(selected_text)
            self.show_message(tr("Copied selected text"))
        elif chosen == search_selection_action and selected_text:
            search_target = build_search_url(self.config.search_engine, selected_text)
            self.open_target(search_target, background=False)
        elif chosen == read_selection_action and selected_text:
            self.speak_text(selected_text)
        elif chosen == read_page_action:
            self.read_page_aloud()
        elif chosen == stop_speech_action:
            self.stop_speaking()
        elif chosen == view_source_action:
            try:
                view.triggerPageAction(QWebEnginePage.WebAction.ViewSource)
            except Exception:
                self.show_message(tr("View source is not available for this page."))
        elif chosen == inspect_text_action:
            self._copy_text_to_clipboard((state.title or state.url) + "\n" + state.url)
            self.show_message(tr("Copied page title and URL"))

    def _refresh_status_metrics(self) -> None:
        try:
            self.memory_status_label.setText(self.stats_text())
        except Exception:
            self.memory_status_label.setText(tr("Memory unavailable"))
        state = self.current_state()
        if state is None:
            self.page_status_label.setText(tr("Ready"))
            self.zoom_status_label.setText(tr("Zoom {percent}%").format(percent=int(round(self._default_zoom_factor() * 100))))
            self._update_security_indicator("")
            return
        label = state.title or state.url or tr("Ready")
        if len(label) > 44:
            label = label[:41].rstrip() + "…"
        self.page_status_label.setText(tr("Page: {label}").format(label=label))
        self.zoom_status_label.setText(tr("Zoom {percent}%").format(percent=int(round(self._current_zoom_factor() * 100))))
        self._update_security_indicator(state.url, loaded_ok=state.last_load_ok)

    def _close_tab_index(self, index: int) -> None:
        state = self._state_for_index(index)
        if not state:
            return
        if hasattr(self, 'tab_bar') and hasattr(self.tab_bar, 'animate_close_tab') and self.tabs.count() > 1:
            self.tab_bar.animate_close_tab(index, lambda: self.close_tab_by_id(state.tab_id))
        else:
            self.close_tab_by_id(state.tab_id)

    def close_current_tab(self) -> None:
        state = self.current_state()
        if state:
            self.close_tab_by_id(state.tab_id)

    def close_tab_by_id(self, tab_id: str) -> None:
        state = self.tab_states.pop(tab_id, None)
        if not state:
            return
        was_parked = state.kind == "parked"
        index = self.tabs.indexOf(state.widget)
        if index >= 0:
            self.tabs.removeTab(index)
        try:
            state.widget.setParent(None); state.widget.deleteLater()
        except Exception:
            pass
        if self.tabs.count() == 0:
            # Son sekmesi kapanan ikincil pencere yeni ana sayfa acmak yerine
            # kapanir; ana pencere (veya tek pencere) ana sayfayi acar.
            if len(browser_windows()) > 1 and not self._is_primary:
                QTimer.singleShot(0, self.close)
            else:
                self.open_target(self.config.homepage)
        else:
            self._refresh_visibility()
        QTimer.singleShot(10, self._position_add_tab_button)
        if was_parked:
            self._persist_parked_tabs()

    def _retranslate_ui(self) -> None:
        """Re-label the window chrome after the interface language changed."""
        self.title_bar.retranslate()
        self.title_bar.logo_button.setToolTip(tr("Open home page"))
        self.add_tab_button.setToolTip(tr("New tab (Ctrl+T)"))
        self.url_bar.setPlaceholderText(tr("Search or enter address"))
        for action, text, tooltip in (
            (self.back_action, "Back", "Back"),
            (self.forward_action, "Forward", "Forward"),
            (self.reload_action, "Reload", "Reload"),
            (self.home_action, "Home", "Home"),
            (self.new_tab_action, "New Tab", "New tab"),
            (self.park_action, "Park", "Park background tabs"),
            (self.park_current_action, "Park Current", "Park the current tab for later"),
            (self.lite_action, "Lite", "Open Lite mode"),
            (self.mobile_action, "Mobile view", "Open the current page in mobile view"),
            (self.add_from_page_action, "Add from page", "Install extension from current page"),
            (self.extensions_action, "Extensions", "Open extensions manager"),
            (self.settings_action, "Settings", "Open settings"),
            (self.zoom_in_action, "Zoom in", ""),
            (self.zoom_out_action, "Zoom out", ""),
            (self.zoom_reset_action, "Reset zoom", ""),
        ):
            action.setText(tr(text))
            if tooltip:
                action.setToolTip(tr(tooltip))
        self.toolbar_overflow_button.setToolTip(tr("Menu"))
        self._setup_menus()
        self._refresh_status_metrics()

    def apply_settings_from_page(self, config: BrowserConfig, tab_id: str | None = None) -> None:
        previous_ui_language = normalize_interface_language(getattr(self.config, "interface_language", "system"))
        self.config = config
        new_ui_language = normalize_interface_language(getattr(config, "interface_language", "system"))
        language_changed = new_ui_language != previous_ui_language
        if language_changed:
            set_ui_language(new_ui_language)
        self.speech.update_config(self.config)
        save_config(self.config)
        self.ruleset = self._build_adblock_ruleset()
        self._sync_adblock_interceptors()
        self.governor = MemoryGovernor(self.config.soft_memory_budget_mb, self.config.max_live_tabs)
        self.streaming_support = detect_streaming_support(self.config.drm_mode, self.config.external_browser_cmd)
        self.capsules = StreamingCapsuleManager(self.config.external_browser_cmd)
        self.ai_dock.set_allow_actions_default(self.config.allow_ai_actions)
        self.tab_bar.set_active_tab_left_click_menu_enabled(getattr(self.config, "active_tab_left_click_menu", True))
        self._rebuild_container_selector()
        for profile in self.containers.profiles():
            self._sync_profile_language(profile)
        self._sync_extensions_to_profiles()
        app = QApplication.instance()
        if app is not None:
            resolved_qt_style = apply_qt_style(app, getattr(self.config, "qt_style", "fusion"))
            if resolved_qt_style != getattr(self.config, "qt_style", "fusion"):
                self.config.qt_style = resolved_qt_style
                save_config(self.config)
            app.setStyleSheet(stylesheet_for(
                self.config.theme,
                getattr(self.config, "background_transparency_percent", 10),
                getattr(self.config, "accent_color", DEFAULT_ACCENT),
                getattr(self.config, "ui_density", "comfortable"),
                getattr(self.config, "window_corner_radius", 18),
            ))
        self._apply_customization_config()
        self._sync_window_transparency()
        self._apply_zoom_factor(self._default_zoom_factor(), announce=False)
        self._refresh_speech_controls()
        self._refresh_status_metrics()
        if language_changed:
            self._retranslate_ui()
            QTimer.singleShot(0, lambda rid=tab_id: self.open_settings_tab(replace_tab_id=rid))
        if tab_id and tab_id in self.tab_states:
            state = self.tab_states[tab_id]
            index = self.tabs.indexOf(state.widget)
            if index >= 0:
                self.tabs.setTabText(index, self._tab_label(state))
        self.show_message(tr("Settings saved. Interface language: {language}. Rendering changes apply immediately where possible.").format(language=interface_language_label(getattr(self.config, "interface_language", "system"))), 6000)

    def open_settings_dialog(self) -> None:
        self.open_settings_tab(replace_tab_id=self._replaceable_internal_tab_id())

    def open_history_page_from_menu(self) -> None:
        self.open_history_tab(replace_tab_id=self._replaceable_internal_tab_id())

    def open_bookmarks_page_from_menu(self) -> None:
        self.open_bookmarks_tab(replace_tab_id=self._replaceable_internal_tab_id())

    def open_downloads_page_from_menu(self) -> None:
        self.open_downloads_tab(replace_tab_id=self._replaceable_internal_tab_id())

    def open_awareness_page_from_menu(self) -> None:
        from .internal_pages import AwarenessPopup

        # QMenu yerine Popup bayrakli QDialog: QMenu paneldeki her tiklamayi
        # kendi kapanma jesti sayiyordu, bu yuzden kutunun bos bir yerine
        # tiklayinca pop-up kapaniyordu.
        popup = getattr(self, "_awareness_popup", None)
        if popup is None:
            popup = AwarenessPopup(
                self.screen_time_snapshot, self.set_daily_screen_limit_minutes, self
            )
            self._awareness_popup = popup
        if popup.isVisible():
            popup.close()
            return
        popup.panel.refresh_screen_metrics()
        popup.adjustSize()

        anchor = self.toolbar_overflow_button.mapToGlobal(
            QPoint(self.toolbar_overflow_button.width() - popup.width(),
                   self.toolbar_overflow_button.height() + 8)
        )
        screen = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        if screen is not None:
            geom = screen.availableGeometry()
            x = max(geom.left() + 10, min(anchor.x(), geom.right() - popup.width() - 10))
            y = max(geom.top() + 10, min(anchor.y(), geom.bottom() - popup.height() - 10))
        else:
            x, y = anchor.x(), anchor.y()
        popup.move(x, y)
        popup.show()
        popup.raise_()

    def _rebuild_container_selector(self) -> None:
        current = self.config.default_container
        self.container_combo.clear()
        for name in self.config.containers:
            self.container_combo.addItem(name)
        self.set_active_container(current)

    def _handle_download(self, item) -> None:
        try:
            downloads_dir().mkdir(parents=True, exist_ok=True)
            filename = item.downloadFileName() or "download.bin"
            suggested_path = downloads_dir() / filename
            chosen, _ = QFileDialog.getSaveFileName(self, tr("Save download"), str(suggested_path))
            if not chosen:
                return
            chosen_path = Path(chosen)
            item.setDownloadDirectory(str(chosen_path.parent)); item.setDownloadFileName(chosen_path.name); item.accept()
            self.show_message(tr("Downloading to {path}").format(path=chosen))
        except Exception as exc:
            self.show_message(tr("Download setup failed: {error}").format(error=exc))

    def changeEvent(self, event) -> None:  # type: ignore[override]
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange and hasattr(self, 'title_bar'):
            self.title_bar.sync_window_state()

    def closeEvent(self, event: QCloseEvent) -> None:  # type: ignore[override]
        try:
            self.speech.stop()
        except Exception:
            pass
        try:
            if self in _BROWSER_WINDOWS:
                _BROWSER_WINDOWS.remove(self)
        except Exception:
            pass
        # Ortak durumu yalnizca ana pencere yazar; aksi halde ikincil
        # pencereler ortak dosyalari kendi eksik sekme listeleriyle ezerdi.
        if self._is_primary:
            self._save_screen_time_state()
            self._persist_parked_tabs()
            save_config(self.config)
        super().closeEvent(event)

