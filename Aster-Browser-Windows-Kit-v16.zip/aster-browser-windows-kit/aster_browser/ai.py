from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Iterable


class AIProviderError(RuntimeError):
    pass


@dataclass
class AIContext:
    url: str = ""
    title: str = ""
    container: str = "default"
    page_text: str = ""
    page_links: list[tuple[str, str]] = field(default_factory=list)
    selected_text: str = ""
    previous_title: str = ""
    previous_url: str = ""
    previous_page_text: str = ""


class AIBroker:
    def __init__(self, provider: str, model: str, base_url: str, api_key_env: str, system_prompt: str, persona: str = "dr_light_lab", reasoning_mode: str = "balanced") -> None:
        self.provider = provider
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key_env = api_key_env
        self.system_prompt = system_prompt
        self.persona = (persona or "dr_light_lab").strip().lower()
        self.reasoning_mode = (reasoning_mode or "balanced").strip().lower()

    def ask(self, prompt: str, context: AIContext | None = None) -> str:
        context = context or AIContext()
        full_prompt = self._compose_prompt(prompt, context)
        provider = self.provider.lower().strip()
        if provider in {"", "disabled", "off", "none"}:
            raise AIProviderError(
                "AI is disabled. Set the provider to internal for the built-in local assistant, or use Ollama/OpenAI if you want a larger external model."
            )
        if provider == "internal":
            return self._ask_internal(prompt, context)
        if provider == "ollama":
            return self._ask_ollama(full_prompt)
        if provider == "openai":
            return self._ask_openai_responses(full_prompt)
        if provider == "openai_compatible":
            return self._ask_openai_compatible(full_prompt)
        raise AIProviderError(f"Unknown provider: {self.provider}")

    def _compose_prompt(self, prompt: str, context: AIContext) -> str:
        page_excerpt = context.page_text.strip()
        selected_excerpt = context.selected_text.strip()
        link_lines = "\n".join(f"- {label[:80]} -> {href}" for label, href in context.page_links[:10])
        chunks = [
            self.system_prompt,
            f"Assistant persona: {self.persona}; reasoning mode: {self.reasoning_mode}.",
            "",
            f"Current page title: {context.title or 'n/a'}",
            f"Current page url: {context.url or 'n/a'}",
            f"Container: {context.container}",
        ]
        if selected_excerpt:
            chunks.extend(["", "Current selected text:", selected_excerpt])
        if page_excerpt:
            chunks.extend(["", "Current page excerpt:", page_excerpt])
        if context.previous_page_text.strip():
            chunks.extend(
                [
                    "",
                    f"Previous tab title: {context.previous_title or 'n/a'}",
                    f"Previous tab url: {context.previous_url or 'n/a'}",
                    "Previous tab excerpt:",
                    context.previous_page_text,
                ]
            )
        if link_lines:
            chunks.extend(["", "Top links from the current page:", link_lines])
        chunks.extend(["", f"User: {prompt}"])
        return "\n".join(chunks)

    def _http_json(self, url: str, payload: dict[str, Any], headers: dict[str, str] | None = None) -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        request_headers = {"Content-Type": "application/json"}
        if headers:
            request_headers.update(headers)
        request = urllib.request.Request(url, data=body, headers=request_headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise AIProviderError(f"HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise AIProviderError(f"Network error: {exc}") from exc

    def _ask_internal(self, prompt: str, context: AIContext) -> str:
        request_payload = {
            "prompt": prompt,
            "context": asdict(context),
            "persona": self.persona,
            "reasoning_mode": self.reasoning_mode,
        }
        cmd = [sys.executable, "-m", "aster_browser.internal_worker"]
        try:
            proc = subprocess.run(
                cmd,
                input=json.dumps(request_payload).encode("utf-8"),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=25,
                check=False,
            )
            if proc.returncode == 0 and proc.stdout:
                data = json.loads(proc.stdout.decode("utf-8"))
                if data.get("ok"):
                    text = str(data.get("text", "")).strip()
                    if text:
                        return text
                error_text = str(data.get("error", "")).strip()
                if error_text:
                    raise AIProviderError(error_text)
            stderr = proc.stderr.decode("utf-8", errors="replace").strip()
            raise AIProviderError(stderr or f"Internal assistant exited with code {proc.returncode}")
        except Exception:
            from .local_assistant import LocalAssistant

            assistant = LocalAssistant(persona=self.persona, reasoning_mode=self.reasoning_mode)
            return assistant.ask(prompt, context)

    def _ask_ollama(self, prompt: str) -> str:
        payload = {"model": self.model, "prompt": prompt, "stream": False}
        data = self._http_json(f"{self.base_url}/api/generate", payload)
        return data.get("response", "No response received from Ollama.")

    def _ask_openai_responses(self, prompt: str) -> str:
        api_key = os.environ.get(self.api_key_env, "")
        if not api_key:
            raise AIProviderError(f"Missing API key in env var {self.api_key_env}")
        payload = {
            "model": self.model,
            "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
        }
        headers = {"Authorization": f"Bearer {api_key}"}
        data = self._http_json(f"{self.base_url}/responses", payload, headers=headers)
        if isinstance(data.get("output_text"), str):
            return data["output_text"]
        try:
            output = data["output"][0]["content"][0]["text"]
            if isinstance(output, str):
                return output
        except Exception:
            pass
        return json.dumps(data, indent=2)

    def _ask_openai_compatible(self, prompt: str) -> str:
        api_key = os.environ.get(self.api_key_env, "")
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt},
            ],
        }
        data = self._http_json(f"{self.base_url}/chat/completions", payload, headers=headers)
        try:
            return data["choices"][0]["message"]["content"]
        except Exception:
            return json.dumps(data, indent=2)


@dataclass
class Command:
    name: str
    help_text: str
    handler: Callable[[list[str]], str]


class CommandRouter:
    def __init__(self, actions: dict[str, Callable[..., Any]]) -> None:
        self.actions = actions
        self.commands: dict[str, Command] = {}
        self._register_builtins()

    def _register_builtins(self) -> None:
        self.register("help", "Show available commands.", self._help)
        self.register("open", "Open a URL or search target in a new tab/context.", self._open)
        self.register("open-here", "Open a URL in the current tab.", self._open_here)
        self.register("external", "Open a URL or the current page in the raw external browser.", self._external)
        self.register("capsule", "Open a URL or the current page in a managed streaming capsule.", self._capsule)
        self.register("capsules", "Show streaming capsule runtime and supported services.", self._capsules)
        self.register("search", "Search with the configured search engine.", self._search)
        self.register("find", "Find text on the current page.", self._find)
        self.register("docs", "Search common local document folders.", self._docs)
        self.register("pdfs", "Search common folders for PDFs.", self._pdfs)
        self.register("history", "Search recent Aster browsing history.", self._history)
        self.register("downloads", "Open Aster's downloads folder.", self._downloads)
        self.register("summarize", "Summarize selected text or the current page locally.", self._summarize)
        self.register("compare", "Compare the current tab with the previous tab locally.", self._compare)
        self.register("tabs", "List open tabs.", self._tabs)
        self.register("switch", "Switch to a tab by number or title.", self._switch)
        self.register("close", "Close the current tab or matching background tabs.", self._close)
        self.register("close-others", "Close every tab except the current one.", self._close_others)
        self.register("bookmark", "Save the current page as a bookmark.", self._bookmark)
        self.register("bookmarks", "Search saved bookmarks.", self._bookmarks)
        self.register("open-doc", "Open the first matching local document.", self._open_doc)
        self.register("open-pdf", "Open the first matching local PDF.", self._open_pdf)
        self.register("links", "List top readable links from the current page.", self._links)
        self.register("open-link", "Open a current-page link by number or text.", self._open_link)
        self.register("back", "Go back in the current tab.", self._back)
        self.register("forward", "Go forward in the current tab.", self._forward)
        self.register("reload", "Reload the current tab.", self._reload)
        self.register("duplicate", "Duplicate the current tab.", self._duplicate)
        self.register("extensions", "List installed browser extensions and runtime status.", self._extensions)
        self.register("install-extension", "Install an extension from a folder, .zip, .xpi, or .crx path.", self._install_extension)
        self.register("install-extension-page", "Install an extension from the current webpage when it exposes a direct package.", self._install_extension_page)
        self.register("toggle-extension", "Enable or disable an installed extension by name or ID.", self._toggle_extension)
        self.register("remove-extension", "Remove an installed extension by name or ID.", self._remove_extension)
        self.register("reload-extensions", "Reload extension runtime across open profiles.", self._reload_extensions)
        self.register("park", "Park background tabs now.", self._park)
        self.register("park-current", "Park the current tab for later.", self._park_current)
        self.register("lite", "Open the current page in Aster Lite mode.", self._lite)
        self.register("mobile", "Open the current page in Aster mobile view.", self._mobile)
        self.register("desktop", "Return the current page to desktop view.", self._desktop)
        self.register("container", "Switch the active container for new tabs.", self._container)
        self.register("stats", "Show current memory and tab stats.", self._stats)
        self.register("streaming", "Show DRM/streaming compatibility status.", self._streaming)
        self.register("diagnose", "Diagnose the current page, HTTPS trust, and browser/runtime basics.", self._diagnose)
        self.register("wg", "Show optional WireGuard status if available.", self._wg)

    def register(self, name: str, help_text: str, handler: Callable[[list[str]], str]) -> None:
        self.commands[name.lower().strip()] = Command(name=name.lower().strip(), help_text=help_text, handler=handler)

    def available_commands(self) -> list[Command]:
        return sorted(self.commands.values(), key=lambda item: item.name)

    def execute(self, text: str) -> str | None:
        text = text.strip()
        if not text.startswith("/"):
            return None
        try:
            parts = shlex.split(text)
        except ValueError:
            parts = text.split()
        if not parts:
            return None
        name = parts[0][1:].lower().strip()
        command = self.commands.get(name)
        if not command:
            return f"Unknown command: {name}. Try /help"
        return command.handler(parts[1:])

    def _join(self, args: list[str]) -> str:
        return " ".join(args).strip()

    def _help(self, _args: list[str]) -> str:
        lines = ["Available commands:"]
        for command in self.available_commands():
            lines.append(f"/{command.name} — {command.help_text}")
        return "\n".join(lines)

    def _open(self, args: list[str]) -> str:
        if not args:
            return "Usage: /open example.com"
        target = self._join(args)
        self.actions["open_url"](target)
        return f"Opening {target}"

    def _open_here(self, args: list[str]) -> str:
        action = self.actions.get("open_in_current")
        if action is None:
            return "Open-in-current-tab is unavailable."
        if not args:
            return "Usage: /open-here example.com"
        return str(action(self._join(args)))

    def _external(self, args: list[str]) -> str:
        action = self.actions.get("open_external")
        if action is None:
            return "External browser is unavailable."
        target = self._join(args) if args else None
        ok = bool(action(target))
        if target:
            return f"Opening externally: {target}" if ok else f"Could not open externally: {target}"
        return "Opened the current page externally." if ok else "Could not open the current page externally."

    def _capsule(self, args: list[str]) -> str:
        action = self.actions.get("open_capsule")
        if action is None:
            return "Streaming capsule support is unavailable."
        target = self._join(args) if args else None
        ok = bool(action(target))
        if target:
            return f"Opening in capsule: {target}" if ok else f"Could not open in capsule: {target}"
        return "Opened the current page in a capsule." if ok else "Could not open the current page in a capsule."

    def _capsules(self, _args: list[str]) -> str:
        action = self.actions.get("capsule_status")
        if action is None:
            return "Streaming capsules are unavailable."
        return str(action())

    def _search(self, args: list[str]) -> str:
        if not args:
            return "Usage: /search network engineer jobs"
        query = self._join(args)
        self.actions["search"](query)
        return f"Searching for: {query}"

    def _find(self, args: list[str]) -> str:
        action = self.actions.get("find_in_page")
        if action is None:
            return "Find-in-page is unavailable."
        if not args:
            return "Usage: /find router firmware"
        query = self._join(args)
        action(query)
        return f"Searching the current page for: {query}"

    def _docs(self, args: list[str]) -> str:
        action = self.actions.get("search_local_documents")
        if action is None:
            return "Local document search is unavailable."
        if not args:
            return "Usage: /docs router firmware"
        return str(action(self._join(args)))

    def _pdfs(self, args: list[str]) -> str:
        action = self.actions.get("search_local_pdfs")
        if action is None:
            return "Local PDF search is unavailable."
        if not args:
            return "Usage: /pdfs resume"
        return str(action(self._join(args)))

    def _history(self, args: list[str]) -> str:
        action = self.actions.get("search_history")
        if action is None:
            return "History search is unavailable."
        if not args:
            return "Usage: /history prime video"
        return str(action(self._join(args)))

    def _downloads(self, _args: list[str]) -> str:
        action = self.actions.get("open_downloads")
        if action is None:
            return "Downloads helper is unavailable."
        ok = bool(action())
        return "Opened the downloads folder." if ok else "Could not open the downloads folder."

    def _summarize(self, _args: list[str]) -> str:
        action = self.actions.get("summarize_selection_or_page")
        if action is None:
            return "Local summarizer is unavailable."
        return str(action())

    def _compare(self, _args: list[str]) -> str:
        action = self.actions.get("compare_tabs")
        if action is None:
            return "Tab comparison is unavailable."
        return str(action())

    def _tabs(self, _args: list[str]) -> str:
        action = self.actions.get("list_tabs")
        if action is None:
            return "Tab listing is unavailable."
        return str(action())

    def _switch(self, args: list[str]) -> str:
        action = self.actions.get("switch_tab")
        if action is None:
            return "Tab switching is unavailable."
        if not args:
            return "Usage: /switch 2 or /switch github"
        return str(action(self._join(args)))

    def _close(self, args: list[str]) -> str:
        if not args:
            action = self.actions.get("close_current_tab")
            if action is None:
                return "Tab closing is unavailable."
            ok = bool(action())
            return "Closed the current tab." if ok else "Could not close the current tab."
        action = self.actions.get("close_tabs_matching")
        if action is None:
            return "Closing matching tabs is unavailable."
        count = int(action(self._join(args)))
        return f"Closed {count} matching background tab(s)."

    def _close_others(self, _args: list[str]) -> str:
        action = self.actions.get("close_other_tabs")
        if action is None:
            return "Close-others is unavailable."
        count = int(action())
        return f"Closed {count} other tab(s)."

    def _bookmark(self, _args: list[str]) -> str:
        action = self.actions.get("bookmark_current_page")
        if action is None:
            return "Bookmarks are unavailable."
        return str(action())

    def _bookmarks(self, args: list[str]) -> str:
        action = self.actions.get("search_bookmarks")
        if action is None:
            return "Bookmarks are unavailable."
        query = self._join(args)
        return str(action(query))

    def _open_doc(self, args: list[str]) -> str:
        action = self.actions.get("open_first_document")
        if action is None:
            return "Opening local documents is unavailable."
        if not args:
            return "Usage: /open-doc router notes"
        return str(action(self._join(args)))

    def _open_pdf(self, args: list[str]) -> str:
        action = self.actions.get("open_first_pdf")
        if action is None:
            return "Opening local PDFs is unavailable."
        if not args:
            return "Usage: /open-pdf resume"
        return str(action(self._join(args)))

    def _links(self, _args: list[str]) -> str:
        action = self.actions.get("list_page_links")
        if action is None:
            return "Page-link listing is unavailable."
        return str(action())

    def _open_link(self, args: list[str]) -> str:
        action = self.actions.get("open_page_link")
        if action is None:
            return "Opening page links is unavailable."
        if not args:
            return "Usage: /open-link 2 or /open-link pricing"
        return str(action(self._join(args)))

    def _back(self, _args: list[str]) -> str:
        action = self.actions.get("navigate_back")
        if action is None:
            return "Back navigation is unavailable."
        ok = bool(action())
        return "Went back in the current tab." if ok else "Could not go back in the current tab."

    def _forward(self, _args: list[str]) -> str:
        action = self.actions.get("navigate_forward")
        if action is None:
            return "Forward navigation is unavailable."
        ok = bool(action())
        return "Went forward in the current tab." if ok else "Could not go forward in the current tab."

    def _reload(self, _args: list[str]) -> str:
        action = self.actions.get("reload_current")
        if action is None:
            return "Reload is unavailable."
        ok = bool(action())
        return "Reloading the current tab." if ok else "Could not reload the current tab."

    def _duplicate(self, _args: list[str]) -> str:
        action = self.actions.get("duplicate_current_tab")
        if action is None:
            return "Tab duplication is unavailable."
        ok = bool(action())
        return "Duplicated the current tab." if ok else "Could not duplicate the current tab."

    def _extensions(self, _args: list[str]) -> str:
        action = self.actions.get("list_extensions")
        if action is None:
            return "Extension support is unavailable."
        return str(action())

    def _install_extension(self, args: list[str]) -> str:
        action = self.actions.get("install_extension")
        if action is None:
            return "Extension install support is unavailable."
        if not args:
            return "Usage: /install-extension /path/to/extension.zip"
        return str(action(self._join(args)))

    def _install_extension_page(self, _args: list[str]) -> str:
        action = self.actions.get("install_extension_from_page")
        if action is None:
            return "Extension page install is unavailable."
        return str(action())

    def _toggle_extension(self, args: list[str]) -> str:
        action = self.actions.get("toggle_extension")
        if action is None:
            return "Extension toggle support is unavailable."
        if not args:
            return "Usage: /toggle-extension ublock"
        return str(action(self._join(args)))

    def _remove_extension(self, args: list[str]) -> str:
        action = self.actions.get("remove_extension")
        if action is None:
            return "Extension removal is unavailable."
        if not args:
            return "Usage: /remove-extension ublock"
        return str(action(self._join(args)))

    def _reload_extensions(self, _args: list[str]) -> str:
        action = self.actions.get("reload_extensions")
        if action is None:
            return "Extension reload support is unavailable."
        return str(action())

    def _park(self, _args: list[str]) -> str:
        count = int(self.actions["park_background_tabs"]())
        return f"Parked {count} background tab(s)."

    def _park_current(self, _args: list[str]) -> str:
        action = self.actions.get("park_current_tab")
        if action is None:
            return "Current-tab parking is unavailable."
        ok = bool(action())
        return "Parked the current tab for later." if ok else "Could not park the current tab."

    def _lite(self, _args: list[str]) -> str:
        ok = bool(self.actions["open_lite_current"]())
        return "Opened the current page in Aster Lite mode." if ok else "Could not switch the current page into Lite mode."

    def _mobile(self, _args: list[str]) -> str:
        action = self.actions.get("open_mobile_current")
        if action is None:
            return "Mobile view is unavailable."
        ok = bool(action())
        return "Opened the current page in mobile view." if ok else "Could not open mobile view for this tab."

    def _desktop(self, _args: list[str]) -> str:
        action = self.actions.get("open_desktop_current")
        if action is None:
            return "Desktop view is unavailable."
        ok = bool(action())
        return "Returned the current page to desktop view." if ok else "Could not return this tab to desktop view."

    def _container(self, args: list[str]) -> str:
        if not args:
            current = self.actions["get_current_container"]()
            return f"Current container: {current}"
        name = args[0]
        self.actions["set_container"](name)
        return f"Switched active container to {name}"

    def _stats(self, _args: list[str]) -> str:
        return str(self.actions["stats"]())

    def _streaming(self, _args: list[str]) -> str:
        action = self.actions.get("streaming_status")
        if action is None:
            return "Streaming helper unavailable."
        return str(action())

    def _diagnose(self, _args: list[str]) -> str:
        action = self.actions.get("diagnose_current_page")
        if action is None:
            return "Diagnostics are unavailable."
        return str(action())

    def _wg(self, _args: list[str]) -> str:
        action = self.actions.get("wireguard_status")
        if action is None:
            return "WireGuard helper is not connected."
        return str(action())


class IntentRouter:
    COMMON_DESTINATIONS = {
        "youtube": "https://www.youtube.com",
        "youtube tv": "https://tv.youtube.com",
        "github": "https://github.com",
        "reddit": "https://www.reddit.com",
        "amazon prime video": "https://www.primevideo.com",
        "prime video": "https://www.primevideo.com",
        "primevideo": "https://www.primevideo.com",
        "netflix": "https://www.netflix.com",
        "disney plus": "https://www.disneyplus.com",
        "disney+": "https://www.disneyplus.com",
        "max": "https://play.max.com",
        "hulu": "https://www.hulu.com",
        "peacock": "https://www.peacocktv.com",
        "paramount plus": "https://www.paramountplus.com",
        "paramount+": "https://www.paramountplus.com",
        "apple tv": "https://tv.apple.com",
        "apple tv+": "https://tv.apple.com",
        "crunchyroll": "https://www.crunchyroll.com",
        "twitch": "https://www.twitch.tv",
        "duckduckgo": "https://duckduckgo.com",
    }
    RISKY_TOKENS = {
        'delete', 'remove file', 'trash', 'send email', 'purchase', 'buy', 'checkout', 'submit form',
        'upload', 'log in', 'login', 'sign in', 'enter password', 'bank transfer', 'pay bill',
    }
    CHAIN_VERBS = (
        'open', 'go', 'visit', 'search', 'find', 'look', 'locate', 'show', 'list', 'summarize', 'compare',
        'park', 'save', 'switch', 'use', 'change', 'close', 'bookmark', 'reload', 'refresh', 'back', 'forward',
        'duplicate', 'mute', 'unmute'
    )

    def __init__(self, actions: dict[str, Callable[..., Any]]) -> None:
        self.actions = actions

    def execute(self, text: str, *, allow_chain: bool = True) -> str | None:
        normalized = " ".join(text.strip().split())
        lowered = normalized.lower()
        if not normalized:
            return None

        if allow_chain:
            parts = self._split_chain(normalized)
            if len(parts) > 1:
                results: list[str] = []
                for part in parts:
                    result = self.execute(part, allow_chain=False)
                    if result is not None:
                        results.append(result)
                if results:
                    return "\n".join(results)

        if any(token in lowered for token in self.RISKY_TOKENS):
            return 'That request needs confirmation and is not performed automatically by the internal assistant.'

        open_external = self.actions.get('open_external')
        open_capsule = self.actions.get('open_capsule')
        open_url = self.actions.get('open_url')
        open_in_current = self.actions.get('open_in_current') or open_url
        search = self.actions.get('search')
        find_in_page = self.actions.get('find_in_page')
        list_tabs = self.actions.get('list_tabs')
        switch_tab = self.actions.get('switch_tab')
        close_current_tab = self.actions.get('close_current_tab')
        close_tabs_matching = self.actions.get('close_tabs_matching')
        close_other_tabs = self.actions.get('close_other_tabs')
        bookmark_current_page = self.actions.get('bookmark_current_page')
        search_bookmarks = self.actions.get('search_bookmarks')
        open_first_bookmark = self.actions.get('open_first_bookmark')
        list_page_links = self.actions.get('list_page_links')
        open_page_link = self.actions.get('open_page_link')
        navigate_back = self.actions.get('navigate_back')
        navigate_forward = self.actions.get('navigate_forward')
        reload_current = self.actions.get('reload_current')
        duplicate_current_tab = self.actions.get('duplicate_current_tab')
        open_first_document = self.actions.get('open_first_document')
        open_first_pdf = self.actions.get('open_first_pdf')
        search_local_documents = self.actions.get('search_local_documents')
        search_local_pdfs = self.actions.get('search_local_pdfs')
        search_history = self.actions.get('search_history')
        open_downloads = self.actions.get('open_downloads')
        summarize_selection_or_page = self.actions.get('summarize_selection_or_page')
        compare_tabs = self.actions.get('compare_tabs')
        park_background_tabs = self.actions.get('park_background_tabs')
        park_current_tab = self.actions.get('park_current_tab')
        open_lite_current = self.actions.get('open_lite_current')
        set_container = self.actions.get('set_container')
        streaming_status = self.actions.get('streaming_status')
        stats = self.actions.get('stats')
        list_extensions = self.actions.get('list_extensions')
        toggle_extension = self.actions.get('toggle_extension')
        remove_extension = self.actions.get('remove_extension')
        reload_extensions = self.actions.get('reload_extensions')

        m = re.match(r"^(?:open|go to|visit)\s+(.+?)\s+(?:externally|outside|in\s+external\s+browser|in\s+compatibility\s+browser)$", lowered)
        if m and open_external is not None:
            raw_target = normalized.split(maxsplit=1)[1].strip()
            for suffix in (" in compatibility browser", " in external browser", " externally", " outside"):
                if raw_target.lower().endswith(suffix):
                    raw_target = raw_target[: -len(suffix)].strip()
                    break
            destination = self._resolve_destination(raw_target)
            open_external(destination)
            return f"Opening externally: {destination}"

        m = re.match(r"^(?:open|go to|visit)\s+(.+?)\s+in\s+(?:this|current)\s+tab$", lowered)
        if m and open_in_current is not None:
            raw_target = normalized.split(maxsplit=1)[1].rsplit(' in ', 1)[0].strip()
            destination = self._resolve_destination(raw_target)
            return str(open_in_current(destination))

        if re.match(r"^(?:open|go to|visit)\s+(.+?)\s+in\s+(?:a\s+)?capsule$", lowered) and open_capsule is not None:
            raw_target = normalized.split(maxsplit=1)[1].rsplit(' in ', 1)[0].strip()
            destination = self._resolve_destination(raw_target)
            open_capsule(destination)
            return f"Opening in capsule: {destination}"

        if 'open downloads' in lowered or 'show downloads' in lowered:
            if open_downloads is None:
                return 'Downloads helper is unavailable.'
            ok = bool(open_downloads())
            return 'Opened the downloads folder.' if ok else 'Could not open the downloads folder.'

        if any(token in lowered for token in ['what tabs are open', 'show tabs', 'list tabs', 'open tabs']):
            if list_tabs is not None:
                return str(list_tabs())

        m = re.match(r"^(?:switch to|go to)\s+tab\s+([0-9]+)$", lowered)
        if m and switch_tab is not None:
            return str(switch_tab(m.group(1)))

        m = re.match(r"^(?:switch to|go to)\s+(.+?)\s+tab$", lowered)
        if m and switch_tab is not None:
            target = normalized.split(maxsplit=2)[2].rsplit(' tab', 1)[0].strip()
            return str(switch_tab(target))

        if lowered in {'close this tab', 'close current tab'}:
            if close_current_tab is None:
                return 'Tab closing is unavailable.'
            ok = bool(close_current_tab())
            return 'Closed the current tab.' if ok else 'Could not close the current tab.'

        if lowered in {'close other tabs', 'close the other tabs'}:
            if close_other_tabs is None:
                return 'Close-others is unavailable.'
            count = int(close_other_tabs())
            return f'Closed {count} other tab(s).'

        m = re.match(r"^(?:close|remove)\s+tabs?\s+(?:about|for|matching)?\s*(.+)$", lowered)
        if m and close_tabs_matching is not None and 'this tab' not in lowered and 'other tabs' not in lowered:
            query = m.group(1).strip()
            if query:
                count = int(close_tabs_matching(query))
                return f'Closed {count} matching background tab(s).'

        if 'diagnose' in lowered and any(token in lowered for token in ['page', 'https', 'security', 'certificate', 'browser']):
            diagnose = self.actions.get('diagnose_current_page')
            if diagnose is not None:
                return str(diagnose())

        if lowered in {'reload', 'reload this page', 'refresh', 'refresh this page'}:
            if reload_current is None:
                return 'Reload is unavailable.'
            ok = bool(reload_current())
            return 'Reloading the current tab.' if ok else 'Could not reload the current tab.'

        if lowered in {'back', 'go back'}:
            if navigate_back is None:
                return 'Back navigation is unavailable.'
            ok = bool(navigate_back())
            return 'Went back in the current tab.' if ok else 'Could not go back in the current tab.'

        if lowered in {'forward', 'go forward'}:
            if navigate_forward is None:
                return 'Forward navigation is unavailable.'
            ok = bool(navigate_forward())
            return 'Went forward in the current tab.' if ok else 'Could not go forward in the current tab.'

        if lowered in {'duplicate this tab', 'duplicate current tab'}:
            if duplicate_current_tab is None:
                return 'Tab duplication is unavailable.'
            ok = bool(duplicate_current_tab())
            return 'Duplicated the current tab.' if ok else 'Could not duplicate the current tab.'

        if lowered in {'bookmark this page', 'save this page', 'bookmark current page', 'save current page'}:
            if bookmark_current_page is None:
                return 'Bookmarks are unavailable.'
            return str(bookmark_current_page())

        m = re.match(r"^(?:show|list|find|search)\s+(?:my\s+)?bookmarks?\s*(?:for|about)?\s*(.*)$", lowered)
        if m and search_bookmarks is not None:
            query = m.group(1).strip()
            return str(search_bookmarks(query))

        m = re.match(r"^(?:open|go to)\s+(?:my\s+)?bookmark\s*(?:for|about)?\s*(.+)$", lowered)
        if m and open_first_bookmark is not None:
            query = m.group(1).strip()
            return str(open_first_bookmark(query))

        if 'show links' in lowered or 'list links' in lowered or 'links on this page' in lowered:
            if list_page_links is not None:
                return str(list_page_links())

        m = re.match(r"^(?:open|click|visit)\s+link\s+([0-9]+)$", lowered)
        if m and open_page_link is not None:
            return str(open_page_link(m.group(1)))

        m = re.match(r"^(?:open|click|visit)\s+link\s+(?:for|about|called|named)?\s*(.+)$", lowered)
        if m and open_page_link is not None:
            query = m.group(1).strip()
            return str(open_page_link(query))

        m = re.match(r"^(?:open|show)\s+(.+?)\s+pdfs?$", lowered)
        if m and open_first_pdf is not None:
            return str(open_first_pdf(m.group(1).replace('my ', '', 1).strip()))

        m = re.match(r"^(?:open|show)\s+(?:my\s+)?pdfs?\s*(?:for|about|named|called)?\s*(.+)$", lowered)
        if m and open_first_pdf is not None:
            return str(open_first_pdf(m.group(1).strip()))

        m = re.match(r"^(?:open|show)\s+(.+?)\s+(?:documents?|files?)$", lowered)
        if m and open_first_document is not None:
            return str(open_first_document(m.group(1).replace('my ', '', 1).strip()))

        m = re.match(r"^(?:open|show)\s+(?:my\s+)?(?:documents?|files?)\s*(?:for|about|named|called)?\s*(.+)$", lowered)
        if m and open_first_document is not None:
            return str(open_first_document(m.group(1).strip()))

        if re.match(r"^(?:open|go to|visit)\s+", lowered) and open_url is not None:
            raw_target = normalized.split(maxsplit=1)[1].strip()
            destination = self._resolve_destination(raw_target)
            open_url(destination)
            return f"Opening {destination}"

        if lowered in {'show extensions', 'list extensions', 'what extensions are installed'} and list_extensions is not None:
            return str(list_extensions())

        m = re.match(r"^(?:enable|disable|toggle)\s+extension\s+(.+)$", lowered)
        if m and toggle_extension is not None:
            return str(toggle_extension(m.group(1).strip()))

        m = re.match(r"^(?:remove|delete|uninstall)\s+extension\s+(.+)$", lowered)
        if m and remove_extension is not None:
            return str(remove_extension(m.group(1).strip()))

        if lowered in {'reload extensions', 'refresh extensions'} and reload_extensions is not None:
            return str(reload_extensions())

        if search_local_pdfs is not None:
            m = re.match(r"^(?:find|search|look\s+for|locate)\s+(?:my\s+)?(?:pdfs?)\s*(?:for|about|named|called)?\s*(.+)$", lowered)
            if m and m.group(1).strip():
                return str(search_local_pdfs(m.group(1).strip()))

        if search_local_documents is not None:
            m = re.match(
                r"^(?:find|search|look\s+for|locate)\s+(?:my\s+)?(?:documents?|files?|downloads?|desktop|notes?|pdfs?)\s*(?:for|about|named|called)?\s*(.+)$",
                lowered,
            )
            if m and m.group(1).strip():
                return str(search_local_documents(m.group(1).strip()))

        if search_history is not None:
            m = re.match(r"^(?:find|search|look\s+for)\s+(?:in\s+)?(?:my\s+)?(?:history|recent pages?|visited sites?)\s*(?:for|about)?\s*(.+)$", lowered)
            if m and m.group(1).strip():
                return str(search_history(m.group(1).strip()))

        if 'compare these two tabs' in lowered or 'compare tabs' in lowered or 'compare current tab' in lowered:
            if compare_tabs is not None:
                return str(compare_tabs())

        if 'summarize selected text' in lowered or 'summarize selection' in lowered or 'summarize this page' in lowered or 'what is this page about' in lowered:
            if summarize_selection_or_page is not None:
                return str(summarize_selection_or_page())

        m = re.match(r"^(?:find|look for|search)\s+(.+?)\s+(?:on|in)\s+(?:this\s+)?page$", lowered)
        if m and find_in_page is not None:
            query = m.group(1).strip()
            find_in_page(query)
            return f"Searching the current page for: {query}"

        m = re.match(r"^(?:find|look for|search)\s+(?:on|in)\s+(?:this\s+)?page\s+for\s+(.+)$", lowered)
        if m and find_in_page is not None:
            query = m.group(1).strip()
            find_in_page(query)
            return f"Searching the current page for: {query}"

        if re.match(r"^(?:search|look up|find)\s+", lowered) and " on page" not in lowered and " in page" not in lowered:
            if search is not None:
                query = normalized.split(maxsplit=1)[1].strip()
                search(query)
                return f"Searching for: {query}"

        if any(token in lowered for token in ["park this tab", "park current", "park current tab", "save this tab for later"]):
            if park_current_tab is not None:
                ok = bool(park_current_tab())
                return "Parked the current tab for later." if ok else "Could not park the current tab."

        if any(token in lowered for token in ["park tabs", "park background", "save memory", "free up memory", "park the other tabs"]):
            if park_background_tabs is not None:
                count = int(park_background_tabs())
                return f"Parked {count} background tab(s)."

        if any(token in lowered for token in ["lite mode", "low memory mode", "reader mode"]):
            if open_lite_current is not None:
                ok = bool(open_lite_current())
                return "Opened the current page in Aster Lite mode." if ok else "Could not switch the current page into Lite mode."

        m = re.search(r"(?:switch to|use|change to)\s+([a-z0-9_.-]+)\s+container", lowered)
        if m and set_container is not None:
            name = m.group(1)
            set_container(name)
            return f"Switched active container to {name}"

        if any(token in lowered for token in ["streaming status", "drm status", "prime video", "widevine"]):
            if streaming_status is not None:
                return str(streaming_status())

        if any(token in lowered for token in ["memory stats", "browser stats", "tab stats"]):
            if stats is not None:
                return str(stats())

        return None

    def _split_chain(self, text: str) -> list[str]:
        parts: list[str] = []
        pending = text.strip()
        if not pending:
            return []
        # Strong separators first.
        strong = re.split(r"\s+(?:and then|then)\s+", pending, flags=re.I)
        queue: list[str] = []
        for item in strong:
            item = item.strip(' ,')
            if not item:
                continue
            queue.append(item)
        if not queue:
            return []
        for item in queue:
            current = item
            while True:
                match = re.search(
                    r"\s+and\s+(?=(?:" + "|".join(self.CHAIN_VERBS) + r")\b)",
                    current,
                    flags=re.I,
                )
                if not match:
                    parts.append(current.strip(' ,'))
                    break
                first = current[: match.start()].strip(' ,')
                second = current[match.end() :].strip(' ,')
                if first:
                    parts.append(first)
                current = second
        cleaned = [part for part in parts if part]
        return cleaned or [text]

    def _resolve_destination(self, raw_target: str) -> str:
        key = raw_target.strip().lower()
        if key in self.COMMON_DESTINATIONS:
            return self.COMMON_DESTINATIONS[key]
        if raw_target.startswith(("http://", "https://", "file://")):
            return raw_target
        if " " not in raw_target and "." in raw_target:
            return raw_target
        return raw_target



def build_search_url(template: str, query: str) -> str:
    encoded = urllib.parse.quote_plus(query)
    return template.replace("{query}", encoded)
