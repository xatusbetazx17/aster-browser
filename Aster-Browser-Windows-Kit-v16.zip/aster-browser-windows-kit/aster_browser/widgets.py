from __future__ import annotations

import copy
import html
import math
from typing import Callable
import json
from pathlib import Path
from PyQt6.QtCore import QElapsedTimer, QEvent, QObject, QPoint, QPointF, QThread, QSize, Qt, pyqtSignal, QSettings, QTimer, QVariantAnimation, QEasingCurve
from PyQt6.QtGui import QBrush, QFont, QFontMetrics, QImage, QMouseEvent, QPainter, QColor, QPen, QPixmap, QRadialGradient
from PyQt6.QtWidgets import (
    QAbstractButton,
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDockWidget,
    QFormLayout,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QTabBar,
    QTabWidget,
    QTextBrowser,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .ai import AIBroker, AIContext, CommandRouter, IntentRouter
from .config import DEFAULT_ACCENT, AIConfig, BrowserConfig, normalize_hex_color
from .icons import svg_icon
from .paths import data_dir
from .lite import LitePage, render_lite_page
from .theme import PAGE_BACKGROUND, available_qt_styles
from .localization import interface_language_choices, language_choices, normalize_interface_language, normalize_language_code, tr


class AddressLineEdit(QLineEdit):
    """Address bar that follows the selection habits of a mainstream browser.

    A plain QLineEdit selects its whole contents whenever it is focused, which is
    wrong in both directions here. Clicking it left the caret where the pointer
    landed instead of offering the address for replacement, while focus the user
    never asked for - the window opening, the new tab page closing under them -
    handed them a fully selected address that the next keystroke would wipe.

    So selection is tied to intent: a click or Ctrl+L selects everything, a drag
    keeps the range the user drew, and focus that merely fell here selects
    nothing and parks the caret at the end.
    """

    _SELECT_ALL_REASONS = (
        Qt.FocusReason.ShortcutFocusReason,
        Qt.FocusReason.TabFocusReason,
        Qt.FocusReason.BacktabFocusReason,
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._select_on_release = False

    def focusInEvent(self, event) -> None:
        super().focusInEvent(event)
        reason = event.reason()
        if reason == Qt.FocusReason.MouseFocusReason:
            # Wait for the release: a drag means the user is picking a range.
            self._select_on_release = True
        elif reason in self._SELECT_ALL_REASONS:
            self.selectAll()
        else:
            self.deselect()
            self.setCursorPosition(len(self.text()))

    def focusOutEvent(self, event) -> None:
        self._select_on_release = False
        super().focusOutEvent(event)
        self.deselect()

    def mouseReleaseEvent(self, event) -> None:
        super().mouseReleaseEvent(event)
        if not self._select_on_release:
            return
        self._select_on_release = False
        if not self.hasSelectedText():
            self.selectAll()


class AsterTitleBar(QWidget):
    def __init__(self, window: QWidget, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._window = window
        self._drag_offset: QPoint | None = None
        self.setObjectName("AsterTitleBar")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 4, 10, 4)
        layout.setSpacing(6)

        self.logo_button = QToolButton(self)
        self.logo_button.setObjectName("TitleLogoButton")
        self.logo_button.setIcon(svg_icon("aster_logo"))
        self.logo_button.setIconSize(QSize(18, 18))
        self.logo_button.setAutoRaise(True)
        self.logo_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.logo_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.logo_button.setFixedSize(24, 24)

        title_box = QVBoxLayout()
        title_box.setContentsMargins(0, 0, 0, 0)
        title_box.setSpacing(0)
        self.title_label = QLabel("Aster Browser")
        self.title_label.setObjectName("AsterTitleLabel")
        self.context_label = QLabel(tr("Low-RAM browser + internal assistant"))
        self.context_label.setObjectName("AsterContextLabel")
        self.context_label.setMinimumWidth(160)
        title_box.addWidget(self.title_label)
        title_box.addWidget(self.context_label)

        self.file_menu = QMenu(tr("File"), self)
        self.view_menu = QMenu(tr("View"), self)
        self.tools_menu = QMenu(tr("Tools"), self)
        self.compact_menu = QMenu(tr("Menu"), self)

        self.file_button = self._make_menu_button(tr("File"), self.file_menu)
        self.view_button = self._make_menu_button(tr("View"), self.view_menu)
        self.tools_button = self._make_menu_button(tr("Tools"), self.tools_menu)
        self.compact_button = self._make_menu_button(tr("Menu"), self.compact_menu)
        self.compact_button.setObjectName("HeaderCompactButton")
        self.compact_button.setIcon(svg_icon("menu_more"))
        self.compact_button.setIconSize(QSize(14, 14))
        self.compact_button.hide()

        self.min_button = self._make_window_button("minimize", tr("Minimize window"))
        self.max_button = self._make_window_button("maximize", tr("Maximize window"))
        self.close_button = self._make_window_button("close", tr("Close window"), close=True)

        self.min_button.clicked.connect(self._window.showMinimized)
        self.max_button.clicked.connect(self.toggle_maximize)
        self.close_button.clicked.connect(self._window.close)

        layout.addWidget(self.logo_button)
        layout.addLayout(title_box)
        layout.addSpacing(8)
        layout.addWidget(self.file_button)
        layout.addWidget(self.view_button)
        layout.addWidget(self.tools_button)
        layout.addWidget(self.compact_button)
        layout.addStretch(1)
        layout.addWidget(self.min_button)
        layout.addWidget(self.max_button)
        layout.addWidget(self.close_button)
        self.sync_window_state()

    def _make_menu_button(self, text: str, menu: QMenu) -> QToolButton:
        button = QToolButton(self)
        button.setText(text)
        # setMenu() KULLANMIYORUZ: menu atanan bir QToolButton'a Qt bir
        # acilir-ok cizer ve bu ok stile gomulu oldugu icin bazi Qt
        # temalarinda QSS ile bastirilamaz.
        button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        button.setObjectName("HeaderMenuButton")
        button.clicked.connect(
            lambda _checked=False, b=button, m=menu: self._popup_header_menu(b, m)
        )
        return button

    def _popup_header_menu(self, button: QToolButton, menu: QMenu) -> None:
        if menu is None:
            return
        # Menuyu tiklama olayi bittikten SONRA aciyoruz: exec() modal bir
        # dongu baslattigi icin dogrudan cagrilirsa buton fare-birakma
        # olayini hic almiyor ve basili gorunumunde takili kaliyor.
        QTimer.singleShot(0, lambda b=button, m=menu: self._exec_header_menu(b, m))

    def _exec_header_menu(self, button: QToolButton, menu: QMenu) -> None:
        button.setDown(False)
        try:
            menu.exec(button.mapToGlobal(QPoint(0, button.height())))
        finally:
            button.setDown(False)
            button.setAttribute(Qt.WidgetAttribute.WA_UnderMouse, False)
            button.update()

    def _make_window_button(self, icon_name: str, tooltip: str, close: bool = False) -> QToolButton:
        button = QToolButton(self)
        button.setIcon(svg_icon(icon_name))
        button.setIconSize(QSize(11, 11))
        button.setFixedSize(28, 22)
        button.setAutoRaise(True)
        button.setToolTip(tooltip)
        button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        button.setObjectName("WindowCloseButton" if close else "WindowButton")
        return button

    def retranslate(self) -> None:
        """Re-apply menu, button and tooltip text after an interface language change."""
        self.file_menu.setTitle(tr("File"))
        self.view_menu.setTitle(tr("View"))
        self.tools_menu.setTitle(tr("Tools"))
        self.compact_menu.setTitle(tr("Menu"))
        self.file_button.setText(tr("File"))
        self.view_button.setText(tr("View"))
        self.tools_button.setText(tr("Tools"))
        self.compact_button.setText(tr("Menu"))
        self.min_button.setToolTip(tr("Minimize window"))
        self.close_button.setToolTip(tr("Close window"))
        self.sync_window_state()
        self._rebuild_compact_menu()

    def set_context_text(self, text: str) -> None:
        clean = (text or "").strip()
        if not clean:
            clean = tr("Low-RAM browser + internal assistant")
        if len(clean) > 72:
            clean = clean[:69].rstrip() + "…"
        self.context_label.setText(clean)

    def apply_compact_mode(self, compact: bool) -> None:
        for button in (self.file_button, self.view_button, self.tools_button):
            button.setVisible(not compact)
        self.compact_button.setVisible(compact)
        self.context_label.setVisible(not compact)
        if compact:
            self._rebuild_compact_menu()

    def _rebuild_compact_menu(self) -> None:
        self.compact_menu.clear()
        file_menu = self.compact_menu.addMenu(tr("File"))
        file_menu.addActions(self.file_menu.actions())
        view_menu = self.compact_menu.addMenu(tr("View"))
        view_menu.addActions(self.view_menu.actions())
        tools_menu = self.compact_menu.addMenu(tr("Tools"))
        tools_menu.addActions(self.tools_menu.actions())

    def apply_visual_scale(self, scale: float) -> None:
        scale = max(0.88, min(scale, 1.15))
        logo_px = max(15, int(round(16 * scale)))
        logo_box = max(20, int(round(22 * scale)))
        window_px = max(10, int(round(11 * scale)))
        window_box_w = max(26, int(round(28 * scale)))
        window_box_h = max(20, int(round(22 * scale)))
        compact_px = max(11, int(round(12 * scale)))
        self.logo_button.setIconSize(QSize(logo_px, logo_px))
        self.logo_button.setFixedSize(logo_box, logo_box)
        self.compact_button.setIconSize(QSize(compact_px, compact_px))
        for button in (self.min_button, self.max_button, self.close_button):
            button.setIconSize(QSize(window_px, window_px))
            button.setFixedSize(window_box_w, window_box_h)
        menu_font = QFont(self.font())
        menu_font.setPointSizeF(max(9.5, 10.0 * scale))
        menu_font.setWeight(QFont.Weight.DemiBold)
        for button in (self.file_button, self.view_button, self.tools_button, self.compact_button):
            button.setFont(menu_font)
            button.setMinimumHeight(max(20, int(round(22 * scale))))
        title_font = QFont(self.title_label.font())
        title_font.setPointSizeF(max(10.5, 11.5 * scale))
        title_font.setWeight(QFont.Weight.DemiBold)
        self.title_label.setFont(title_font)
        context_font = QFont(self.context_label.font())
        context_font.setPointSizeF(max(8.5, 9.2 * scale))
        self.context_label.setFont(context_font)

    def sync_window_state(self) -> None:
        if self._window.isMaximized():
            self.max_button.setIcon(svg_icon("restore"))
            self.max_button.setToolTip(tr("Restore window"))
        else:
            self.max_button.setIcon(svg_icon("maximize"))
            self.max_button.setToolTip(tr("Maximize window"))

    def toggle_maximize(self) -> None:
        if self._window.isMaximized():
            self._window.showNormal()
        else:
            self._window.showMaximized()
        self.sync_window_state()

    def _can_drag_from(self, pos) -> bool:
        child = self.childAt(pos)
        return child is None or isinstance(child, QLabel)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.MouseButton.LeftButton and self._can_drag_from(event.position().toPoint()):
            self._drag_offset = event.globalPosition().toPoint() - self._window.frameGeometry().topLeft()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            if self._window.isMaximized():
                self._window.showNormal()
                self.sync_window_state()
                self._drag_offset = QPoint(self.width() // 2, 18)
            self._window.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        self._drag_offset = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.MouseButton.LeftButton and self._can_drag_from(event.position().toPoint()):
            self.toggle_maximize()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class TabCloseButton(QAbstractButton):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(26, 18)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(tr("Close tab"))
        self._is_hovered = False
        self._opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._opacity_effect)
        self._target_opacity = 0.0
        self._opacity_effect.setOpacity(0.0)
        self._anim: QVariantAnimation | None = None

    def set_target_opacity(self, target: float, animate: bool = True) -> None:
        if not animate:
            if self._anim is not None:
                self._anim.stop()
                self._anim = None
            self._target_opacity = target
            self._opacity_effect.setOpacity(target)
            self.setVisible(target > 0.02)
            return

        if abs(self._target_opacity - target) < 0.01:
            return

        self._target_opacity = target
        if target > 0.02:
            self.setVisible(True)

        if self._anim is not None:
            self._anim.stop()
            self._anim = None

        anim = QVariantAnimation(self)
        anim.setDuration(120)
        anim.setStartValue(self._opacity_effect.opacity())
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic if target > 0.5 else QEasingCurve.Type.InCubic)

        def _on_val(val: float) -> None:
            self._opacity_effect.setOpacity(float(val))

        def _on_finish() -> None:
            if target <= 0.02:
                self.setVisible(False)
            if self._anim is anim:
                self._anim = None

        anim.valueChanged.connect(_on_val)
        anim.finished.connect(_on_finish)
        self._anim = anim
        anim.start()

    def enterEvent(self, event) -> None:
        self._is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._is_hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self._is_hovered:
            if self.isDown():
                painter.setBrush(QColor(255, 255, 255, 45))
            else:
                painter.setBrush(QColor(255, 255, 255, 28))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(0, 0, 18, 18, 9, 9)
        cross_color = QColor(245, 247, 250) if self._is_hovered else QColor(195, 202, 212)
        pen = QPen(cross_color, 1.4)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(QPointF(5.5, 5.5), QPointF(12.5, 12.5))
        painter.drawLine(QPointF(12.5, 5.5), QPointF(5.5, 12.5))


class AsterTabBar(QTabBar):
    quick_actions_requested = pyqtSignal(int, QPoint)
    tab_close_animated = pyqtSignal(int)
    # (sekme indeksi, birakilan ekran noktasi)
    tab_detach_requested = pyqtSignal(int, QPoint)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setTabsClosable(True)
        self._press_index = -1
        self._press_was_current = False
        self._press_pos = QPoint()
        self._dragging = False
        self._active_tab_left_click_menu_enabled = True
        self._hovered_tab = -1
        self._animating_widths: dict[int, float] = {}
        self._closing_tabs: set[int] = set()
        self._open_animations: list[QVariantAnimation] = []
        self._open_animations_enabled = True
        self._detaching = False
        # Sekme cubugunun disina bu kadar piksel cikilinca sekme kopar.
        self._detach_threshold = 45
        self.setMouseTracking(True)
        self.setDrawBase(False)
        self.setExpanding(False)
        self.setUsesScrollButtons(True)
        self.setMovable(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._emit_custom_context_menu)
        self.currentChanged.connect(lambda _: self.update_close_buttons(animate=False))

    def tabSizeHint(self, index: int) -> QSize:
        base = super().tabSizeHint(index)
        extra_w = 16
        w = base.width() + extra_w
        if index in self._animating_widths:
            factor = self._animating_widths[index]
            return QSize(max(0, int(w * factor)), base.height())
        return QSize(w, base.height())

    def _force_tab_relayout(self) -> None:
        """QTabBar'a sekme yerlesimini yeniden hesaplatir.

        tabSizeHint'i degistirmek tek basina yetmiyor: QTabBar sekme
        geometrilerini onbellege aliyor ve updateGeometry() bu onbellegi
        gecersiz kilmiyor (olcumde tabRect sabit kaliyordu, yani animasyon
        ekrana hic yansimiyordu). setIconSize layoutDirty bayragini kaldirip
        yerlesimi yeniden kurduruyor.
        """
        self.setIconSize(self.iconSize())
        self.updateGeometry()

    def animate_open_tab(self, index: int) -> None:
        """Yeni sekmeyi Chromium'daki gibi genisleyerek acar."""
        if index < 0 or index >= self.count() or index in self._closing_tabs:
            return
        if index in self._animating_widths:
            return
        btn = self.tabButton(index, QTabBar.ButtonPosition.RightSide)
        if btn is not None:
            btn.hide()

        anim = QVariantAnimation(self)
        anim.setDuration(190)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)

        def _on_step(val: float) -> None:
            self._animating_widths[index] = float(val)
            self._force_tab_relayout()

        def _on_done() -> None:
            self._animating_widths.pop(index, None)
            self._force_tab_relayout()
            self.update_close_buttons(animate=False)

        anim.valueChanged.connect(_on_step)
        anim.finished.connect(_on_done)
        self._open_animations.append(anim)
        anim.finished.connect(
            lambda a=anim: self._open_animations.remove(a) if a in self._open_animations else None
        )
        anim.start()

    def set_open_animations_enabled(self, enabled: bool) -> None:
        self._open_animations_enabled = bool(enabled)

    def _end_internal_drag(self) -> None:
        """QTabBar'in kendi yatay tasima islemini sonlandirir."""
        try:
            release = QMouseEvent(
                QEvent.Type.MouseButtonRelease,
                QPointF(self._press_pos),
                Qt.MouseButton.LeftButton,
                Qt.MouseButton.NoButton,
                Qt.KeyboardModifier.NoModifier,
            )
            QTabBar.mouseReleaseEvent(self, release)
        except Exception:
            pass

    def animate_close_tab(self, index: int, on_complete: Callable[[], None]) -> None:
        if index in self._closing_tabs or index < 0 or index >= self.count():
            on_complete()
            return
        self._closing_tabs.add(index)
        btn = self.tabButton(index, QTabBar.ButtonPosition.RightSide)
        if btn is not None:
            btn.hide()
        anim = QVariantAnimation(self)
        # InOutCubic sonda ani "sicrama" hissini kaldiriyor.
        anim.setDuration(190)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)

        def _on_step(val: float) -> None:
            self._animating_widths[index] = float(val)
            self._force_tab_relayout()

        def _on_done() -> None:
            self._animating_widths.pop(index, None)
            self._closing_tabs.discard(index)
            self._force_tab_relayout()
            on_complete()

        anim.valueChanged.connect(_on_step)
        anim.finished.connect(_on_done)
        anim.start()

    def _ensure_custom_close_btn(self, index: int) -> TabCloseButton:
        btn = self.tabButton(index, QTabBar.ButtonPosition.RightSide)
        if not isinstance(btn, TabCloseButton):
            btn = TabCloseButton(self)
            btn.clicked.connect(lambda _=False, b=btn: self._on_close_clicked(b))
            self.setTabButton(index, QTabBar.ButtonPosition.RightSide, btn)
        return btn

    def _on_close_clicked(self, button: TabCloseButton) -> None:
        for i in range(self.count()):
            if self.tabButton(i, QTabBar.ButtonPosition.RightSide) is button:
                self.tabCloseRequested.emit(i)
                return

    def update_close_buttons(self, animate: bool = True) -> None:
        curr = self.currentIndex()
        for i in range(self.count()):
            if i in self._closing_tabs:
                continue
            btn = self._ensure_custom_close_btn(i)
            is_target = (i == curr or i == self._hovered_tab)
            target_op = 1.0 if is_target else 0.0
            should_animate = animate and (i != curr)
            btn.set_target_opacity(target_op, animate=should_animate)

    def set_active_tab_left_click_menu_enabled(self, enabled: bool) -> None:
        self._active_tab_left_click_menu_enabled = bool(enabled)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        self._press_pos = event.position().toPoint()
        self._press_index = self.tabAt(self._press_pos)
        self._press_was_current = self._press_index >= 0 and self._press_index == self.currentIndex()
        self._dragging = False
        self._detaching = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        pos = event.position().toPoint()
        if self._press_index >= 0 and (pos - self._press_pos).manhattanLength() > QApplication.startDragDistance():
            self._dragging = True

        # Sekme cubugundan dikeyde yeterince uzaklasildiysa sekmeyi kopar.
        if (
            self._press_index >= 0
            and not self._detaching
            and bool(event.buttons() & Qt.MouseButton.LeftButton)
            and self.count() > 0
        ):
            limit = self._detach_threshold
            if pos.y() < -limit or pos.y() > self.height() + limit:
                self._detaching = True
                index = self._press_index
                global_pos = event.globalPosition().toPoint()
                self._end_internal_drag()
                self._press_index = -1
                self._dragging = False
                QTimer.singleShot(
                    0, lambda i=index, g=global_pos: self.tab_detach_requested.emit(i, g)
                )
                event.accept()
                return

        super().mouseMoveEvent(event)
        idx = self.tabAt(pos)
        if idx != self._hovered_tab:
            self._hovered_tab = idx
            self.update_close_buttons(animate=True)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        super().leaveEvent(event)
        self._hovered_tab = -1
        self.update_close_buttons(animate=True)

    def tabInserted(self, index: int) -> None:
        super().tabInserted(index)
        self._ensure_custom_close_btn(index)
        # Ilk sekme ve pencere kurulumu sirasinda animasyon istemiyoruz.
        if self._open_animations_enabled and self.count() > 1:
            QTimer.singleShot(0, lambda i=index: self.animate_open_tab(i))
        QTimer.singleShot(0, lambda: self.update_close_buttons(animate=False))

    def tabRemoved(self, index: int) -> None:
        super().tabRemoved(index)
        QTimer.singleShot(0, lambda: self.update_close_buttons(animate=False))

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if self._detaching:
            # Sekme koparildi; bu birakma olayi eski sekmeye ait, yut.
            self._detaching = False
            self._press_index = -1
            self._dragging = False
            event.accept()
            return
        release_pos = event.position().toPoint()
        release_index = self.tabAt(release_pos)
        is_over_close_btn = False
        if release_index >= 0:
            btn = self.tabButton(release_index, QTabBar.ButtonPosition.RightSide)
            if btn and btn.geometry().contains(release_pos):
                is_over_close_btn = True

        should_open = (
            self._active_tab_left_click_menu_enabled
            and event.button() == Qt.MouseButton.LeftButton
            and self._press_was_current
            and not self._dragging
            and not is_over_close_btn
            and self._press_index >= 0
            and release_index == self._press_index
        )
        super().mouseReleaseEvent(event)
        if should_open:
            anchor = self.mapToGlobal(self.tabRect(self._press_index).bottomLeft())
            self.quick_actions_requested.emit(self._press_index, anchor)
            event.accept()

    def _emit_custom_context_menu(self, pos: QPoint) -> None:
        index = self.tabAt(pos)
        if index >= 0:
            self.quick_actions_requested.emit(index, self.mapToGlobal(pos))

    def contextMenuEvent(self, event) -> None:  # type: ignore[override]
        index = self.tabAt(event.pos())
        if index >= 0:
            self.quick_actions_requested.emit(index, self.mapToGlobal(event.pos()))
            event.accept()
            return
        super().contextMenuEvent(event)


class MobileViewWidget(QWidget):
    open_desktop_requested = pyqtSignal()
    refresh_requested = pyqtSignal()

    def __init__(self, view: QWidget, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._view = view
        self.setObjectName("AsterMobileView")
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        controls = QHBoxLayout()
        badge = QLabel(tr("Mobile view"))
        badge.setObjectName("AsterMobileBadge")
        self.device_combo = QComboBox(self)
        self.device_combo.addItem("Pixel 7 · 412 px", 412)
        self.device_combo.addItem("iPhone 14 Pro · 393 px", 393)
        self.device_combo.addItem("Galaxy S23 · 360 px", 360)
        self.device_combo.addItem("Small tablet · 768 px", 768)
        self.device_combo.currentIndexChanged.connect(self._apply_device_width)
        reload_button = QPushButton(tr("Reload"))
        reload_button.clicked.connect(lambda _checked=False: self.refresh_requested.emit())
        desktop_button = QPushButton(tr("Desktop view"))
        desktop_button.clicked.connect(lambda _checked=False: self.open_desktop_requested.emit())
        controls.addWidget(badge)
        controls.addWidget(self.device_combo)
        controls.addStretch(1)
        controls.addWidget(reload_button)
        controls.addWidget(desktop_button)

        center_row = QHBoxLayout()
        center_row.addStretch(1)
        self.mobile_shell = QFrame(self)
        self.mobile_shell.setObjectName("AsterMobileShell")
        shell_layout = QVBoxLayout(self.mobile_shell)
        shell_layout.setContentsMargins(12, 12, 12, 12)
        shell_layout.setSpacing(8)
        self.mobile_header = QLabel(tr("Responsive preview · mobile UA"))
        self.mobile_header.setObjectName("AsterMobileHeader")
        shell_layout.addWidget(self.mobile_header)
        self.phone_frame = QFrame(self.mobile_shell)
        self.phone_frame.setObjectName("AsterMobileFrame")
        phone_layout = QVBoxLayout(self.phone_frame)
        phone_layout.setContentsMargins(0, 0, 0, 0)
        phone_layout.setSpacing(0)
        phone_layout.addWidget(self._view)
        # 1. phone_frame'in dikeyde ezilmemesi ve ekranı kaplaması için '1' (esneme payı) ekliyoruz
        shell_layout.addWidget(self.phone_frame, 1, Qt.AlignmentFlag.AlignHCenter)
        
        # 2. Ana çerçevenin yukarı (AlignTop) yapışıp kağıt gibi katlanmasını engelliyoruz
        center_row.addWidget(self.mobile_shell)
        center_row.addStretch(1)

        layout.addLayout(controls)
        layout.addLayout(center_row, 1)
        self._apply_device_width()

    def web_view(self):
        return self._view

    def _apply_device_width(self) -> None:
        width = int(self.device_combo.currentData() or 412)
        width = max(320, min(width, 900))
        self.phone_frame.setFixedWidth(width)
        self.mobile_header.setText(tr("Responsive preview · {width}px viewport · mobile UA").format(width=width))


def _scaled_icon_pixmap(widget: QWidget, icon_name: str, logical_px: int):
    screen = None
    try:
        window_handle = widget.window().windowHandle() if widget.window() else None
        screen = window_handle.screen() if window_handle is not None else None
    except Exception:
        screen = None
    if screen is None:
        screen = QApplication.primaryScreen()
    try:
        dpr = float(screen.devicePixelRatio()) if screen is not None else 1.0
    except Exception:
        dpr = 1.0
    dpr = max(1.0, dpr)
    physical_px = max(logical_px, int(round(logical_px * dpr)))
    pixmap = svg_icon(icon_name).pixmap(physical_px, physical_px)
    try:
        pixmap.setDevicePixelRatio(dpr)
    except Exception:
        pass
    return pixmap


def get_site_favicon_cache_path(url: str) -> Path:
    from urllib.parse import urlparse
    if not url:
        return data_dir() / "favicons" / "unknown.png"
    parsed = urlparse(url if "://" in url else "https://" + url)
    domain = (parsed.netloc or parsed.path).strip().lower()
    if ":" in domain:
        domain = domain.split(":")[0]
    clean_domain = "".join(c if c.isalnum() or c in ".-_" else "_" for c in domain)
    if not clean_domain:
        clean_domain = "unknown"
    fav_dir = data_dir() / "favicons"
    fav_dir.mkdir(parents=True, exist_ok=True)
    return fav_dir / f"{clean_domain}.png"

def fetch_and_cache_favicon(url: str, timeout: float = 3.0) -> str | None:
    if not url:
        return None
    import urllib.request
    from urllib.parse import urlparse
    parsed = urlparse(url if "://" in url else "https://" + url)
    domain = (parsed.netloc or parsed.path).strip().lower()
    if not domain or "." not in domain:
        return None
    cache_path = get_site_favicon_cache_path(url)
    if cache_path.exists() and cache_path.stat().st_size > 100:
        return str(cache_path)
    
    endpoints = [
        f"https://www.google.com/s2/favicons?domain={domain}&sz=64",
        f"https://icons.duckduckgo.com/ip3/{domain}.ico",
        f"https://{domain}/favicon.ico"
    ]
    for ep in endpoints:
        try:
            req = urllib.request.Request(ep, headers={"User-Agent": "Mozilla/5.0 AsterBrowser/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                if len(data) > 100:
                    with open(cache_path, "wb") as f:
                        f.write(data)
                    return str(cache_path)
        except Exception:
            continue
    return None

class EditQuickLinkDialog(QDialog):
    def __init__(self, data=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Edit shortcut") if data else tr("Add shortcut"))
        self.setMinimumWidth(400)
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.title_input = QLineEdit(data.get("title", "") if data else "")
        self.title_input.setPlaceholderText(tr("e.g. X (Twitter)"))
        
        self.subtitle_input = QLineEdit(data.get("subtitle", "") if data else "")
        self.subtitle_input.setPlaceholderText(tr("Optional"))
        
        self.url_input = QLineEdit(data.get("url", "") if data else "")
        self.url_input.setPlaceholderText("https://...")

        # Simge Seçimi + Önizleme
        icon_row = QHBoxLayout()
        icon_row.setSpacing(8)
        self.icon_combo = QComboBox()
        self.icon_combo.addItem(svg_icon("search"), tr("Site favicon (automatic)"), "favicon")
        
        icons = ["search", "play_circle", "tv", "code_braces", "book_open", "speedometer"]
        for ic in icons:
            self.icon_combo.addItem(svg_icon(ic), ic, ic)

        self.preview_label = QLabel()
        self.preview_label.setFixedSize(24, 24)
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        icon_row.addWidget(self.icon_combo, 1)
        icon_row.addWidget(self.preview_label)

        current_icon = data.get("icon", "favicon") if data else "favicon"
        idx = self.icon_combo.findData(current_icon)
        if idx >= 0:
            self.icon_combo.setCurrentIndex(idx)
        else:
            self.icon_combo.setCurrentIndex(0)

        form.addRow(tr("Page name:"), self.title_input)
        form.addRow(tr("Subtitle:"), self.subtitle_input)
        form.addRow(tr("URL:"), self.url_input)
        form.addRow(tr("Icon:"), icon_row)

        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.url_input.textChanged.connect(self._update_preview)
        self.icon_combo.currentIndexChanged.connect(self._update_preview)
        self._update_preview()

    def _update_preview(self):
        sel = self.icon_combo.currentData()
        if sel == "favicon":
            url = self.url_input.text().strip()
            cache_path = get_site_favicon_cache_path(url) if url else None
            if cache_path and cache_path.exists() and cache_path.stat().st_size > 50:
                pm = QPixmap(str(cache_path))
                if not pm.isNull():
                    self.preview_label.setPixmap(pm.scaled(20, 20, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                    return
            self.preview_label.setPixmap(svg_icon("search").pixmap(20, 20))
        else:
            self.preview_label.setPixmap(svg_icon(sel).pixmap(20, 20))

    def _validate_and_accept(self):
        url = self.url_input.text().strip()
        if not self.title_input.text().strip() or not url:
            return
        if self.icon_combo.currentData() == "favicon":
            import threading
            threading.Thread(target=fetch_and_cache_favicon, args=(url,), daemon=True).start()
        self.accept()

    def get_data(self):
        return {
            "title": self.title_input.text().strip(),
            "subtitle": self.subtitle_input.text().strip(),
            "url": self.url_input.text().strip(),
            "icon": self.icon_combo.currentData() or "favicon"
        }
class MenuTile(QFrame):
    clicked = pyqtSignal()

    def __init__(self, title: str, subtitle: str, icon_name: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.icon_name = icon_name
        self.setObjectName("AsterMenuTile")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(10, 8, 10, 8)
        self._layout.setSpacing(3)
        self.icon_label = QLabel(self)
        self.icon_label.setObjectName("AsterMenuTileIcon")
        self.icon_label.setStyleSheet("background: transparent; border: none;")
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label = QLabel(title, self)
        self.title_label.setObjectName("AsterMenuTileTitle")
        self.title_label.setStyleSheet("background: transparent; border: none;")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # Alt yazi kaldirildi; aciklama yalnizca ipucu olarak duruyor.
        self._subtitle_text = subtitle
        self.setToolTip(f"{title} - {subtitle}" if subtitle else title)
        self._layout.addStretch(1)
        self._layout.addWidget(self.icon_label, 0, Qt.AlignmentFlag.AlignHCenter)
        self._layout.addWidget(self.title_label)
        self._layout.addStretch(1)
        self.apply_density(1.0)

    def apply_density(self, scale: float = 1.0) -> None:
        scale = max(0.85, min(scale, 1.25))
        icon_px = max(15, int(round(17 * scale)))
        self.icon_label.setPixmap(_scaled_icon_pixmap(self, self.icon_name, icon_px))
        self.icon_label.setFixedSize(icon_px + 4, icon_px + 4)
        title_font = QFont(self.title_label.font())
        title_font.setPointSizeF(max(9.8, 11.0 * scale))
        title_font.setWeight(QFont.Weight.DemiBold)
        self.title_label.setFont(title_font)
        margin = max(6, int(round(8 * scale)))
        self._layout.setContentsMargins(margin, margin, margin, margin)
        self._layout.setSpacing(max(2, int(round(3 * scale))))
        # Alt yazi satiri kaldirildigi icin kutucuk alcaldi; genislik pop-up
        # olcusu sabit kalsin diye korundu.
        tile_w = max(124, int(round(136 * scale)))
        tile_h = max(56, int(round(64 * scale)))
        self.setMinimumSize(tile_w, tile_h)
        self.setMaximumSize(tile_w + 24, tile_h + 10)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mouseReleaseEvent(event)

# Varsayilan kisayollar. Simgeler tarayicinin kendi ikon setinden geliyor
# (favicon indirmeye gerek yok), boylece hepsi ayni cizgide gorunuyor.
DEFAULT_QUICK_LINKS = [
    {"title": "OpenStreetMap", "icon": "globe", "url": "https://www.openstreetmap.org"},
    {"title": "Internet Archive", "icon": "history", "url": "https://archive.org"},
    {"title": "Prime Video", "icon": "tv", "url": "https://www.primevideo.com"},
    {"title": "GitHub", "icon": "code_braces", "url": "https://github.com"},
    {"title": "Wikipedia", "icon": "book_open", "url": "https://wikipedia.org"},
    {"title": "Speedtest", "icon": "speedometer", "url": "https://www.speedtest.net"},
]


class QuickLinkTile(QFrame):
    action_requested = pyqtSignal(int, str) 

    def __init__(self, index: int, data: dict | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.index = index
        self.data = data
        self.setObjectName("AsterQuickLinkButton")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(4, 4, 4, 4)
        self._layout.setSpacing(1)

        if self.data is not None:
            self.icon_label = QLabel(self)
            self.icon_label.setObjectName("AsterQuickLinkIcon")
            self.icon_label.setStyleSheet("background: transparent; border: none;")
            self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.title_label = QLabel(data.get("title", ""), self)
            self.title_label.setObjectName("AsterQuickLinkTitle")
            self.title_label.setStyleSheet("background: transparent; border: none;")
            self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # Alt yazi kaldirildi; ikon ve baslik dikeyde ortalaniyor.
            self._layout.addStretch(1)
            self._layout.addWidget(self.icon_label, 0, Qt.AlignmentFlag.AlignHCenter)
            self._layout.addWidget(self.title_label)
            self._layout.addStretch(1)

            self.menu = QMenu(self)
            self.menu.addAction(tr("Edit"), lambda: self.action_requested.emit(self.index, "edit"))
            self.menu.addAction(tr("Remove"), lambda: self.action_requested.emit(self.index, "remove"))
        else:
            self.add_label = QLabel("+", self)
            self.add_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.add_label.setStyleSheet("background: transparent; border: none; color: rgba(255, 255, 255, 0.4); font-size: 16px; font-weight: bold;")
            self.setToolTip(tr("Add"))
            self._layout.addWidget(self.add_label, 1, Qt.AlignmentFlag.AlignCenter)
            self.setStyleSheet("""
                QFrame#AsterQuickLinkButton {
                    background: rgba(255, 255, 255, 0.02);
                    border: 1px dashed rgba(255, 255, 255, 0.12);
                    border-radius: 8px;
                }
                QFrame#AsterQuickLinkButton QLabel {
                    background: transparent;
                    border: none;
                }
                QFrame#AsterQuickLinkButton:hover {
                    background: rgba(255, 255, 255, 0.06);
                    border: 1px dashed rgba(255, 255, 255, 0.28);
                }
            """)

        self.apply_density(1.0)

    def apply_density(self, scale: float) -> None:
        scale = max(0.80, min(scale, 1.15))
        tile_w = max(70, int(round(86 * scale)))
        tile_h = max(52, int(round(60 * scale)))
        self.setMinimumSize(tile_w, tile_h)
        self.setMaximumSize(tile_w + 16, tile_h + 6)
        
        if self.data is not None:
            icon_px = max(15, int(round(18 * scale)))
            self._update_tile_icon(icon_px)
            self._title_base_px = max(11, int(round(12 * scale)))
            self._title_applied_px = None
            margin = max(3, int(round(4 * scale)))
            self._layout.setContentsMargins(margin, margin, margin, margin)
            self._layout.setSpacing(3)
            self._fit_title_font()

    def _fit_title_font(self) -> None:
        """Uzun site adlarinda baslik puntosunu kutucuga sigacak kadar kucultur.

        Boyutu QFont ile DEGIL widget'in kendi stylesheet'i ile veriyoruz:
        uygulama genelindeki QSS'te QWidget { font-size: 13px; } kurali var ve
        bu kural setFont() ile verilen boyutu eziyor (pointSizeF -1 donuyordu).
        """
        if self.data is None or not hasattr(self, "title_label"):
            return
        text = str(self.data.get("title", "") or "")
        if not text:
            return
        margins = self._layout.contentsMargins()
        available = self.width() - margins.left() - margins.right() - 2
        if available <= 10:
            return
        px = int(getattr(self, "_title_base_px", 12))
        font = QFont(self.title_label.font())
        font.setWeight(QFont.Weight.DemiBold)
        font.setPixelSize(px)
        while px > 8 and QFontMetrics(font).horizontalAdvance(text) > available:
            px -= 1
            font.setPixelSize(px)
        if px != getattr(self, "_title_applied_px", None):
            self._title_applied_px = px
            self.title_label.setStyleSheet(
                "background: transparent; border: none; font-weight: 600;"
                " font-size: %dpx;" % px
            )
        metrics = QFontMetrics(font)
        display = text
        if metrics.horizontalAdvance(text) > available:
            display = metrics.elidedText(text, Qt.TextElideMode.ElideRight, available)
        if self.title_label.text() != display:
            self.title_label.setText(display)
        self.setToolTip(text)

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._fit_title_font()

    def _update_tile_icon(self, icon_px: int) -> None:
        icon_name = self.data.get("icon", "favicon") if self.data else "search"
        if icon_name in ("favicon", "", None) or not icon_name:
            url = self.data.get("url", "")
            cache_path = get_site_favicon_cache_path(url)
            if cache_path.exists() and cache_path.stat().st_size > 50:
                pm = QPixmap(str(cache_path))
                if not pm.isNull():
                    self.icon_label.setPixmap(pm.scaled(icon_px, icon_px, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                    self.icon_label.setFixedSize(icon_px + 2, icon_px + 2)
                    return
            self.icon_label.setPixmap(_scaled_icon_pixmap(self, "search", icon_px))
            self.icon_label.setFixedSize(icon_px + 2, icon_px + 2)
            self._fetch_favicon_async(url, icon_px)
        else:
            self.icon_label.setPixmap(_scaled_icon_pixmap(self, icon_name, icon_px))
            self.icon_label.setFixedSize(icon_px + 2, icon_px + 2)

    def _fetch_favicon_async(self, url: str, icon_px: int) -> None:
        if not url:
            return
        import threading
        def _worker():
            res = fetch_and_cache_favicon(url)
            if res:
                QTimer.singleShot(0, lambda: self._apply_cached_favicon(res, icon_px))
        threading.Thread(target=_worker, daemon=True).start()

    def _apply_cached_favicon(self, path: str, icon_px: int) -> None:
        if self.data is None or self.data.get("icon", "favicon") != "favicon":
            return
        pm = QPixmap(path)
        if not pm.isNull():
            self.icon_label.setPixmap(pm.scaled(icon_px, icon_px, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            if self.data is None:
                self.action_requested.emit(self.index, "add")
            else:
                self.action_requested.emit(self.index, "open")
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def contextMenuEvent(self, event) -> None:
        if self.data is not None:
            self.menu.exec(event.globalPos())
            event.accept()
            return
        super().contextMenuEvent(event)


class HomePageCustomizerDrawer(QFrame):
    settings_changed = pyqtSignal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("HomePageCustomizerDrawer")
        self.setFixedWidth(290)
        self.hide()
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(14)
        
        header_layout = QHBoxLayout()
        header_layout.setSpacing(8)
        
        title_icon = QLabel()
        title_icon.setPixmap(svg_icon("pencil").pixmap(18, 18))
        header_layout.addWidget(title_icon)
        
        title = QLabel(tr("Customize page"))
        title.setStyleSheet("font-size: 14px; font-weight: 700; color: #eef2f7;")
        header_layout.addWidget(title, 1)
        
        close_btn = QToolButton(self)
        close_btn.setIcon(svg_icon("close"))
        close_btn.setIconSize(QSize(14, 14))
        close_btn.setFixedSize(24, 24)
        close_btn.setStyleSheet("background: transparent; border: none; border-radius: 6px;")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(self.hide)
        header_layout.addWidget(close_btn)
        
        layout.addLayout(header_layout)
        
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background: #252c38; max-height: 1px;")
        layout.addWidget(sep)
        
        sec_label = QLabel(tr("VISIBLE ELEMENTS"))
        sec_label.setStyleSheet("font-size: 11px; font-weight: 700; color: #7f8c9d; letter-spacing: 0.5px;")
        layout.addWidget(sec_label)
        
        settings = QSettings("Aster", "Browser")
        
        self.logo_check = QCheckBox(tr("Aster logo and title"))
        self.logo_check.setChecked(settings.value("home_show_logo", "true").lower() == "true")
        self.logo_check.setStyleSheet("color: #d8e2ec; font-size: 12px; font-weight: 500; spacing: 8px;")
        self.logo_check.toggled.connect(self._on_setting_changed)
        layout.addWidget(self.logo_check)
        
        self.search_check = QCheckBox(tr("Search bar"))
        self.search_check.setChecked(settings.value("home_show_search", "true").lower() == "true")
        self.search_check.setStyleSheet("color: #d8e2ec; font-size: 12px; font-weight: 500; spacing: 8px;")
        self.search_check.toggled.connect(self._on_setting_changed)
        layout.addWidget(self.search_check)
        
        self.shortcuts_check = QCheckBox(tr("Shortcuts / suggestions"))
        self.shortcuts_check.setChecked(settings.value("home_show_shortcuts", "true").lower() == "true")
        self.shortcuts_check.setStyleSheet("color: #d8e2ec; font-size: 12px; font-weight: 500; spacing: 8px;")
        self.shortcuts_check.toggled.connect(self._on_setting_changed)
        layout.addWidget(self.shortcuts_check)
        
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet("background: #252c38; max-height: 1px;")
        layout.addWidget(sep2)
        
        sec_label2 = QLabel(tr("SHORTCUT GRID"))
        sec_label2.setStyleSheet("font-size: 11px; font-weight: 700; color: #7f8c9d; letter-spacing: 0.5px;")
        layout.addWidget(sec_label2)
        
        self.grid_combo = QComboBox()
        self.grid_combo.addItem(tr("1 row (1x6 · 6 shortcuts)"), "1x6")
        self.grid_combo.addItem(tr("2 rows (2x6 · 12 shortcuts)"), "2x6")
        saved_grid = settings.value("home_grid_mode", "1x6")
        idx = self.grid_combo.findData(saved_grid)
        if idx >= 0:
            self.grid_combo.setCurrentIndex(idx)
        self.grid_combo.currentIndexChanged.connect(self._on_setting_changed)
        self.grid_combo.setStyleSheet("background: #191f2b; color: #eef2f7; border: 1px solid #333d4e; border-radius: 6px; padding: 6px 10px; font-size: 12px;")
        layout.addWidget(self.grid_combo)
        
        layout.addStretch(1)
        
        self.setStyleSheet("""
            QFrame#HomePageCustomizerDrawer {
                background: #14171f;
                border-left: 1px solid #282f3b;
            }
            QFrame#HomePageCustomizerDrawer QLabel {
                background: transparent;
                border: none;
            }
        """)

    def _on_setting_changed(self) -> None:
        settings = QSettings("Aster", "Browser")
        settings.setValue("home_show_logo", "true" if self.logo_check.isChecked() else "false")
        settings.setValue("home_show_search", "true" if self.search_check.isChecked() else "false")
        settings.setValue("home_show_shortcuts", "true" if self.shortcuts_check.isChecked() else "false")
        settings.setValue("home_grid_mode", self.grid_combo.currentData() or "1x6")
        self.settings_changed.emit()

class AuroraBackdrop(QObject):
    """The new tab page's backdrop: the tab colour with gradient blooms
    drifting in the corners.

    Each corner holds a couple of soft elliptical lights that orbit, breathe and
    turn on their own slow clocks. Where they overlap they merge, so a corner
    reads as one fluid shape rather than as circles. Everything is additive over
    the page colour and the motion takes minutes, so the page stays calm.
    """

    #: Seconds for one full turn of the drift. Deliberately long.
    CYCLE_SECONDS = 420.0
    FRAME_MS = 50
    #: Painted into a third-resolution buffer and scaled back up. Nothing here
    #: has a hard edge, so the upscale costs a ninth of the pixels and softens
    #: the blooms further - this browser is meant to stay light on weak machines.
    DOWNSCALE = 3

    #: (offset, frequency, radius scale, brightness scale). Every bloom is drawn
    #: as these three lobes wandering around its centre on different clocks, so
    #: its outline is never the clean ellipse that would give the effect away.
    LOBES = (
        (0.00, 1.00, 1.00, 1.00),
        (0.34, 1.70, 0.78, 0.58),
        (0.28, 2.60, 0.62, 0.42),
    )

    #: The blooms stay in this blue whatever the interface accent is: a white
    #: or grey accent carries no hue of its own, so the family below is built
    #: from this instead.
    BLOOM_BLUE = "#67CBEF"
    #: (hue offset from the accent, value). Working in offsets keeps the blooms
    #: inside Aster's own palette whichever accent the user has configured.
    ACCENT_FAMILY = (
        (0, 255),
        (24, 246),
        (-26, 240),
        (50, 232),
    )

    #: (corner x, corner y, radius, accent family index, peak alpha, speed,
    #: offset). The corners are 0/1 anchors, so most of every bloom sits off
    #: screen and only its edge spills in. Two tones per corner so the pair
    #: bleeds together instead of reading as one flat glow.
    BLOOMS = (
        (0.0, 0.0, 0.34, 0, 142, 0.55, 0.0),
        (0.0, 0.0, 0.24, 1, 96, 0.37, 2.2),
        (1.0, 0.0, 0.32, 1, 132, 0.44, 1.1),
        (1.0, 0.0, 0.23, 3, 90, 0.61, 3.4),
        (1.0, 1.0, 0.35, 2, 128, 0.33, 0.7),
        (1.0, 1.0, 0.24, 0, 88, 0.52, 4.1),
        (0.0, 1.0, 0.31, 3, 124, 0.47, 2.8),
        (0.0, 1.0, 0.22, 2, 86, 0.29, 5.0),
    )

    def __init__(self, widget: QWidget) -> None:
        super().__init__(widget)
        self._widget = widget
        self._clock = QElapsedTimer()
        self._clock.start()
        self._buffer = QImage()
        self._palette: tuple = ()
        self.set_accent(self.BLOOM_BLUE)
        self._timer = QTimer(self)
        self._timer.setInterval(self.FRAME_MS)
        self._timer.timeout.connect(widget.update)

    def set_accent(self, color: str) -> None:
        accent = QColor(color or "")
        if not accent.isValid():
            accent = QColor(self.BLOOM_BLUE)
        hue = accent.hue()
        if hue < 0:  # white, black or grey: no hue to build a family from
            hue = QColor(self.BLOOM_BLUE).hue()
        saturation = max(accent.saturation(), 205)
        self._palette = tuple(
            QColor.fromHsv((hue + shift) % 360, saturation, value).getRgb()[:3]
            for shift, value in self.ACCENT_FAMILY
        )
        self._widget.update()

    def start(self) -> None:
        if not self._timer.isActive():
            self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def paint(self, painter: QPainter, rect) -> None:
        if rect.width() <= 0 or rect.height() <= 0:
            return
        size = QSize(
            max(1, rect.width() // self.DOWNSCALE),
            max(1, rect.height() // self.DOWNSCALE),
        )
        if self._buffer.size() != size:
            self._buffer = QImage(size, QImage.Format.Format_RGB32)
        self._render(self._buffer)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.drawImage(rect, self._buffer)

    def _render(self, image: QImage) -> None:
        phase = 2.0 * math.pi * (self._clock.elapsed() / 1000.0) / self.CYCLE_SECONDS
        w = float(image.width())
        h = float(image.height())
        span = min(w, h)

        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.fillRect(0, 0, image.width(), image.height(), QColor(PAGE_BACKGROUND))
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_Plus)

        for corner_x, corner_y, radius_factor, tone, alpha, speed, offset in self.BLOOMS:
            rgb = self._palette[tone]
            drift = phase * speed + offset
            # Two frequencies per axis keep the orbit from ever retracing the
            # same loop, which is what makes the motion look fluid.
            cx = w * corner_x + span * (0.10 * math.sin(drift) + 0.05 * math.sin(drift * 2.3))
            cy = h * corner_y + span * (0.09 * math.cos(drift * 0.8) + 0.04 * math.cos(drift * 1.9))
            radius = span * radius_factor * (1.0 + 0.14 * math.sin(drift * 1.3 + offset))
            if radius <= 1.0:
                continue
            stretch = 1.0 + 0.30 * math.sin(drift * 0.7 + offset)
            level = alpha * (0.80 + 0.20 * math.sin(drift * 1.1))

            for lobe, (spread, frequency, size, weight) in enumerate(self.LOBES):
                wander = drift * frequency + lobe * 1.9
                lobe_radius = radius * size
                lobe_level = int(level * weight)
                if lobe_radius <= 1.0 or lobe_level <= 0:
                    continue
                gradient = QRadialGradient(0.0, 0.0, lobe_radius)
                gradient.setColorAt(0.0, QColor(*rgb, lobe_level))
                # A long, gentle tail is what keeps the bloom a haze rather than
                # a lamp with a visible edge.
                gradient.setColorAt(0.28, QColor(*rgb, int(lobe_level * 0.55)))
                gradient.setColorAt(0.55, QColor(*rgb, int(lobe_level * 0.22)))
                gradient.setColorAt(0.80, QColor(*rgb, int(lobe_level * 0.06)))
                gradient.setColorAt(1.0, QColor(*rgb, 0))

                painter.save()
                painter.translate(
                    cx + radius * spread * math.sin(wander),
                    cy + radius * spread * math.cos(wander * 1.31),
                )
                painter.rotate(math.degrees(wander * 0.35))
                painter.scale(stretch, 1.0 / stretch)
                painter.setBrush(QBrush(gradient))
                painter.drawEllipse(QPointF(0.0, 0.0), lobe_radius, lobe_radius)
                painter.restore()

        painter.end()


class NewTabWidget(QWidget):
    open_requested = pyqtSignal(str)

    def __init__(self, stats_provider: Callable[[], str], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterInternalPage")
        self.stats_provider = stats_provider
        self.tiles: list[QuickLinkTile] = []
        self.links_data = self._load_links()
        self.grid_mode = "1x6"
        self.backdrop = AuroraBackdrop(self)
        self._build_ui()
        self.refresh_stats()

    def set_accent(self, color: str) -> None:
        self.backdrop.set_accent(color)

    def focus_search(self) -> None:
        """Put the caret in the page's own search box."""
        self.entry.setFocus(Qt.FocusReason.OtherFocusReason)

    def _load_links(self) -> list:
        settings = QSettings("Aster", "Browser")
        saved = settings.value("quick_links", "")
        if saved:
            try:
                return json.loads(saved)
            except Exception:
                pass
        
        return list(DEFAULT_QUICK_LINKS)

    def _save_links(self) -> None:
        settings = QSettings("Aster", "Browser")
        settings.setValue("quick_links", json.dumps(self.links_data))

    def _build_ui(self) -> None:
        self.outer_layout = QVBoxLayout(self)
        self.outer_layout.setContentsMargins(28, 24, 28, 24)
        self.outer_layout.addStretch(2)

        self.row_layout = QHBoxLayout()
        self.row_layout.addStretch(1)

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(14)

        self.card = QFrame(self.shell)
        self.card.setObjectName("AsterCard")
        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(10, 10, 10, 10)
        card_layout.setSpacing(14)

        # Logo container
        self.logo_container = QWidget(self.card)
        self.logo_container.setObjectName("AsterHomeBlock")
        logo_vbox = QVBoxLayout(self.logo_container)
        logo_vbox.setContentsMargins(0, 0, 0, 0)
        logo_vbox.setSpacing(10)
        self.logo = QLabel(self.logo_container)
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label = QLabel("Aster Browser", self.logo_container)
        self.title_label.setObjectName("AsterCardTitle")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_vbox.addWidget(self.logo)
        logo_vbox.addWidget(self.title_label)

        # Search container
        self.search_container = QWidget(self.card)
        self.search_container.setObjectName("AsterHomeBlock")
        search_vbox = QVBoxLayout(self.search_container)
        search_vbox.setContentsMargins(0, 0, 0, 0)
        search_row = QHBoxLayout()
        search_row.setSpacing(10)
        self.entry = QLineEdit(self.search_container)
        self.entry.setPlaceholderText(tr("Enter a URL or search query"))
        self.entry.returnPressed.connect(self._emit_open)
        self.open_button = QPushButton(tr("Open"), self.search_container)
        self.open_button.clicked.connect(self._emit_open)
        search_row.addWidget(self.entry, 1)
        search_row.addWidget(self.open_button)
        search_vbox.addLayout(search_row)

        # Links container
        self.links_container = QWidget(self.card)
        self.links_container.setObjectName("AsterHomeBlock")
        links_vbox = QVBoxLayout(self.links_container)
        links_vbox.setContentsMargins(0, 0, 0, 0)
        self.links_grid = QGridLayout()
        self.links_grid.setHorizontalSpacing(12)
        self.links_grid.setVerticalSpacing(12)
        links_vbox.addLayout(self.links_grid)

        card_layout.addWidget(self.logo_container)
        card_layout.addWidget(self.search_container)
        card_layout.addWidget(self.links_container)

        shell_layout.addWidget(self.card)

        self.row_layout.addWidget(self.shell, 0, Qt.AlignmentFlag.AlignTop)
        self.row_layout.addStretch(1)

        self.outer_layout.addLayout(self.row_layout)
        self.outer_layout.addStretch(3)

        # Floating customize button at bottom right
        self.customize_button = QToolButton(self)
        self.customize_button.setObjectName("AsterCustomizeButton")
        self.customize_button.setIcon(svg_icon("pencil"))
        self.customize_button.setIconSize(QSize(18, 18))
        self.customize_button.setFixedSize(36, 36)
        self.customize_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.customize_button.setToolTip(tr("Customize home page"))
        self.customize_button.setStyleSheet("""
            QToolButton#AsterCustomizeButton {
                background: rgba(30, 36, 48, 0.85);
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 18px;
                color: #eef2f7;
            }
            QToolButton#AsterCustomizeButton:hover {
                background: rgba(255, 255, 255, 0.22);
                border: 1px solid rgba(255, 255, 255, 0.55);
            }
        """)
        self.customize_button.clicked.connect(self._toggle_drawer)

        # Drawer
        self.drawer = HomePageCustomizerDrawer(self)
        self.drawer.settings_changed.connect(self._apply_customizer_settings)

        self._apply_customizer_settings()

    def _drawer_host(self) -> QWidget:
        """Drawer'i sekme kabina baglar.

        Yeni sekme sayfasi sekme cubugunun altinda basliyor; drawer bu sayfanin
        cocugu kalirsa cubugun sagindaki serit bos gorunuyor. Sekme kabina
        baglayinca panel o seridi de kapliyor ve pencerenin sag/alt
        kenarlariyla tam hizalaniyor.
        """
        widget = self.parentWidget()
        while widget is not None:
            if isinstance(widget, QTabWidget):
                return widget
            widget = widget.parentWidget()
        return self

    def _sync_drawer_geometry(self) -> None:
        host = self.drawer.parentWidget()
        if host is None:
            return
        width = min(290, max(180, host.width()))
        self.drawer.setFixedWidth(width)
        self.drawer.setGeometry(host.width() - width, 0, width, host.height())

    def _close_drawer(self) -> None:
        drawer = getattr(self, "drawer", None)
        if drawer is None:
            return
        drawer.hide()
        # Sahipligi geri aliyoruz; sekme kapandiginda panel de yok olsun.
        if drawer.parentWidget() is not self:
            drawer.setParent(self)

    def _toggle_drawer(self) -> None:
        if self.drawer.isVisible():
            self._close_drawer()
            return
        host = self._drawer_host()
        if self.drawer.parentWidget() is not host:
            self.drawer.setParent(host)
        self._sync_drawer_geometry()
        self.drawer.show()
        self.drawer.raise_()

    def _apply_customizer_settings(self) -> None:
        settings = QSettings("Aster", "Browser")
        show_logo = settings.value("home_show_logo", "true").lower() == "true"
        show_search = settings.value("home_show_search", "true").lower() == "true"
        show_shortcuts = settings.value("home_show_shortcuts", "true").lower() == "true"
        self.grid_mode = settings.value("home_grid_mode", "1x6")

        self.logo_container.setVisible(show_logo)
        self.search_container.setVisible(show_search)
        self.links_container.setVisible(show_shortcuts)

        # When logo is hidden, search bar moves up gracefully
        if show_logo:
            self.outer_layout.setStretch(0, 2)
            self.outer_layout.setStretch(2, 3)
            self.card.layout().setSpacing(14)
        else:
            self.outer_layout.setStretch(0, 0)
            self.outer_layout.setStretch(2, 2)
            self.card.layout().setSpacing(10)

        self._render_tiles()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        painter = QPainter(self)
        self.backdrop.paint(painter, self.rect())
        painter.end()
        super().paintEvent(event)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.backdrop.start()
        if self.width() > 100:
            self.apply_density_for_width(self.width())

    def hideEvent(self, event) -> None:  # type: ignore[override]
        # Nothing to animate for a page nobody is looking at.
        self.backdrop.stop()
        super().hideEvent(event)

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        # Baska sekmeye gecildiginde (ya da sekme kapandiginda) panel kapansin.
        self._close_drawer()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if event.size().width() > 100:
            self.apply_density_for_width(event.size().width())
        self.customize_button.move(self.width() - 48, self.height() - 48)
        self.customize_button.raise_()
        if self.drawer.isVisible():
            self._sync_drawer_geometry()
            self.drawer.raise_()

    def _render_tiles(self) -> None:
        while self.links_grid.count():
            child = self.links_grid.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        self.tiles.clear()

        total = 12 if getattr(self, "grid_mode", "1x6") == "2x6" else 6
        for index in range(total):
            data = self.links_data[index] if index < len(self.links_data) else None
            tile = QuickLinkTile(index, data, self.card)
            tile.action_requested.connect(self._handle_tile_action)
            self.tiles.append(tile)
            row = index // 6
            col = index % 6
            self.links_grid.addWidget(tile, row, col)

        self.apply_density_for_width(self.width() or 960)

    def _handle_tile_action(self, index: int, action: str) -> None:
        if action == "open":
            target = self.links_data[index].get("url", "")
            if target:
                self.open_requested.emit(target)
        elif action == "remove":
            self.links_data[index] = None
            self._save_links()
            self._render_tiles()
        elif action in ("add", "edit"):
            data = self.links_data[index] if index < len(self.links_data) else None
            dialog = EditQuickLinkDialog(data, self)
            if dialog.exec():
                while len(self.links_data) <= index:
                    self.links_data.append(None)
                self.links_data[index] = dialog.get_data()
                self._save_links()
                self._render_tiles()

    def apply_density_for_width(self, width: int) -> None:
        width = max(480, int(width or 0))
        
        if width < 720:
            scale = 0.85
        elif width < 960:
            scale = 0.92
        elif width < 1280:
            scale = 1.00
        else:
            scale = 1.06
            
        target_width = min(840, max(580, int(width * 0.72)))
        self.shell.setMaximumWidth(target_width)
        self.shell.setMinimumWidth(min(target_width, max(560, int(target_width * 0.92))))

        self.logo.setPixmap(_scaled_icon_pixmap(self, "aster_logo", int(round(44 * scale))))
        
        title_font = QFont(self.title_label.font())
        title_font.setPointSizeF(max(16.0, 20.0 * scale))
        title_font.setWeight(QFont.Weight.Black)
        self.title_label.setFont(title_font)
        
        for tile in self.tiles:
            tile.apply_density(scale)

    def refresh_stats(self) -> None:
        return

    def _emit_open(self) -> None:
        target = self.entry.text().strip()
        if target:
            self.open_requested.emit(target)


class ErrorPageWidget(QWidget):

    retry_requested = pyqtSignal()

    home_requested = pyqtSignal()

    external_requested = pyqtSignal()



    def __init__(self, title: str, subtitle: str, url: str, details: list[str], parent: QWidget | None = None) -> None:

        super().__init__(parent)
        self.setObjectName("AsterInternalPage")

        outer = QVBoxLayout(self)

        outer.setContentsMargins(32, 28, 32, 28)

        outer.addStretch(1)

        row = QHBoxLayout()

        row.addStretch(1)

        shell = QFrame(self)

        shell.setObjectName("AsterPageShell")

        shell.setMaximumWidth(820)

        shell_layout = QVBoxLayout(shell)

        shell_layout.setContentsMargins(24, 24, 24, 24)

        card = QFrame(shell)

        card.setObjectName("AsterErrorCard")

        layout = QVBoxLayout(card)

        layout.setContentsMargins(28, 28, 28, 28)

        layout.setSpacing(14)

        icon_wrap = QFrame(card)

        icon_wrap.setObjectName("AsterErrorIconWrap")

        icon_layout = QVBoxLayout(icon_wrap)

        icon_layout.setContentsMargins(16, 16, 16, 16)

        icon = QLabel(icon_wrap)

        icon.setPixmap(svg_icon("warning_triangle").pixmap(30, 30))

        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)

        icon_layout.addWidget(icon)

        title_label = QLabel(title, card)

        title_label.setObjectName("AsterErrorTitle")

        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        subtitle_label = QLabel(subtitle, card)

        subtitle_label.setObjectName("AsterErrorSubtitle")

        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        subtitle_label.setWordWrap(True)

        url_label = QLabel(url, card)

        url_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        url_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        details_label = QLabel("\n".join(f"• {item}" for item in details if item), card)

        details_label.setWordWrap(True)

        details_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        button_row = QHBoxLayout()

        retry = QPushButton(tr("Retry"), card)

        retry.clicked.connect(lambda _checked=False: self.retry_requested.emit())

        home = QPushButton(tr("Go home"), card)

        home.setObjectName("SecondaryButton")

        home.clicked.connect(lambda _checked=False: self.home_requested.emit())

        external = QPushButton(tr("Open externally"), card)

        external.setObjectName("GhostButton")

        external.clicked.connect(lambda _checked=False: self.external_requested.emit())

        button_row.addStretch(1)

        button_row.addWidget(retry)

        button_row.addWidget(home)

        button_row.addWidget(external)

        button_row.addStretch(1)

        layout.addWidget(icon_wrap, 0, Qt.AlignmentFlag.AlignHCenter)

        layout.addWidget(title_label)

        layout.addWidget(subtitle_label)

        layout.addWidget(url_label)

        layout.addWidget(details_label)

        layout.addLayout(button_row)

        shell_layout.addWidget(card)

        row.addWidget(shell, 1)

        row.addStretch(1)

        outer.addLayout(row)

        outer.addStretch(1)





class CompatibilityRedirectWidget(QWidget):

    try_inside_requested = pyqtSignal()

    open_external_requested = pyqtSignal()



    def __init__(self, title: str, url: str, reason: str, parent: QWidget | None = None) -> None:

        super().__init__(parent)
        self.setObjectName("AsterInternalPage")

        layout = QVBoxLayout(self)

        layout.setContentsMargins(28, 28, 28, 28)

        title_label = QLabel(title)

        title_label.setStyleSheet("font-size: 22px; font-weight: 600;")

        url_label = QLabel(url)

        url_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        reason_label = QLabel(reason)

        reason_label.setWordWrap(True)

        open_external = QPushButton(tr("Open in compatibility browser"))

        open_external.clicked.connect(lambda _checked=False: self.open_external_requested.emit())

        try_inside = QPushButton(tr("Try inside Aster anyway"))

        try_inside.clicked.connect(lambda _checked=False: self.try_inside_requested.emit())

        buttons = QHBoxLayout()

        buttons.addWidget(open_external)

        buttons.addWidget(try_inside)

        layout.addWidget(title_label)

        layout.addWidget(url_label)

        layout.addSpacing(10)

        layout.addWidget(reason_label)

        layout.addSpacing(14)

        layout.addLayout(buttons)

        layout.addStretch(1)





class StreamingCapsuleWidget(QWidget):

    launch_requested = pyqtSignal()

    try_inside_requested = pyqtSignal()

    reset_profile_requested = pyqtSignal()

    open_raw_requested = pyqtSignal()



    def __init__(self, service: str, url: str, reason: str, runtime_hint: str, parent: QWidget | None = None) -> None:

        super().__init__(parent)
        self.setObjectName("AsterInternalPage")

        self._build_ui(service, url, reason, runtime_hint)



    def _build_ui(self, service: str, url: str, reason: str, runtime_hint: str) -> None:

        layout = QVBoxLayout(self)

        layout.setContentsMargins(28, 28, 28, 28)



        title_label = QLabel(f"{service} Capsule")

        title_label.setStyleSheet("font-size: 24px; font-weight: 700;")



        badge_label = QLabel(tr("Protected playback path"))

        badge_label.setStyleSheet("font-size: 13px; font-weight: 600;")



        url_label = QLabel(url)

        url_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        url_label.setWordWrap(True)



        intro_label = QLabel(

            tr("Aster stays your main browser for tabs, ad blocking, profiles, AI, and low-memory control. "

            "This page opens through a separate streaming capsule so protected playback can use a more compatible runtime when needed. The v16 DRM capsule can use a bundled CastLabs/Electron Chromium runtime, so Chrome is not required.")

        )

        intro_label.setWordWrap(True)



        reason_label = QLabel(reason)

        reason_label.setWordWrap(True)



        self.runtime_label = QLabel(tr("Capsule runtime: {runtime}").format(runtime=runtime_hint))

        self.runtime_label.setWordWrap(True)



        self.profile_label = QLabel(tr("Capsule profile: auto"))

        self.profile_label.setWordWrap(True)



        self.status_label = QLabel(tr("Launch status: waiting"))

        self.status_label.setWordWrap(True)

        self.status_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)



        launch_button = QPushButton(tr("Launch or relaunch capsule"))

        launch_button.clicked.connect(lambda _checked=False: self.launch_requested.emit())



        reset_button = QPushButton(tr("Reset capsule profile"))

        reset_button.clicked.connect(lambda _checked=False: self.reset_profile_requested.emit())



        raw_button = QPushButton(tr("Open raw external browser"))

        raw_button.clicked.connect(lambda _checked=False: self.open_raw_requested.emit())



        try_inside = QPushButton(tr("Try inside Aster anyway"))

        try_inside.clicked.connect(lambda _checked=False: self.try_inside_requested.emit())



        buttons = QHBoxLayout()

        buttons.addWidget(launch_button)

        buttons.addWidget(reset_button)

        buttons.addWidget(raw_button)

        buttons.addWidget(try_inside)



        layout.addWidget(title_label)

        layout.addWidget(badge_label)

        layout.addSpacing(8)

        layout.addWidget(url_label)

        layout.addSpacing(12)

        layout.addWidget(intro_label)

        layout.addSpacing(8)

        layout.addWidget(reason_label)

        layout.addSpacing(8)

        layout.addWidget(self.runtime_label)

        layout.addWidget(self.profile_label)

        layout.addWidget(self.status_label)

        layout.addSpacing(16)

        layout.addLayout(buttons)

        layout.addStretch(1)



    def set_runtime_hint(self, text: str) -> None:

        self.runtime_label.setText(f"Capsule runtime: {text}")



    def set_profile_hint(self, text: str) -> None:

        self.profile_label.setText(tr("Capsule profile: {profile}").format(profile=text))



    def set_status_text(self, text: str) -> None:

        self.status_label.setText(tr("Launch status: {status}").format(status=text))



import json

from pathlib import Path

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 

                             QScrollArea, QFrame, QComboBox, QPushButton, QSizePolicy)

from PyQt6.QtCore import Qt



class FlagsPageWidget(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)
        self.setObjectName("AsterInternalPage")

        

        self.flags_file = Path.home() / ".config" / "Aster" / "flags.json"

        self.saved_flags = self._load_flags()

        

        self.flags_config = [

            {"id": "disable_gpu", "name": "Disable GPU Acceleration", "desc": "Turns off graphics card use completely, to prevent crashes caused by Linux hardware incompatibilities (GLX/GBM).", "enable": "--disable-gpu", "disable": ""},

            {"id": "gpu_rasterization", "name": "GPU Rasterization", "desc": "Uses the GPU to render web content. Improves scrolling and page load performance.", "enable": "--enable-gpu-rasterization", "disable": "--disable-gpu-rasterization"},

            {"id": "smooth_scrolling", "name": "Smooth Scrolling", "desc": "Makes page scrolling animations smooth.", "enable": "--enable-smooth-scrolling", "disable": "--disable-smooth-scrolling"},

            {"id": "overlay_scrollbars", "name": "Overlay Scrollbars", "desc": "Uses thin, modern scrollbars that appear on hover.", "enable": "--enable-features=OverlayScrollbar", "disable": "--disable-features=OverlayScrollbar"},

        ]

        

        self._build_ui()



    def _load_flags(self):

        if self.flags_file.exists():

            try:

                return json.loads(self.flags_file.read_text(encoding="utf-8"))

            except Exception:

                return {}

        return {}



    def _save_flag(self, flag_id, value):

        self.saved_flags[flag_id] = value

        self.flags_file.parent.mkdir(parents=True, exist_ok=True)

        self.flags_file.write_text(json.dumps(self.saved_flags, indent=4), encoding="utf-8")

        

        self.changes_lbl.setText(tr("Changes pending restart."))

        self.restart_btn.setVisible(True)



    def _build_ui(self):

        outer = QVBoxLayout(self)

        outer.setContentsMargins(10, 10, 10, 10)

        

        row = QHBoxLayout()

        

        self.shell = QFrame(self)

        self.shell.setObjectName("AsterPageShell")

        self.shell.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.shell.setMinimumWidth(0)

        self.shell.setMaximumWidth(16777215)

        

        shell_layout = QVBoxLayout(self.shell)

        shell_layout.setContentsMargins(28, 26, 28, 24)

        shell_layout.setSpacing(16)

        

        self.title_label = QLabel(tr("Aster Experiments"), self.shell)

        self.title_label.setObjectName("AsterSettingsTitle")

        

        self.subtitle_label = QLabel(tr("Warning: Experimental features ahead. By enabling these features, you could lose browser data or compromise your security."), self.shell)

        self.subtitle_label.setObjectName("AsterSettingsSubtitle")

        self.subtitle_label.setWordWrap(True)

        

        self.card = QFrame(self.shell)

        self.card.setObjectName("AsterSettingsCard")

        self.card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        

        self.card_layout = QVBoxLayout(self.card)

        self.card_layout.setContentsMargins(22, 20, 22, 20)

        self.card_layout.setSpacing(14)

        

        # --- Kart İçeriği ---

        top_row = QHBoxLayout()

        top_row.setSpacing(10)

        avail_lbl = QLabel(tr("Available Experiments"), self.card)

        top_row.addWidget(avail_lbl, 1)

        

        scroll = QScrollArea(self.card)

        scroll.setWidgetResizable(True)

        scroll.setStyleSheet("""

            QScrollArea { border: none; background: transparent; }

            QScrollArea > QWidget { border: none; background: transparent; }

        """)

        

        self.scroll_widget = QWidget()

        self.list_layout = QVBoxLayout(self.scroll_widget)

        self.list_layout.setSpacing(6)

        self.list_layout.setContentsMargins(0, 0, 0, 0)

        

        for flag in self.flags_config:

            row_frame = QFrame()

            row_frame.setStyleSheet("QFrame { padding: 4px; border-radius: 6px; background: transparent; } QFrame:hover { background: rgba(255, 255, 255, 0.05); }")

            row_lyt = QHBoxLayout(row_frame)

            row_lyt.setContentsMargins(6, 6, 6, 6)

            

            info_lyt = QVBoxLayout()

            info_lyt.setSpacing(2)

            name_lbl = QLabel(flag["name"])

            name_lbl.setStyleSheet("font-weight: bold; background: transparent; border: none;")

            

            desc_lbl = QLabel(flag["desc"] + f"  —  #{flag['id']}")

            desc_lbl.setStyleSheet("color: #8b949e; background: transparent; border: none;")

            desc_lbl.setWordWrap(True)

            

            info_lyt.addWidget(name_lbl)

            info_lyt.addWidget(desc_lbl)

            

            combo = QComboBox()

            combo.setCursor(Qt.CursorShape.PointingHandCursor)

            combo.setStyleSheet("QComboBox { padding: 4px 10px; border-radius: 6px; }") # Ana temanın butonlarına uyması için minimal tutuldu

            combo.addItems(["Default", "Enabled", "Disabled"])

            

            current_val = self.saved_flags.get(flag["id"], "Default")

            combo.setCurrentText(current_val)

            combo.currentTextChanged.connect(lambda text, f_id=flag["id"]: self._save_flag(f_id, text))

            

            row_lyt.addLayout(info_lyt, 1)

            row_lyt.addSpacing(20)

            row_lyt.addWidget(combo, alignment=Qt.AlignmentFlag.AlignVCenter)

            self.list_layout.addWidget(row_frame)

            

        self.list_layout.addStretch(1)

        scroll.setWidget(self.scroll_widget)

        

        footer = QHBoxLayout()

        self.changes_lbl = QLabel(tr("No pending changes."), self.card)

        self.changes_lbl.setObjectName("AsterFooterInfo")

        self.changes_lbl.setWordWrap(True)

        

        self.restart_btn = QPushButton(tr("Restart Aster"), self.card)

        # Sınıf adı verilmediği için CSS'deki o şık ana mavi/yeşil "Open selected" butonuna benzeyecek

        self.restart_btn.setVisible(False)

        

        footer.addWidget(self.changes_lbl, 1)

        footer.addWidget(self.restart_btn)

        

        self.card_layout.addLayout(top_row)

        self.card_layout.addWidget(scroll, 1)

        self.card_layout.addLayout(footer)

        

        shell_layout.addWidget(self.title_label)

        shell_layout.addWidget(self.subtitle_label)

        shell_layout.addWidget(self.card, 1)

        

        row.addWidget(self.shell)

        outer.addLayout(row)





class ParkedTabWidget(QWidget):
    restore_requested = pyqtSignal()
    lite_requested = pyqtSignal()
    close_requested = pyqtSignal()

    def __init__(self, title: str, url: str, container: str, reason: str, animated: bool = True, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterInternalPage")
        self._animated = bool(animated)
        self._frame = 0
        self._camel_frames = [
            "🐪    Parked",
            " 🐪   Parked",
            "  🐪  Parked",
            "   🐪 Parked",
            "    🐪 Parked",
            "   🐪 Parked",
            "  🐪  Parked",
            " 🐪   Parked",
        ]
        self._camel_timer = QTimer(self)
        self._camel_timer.setInterval(650)
        self._camel_timer.timeout.connect(self._advance_camel)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(12)
        self.camel_label = QLabel(self._camel_frames[0] if self._animated else "🐪 Parked")
        self.camel_label.setStyleSheet("font-size: 30px; font-weight: 700;")
        title_label = QLabel(title or "Parked Tab")
        title_label.setStyleSheet("font-size: 22px; font-weight: 600;")
        url_label = QLabel(url)
        url_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        info = QLabel(
            f"This tab is parked and not running a web engine right now, so it saves RAM.\n"
            f"Container: {container}\n"
            f"Reason: {reason or 'manual or memory pressure'}\n"
            "It will stay parked after closing Aster until you restore/unpark it."
        )
        info.setWordWrap(True)
        restore = QPushButton(tr("Unpark / restore full tab"))
        restore.clicked.connect(lambda _checked=False: self.restore_requested.emit())
        lite = QPushButton(tr("Open in Lite mode"))
        lite.clicked.connect(lambda _checked=False: self.lite_requested.emit())
        close_button = QPushButton(tr("Close parked tab"))
        close_button.clicked.connect(lambda _checked=False: self.close_requested.emit())
        buttons = QHBoxLayout()
        buttons.addWidget(restore)
        buttons.addWidget(lite)
        buttons.addWidget(close_button)
        layout.addWidget(self.camel_label)
        layout.addWidget(title_label)
        layout.addWidget(url_label)
        layout.addSpacing(8)
        layout.addWidget(info)
        layout.addSpacing(12)
        layout.addLayout(buttons)
        layout.addStretch(1)

    def _advance_camel(self) -> None:
        if not self._animated:
            return
        self._frame = (self._frame + 1) % len(self._camel_frames)
        self.camel_label.setText(self._camel_frames[self._frame])

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        if self._animated and not self._camel_timer.isActive():
            self._camel_timer.start()

    def hideEvent(self, event) -> None:  # type: ignore[override]
        if self._camel_timer.isActive():
            self._camel_timer.stop()
        super().hideEvent(event)


class LiteWorker(QObject):
    loaded = pyqtSignal(object)
    failed = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, url: str) -> None:
        super().__init__()
        self.url = url

    def run(self) -> None:
        try:
            page = render_lite_page(self.url)
        except Exception as exc:
            self.failed.emit(str(exc))
        else:
            self.loaded.emit(page)
        finally:
            self.finished.emit()


class LitePageWidget(QWidget):
    open_full_requested = pyqtSignal(str)
    open_link_requested = pyqtSignal(str)
    title_changed = pyqtSignal(str)
    status_message = pyqtSignal(str)

    def __init__(self, url: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterInternalPage")
        self.url = url
        self.page: LitePage | None = None
        self.thread: QThread | None = None
        self.worker: LiteWorker | None = None
        self._build_ui()
        self.load_url(url)

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        controls = QHBoxLayout()
        self.url_label = QLabel(self.url)
        self.url_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        reload_button = QPushButton(tr("Reload Lite"))
        reload_button.clicked.connect(lambda _checked=False: self.load_url(self.url))
        full_button = QPushButton(tr("Open full site"))
        full_button.clicked.connect(lambda _checked=False: self.open_full_requested.emit(self.url))
        controls.addWidget(self.url_label, 1)
        controls.addWidget(reload_button)
        controls.addWidget(full_button)
        self.viewer = QTextBrowser()
        self.viewer.setOpenLinks(False)
        self.viewer.anchorClicked.connect(lambda qurl: self.open_link_requested.emit(qurl.toString()))
        layout.addLayout(controls)
        layout.addWidget(self.viewer, 1)

    def load_url(self, url: str) -> None:
        self.url = url
        self.url_label.setText(url)
        self.viewer.setHtml("<h2>Loading Lite page…</h2>")
        self.thread = QThread(self)
        self.worker = LiteWorker(url)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.loaded.connect(self._on_loaded)
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def _on_loaded(self, page: LitePage) -> None:
        self.page = page
        self.title_changed.emit(page.title)
        self.status_message.emit(f"Lite page loaded: {page.title}")
        body = f"""
        <html>
          <body style="font-family: sans-serif; line-height: 1.45; max-width: 860px; margin: 12px auto;">
            {page.html}
          </body>
        </html>
        """
        self.viewer.setHtml(body)

    def _on_failed(self, message: str) -> None:
        self.viewer.setHtml(f"<h2>Lite mode error</h2><p>{html.escape(message)}</p>")
        self.status_message.emit(f"Lite mode failed: {message}")


class AIWorker(QObject):
    result_ready = pyqtSignal(str)
    failed = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, broker: AIBroker, prompt: str, context: AIContext) -> None:
        super().__init__()
        self.broker = broker
        self.prompt = prompt
        self.context = context

    def run(self) -> None:
        try:
            result = self.broker.ask(self.prompt, self.context)
        except Exception as exc:
            self.failed.emit(str(exc))
        else:
            self.result_ready.emit(result)
        finally:
            self.finished.emit()


class AIDockWidget(QDockWidget):
    def __init__(
        self,
        broker_provider: Callable[[], AIBroker],
        command_router: CommandRouter,
        intent_router: IntentRouter,
        context_provider: Callable[[], AIContext],
        allow_actions_default: bool = False,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__("AI", parent)
        self.broker_provider = broker_provider
        self.command_router = command_router
        self.intent_router = intent_router
        self.context_provider = context_provider
        self.thread: QThread | None = None
        self.worker: AIWorker | None = None
        self._build_ui(allow_actions_default)

    def _build_ui(self, allow_actions_default: bool) -> None:
        host = QWidget()
        layout = QVBoxLayout(host)
        self.transcript = QTextEdit()
        self.transcript.setReadOnly(True)
        self.transcript.setPlaceholderText(
            tr("Ask the built-in local assistant to summarize this page, compare tabs, list open tabs, search your documents/history/bookmarks, manage extensions with /extensions, use /help or /capsules, or enable AI actions to say things like 'open prime video in this tab and park the other tabs'.")
        )
        self.entry = QLineEdit()
        self.entry.setPlaceholderText(tr("Ask Aster, use /help, /tabs, /extensions, /bookmarks, or say 'bookmark this page'"))
        self.entry.returnPressed.connect(self.submit)
        self.allow_actions = QCheckBox(tr("Allow AI actions (tabs/bookmarks/open/search/find/docs/downloads/navigation)"))
        self.allow_actions.setChecked(allow_actions_default)
        send_button = QPushButton(tr("Send"))
        send_button.clicked.connect(self.submit)
        help_button = QPushButton(tr("Commands"))
        help_button.clicked.connect(lambda _checked=False: self.append_assistant(self.command_router.execute("/help") or tr("No commands available.")))
        clear_button = QPushButton(tr("Clear"))
        clear_button.clicked.connect(self.transcript.clear)
        row = QHBoxLayout()
        row.addWidget(self.entry, 1)
        row.addWidget(send_button)
        row.addWidget(help_button)
        row.addWidget(clear_button)
        layout.addWidget(self.transcript, 1)
        layout.addWidget(self.allow_actions)
        layout.addLayout(row)
        self.setWidget(host)

    def set_allow_actions_default(self, value: bool) -> None:
        self.allow_actions.setChecked(value)

    def append_user(self, text: str) -> None:
        self.transcript.append(f"<p><b>You:</b> {html.escape(text)}</p>")

    def append_assistant(self, text: str) -> None:
        self.transcript.append(f"<p><b>Aster:</b> {html.escape(text)}</p>")

    def submit(self) -> None:
        text = self.entry.text().strip()
        if not text:
            return
        self.append_user(text)
        self.entry.clear()
        command_result = self.command_router.execute(text)
        if command_result is not None:
            self.append_assistant(command_result)
            return
        if self.allow_actions.isChecked():
            intent_result = self.intent_router.execute(text)
            if intent_result is not None:
                self.append_assistant(intent_result)
                return
        try:
            broker = self.broker_provider()
            context = self.context_provider()
        except Exception as exc:
            self.append_assistant(f"Broker setup failed: {exc}")
            return
        self.thread = QThread(self)
        self.worker = AIWorker(broker, text, context)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.result_ready.connect(self.append_assistant)
        self.worker.failed.connect(lambda msg: self.append_assistant(f"AI error: {msg}"))
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()


class ExtensionManagerDialog(QDialog):
    def __init__(
        self,
        list_provider: Callable[[], list[object]],
        install_file_callback: Callable[[], str],
        install_folder_callback: Callable[[], str],
        toggle_callback: Callable[[str], str],
        remove_callback: Callable[[str], str],
        reload_callback: Callable[[], str],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("Aster Extensions"))
        self.resize(820, 520)
        self.list_provider = list_provider
        self.install_file_callback = install_file_callback
        self.install_folder_callback = install_folder_callback
        self.toggle_callback = toggle_callback
        self.remove_callback = remove_callback
        self.reload_callback = reload_callback
        self._build_ui()
        self.refresh_list()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        intro = QLabel(
            tr("Import unpacked extensions, .zip, .xpi, or .crx packages. Supported extension pages can also show an Add to Aster button for direct package downloads. Aster defaults to a safe extension backend for stability; you can switch to native_when_available in Settings when you want Qt WebEngine to try loading Manifest V3 extensions directly.")
        )
        intro.setWordWrap(True)
        self.list_widget = QListWidget()
        self.list_widget.itemSelectionChanged.connect(self._update_buttons)
        self.status_label = QLabel(tr("Select an extension to enable, disable, or remove it."))
        self.status_label.setWordWrap(True)

        button_row = QHBoxLayout()
        self.install_file_button = QPushButton(tr("Install file"))
        self.install_file_button.clicked.connect(self._install_file)
        self.install_folder_button = QPushButton(tr("Install folder"))
        self.install_folder_button.clicked.connect(self._install_folder)
        self.toggle_button = QPushButton(tr("Enable / disable"))
        self.toggle_button.clicked.connect(self._toggle_selected)
        self.remove_button = QPushButton(tr("Remove"))
        self.remove_button.clicked.connect(self._remove_selected)
        self.reload_button = QPushButton(tr("Reload runtime"))
        self.reload_button.clicked.connect(self._reload_runtime)
        for button in [self.install_file_button, self.install_folder_button, self.toggle_button, self.remove_button, self.reload_button]:
            button_row.addWidget(button)

        close_buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close_buttons.rejected.connect(self.reject)
        close_buttons.accepted.connect(self.accept)

        layout.addWidget(intro)
        layout.addWidget(self.list_widget, 1)
        layout.addWidget(self.status_label)
        layout.addLayout(button_row)
        layout.addWidget(close_buttons)
        self._update_buttons()

    def refresh_list(self) -> None:
        self.list_widget.clear()
        records = self.list_provider()
        if not records:
            self.status_label.setText(
                tr("No extensions installed yet. Use Install file for .zip/.xpi/.crx packages or Install folder for an unpacked extension directory.")
            )
        for record in records:
            name = getattr(record, "name", "Extension")
            version = getattr(record, "version", "")
            enabled = bool(getattr(record, "enabled", False))
            runtime_kind = getattr(record, "runtime_kind", "unknown")
            source_kind = getattr(record, "source_kind", "unknown")
            status = getattr(record, "status", "ready")
            note = getattr(record, "note", "")
            ext_id = getattr(record, "ext_id", name)
            header = f"{name} {version} [{'enabled' if enabled else 'disabled'} | {runtime_kind} | {source_kind} | {status}]"
            body = f"{header}\n{note}" if note else header
            item = QListWidgetItem(body)
            item.setData(Qt.ItemDataRole.UserRole, ext_id)
            self.list_widget.addItem(item)
        self._update_buttons()

    def _selected_ext_id(self) -> str:
        item = self.list_widget.currentItem()
        if item is None:
            return ""
        value = item.data(Qt.ItemDataRole.UserRole)
        return str(value or "")

    def _update_buttons(self) -> None:
        has_selection = bool(self._selected_ext_id())
        self.toggle_button.setEnabled(has_selection)
        self.remove_button.setEnabled(has_selection)

    def _install_file(self) -> None:
        message = self.install_file_callback()
        self.status_label.setText(message)
        self.refresh_list()

    def _install_folder(self) -> None:
        message = self.install_folder_callback()
        self.status_label.setText(message)
        self.refresh_list()

    def _toggle_selected(self) -> None:
        ext_id = self._selected_ext_id()
        if not ext_id:
            return
        message = self.toggle_callback(ext_id)
        self.status_label.setText(message)
        self.refresh_list()

    def _remove_selected(self) -> None:
        ext_id = self._selected_ext_id()
        if not ext_id:
            return
        message = self.remove_callback(ext_id)
        self.status_label.setText(message)
        self.refresh_list()

    def _reload_runtime(self) -> None:
        message = self.reload_callback()
        self.status_label.setText(message)
        self.refresh_list()


class NoWheelEventFilter(QObject):
    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if event.type() == QEvent.Type.Wheel:
            # Prevent accidental mouse wheel setting changes unless focused
            if not obj.hasFocus():
                event.ignore()
                return True
        return super().eventFilter(obj, event)

class SettingsFormWidget(QWidget):
    manage_speech_requested = pyqtSignal()

    def __init__(self, config: BrowserConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.original = copy.deepcopy(config)
        self._wheel_filter = NoWheelEventFilter(self)
        self._build_ui(config)
        self._install_wheel_filters()

    def _install_wheel_filters(self) -> None:
        for child in self.findChildren((QComboBox, QSpinBox)):
            child.installEventFilter(self._wheel_filter)
            child.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    @staticmethod
    def _fill_combo(combo: QComboBox, values: list[str], current_text: str) -> None:
        combo.blockSignals(True)
        combo.clear()
        seen: list[str] = []
        for item in [current_text, *values]:
            clean = str(item or '').strip()
            if clean and clean not in seen:
                seen.append(clean)
                combo.addItem(clean)
        if current_text:
            combo.setCurrentText(current_text)
        elif seen:
            combo.setCurrentText(seen[0])
        combo.blockSignals(False)

    @staticmethod
    def _fill_language_combo(combo: QComboBox, current_code: str) -> None:
        combo.blockSignals(True)
        combo.clear()
        normalized = normalize_language_code(current_code)
        selected_index = -1
        for code, label in language_choices():
            combo.addItem(label, code)
            if normalize_language_code(code).lower() == normalized.lower():
                selected_index = combo.count() - 1
        if selected_index < 0 and normalized != "system":
            combo.addItem(normalized, normalized)
            selected_index = combo.count() - 1
        combo.setCurrentIndex(max(0, selected_index))
        combo.blockSignals(False)

    @staticmethod
    def _fill_interface_language_combo(combo: QComboBox, current_code: str) -> None:
        combo.blockSignals(True)
        combo.clear()
        normalized = normalize_interface_language(current_code)
        selected_index = 0
        for code, label in interface_language_choices():
            combo.addItem(label, code)
            if code == normalized:
                selected_index = combo.count() - 1
        combo.setCurrentIndex(selected_index)
        combo.blockSignals(False)

    def _current_interface_language(self) -> str:
        data = self.interface_language_combo.currentData()
        return normalize_interface_language(str(data or "system"))

    def _current_language_code(self) -> str:
        data = self.language_combo.currentData()
        current_text = self.language_combo.currentText().strip()
        if data and current_text == self.language_combo.itemText(self.language_combo.currentIndex()):
            return normalize_language_code(str(data))
        return normalize_language_code(current_text)

    def _add_section_tab(self, label: str, icon_name: str, section: QFrame) -> None:
        """Bir ayar bolumunu sol raydaki kendi sekmesine yerlestirir."""
        index = self.section_stack.count()

        page = QScrollArea(self.section_stack)
        page.setObjectName("AsterSettingsSectionScroll")
        page.setWidgetResizable(True)
        page.setFrameShape(QFrame.Shape.NoFrame)
        page.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        holder = QWidget(page)
        holder_layout = QVBoxLayout(holder)
        holder_layout.setContentsMargins(0, 0, 6, 0)
        holder_layout.setSpacing(0)
        section.setParent(holder)
        holder_layout.addWidget(section)
        holder_layout.addStretch(1)
        page.setWidget(holder)
        self.section_stack.addWidget(page)

        button = QPushButton(label, self.nav_frame)
        button.setObjectName("AsterSettingsNavItem")
        button.setCheckable(True)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setIcon(svg_icon(icon_name))
        button.setIconSize(QSize(16, 16))
        button.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        button.clicked.connect(
            lambda _checked=False, value=index: self.section_stack.setCurrentIndex(value)
        )
        self.nav_group.addButton(button, index)
        self._nav_buttons.append(button)
        self.nav_layout.addWidget(button)

    def _build_ui(self, config: BrowserConfig) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)

        self.nav_frame = QFrame(self)
        self.nav_frame.setObjectName("AsterSettingsNav")
        self.nav_frame.setFixedWidth(164)
        self.nav_frame.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.nav_layout = QVBoxLayout(self.nav_frame)
        self.nav_layout.setContentsMargins(0, 0, 0, 0)
        self.nav_layout.setSpacing(3)

        self.section_stack = QStackedWidget(self)
        self.section_stack.setObjectName("AsterSettingsStack")
        self.section_stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self._nav_buttons: list[QPushButton] = []

        general_section = QFrame(self)
        general_section.setObjectName("AsterFormSection")
        general_layout = QVBoxLayout(general_section)
        general_layout.setContentsMargins(18, 18, 18, 18)
        general_layout.setSpacing(12)
        self._language_code = normalize_language_code(getattr(config, "language_code", "system"))
        general_title = QLabel(tr("General"))
        general_title.setObjectName("AsterSectionTitle")
        general_note = QLabel(tr("Homepage, language, search, theme, Qt widget style, zoom, and basic browsing behavior."))
        general_note.setObjectName("AsterMutedLabel")
        general_note.setWordWrap(True)
        general_form = QFormLayout()

        self.homepage_edit = QLineEdit(config.homepage)
        self.search_engine_edit = QLineEdit(config.search_engine)
        self.language_combo = QComboBox(); self.language_combo.setEditable(True); self._fill_language_combo(self.language_combo, getattr(config, "language_code", "system"))
        self.interface_language_combo = QComboBox(); self._fill_interface_language_combo(self.interface_language_combo, getattr(config, "interface_language", "system"))
        self.theme_combo = QComboBox(); self.theme_combo.addItems(["black_arc", "aster_dark", "system"]); self.theme_combo.setCurrentText(config.theme if config.theme in {"black_arc", "aster_dark", "system"} else "black_arc")
        self.accent_color_edit = QLineEdit(str(getattr(config, "accent_color", DEFAULT_ACCENT) or DEFAULT_ACCENT)); self.accent_color_edit.setPlaceholderText(DEFAULT_ACCENT)
        self.qt_style_combo = QComboBox(); self.qt_style_combo.addItems(available_qt_styles()); self.qt_style_combo.setCurrentText(getattr(config, "qt_style", "fusion") or "fusion")
        self.tab_position_combo = QComboBox(); self.tab_position_combo.addItems(["top", "bottom", "left", "right"]); self.tab_position_combo.setCurrentText(getattr(config, "tab_position", "top") if getattr(config, "tab_position", "top") in {"top", "bottom", "left", "right"} else "top")
        self.toolbar_density_combo = QComboBox(); self.toolbar_density_combo.addItems(["compact", "comfortable", "spacious"]); self.toolbar_density_combo.setCurrentText(getattr(config, "ui_density", getattr(config, "toolbar_density", "comfortable")) if getattr(config, "ui_density", getattr(config, "toolbar_density", "comfortable")) in {"compact", "comfortable", "spacious"} else "comfortable")
        self.transparency_spin = QSpinBox(); self.transparency_spin.setRange(0, 60); self.transparency_spin.setSuffix(" %"); self.transparency_spin.setValue(int(getattr(config, "background_transparency_percent", 10) or 10))
        self.default_zoom_spin = QSpinBox(); self.default_zoom_spin.setRange(50, 300); self.default_zoom_spin.setSuffix(" %"); self.default_zoom_spin.setSingleStep(10); self.default_zoom_spin.setValue(int(getattr(config, "default_zoom_percent", 100) or 100))
        self.show_status_bar_check = QCheckBox(); self.show_status_bar_check.setChecked(bool(getattr(config, "show_status_bar", True)))
        self.toolbar_text_check = QCheckBox(); self.toolbar_text_check.setChecked(bool(getattr(config, "toolbar_text", False)))
        self.corner_radius_spin = QSpinBox(); self.corner_radius_spin.setRange(0, 40); self.corner_radius_spin.setSuffix(" px"); self.corner_radius_spin.setValue(int(getattr(config, "window_corner_radius", 18) or 18))
        self.show_home_button_check = QCheckBox(); self.show_home_button_check.setChecked(bool(getattr(config, "show_home_button", True)))
        self.show_new_tab_button_check = QCheckBox(); self.show_new_tab_button_check.setChecked(bool(getattr(config, "show_new_tab_button", True)))
        self.show_container_selector_check = QCheckBox(); self.show_container_selector_check.setChecked(bool(getattr(config, "show_container_selector", True)))
        self.show_progress_bar_check = QCheckBox(); self.show_progress_bar_check.setChecked(bool(getattr(config, "show_progress_bar", True)))
        self.security_combo = QComboBox(); self.security_combo.addItems(["strict", "balanced", "permissive"]); self.security_combo.setCurrentText(config.security_mode)
        self.max_tabs_spin = QSpinBox(); self.max_tabs_spin.setRange(1, 100); self.max_tabs_spin.setValue(config.max_live_tabs)
        self.soft_budget_spin = QSpinBox(); self.soft_budget_spin.setRange(256, 32768); self.soft_budget_spin.setValue(config.soft_memory_budget_mb)
        self.auto_park_check = QCheckBox(); self.auto_park_check.setChecked(config.auto_park)
        self.parked_persist_check = QCheckBox(); self.parked_persist_check.setChecked(bool(getattr(config, "parked_tabs_persist", True)))
        self.camel_animation_check = QCheckBox(); self.camel_animation_check.setChecked(bool(getattr(config, "parked_camel_animation", True)))
        self.left_click_menu_check = QCheckBox(); self.left_click_menu_check.setChecked(getattr(config, "active_tab_left_click_menu", True))

        general_form.addRow(tr("Homepage"), self.homepage_edit)
        general_form.addRow(tr("Search engine"), self.search_engine_edit)
        general_form.addRow(tr("Language"), self.language_combo)
        general_form.addRow(tr("Interface language"), self.interface_language_combo)
        general_form.addRow(tr("Theme"), self.theme_combo)
        general_form.addRow(tr("Accent color"), self.accent_color_edit)
        general_form.addRow(tr("Qt widget style"), self.qt_style_combo)
        general_form.addRow(tr("Tab position"), self.tab_position_combo)
        general_form.addRow(tr("Toolbar density"), self.toolbar_density_combo)
        general_form.addRow(tr("Window transparency"), self.transparency_spin)
        general_form.addRow(tr("Default page zoom"), self.default_zoom_spin)
        general_form.addRow(tr("Show status bar"), self.show_status_bar_check)
        general_form.addRow(tr("Show toolbar text"), self.toolbar_text_check)
        general_form.addRow(tr("Window corner radius"), self.corner_radius_spin)
        general_form.addRow(tr("Show Home button"), self.show_home_button_check)
        general_form.addRow(tr("Show New Tab button"), self.show_new_tab_button_check)
        general_form.addRow(tr("Show container selector"), self.show_container_selector_check)
        general_form.addRow(tr("Show loading progress"), self.show_progress_bar_check)
        general_form.addRow(tr("Security mode"), self.security_combo)
        general_form.addRow(tr("Max live tabs"), self.max_tabs_spin)
        general_form.addRow(tr("Soft budget (MB)"), self.soft_budget_spin)
        general_form.addRow(tr("Auto-park tabs"), self.auto_park_check)
        general_form.addRow(tr("Keep parked tabs after restart"), self.parked_persist_check)
        general_form.addRow(tr("Camel parked-tab animation"), self.camel_animation_check)
        general_form.addRow(tr("Active-tab left click menu"), self.left_click_menu_check)
        general_layout.addWidget(general_title)
        general_layout.addWidget(general_note)
        general_layout.addLayout(general_form)

        customization_section = QFrame(self)
        customization_section.setObjectName("AsterFormSection")
        customization_layout = QVBoxLayout(customization_section)
        customization_layout.setContentsMargins(18, 18, 18, 18)
        customization_layout.setSpacing(12)
        customization_title = QLabel(tr("Advanced customization"))
        customization_title.setObjectName("AsterSectionTitle")
        customization_note = QLabel(tr("Optional user CSS lets power users adjust page appearance, similar to advanced browser customization. Keep it simple because CSS may affect some websites."))
        customization_note.setObjectName("AsterMutedLabel")
        customization_note.setWordWrap(True)
        customization_form = QFormLayout()
        self.custom_css_enabled_check = QCheckBox(); self.custom_css_enabled_check.setChecked(bool(getattr(config, "custom_page_css_enabled", False)))
        self.custom_css_edit = QTextEdit(str(getattr(config, "custom_page_css", "") or ""))
        self.custom_css_edit.setAcceptRichText(False)
        self.custom_css_edit.setPlaceholderText("/* Example: body { font-size: 18px; } */")
        self.custom_css_edit.setMinimumHeight(90)
        customization_form.addRow(tr("Enable page CSS"), self.custom_css_enabled_check)
        customization_form.addRow(tr("Custom page CSS"), self.custom_css_edit)
        customization_layout.addWidget(customization_title)
        customization_layout.addWidget(customization_note)
        customization_layout.addLayout(customization_form)

        browsing_section = QFrame(self)
        browsing_section.setObjectName("AsterFormSection")
        browsing_layout = QVBoxLayout(browsing_section)
        browsing_layout.setContentsMargins(18, 18, 18, 18)
        browsing_layout.setSpacing(12)
        browsing_title = QLabel(tr("Browsing and streaming"))
        browsing_title.setObjectName("AsterSectionTitle")
        browsing_note = QLabel(tr("Ad blocking, containers, rendering, downloads, and streaming compatibility."))
        browsing_note.setObjectName("AsterMutedLabel")
        browsing_note.setWordWrap(True)
        browsing_form = QFormLayout()
        self.adblock_check = QCheckBox(); self.adblock_check.setChecked(config.adblock_enabled)
        self.strict_adblock_check = QCheckBox(); self.strict_adblock_check.setChecked(config.strict_adblock)
        self.adblock_mode_combo = QComboBox(); self.adblock_mode_combo.addItems(["balanced", "strict", "custom", "off"]); self.adblock_mode_combo.setCurrentText(getattr(config, "adblock_mode", "balanced") if getattr(config, "adblock_mode", "balanced") in {"balanced", "strict", "custom", "off"} else "balanced")
        self.adblock_streaming_allow_check = QCheckBox(); self.adblock_streaming_allow_check.setChecked(bool(getattr(config, "adblock_streaming_allowlist", True)))
        self.adblock_allow_hosts_edit = QLineEdit(", ".join(getattr(config, "adblock_allow_hosts", []) or [])); self.adblock_allow_hosts_edit.setPlaceholderText("cdn.example.com, video.example.com")
        self.adblock_block_hosts_edit = QLineEdit(", ".join(getattr(config, "adblock_block_hosts", []) or [])); self.adblock_block_hosts_edit.setPlaceholderText("ads.example.com, tracker.example.net")
        self.adblock_custom_rules_edit = QTextEdit(str(getattr(config, "adblock_custom_rules", "") or "")); self.adblock_custom_rules_edit.setAcceptRichText(False); self.adblock_custom_rules_edit.setMinimumHeight(90); self.adblock_custom_rules_edit.setPlaceholderText("||tracker.example^\n@@||trusted-cdn.example^\nblock:ads.example.com\nallow:video-cdn.example.com")
        self.container_edit = QLineEdit(", ".join(config.containers))
        self.default_container_edit = QLineEdit(config.default_container)
        self.extension_backend_combo = QComboBox(); self.extension_backend_combo.addItems(["safe", "native_when_available"]); self.extension_backend_combo.setCurrentText(config.extension_backend)
        self.force_software_check = QCheckBox(); self.force_software_check.setChecked(config.force_software_rendering)
        self.drm_mode_combo = QComboBox(); self.drm_mode_combo.addItems(["chromium_drm_capsule", "qtwebengine_capsule", "internal_preferred", "auto", "internal_only", "external_only"]); self.drm_mode_combo.setCurrentText(config.drm_mode if config.drm_mode in {"chromium_drm_capsule", "qtwebengine_capsule", "internal_preferred", "auto", "internal_only", "external_only"} else "chromium_drm_capsule")
        self.external_browser_edit = QLineEdit(config.external_browser_cmd)
        self.trust_system_ca_check = QCheckBox(); self.trust_system_ca_check.setChecked(bool(getattr(config, "trust_system_ca", True)))
        self.https_auto_update_ca_check = QCheckBox(); self.https_auto_update_ca_check.setChecked(bool(getattr(config, "https_auto_update_ca", True)))
        self.cert_exception_hosts_edit = QLineEdit(", ".join(getattr(config, "certificate_exception_hosts", []) or [])); self.cert_exception_hosts_edit.setPlaceholderText("router.lan, example.local")
        browsing_form.addRow(tr("Adblock"), self.adblock_check)
        browsing_form.addRow(tr("Adblock mode"), self.adblock_mode_combo)
        browsing_form.addRow(tr("Strict adblock"), self.strict_adblock_check)
        browsing_form.addRow(tr("Protect streaming/CDN hosts"), self.adblock_streaming_allow_check)
        browsing_form.addRow(tr("Adblock allow hosts"), self.adblock_allow_hosts_edit)
        browsing_form.addRow(tr("Adblock block hosts"), self.adblock_block_hosts_edit)
        browsing_form.addRow(tr("Custom adblock rules"), self.adblock_custom_rules_edit)
        browsing_form.addRow(tr("Containers"), self.container_edit)
        browsing_form.addRow(tr("Default container"), self.default_container_edit)
        browsing_form.addRow(tr("Extension backend"), self.extension_backend_combo)
        browsing_form.addRow(tr("Force software rendering"), self.force_software_check)
        browsing_form.addRow(tr("DRM mode"), self.drm_mode_combo)
        browsing_form.addRow(tr("Capsule/browser override"), self.external_browser_edit)
        browsing_form.addRow(tr("Use system CA paths"), self.trust_system_ca_check)
        browsing_form.addRow(tr("Auto-refresh CA trust on install/update"), self.https_auto_update_ca_check)
        browsing_form.addRow(tr("HTTPS exception hosts"), self.cert_exception_hosts_edit)
        browsing_layout.addWidget(browsing_title)
        browsing_layout.addWidget(browsing_note)
        browsing_layout.addLayout(browsing_form)

        speech_section = QFrame(self)
        speech_section.setObjectName("AsterFormSection")
        speech_layout = QVBoxLayout(speech_section)
        speech_layout.setContentsMargins(18, 18, 18, 18)
        speech_layout.setSpacing(12)
        speech_title = QLabel(tr("Speech and voices"))
        speech_title.setObjectName("AsterSectionTitle")
        speech_note = QLabel(
            tr("Use the system voice, installed Piper voices, or a custom local voice-cloning command. "
            "You can record or import a reference sample from the speech tools button below.")
        )
        speech_note.setObjectName("AsterMutedLabel")
        speech_note.setWordWrap(True)
        speech_form = QFormLayout()
        self.tts_engine_combo = QComboBox(); self.tts_engine_combo.addItems(["off", "system", "piper", "custom_command"]); self.tts_engine_combo.setCurrentText(getattr(config, "tts_engine", "system") or "system")
        self.tts_system_voice_combo = QComboBox(); self.tts_system_voice_combo.setEditable(True)
        self.tts_piper_voice_combo = QComboBox(); self.tts_piper_voice_combo.setEditable(True)
        self.tts_rate_spin = QSpinBox(); self.tts_rate_spin.setRange(-100, 100); self.tts_rate_spin.setSuffix(" %"); self.tts_rate_spin.setValue(int(getattr(config, "tts_rate_percent", 0) or 0))
        self.tts_volume_spin = QSpinBox(); self.tts_volume_spin.setRange(0, 200); self.tts_volume_spin.setSuffix(" %"); self.tts_volume_spin.setSingleStep(10); self.tts_volume_spin.setValue(int(getattr(config, "tts_volume_percent", 100) or 100))
        self.tts_pitch_spin = QSpinBox(); self.tts_pitch_spin.setRange(50, 200); self.tts_pitch_spin.setSuffix(" %"); self.tts_pitch_spin.setSingleStep(10); self.tts_pitch_spin.setValue(int(getattr(config, "tts_pitch_percent", 100) or 100))
        self.tts_reference_audio_edit = QLineEdit(str(getattr(config, "tts_reference_audio_path", "") or "")); self.tts_reference_audio_edit.setReadOnly(True)
        self.tts_custom_command_edit = QLineEdit(str(getattr(config, "tts_custom_command", "") or ""))
        self.refresh_speech_choices([], [], str(getattr(config, "tts_reference_audio_path", "") or ""))
        speech_form.addRow(tr("TTS engine"), self.tts_engine_combo)
        speech_form.addRow(tr("System voice"), self.tts_system_voice_combo)
        speech_form.addRow(tr("Piper voice"), self.tts_piper_voice_combo)
        speech_form.addRow(tr("Speech rate"), self.tts_rate_spin)
        speech_form.addRow(tr("Speech volume"), self.tts_volume_spin)
        speech_form.addRow(tr("Speech pitch"), self.tts_pitch_spin)
        speech_form.addRow(tr("Reference audio"), self.tts_reference_audio_edit)
        speech_form.addRow(tr("Custom command"), self.tts_custom_command_edit)
        speech_help = QLabel(
            tr("Custom command placeholders: {text_file}, {output_wav}, {reference_audio}, {voices_dir}, {cache_dir}, and {text}.")
        )
        speech_help.setObjectName("AsterMutedLabel")
        speech_help.setWordWrap(True)
        manage_row = QHBoxLayout()
        manage_row.addStretch(1)
        manage_button = QPushButton(tr("Manage voices and reference audio"))
        manage_button.setObjectName("SecondaryButton")
        manage_button.clicked.connect(lambda _checked=False: self.manage_speech_requested.emit())
        manage_row.addWidget(manage_button)
        speech_layout.addWidget(speech_title)
        speech_layout.addWidget(speech_note)
        speech_layout.addLayout(speech_form)
        speech_layout.addWidget(speech_help)
        speech_layout.addLayout(manage_row)

        ai_section = QFrame(self)
        ai_section.setObjectName("AsterFormSection")
        ai_layout = QVBoxLayout(ai_section)
        ai_layout.setContentsMargins(18, 18, 18, 18)
        ai_layout.setSpacing(12)
        ai_title = QLabel(tr("Assistant"))
        ai_title.setObjectName("AsterSectionTitle")
        ai_note = QLabel(tr("The internal assistant is local-first and now uses an engineer-mentor behavior profile. External providers remain optional for larger models."))
        ai_note.setObjectName("AsterMutedLabel")
        ai_note.setWordWrap(True)
        ai_form = QFormLayout()
        self.allow_ai_actions_check = QCheckBox(); self.allow_ai_actions_check.setChecked(config.allow_ai_actions)
        self.ai_context_chars_spin = QSpinBox(); self.ai_context_chars_spin.setRange(1000, 40000); self.ai_context_chars_spin.setSingleStep(500); self.ai_context_chars_spin.setValue(config.ai_page_context_chars)
        self.ai_provider_combo = QComboBox(); self.ai_provider_combo.addItems(["internal", "disabled", "ollama", "openai", "openai_compatible"]); self.ai_provider_combo.setCurrentText(config.ai.provider)
        self.ai_persona_combo = QComboBox(); self.ai_persona_combo.addItems(["dr_light_lab", "network_engineer", "cyber_guardian", "browser_helper", "concise"]); self.ai_persona_combo.setCurrentText(getattr(config.ai, "persona", "dr_light_lab") if getattr(config.ai, "persona", "dr_light_lab") in {"dr_light_lab", "network_engineer", "cyber_guardian", "browser_helper", "concise"} else "dr_light_lab")
        self.ai_reasoning_combo = QComboBox(); self.ai_reasoning_combo.addItems(["fast", "balanced", "deep"]); self.ai_reasoning_combo.setCurrentText(getattr(config.ai, "reasoning_mode", "balanced") if getattr(config.ai, "reasoning_mode", "balanced") in {"fast", "balanced", "deep"} else "balanced")
        self.ai_model_edit = QLineEdit(config.ai.model)
        self.ai_base_url_edit = QLineEdit(config.ai.base_url)
        self.ai_api_key_env_edit = QLineEdit(config.ai.api_key_env)
        ai_form.addRow(tr("Allow AI actions by default"), self.allow_ai_actions_check)
        ai_form.addRow(tr("Page context chars"), self.ai_context_chars_spin)
        ai_form.addRow(tr("AI provider"), self.ai_provider_combo)
        ai_form.addRow(tr("AI persona"), self.ai_persona_combo)
        ai_form.addRow(tr("Reasoning mode"), self.ai_reasoning_combo)
        ai_form.addRow(tr("AI model"), self.ai_model_edit)
        ai_form.addRow(tr("AI base URL"), self.ai_base_url_edit)
        ai_form.addRow(tr("AI key env var"), self.ai_api_key_env_edit)
        ai_layout.addWidget(ai_title)
        ai_layout.addWidget(ai_note)
        ai_layout.addLayout(ai_form)

        self._add_section_tab(tr("General"), "settings", general_section)
        self._add_section_tab(tr("Customization"), "sliders", customization_section)
        self._add_section_tab(tr("Browsing"), "globe", browsing_section)
        self._add_section_tab(tr("Speech"), "voice", speech_section)
        self._add_section_tab(tr("Assistant"), "sparkle", ai_section)
        self.nav_layout.addStretch(1)
        self._nav_buttons[0].setChecked(True)

        layout.addWidget(self.nav_frame)
        layout.addWidget(self.section_stack, 1)

    def refresh_speech_choices(self, system_voices: list[str], piper_voices: list[str], reference_audio_path: str = "") -> None:
        current_system = self.tts_system_voice_combo.currentText().strip() or str(getattr(self.original, 'tts_system_voice_name', '') or '').strip()
        current_piper = self.tts_piper_voice_combo.currentText().strip() or str(getattr(self.original, 'tts_piper_voice_name', '') or '').strip()
        self._fill_combo(self.tts_system_voice_combo, system_voices, current_system)
        self._fill_combo(self.tts_piper_voice_combo, piper_voices, current_piper)
        self.tts_reference_audio_edit.setText(reference_audio_path or "")

    def build_config(self) -> BrowserConfig:
        containers = [item.strip() for item in self.container_edit.text().split(",") if item.strip()]
        if not containers:
            containers = ["default"]
        default_container = self.default_container_edit.text().strip() or containers[0]
        if default_container not in containers:
            containers.insert(0, default_container)
        return BrowserConfig(
            homepage=self.homepage_edit.text().strip() or "aster:newtab",
            search_engine=self.search_engine_edit.text().strip() or "https://duckduckgo.com/?q={query}",
            language_code=self._current_language_code(),
            interface_language=self._current_interface_language(),
            adblock_enabled=self.adblock_check.isChecked(),
            strict_adblock=self.strict_adblock_check.isChecked(),
            adblock_mode=self.adblock_mode_combo.currentText(),
            adblock_custom_rules=self.adblock_custom_rules_edit.toPlainText()[:50000],
            adblock_allow_hosts=[item.strip() for item in self.adblock_allow_hosts_edit.text().replace("\n", ",").split(",") if item.strip()],
            adblock_block_hosts=[item.strip() for item in self.adblock_block_hosts_edit.text().replace("\n", ",").split(",") if item.strip()],
            adblock_streaming_allowlist=self.adblock_streaming_allow_check.isChecked(),
            security_mode=self.security_combo.currentText(),
            max_live_tabs=int(self.max_tabs_spin.value()),
            soft_memory_budget_mb=int(self.soft_budget_spin.value()),
            auto_park=self.auto_park_check.isChecked(),
            parked_tabs_persist=self.parked_persist_check.isChecked(),
            parked_camel_animation=self.camel_animation_check.isChecked(),
            default_container=default_container,
            hardware_acceleration=self.original.hardware_acceleration,
            force_software_rendering=self.force_software_check.isChecked(),
            containers=containers,
            drm_mode=self.drm_mode_combo.currentText(),
            external_browser_cmd=self.external_browser_edit.text().strip(),
            allow_ai_actions=self.allow_ai_actions_check.isChecked(),
            ai_page_context_chars=int(self.ai_context_chars_spin.value()),
            theme=self.theme_combo.currentText(),
            qt_style=self.qt_style_combo.currentText(),
            background_transparency_percent=int(self.transparency_spin.value()),
            default_zoom_percent=int(self.default_zoom_spin.value()),
            accent_color=normalize_hex_color(self.accent_color_edit.text().strip() or DEFAULT_ACCENT),
            tab_position=self.tab_position_combo.currentText(),
            ui_density=self.toolbar_density_combo.currentText(),
            toolbar_text=self.toolbar_text_check.isChecked(),
            window_corner_radius=int(self.corner_radius_spin.value()),
            show_status_bar=self.show_status_bar_check.isChecked(),
            show_home_button=self.show_home_button_check.isChecked(),
            show_new_tab_button=self.show_new_tab_button_check.isChecked(),
            show_container_selector=self.show_container_selector_check.isChecked(),
            show_progress_bar=self.show_progress_bar_check.isChecked(),
            custom_page_css_enabled=self.custom_css_enabled_check.isChecked(),
            custom_page_css=self.custom_css_edit.toPlainText()[:20000],
            trust_system_ca=self.trust_system_ca_check.isChecked(),
            https_auto_update_ca=self.https_auto_update_ca_check.isChecked(),
            certificate_exception_hosts=[item.strip() for item in self.cert_exception_hosts_edit.text().replace("\n", ",").split(",") if item.strip()],
            extension_backend=self.extension_backend_combo.currentText(),
            active_tab_left_click_menu=self.left_click_menu_check.isChecked(),
            tts_engine=self.tts_engine_combo.currentText(),
            tts_system_voice_name=self.tts_system_voice_combo.currentText().strip(),
            tts_piper_voice_name=self.tts_piper_voice_combo.currentText().strip(),
            tts_rate_percent=int(self.tts_rate_spin.value()),
            tts_volume_percent=int(self.tts_volume_spin.value()),
            tts_pitch_percent=int(self.tts_pitch_spin.value()),
            tts_custom_command=self.tts_custom_command_edit.text().strip(),
            tts_reference_audio_path=self.tts_reference_audio_edit.text().strip(),
            ai=AIConfig(
                provider=self.ai_provider_combo.currentText(),
                model=self.ai_model_edit.text().strip() or "aster-internal",
                base_url=self.ai_base_url_edit.text().strip(),
                api_key_env=self.ai_api_key_env_edit.text().strip(),
                persona=self.ai_persona_combo.currentText(),
                reasoning_mode=self.ai_reasoning_combo.currentText(),
                system_prompt=self.original.ai.system_prompt,
            ),
        )


class SpeechToolsDialog(QDialog):
    install_piper_voice_requested = pyqtSignal(str)
    remove_piper_voice_requested = pyqtSignal(str)
    import_reference_requested = pyqtSignal()
    start_recording_requested = pyqtSignal()
    stop_recording_requested = pyqtSignal()
    clear_reference_requested = pyqtSignal()
    read_file_requested = pyqtSignal()
    speak_test_requested = pyqtSignal(str)
    stop_speaking_requested = pyqtSignal()

    def __init__(self, config: BrowserConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("Aster speech tools"))
        self.resize(780, 680)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        title = QLabel(tr("Speech tools"), self)
        title.setObjectName("AsterSettingsTitle")
        subtitle = QLabel(
            tr("Install or remove free Piper voices, record or import a reference sample, and test read-aloud without leaving the browser."),
            self,
        )
        subtitle.setObjectName("AsterSettingsSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        reference_section = QFrame(self)
        reference_section.setObjectName("AsterFormSection")
        reference_layout = QVBoxLayout(reference_section)
        reference_layout.setContentsMargins(18, 18, 18, 18)
        reference_layout.setSpacing(12)
        reference_title = QLabel(tr("Reference audio"))
        reference_title.setObjectName("AsterSectionTitle")
        reference_note = QLabel(tr("Import a voice sample or record one locally. The sample can be used by custom local voice-cloning commands."))
        reference_note.setObjectName("AsterMutedLabel")
        reference_note.setWordWrap(True)
        self.reference_path_edit = QLineEdit(str(getattr(config, "tts_reference_audio_path", "") or ""), self)
        self.reference_path_edit.setReadOnly(True)
        ref_buttons = QHBoxLayout()
        import_button = QPushButton(tr("Import audio file"), self)
        import_button.setObjectName("SecondaryButton")
        import_button.clicked.connect(lambda _checked=False: self.import_reference_requested.emit())
        record_button = QPushButton(tr("Start recording"), self)
        record_button.setObjectName("SecondaryButton")
        record_button.clicked.connect(lambda _checked=False: self.start_recording_requested.emit())
        stop_record_button = QPushButton(tr("Stop recording"), self)
        stop_record_button.setObjectName("SecondaryButton")
        stop_record_button.clicked.connect(lambda _checked=False: self.stop_recording_requested.emit())
        clear_button = QPushButton(tr("Clear sample"), self)
        clear_button.setObjectName("SecondaryButton")
        clear_button.clicked.connect(lambda _checked=False: self.clear_reference_requested.emit())
        ref_buttons.addWidget(import_button)
        ref_buttons.addWidget(record_button)
        ref_buttons.addWidget(stop_record_button)
        ref_buttons.addWidget(clear_button)
        ref_buttons.addStretch(1)
        reference_layout.addWidget(reference_title)
        reference_layout.addWidget(reference_note)
        reference_layout.addWidget(self.reference_path_edit)
        reference_layout.addLayout(ref_buttons)
        layout.addWidget(reference_section)

        piper_section = QFrame(self)
        piper_section.setObjectName("AsterFormSection")
        piper_layout = QVBoxLayout(piper_section)
        piper_layout.setContentsMargins(18, 18, 18, 18)
        piper_layout.setSpacing(12)
        piper_title = QLabel(tr("Installed Piper voices"))
        piper_title.setObjectName("AsterSectionTitle")
        piper_note = QLabel(tr("Type a Piper voice name such as en_US-lessac-medium, then install it. You can remove installed voices later to save space."))
        piper_note.setObjectName("AsterMutedLabel")
        piper_note.setWordWrap(True)
        install_row = QHBoxLayout()
        self.piper_voice_edit = QLineEdit(str(getattr(config, "tts_piper_voice_name", "") or ""), self)
        self.piper_voice_edit.setPlaceholderText("en_US-lessac-medium")
        install_button = QPushButton(tr("Install voice"), self)
        install_button.clicked.connect(lambda _checked=False: self.install_piper_voice_requested.emit(self.piper_voice_edit.text().strip()))
        remove_button = QPushButton(tr("Remove selected voice"), self)
        remove_button.setObjectName("SecondaryButton")
        remove_button.clicked.connect(self._emit_remove_selected)
        install_row.addWidget(self.piper_voice_edit, 1)
        install_row.addWidget(install_button)
        install_row.addWidget(remove_button)
        self.installed_voices = QListWidget(self)
        piper_layout.addWidget(piper_title)
        piper_layout.addWidget(piper_note)
        piper_layout.addLayout(install_row)
        piper_layout.addWidget(self.installed_voices, 1)
        layout.addWidget(piper_section, 1)

        test_section = QFrame(self)
        test_section.setObjectName("AsterFormSection")
        test_layout = QVBoxLayout(test_section)
        test_layout.setContentsMargins(18, 18, 18, 18)
        test_layout.setSpacing(12)
        test_title = QLabel(tr("Test and read aloud"))
        test_title.setObjectName("AsterSectionTitle")
        test_note = QLabel(tr("Use the current settings to read a local text file, the current page, or this test text."))
        test_note.setObjectName("AsterMutedLabel")
        test_note.setWordWrap(True)
        self.test_text_edit = QTextEdit(self)
        self.test_text_edit.setAcceptRichText(False)
        self.test_text_edit.setPlainText("This is a quick speech test inside Aster Browser.")
        test_buttons = QHBoxLayout()
        read_file_button = QPushButton(tr("Read text file aloud"), self)
        read_file_button.setObjectName("SecondaryButton")
        read_file_button.clicked.connect(lambda _checked=False: self.read_file_requested.emit())
        speak_button = QPushButton(tr("Speak test text"), self)
        speak_button.clicked.connect(lambda _checked=False: self.speak_test_requested.emit(self.test_text_edit.toPlainText()))
        stop_button = QPushButton(tr("Stop speaking"), self)
        stop_button.setObjectName("SecondaryButton")
        stop_button.clicked.connect(lambda _checked=False: self.stop_speaking_requested.emit())
        test_buttons.addWidget(read_file_button)
        test_buttons.addStretch(1)
        test_buttons.addWidget(stop_button)
        test_buttons.addWidget(speak_button)
        test_layout.addWidget(test_title)
        test_layout.addWidget(test_note)
        test_layout.addWidget(self.test_text_edit)
        test_layout.addLayout(test_buttons)
        layout.addWidget(test_section)

        self.status_label = QLabel(tr("Ready."), self)
        self.status_label.setObjectName("AsterMutedLabel")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        close_row = QHBoxLayout()
        close_row.addStretch(1)
        close_button = QPushButton(tr("Close"), self)
        close_button.setObjectName("SecondaryButton")
        close_button.clicked.connect(self.accept)
        close_row.addWidget(close_button)
        layout.addLayout(close_row)

    def _emit_remove_selected(self) -> None:
        item = self.installed_voices.currentItem()
        if item is None:
            self.set_status("Select an installed Piper voice first.")
            return
        self.remove_piper_voice_requested.emit(item.text().strip())

    def set_installed_piper_voices(self, voices: list[str], current_voice: str = "") -> None:
        self.installed_voices.clear()
        selected_row = -1
        for index, voice in enumerate(voices):
            item = QListWidgetItem(voice)
            self.installed_voices.addItem(item)
            if current_voice and voice == current_voice:
                selected_row = index
        if selected_row >= 0:
            self.installed_voices.setCurrentRow(selected_row)

    def set_reference_audio_path(self, path: str) -> None:
        self.reference_path_edit.setText(path or "")

    def set_status(self, text: str) -> None:
        self.status_label.setText(text or tr("Ready."))


class SettingsPageWidget(QWidget):
    save_requested = pyqtSignal(object)
    cancel_requested = pyqtSignal()
    manage_speech_requested = pyqtSignal()

    def __init__(self, config: BrowserConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterInternalPage")
        language_code = normalize_language_code(getattr(config, "language_code", "system"))
        outer = QVBoxLayout(self)
        
        # Kenar boşluklarını temizleyerek tam ekran ve düz tasarım sağlıyoruz
        outer.setContentsMargins(20, 14, 20, 14)
        
        row = QHBoxLayout()

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        
        self.shell.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.shell.setMinimumWidth(0)
        self.shell.setMaximumWidth(16777215)
        
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        
        card = QFrame(self.shell)
        card.setObjectName("AsterSettingsCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(12)
        
        title = QLabel(tr("Settings"), card)
        title.setObjectName("AsterSettingsTitle")
        subtitle = QLabel(tr("A centered settings page inside the browser. Changes apply immediately where possible."), card)
        subtitle.setObjectName("AsterSettingsSubtitle")
        subtitle.setWordWrap(True)
        
        # Her bolumun kendi kaydirma alani var, bu yuzden distaki scroll yok.
        self.form_widget = SettingsFormWidget(config, card)
        self.form_widget.manage_speech_requested.connect(self.manage_speech_requested.emit)
        self.form_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        save = QPushButton(tr("Save settings"), card)
        save.clicked.connect(lambda _checked=False: self.save_requested.emit(self.form_widget.build_config()))
        buttons.addWidget(save)
        
        card_layout.addWidget(title)
        card_layout.addWidget(subtitle)
        
        # Scroll alanının tüm boşluğu kaplaması için dikey büyüme payını 1 yapıyoruz
        card_layout.addWidget(self.form_widget, 1)
        card_layout.addLayout(buttons)
        
        shell_layout.addWidget(card, 1)
        
        # Sağda ve soldaki boşlukları (addStretch) sildik
        row.addWidget(self.shell) 
        outer.addLayout(row)

    def refresh_speech_choices(self, system_voices: list[str], piper_voices: list[str], reference_audio_path: str = "") -> None:
        self.form_widget.refresh_speech_choices(system_voices, piper_voices, reference_audio_path)


class SettingsDialog(QDialog):
    def __init__(self, config: BrowserConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("Aster Settings"))
        self.resize(860, 720)
        layout = QVBoxLayout(self)
        self.form_widget = SettingsFormWidget(config, self)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(self.form_widget, 1)
        layout.addWidget(buttons)

    def build_config(self) -> BrowserConfig:
        return self.form_widget.build_config()
    
class TaskManagerWidget(QWidget):
    def __init__(self, get_tabs_cb, close_tab_cb, get_stats_cb, parent=None):
        super().__init__(parent)
        self.setObjectName("AsterInternalPage")
        self.get_tabs_cb = get_tabs_cb
        self.close_tab_cb = close_tab_cb
        self.get_stats_cb = get_stats_cb
        
        self._build_ui()
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(2000)
        self.refresh_data()

    def _build_ui(self):
        # 1. Ana Dış Boşluk (History'deki _PageShell yapısı)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        
        row = QHBoxLayout()
        
        # 2. Ana Shell (Arkaplanın temasını ana CSS'den çeker)
        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.shell.setMinimumWidth(0)
        self.shell.setMaximumWidth(16777215)
        
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(28, 26, 28, 24)
        shell_layout.setSpacing(16)
        
        # 3. Başlıklar
        self.title_label = QLabel(tr("Task Manager"), self.shell)
        self.title_label.setObjectName("AsterSettingsTitle")
        
        self.subtitle_label = QLabel(tr("Manage background processes and monitor system resources."), self.shell)
        self.subtitle_label.setObjectName("AsterSettingsSubtitle")
        self.subtitle_label.setWordWrap(True)
        
        # 4. İç Kart (History'deki listeyi tutan çerçeve)
        self.card = QFrame(self.shell)
        self.card.setObjectName("AsterSettingsCard")
        self.card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        self.card_layout = QVBoxLayout(self.card)
        self.card_layout.setContentsMargins(22, 20, 22, 20)
        self.card_layout.setSpacing(14)

        # --- Kart İçeriği ---
        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        
        search_mock = QLabel(tr("Active Processes"), self.card)
        
        refresh_btn = QPushButton(tr("Refresh"), self.card)
        refresh_btn.setObjectName("SecondaryButton") # History ile aynı şık yan buton stili
        refresh_btn.clicked.connect(self.refresh_data)
        
        top_row.addWidget(search_mock, 1)
        top_row.addWidget(refresh_btn)
        
        # Liste Alanı (History list_widget spacing: 6)
        scroll = QScrollArea(self.card)
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollArea > QWidget { border: none; background: transparent; }
        """)
        
        self.scroll_widget = QWidget()
        self.list_layout = QVBoxLayout(self.scroll_widget)
        self.list_layout.setSpacing(6)
        self.list_layout.setContentsMargins(0, 0, 0, 0)
        self.list_layout.addStretch(1)
        
        scroll.setWidget(self.scroll_widget)
        
        # Alt Footer (History FooterInfo stili)
        footer = QHBoxLayout()
        self.stats_label = QLabel(tr("Calculating stats..."), self.card)
        self.stats_label.setObjectName("AsterFooterInfo")
        self.stats_label.setWordWrap(True)
        footer.addWidget(self.stats_label, 1)

        # Yerleşimleri tamamla
        self.card_layout.addLayout(top_row)
        self.card_layout.addWidget(scroll, 1)
        self.card_layout.addLayout(footer)

        shell_layout.addWidget(self.title_label)
        shell_layout.addWidget(self.subtitle_label)
        shell_layout.addWidget(self.card, 1)
        
        row.addWidget(self.shell)
        outer.addLayout(row)

    def refresh_data(self):
        stats = self.get_stats_cb()
        self.stats_label.setText(f"Live tabs: {stats['live']} | Parked tabs: {stats['parked']} | Estimated live memory: {stats['rss']} MB | Network: {stats['network']}")
        
        while self.list_layout.count() > 1:
            item = self.list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        tabs = self.get_tabs_cb()
        for tab in tabs:
            row = QFrame()
            # History'deki QListWidgetItem ile aynı hover hissi ve boşluk
            row.setStyleSheet("QFrame { padding: 4px; border-radius: 6px; background: transparent; } QFrame:hover { background: rgba(255, 255, 255, 0.05); }")
            row_lyt = QHBoxLayout(row)
            row_lyt.setContentsMargins(6, 6, 6, 6)
            
            info_lyt = QVBoxLayout()
            info_lyt.setSpacing(2)
            name_lbl = QLabel(tab['title'])
            name_lbl.setStyleSheet("font-weight: bold; background: transparent; border: none;")
            url_lbl = QLabel(tab['url'][:90] + "..." if len(tab['url']) > 90 else tab['url'])
            url_lbl.setStyleSheet("color: #8b949e; background: transparent; border: none;")
            info_lyt.addWidget(name_lbl)
            info_lyt.addWidget(url_lbl)
            
            status_color = "#3fb950" if tab['kind'] == 'web' else "#d29922" if tab['kind'] == 'parked' else "#e6edf3"
            kind_lbl = QLabel(tab['kind'].upper())
            kind_lbl.setStyleSheet(f"font-weight: bold; color: {status_color}; background: transparent; border: none;")
            
            mem_lbl = QLabel(f"{tab['memory']} MB")
            mem_lbl.setStyleSheet("font-weight: bold; background: transparent; border: none;")
            mem_lbl.setFixedWidth(70)
            mem_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            
            close_btn = QPushButton(tr("Close"))
            close_btn.setObjectName("SecondaryButton")
            close_btn.clicked.connect(lambda checked=False, tid=tab['id']: self.close_tab_cb(tid))
            
            row_lyt.addLayout(info_lyt, 1)
            row_lyt.addSpacing(20)
            row_lyt.addWidget(kind_lbl)
            row_lyt.addSpacing(20)
            row_lyt.addWidget(mem_lbl)
            row_lyt.addSpacing(20)
            row_lyt.addWidget(close_btn)
            
            self.list_layout.insertWidget(self.list_layout.count() - 1, row)