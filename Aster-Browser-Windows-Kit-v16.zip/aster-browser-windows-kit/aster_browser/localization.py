from __future__ import annotations

import locale
import os
import re
from functools import lru_cache

_BCP47_RE = re.compile(r"^[A-Za-z]{2,3}(?:[-_][A-Za-z0-9]{2,8})*$")

# Common choices shown in Settings. The combobox is editable, so any valid BCP-47
# language tag such as es-MX, pt-BR, ar-SA, hi-IN, or zh-Hant can also be typed.
SUPPORTED_LANGUAGE_CHOICES: list[tuple[str, str]] = [
    ("system", "System default"),
    ("en-US", "English (United States)"),
    ("en-GB", "English (United Kingdom)"),
    ("es-ES", "Español (España)"),
    ("es-MX", "Español (México)"),
    ("es-US", "Español (Estados Unidos)"),
    ("pt-BR", "Português (Brasil)"),
    ("pt-PT", "Português (Portugal)"),
    ("fr-FR", "Français (France)"),
    ("fr-CA", "Français (Canada)"),
    ("de-DE", "Deutsch"),
    ("it-IT", "Italiano"),
    ("nl-NL", "Nederlands"),
    ("sv-SE", "Svenska"),
    ("da-DK", "Dansk"),
    ("no-NO", "Norsk"),
    ("fi-FI", "Suomi"),
    ("is-IS", "Íslenska"),
    ("pl-PL", "Polski"),
    ("cs-CZ", "Čeština"),
    ("sk-SK", "Slovenčina"),
    ("sl-SI", "Slovenščina"),
    ("hr-HR", "Hrvatski"),
    ("sr-RS", "Srpski"),
    ("bs-BA", "Bosanski"),
    ("ro-RO", "Română"),
    ("hu-HU", "Magyar"),
    ("el-GR", "Ελληνικά"),
    ("tr-TR", "Türkçe"),
    ("ru-RU", "Русский"),
    ("uk-UA", "Українська"),
    ("bg-BG", "Български"),
    ("he-IL", "עברית"),
    ("ar-SA", "العربية"),
    ("fa-IR", "فارسی"),
    ("ur-PK", "اردو"),
    ("hi-IN", "हिन्दी"),
    ("bn-BD", "বাংলা"),
    ("pa-IN", "ਪੰਜਾਬੀ"),
    ("gu-IN", "ગુજરાતી"),
    ("ta-IN", "தமிழ்"),
    ("te-IN", "తెలుగు"),
    ("kn-IN", "ಕನ್ನಡ"),
    ("ml-IN", "മലയാളം"),
    ("mr-IN", "मराठी"),
    ("si-LK", "සිංහල"),
    ("th-TH", "ไทย"),
    ("vi-VN", "Tiếng Việt"),
    ("id-ID", "Bahasa Indonesia"),
    ("ms-MY", "Bahasa Melayu"),
    ("fil-PH", "Filipino"),
    ("zh-CN", "简体中文"),
    ("zh-TW", "繁體中文（台灣）"),
    ("zh-HK", "繁體中文（香港）"),
    ("ja-JP", "日本語"),
    ("ko-KR", "한국어"),
    ("sw-KE", "Kiswahili"),
    ("am-ET", "አማርኛ"),
    ("yo-NG", "Yorùbá"),
    ("ig-NG", "Igbo"),
    ("ha-NG", "Hausa"),
    ("zu-ZA", "isiZulu"),
    ("af-ZA", "Afrikaans"),
]

_LANGUAGE_LABELS = {code.lower(): label for code, label in SUPPORTED_LANGUAGE_CHOICES}

_TRANSLATIONS: dict[str, dict[str, str]] = {
    "es": {
        "Aster Browser": "Navegador Aster",
        "Low-RAM browser + internal assistant": "Navegador de baja memoria + asistente interno",
        "General": "General",
        "Language": "Idioma",
        "Homepage": "Página de inicio",
        "Search engine": "Motor de búsqueda",
        "Theme": "Tema",
        "Settings": "Configuración",
        "History": "Historial",
        "Bookmarks": "Marcadores",
        "Downloads": "Descargas",
        "Extensions": "Extensiones",
        "New Tab": "Nueva pestaña",
        "Ready": "Listo",
        "Back": "Atrás",
        "Forward": "Adelante",
        "Reload": "Recargar",
        "Home": "Inicio",
        "Save settings": "Guardar configuración",
        "Cancel": "Cancelar",
        "Speech and voices": "Voz y lectura",
        "Assistant": "Asistente",
        "Browsing and streaming": "Navegación y streaming",
    },
    "tr": {
        "Aster Browser": "Aster Tarayıcı",
        "Low-RAM browser + internal assistant": "Düşük bellek tarayıcı + dahili asistan",
        "General": "Genel",
        "Language": "Dil",
        "Homepage": "Ana sayfa",
        "Search engine": "Arama motoru",
        "Theme": "Tema",
        "Settings": "Ayarlar",
        "History": "Geçmiş",
        "Bookmarks": "Yer imleri",
        "Downloads": "İndirilenler",
        "Extensions": "Eklentiler",
        "New Tab": "Yeni sekme",
        "Ready": "Hazır",
        "Back": "Geri",
        "Forward": "İleri",
        "Reload": "Yenile",
        "Home": "Ana sayfa",
        "Save settings": "Ayarları kaydet",
        "Cancel": "İptal",
        "Speech and voices": "Konuşma ve sesler",
        "Assistant": "Asistan",
        "Browsing and streaming": "Gezinme ve yayın",
    },
    "pt": {
        "Aster Browser": "Navegador Aster",
        "Low-RAM browser + internal assistant": "Navegador leve + assistente interno",
        "General": "Geral",
        "Language": "Idioma",
        "Homepage": "Página inicial",
        "Search engine": "Mecanismo de pesquisa",
        "Theme": "Tema",
        "Settings": "Configurações",
        "History": "Histórico",
        "Bookmarks": "Favoritos",
        "Downloads": "Downloads",
        "Extensions": "Extensões",
        "New Tab": "Nova guia",
        "Ready": "Pronto",
        "Back": "Voltar",
        "Forward": "Avançar",
        "Reload": "Recarregar",
        "Home": "Início",
        "Save settings": "Salvar configurações",
        "Cancel": "Cancelar",
        "Speech and voices": "Fala e vozes",
        "Assistant": "Assistente",
        "Browsing and streaming": "Navegação e streaming",
    },
    "fr": {
        "Aster Browser": "Navigateur Aster",
        "General": "Général",
        "Language": "Langue",
        "Homepage": "Page d’accueil",
        "Search engine": "Moteur de recherche",
        "Theme": "Thème",
        "Settings": "Paramètres",
        "History": "Historique",
        "Bookmarks": "Favoris",
        "Downloads": "Téléchargements",
        "Extensions": "Extensions",
        "New Tab": "Nouvel onglet",
        "Ready": "Prêt",
        "Back": "Retour",
        "Forward": "Avancer",
        "Reload": "Recharger",
        "Home": "Accueil",
        "Save settings": "Enregistrer",
        "Cancel": "Annuler",
        "Speech and voices": "Voix et lecture",
        "Assistant": "Assistant",
        "Browsing and streaming": "Navigation et streaming",
    },
    "de": {
        "General": "Allgemein",
        "Language": "Sprache",
        "Homepage": "Startseite",
        "Search engine": "Suchmaschine",
        "Theme": "Design",
        "Settings": "Einstellungen",
        "History": "Verlauf",
        "Bookmarks": "Lesezeichen",
        "Downloads": "Downloads",
        "Extensions": "Erweiterungen",
        "New Tab": "Neuer Tab",
        "Ready": "Bereit",
        "Back": "Zurück",
        "Forward": "Vorwärts",
        "Reload": "Neu laden",
        "Home": "Startseite",
        "Save settings": "Einstellungen speichern",
        "Cancel": "Abbrechen",
        "Speech and voices": "Sprache und Stimmen",
        "Assistant": "Assistent",
        "Browsing and streaming": "Surfen und Streaming",
    },
    "ar": {
        "General": "عام",
        "Language": "اللغة",
        "Homepage": "الصفحة الرئيسية",
        "Search engine": "محرك البحث",
        "Theme": "السمة",
        "Settings": "الإعدادات",
        "History": "السجل",
        "Bookmarks": "الإشارات المرجعية",
        "Downloads": "التنزيلات",
        "Extensions": "الإضافات",
        "New Tab": "تبويب جديد",
        "Ready": "جاهز",
        "Back": "رجوع",
        "Forward": "تقدم",
        "Reload": "إعادة تحميل",
        "Home": "الرئيسية",
        "Save settings": "حفظ الإعدادات",
        "Cancel": "إلغاء",
        "Speech and voices": "الكلام والأصوات",
        "Assistant": "المساعد",
        "Browsing and streaming": "التصفح والبث",
    },
    "zh": {
        "General": "常规",
        "Language": "语言",
        "Homepage": "主页",
        "Search engine": "搜索引擎",
        "Theme": "主题",
        "Settings": "设置",
        "History": "历史记录",
        "Bookmarks": "书签",
        "Downloads": "下载",
        "Extensions": "扩展",
        "New Tab": "新标签页",
        "Ready": "就绪",
        "Back": "后退",
        "Forward": "前进",
        "Reload": "重新加载",
        "Home": "主页",
        "Save settings": "保存设置",
        "Cancel": "取消",
        "Speech and voices": "语音和朗读",
        "Assistant": "助手",
        "Browsing and streaming": "浏览和流媒体",
    },
    "ja": {
        "General": "一般",
        "Language": "言語",
        "Homepage": "ホームページ",
        "Search engine": "検索エンジン",
        "Theme": "テーマ",
        "Settings": "設定",
        "History": "履歴",
        "Bookmarks": "ブックマーク",
        "Downloads": "ダウンロード",
        "Extensions": "拡張機能",
        "New Tab": "新しいタブ",
        "Ready": "準備完了",
        "Back": "戻る",
        "Forward": "進む",
        "Reload": "再読み込み",
        "Home": "ホーム",
        "Save settings": "設定を保存",
        "Cancel": "キャンセル",
        "Speech and voices": "音声と読み上げ",
        "Assistant": "アシスタント",
        "Browsing and streaming": "ブラウジングとストリーミング",
    },
    "ko": {
        "General": "일반",
        "Language": "언어",
        "Homepage": "홈페이지",
        "Search engine": "검색 엔진",
        "Theme": "테마",
        "Settings": "설정",
        "History": "기록",
        "Bookmarks": "북마크",
        "Downloads": "다운로드",
        "Extensions": "확장 프로그램",
        "New Tab": "새 탭",
        "Ready": "준비됨",
        "Back": "뒤로",
        "Forward": "앞으로",
        "Reload": "새로고침",
        "Home": "홈",
        "Save settings": "설정 저장",
        "Cancel": "취소",
        "Speech and voices": "음성 및 읽기",
        "Assistant": "도우미",
        "Browsing and streaming": "탐색 및 스트리밍",
    },
}


def normalize_language_code(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw or raw.lower() in {"system", "auto", "default"}:
        return "system"
    raw = raw.replace("_", "-")
    if not _BCP47_RE.match(raw):
        return "system"
    parts = raw.split("-")
    normalized: list[str] = []
    for index, part in enumerate(parts):
        if index == 0:
            normalized.append(part.lower())
        elif len(part) == 2 and part.isalpha():
            normalized.append(part.upper())
        elif len(part) == 4 and part.isalpha():
            normalized.append(part.title())
        else:
            normalized.append(part)
    return "-".join(normalized)


def _locale_from_environment() -> str:
    candidates = [os.environ.get("LANGUAGE", ""), os.environ.get("LC_ALL", ""), os.environ.get("LC_MESSAGES", ""), os.environ.get("LANG", "")]
    loc = ""
    try:
        loc = locale.getlocale()[0] or ""
    except Exception:
        loc = ""
    candidates.append(loc)
    for raw in candidates:
        if not raw:
            continue
        code = raw.split(":", 1)[0].split(".", 1)[0]
        normalized = normalize_language_code(code)
        if normalized != "system":
            return normalized
    return "en-US"


@lru_cache(maxsize=64)
def accept_language_for(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        code = _locale_from_environment()
    primary = code.split("-", 1)[0]
    if primary and primary.lower() != code.lower():
        return f"{code},{primary};q=0.9,en;q=0.7"
    return f"{code},en;q=0.7"


def language_label(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        return "System default"
    return _LANGUAGE_LABELS.get(code.lower(), code)


def language_choices() -> list[tuple[str, str]]:
    return list(SUPPORTED_LANGUAGE_CHOICES)


def translation_family(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        code = _locale_from_environment()
    return code.split("-", 1)[0].lower()


def tr(text: str, language_code: str | None = None) -> str:
    family = translation_family(language_code)
    return _TRANSLATIONS.get(family, {}).get(text, text)
