from __future__ import annotations

import locale
import os
import re
from functools import lru_cache

from .translations import INTERFACE_LANGUAGE_CHOICES, TRANSLATED_FAMILIES, TRANSLATIONS

_BCP47_RE = re.compile(r"^[A-Za-z]{2,3}(?:[-_][A-Za-z0-9]{2,8})*$")

# Content language sent to websites through Accept-Language. The combobox is
# editable, so any valid BCP-47 language tag such as es-MX, pt-BR, ar-SA, hi-IN,
# or zh-Hant can also be typed.
SUPPORTED_LANGUAGE_CHOICES: list[tuple[str, str]] = [
    ("system", "System default"),
    ("en-US", "English (United States)"),
    ("en-GB", "English (United Kingdom)"),
    ("es-ES", "Español (España)"),
    ("es-MX", "Español (México)"),
    ("es-US", "Español (Estados Unidos)"),
    ("pt-BR", "Português (Brasil)"),
    ("pt-PT", "Português (Portugal)"),
    ("fr-FR", "Français (France)"),
    ("fr-CA", "Français (Canada)"),
    ("de-DE", "Deutsch"),
    ("it-IT", "Italiano"),
    ("nl-NL", "Nederlands"),
    ("sv-SE", "Svenska"),
    ("da-DK", "Dansk"),
    ("no-NO", "Norsk"),
    ("fi-FI", "Suomi"),
    ("is-IS", "Íslenska"),
    ("pl-PL", "Polski"),
    ("cs-CZ", "Čeština"),
    ("sk-SK", "Slovenčina"),
    ("sl-SI", "Slovenščina"),
    ("hr-HR", "Hrvatski"),
    ("sr-RS", "Srpski"),
    ("bs-BA", "Bosanski"),
    ("ro-RO", "Română"),
    ("hu-HU", "Magyar"),
    ("el-GR", "Ελληνικά"),
    ("tr-TR", "Türkçe"),
    ("ru-RU", "Русский"),
    ("uk-UA", "Українська"),
    ("bg-BG", "Български"),
    ("he-IL", "עברית"),
    ("ar-SA", "العربية"),
    ("fa-IR", "فارسی"),
    ("ur-PK", "اردو"),
    ("hi-IN", "हिन्दी"),
    ("bn-BD", "বাংলা"),
    ("pa-IN", "ਪੰਜਾਬੀ"),
    ("gu-IN", "ગુજરાતી"),
    ("ta-IN", "தமிழ்"),
    ("te-IN", "తెలుగు"),
    ("kn-IN", "ಕನ್ನಡ"),
    ("ml-IN", "മലയാളം"),
    ("mr-IN", "मराठी"),
    ("si-LK", "සිංහල"),
    ("th-TH", "ไทย"),
    ("vi-VN", "Tiếng Việt"),
    ("id-ID", "Bahasa Indonesia"),
    ("ms-MY", "Bahasa Melayu"),
    ("fil-PH", "Filipino"),
    ("zh-CN", "简体中文"),
    ("zh-TW", "繁體中文（台灣）"),
    ("zh-HK", "繁體中文（香港）"),
    ("ja-JP", "日本語"),
    ("ko-KR", "한국어"),
    ("sw-KE", "Kiswahili"),
    ("am-ET", "አማርኛ"),
    ("yo-NG", "Yorùbá"),
    ("ig-NG", "Igbo"),
    ("ha-NG", "Hausa"),
    ("zu-ZA", "isiZulu"),
    ("af-ZA", "Afrikaans"),
]

_LANGUAGE_LABELS = {code.lower(): label for code, label in SUPPORTED_LANGUAGE_CHOICES}
_INTERFACE_LABELS = {code.lower(): label for code, label in INTERFACE_LANGUAGE_CHOICES}

# Interface language currently used by tr(). Set from the saved configuration at
# start-up and whenever the user saves a different interface language.
_active_interface_language = "system"


def normalize_language_code(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw or raw.lower() in {"system", "auto", "default"}:
        return "system"
    raw = raw.replace("_", "-")
    if not _BCP47_RE.match(raw):
        return "system"
    parts = raw.split("-")
    normalized: list[str] = []
    for index, part in enumerate(parts):
        if index == 0:
            normalized.append(part.lower())
        elif len(part) == 2 and part.isalpha():
            normalized.append(part.upper())
        elif len(part) == 4 and part.isalpha():
            normalized.append(part.title())
        else:
            normalized.append(part)
    return "-".join(normalized)


def normalize_interface_language(value: str | None) -> str:
    """Clamp an interface language to one Aster actually ships a catalog for."""
    code = normalize_language_code(value)
    if code == "system":
        return "system"
    family = code.split("-", 1)[0].lower()
    if family in TRANSLATED_FAMILIES:
        return family
    return "system"


def _locale_from_environment() -> str:
    candidates = [os.environ.get("LANGUAGE", ""), os.environ.get("LC_ALL", ""), os.environ.get("LC_MESSAGES", ""), os.environ.get("LANG", "")]
    loc = ""
    try:
        loc = locale.getlocale()[0] or ""
    except Exception:
        loc = ""
    candidates.append(loc)
    for raw in candidates:
        if not raw:
            continue
        code = raw.split(":", 1)[0].split(".", 1)[0]
        normalized = normalize_language_code(code)
        if normalized != "system":
            return normalized
    return "en-US"


@lru_cache(maxsize=64)
def accept_language_for(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        code = _locale_from_environment()
    primary = code.split("-", 1)[0]
    if primary and primary.lower() != code.lower():
        return f"{code},{primary};q=0.9,en;q=0.7"
    return f"{code},en;q=0.7"


def language_label(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        return tr("System default")
    return _LANGUAGE_LABELS.get(code.lower(), code)


def language_choices() -> list[tuple[str, str]]:
    return list(SUPPORTED_LANGUAGE_CHOICES)


def interface_language_choices() -> list[tuple[str, str]]:
    """(code, label) pairs for the Settings -> Interface language combobox."""
    return [(code, tr("System default") if code == "system" else label) for code, label in INTERFACE_LANGUAGE_CHOICES]


def interface_language_label(language_code: str | None) -> str:
    code = normalize_interface_language(language_code)
    if code == "system":
        return tr("System default")
    return _INTERFACE_LABELS.get(code, code)


def set_ui_language(language_code: str | None) -> str:
    """Switch the language used by tr() and return the normalized code."""
    global _active_interface_language
    _active_interface_language = normalize_interface_language(language_code)
    return _active_interface_language


def ui_language() -> str:
    """The configured interface language, which may still be "system"."""
    return _active_interface_language


def translation_family(language_code: str | None) -> str:
    code = normalize_language_code(language_code)
    if code == "system":
        code = _locale_from_environment()
    return code.split("-", 1)[0].lower()


def active_translation_family() -> str:
    """The language family tr() translates into right now, never "system"."""
    code = _active_interface_language
    if code == "system":
        family = translation_family("system")
        return family if family in TRANSLATED_FAMILIES else "en"
    return code


def tr(text: str, language_code: str | None = None) -> str:
    """Translate a user interface string.

    With no ``language_code`` the active interface language is used, so call
    sites only need to wrap their literal. Passing a code translates into that
    language instead, which keeps older call sites and tests working.
    """
    if language_code is None:
        family = active_translation_family()
    else:
        family = normalize_interface_language(language_code)
        if family == "system":
            family = translation_family(language_code)
    return TRANSLATIONS.get(family, {}).get(text, text)
