from __future__ import annotations

import os
from pathlib import Path

from .certs import configure_certificate_environment, detect_certificate_environment


def _append_chromium_flag(flag: str) -> None:
    existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
    parts = existing.split()
    if flag not in parts:
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (existing + " " + flag).strip()


def configure_system_trust_environment():
    """Configure safe certificate trust hints without touching the user's NSS DB.

    The v7 installer tried to refresh NSS stores and could trigger repeated
    "NSS Certificate DB" password prompts. This runtime path only points Aster
    and Python helpers at normal distro CA bundles/directories, and asks
    QtWebEngine/Chromium to prefer the system verifier when that flag is
    supported by the bundled Chromium.
    """
    cert_env = configure_certificate_environment()
    if cert_env.ca_file or cert_env.ca_dir:
        _append_chromium_flag("--use-system-cert-verifier")
    return cert_env


def system_ca_bundle() -> Path | None:
    cert_env = detect_certificate_environment()
    if cert_env.ca_file:
        return Path(cert_env.ca_file)
    return None
