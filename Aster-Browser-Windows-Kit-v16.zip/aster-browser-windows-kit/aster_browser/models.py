from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TabSnapshot:
    tab_id: str
    kind: str
    title: str
    url: str
    live: bool
    visible: bool
    pinned: bool
    audible: bool
    last_active: float
    estimated_cost_mb: int


@dataclass
class TabState:
    kind: str
    title: str
    url: str
    container: str = "default"
    tab_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    widget: Any = None
    live: bool = True
    visible: bool = False
    pinned: bool = False
    audible: bool = False
    audio_muted: bool = False
    mobile_mode: bool = False
    compatibility_mode: bool = False
    last_active: float = field(default_factory=time.time)
    estimated_cost_mb: int = 120
    zoom_factor: float = 1.0
    parked_reason: str = ""
    page_text: str = ""
    page_links: list[tuple[str, str]] = field(default_factory=list)
    security_details: dict[str, Any] = field(default_factory=dict)
    security_state: str = ""
    security_note: str = ""
    last_load_ok: bool | None = None
    last_load_error: str = ""

    def snapshot(self) -> TabSnapshot:
        return TabSnapshot(
            tab_id=self.tab_id,
            kind=self.kind,
            title=self.title,
            url=self.url,
            live=self.live,
            visible=self.visible,
            pinned=self.pinned,
            audible=self.audible,
            last_active=self.last_active,
            estimated_cost_mb=self.estimated_cost_mb,
        )
