from __future__ import annotations

import importlib.util
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Sequence

from PyQt6.QtCore import QObject, QThread, QUrl, pyqtSignal

from .config import BrowserConfig
from .paths import ensure_directories, tts_cache_dir, tts_reference_dir, tts_voices_dir


class SpeechCommandWorker(QObject):
    finished = pyqtSignal(str, str)
    failed = pyqtSignal(str)

    def __init__(
        self,
        *,
        mode: str,
        command: Sequence[str] | str,
        output_wav: str,
        cleanup_files: Sequence[str] | None = None,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.mode = mode
        self.command = command
        self.output_wav = output_wav
        self.cleanup_files = [str(item) for item in (cleanup_files or [])]
        self._stop_requested = False
        self._process: subprocess.Popen[str] | None = None

    def request_stop(self) -> None:
        self._stop_requested = True
        process = self._process
        if process is None:
            return
        try:
            if process.poll() is None:
                process.terminate()
        except Exception:
            pass

    def run(self) -> None:
        try:
            if isinstance(self.command, str):
                self._process = subprocess.Popen(
                    self.command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
            else:
                self._process = subprocess.Popen(
                    list(self.command),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
            stdout, stderr = self._process.communicate()
            if self._stop_requested:
                raise RuntimeError("Speech generation cancelled.")
            if self._process.returncode not in {0, None}:
                detail = (stderr or stdout or "unknown error").strip()
                raise RuntimeError(f"{self.mode} synthesis failed: {detail}")
            output_path = Path(self.output_wav)
            if not output_path.exists() or output_path.stat().st_size <= 0:
                detail = (stderr or stdout or "no audio output was produced").strip()
                raise RuntimeError(f"{self.mode} synthesis failed: {detail}")
            message = (stdout or stderr or f"Generated speech with {self.mode}.").strip()
            self.finished.emit(message, str(output_path))
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self._process = None
            for path_text in self.cleanup_files:
                try:
                    Path(path_text).unlink(missing_ok=True)
                except Exception:
                    pass


class SpeechManager(QObject):
    status = pyqtSignal(str)
    voices_changed = pyqtSignal()
    recording_state_changed = pyqtSignal(bool)

    def __init__(self, config: BrowserConfig, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self._qt_tts = None
        self._player = None
        self._audio_output = None
        self._capture_session = None
        self._audio_input = None
        self._recorder = None
        self._worker: SpeechCommandWorker | None = None
        self._worker_thread: QThread | None = None
        ensure_directories()

    def update_config(self, config: BrowserConfig) -> None:
        self.config = config
        self._apply_system_voice_settings()
        self._apply_player_volume()

    def system_tts_available(self) -> bool:
        return self._import_qt_text_to_speech() is not None

    def recording_available(self) -> bool:
        return self._import_qt_multimedia() is not None

    def piper_available(self) -> bool:
        return importlib.util.find_spec("piper") is not None or shutil.which("piper") is not None

    def available_system_voice_names(self) -> list[str]:
        engine = self._ensure_system_tts()
        if engine is None:
            return []
        voices: list[str] = []
        try:
            for voice in engine.availableVoices():
                name_fn = getattr(voice, "name", None)
                name = name_fn() if callable(name_fn) else str(voice)
                clean = str(name or "").strip()
                if clean and clean not in voices:
                    voices.append(clean)
        except Exception:
            return []
        voices.sort(key=str.casefold)
        return voices

    def installed_piper_voice_names(self) -> list[str]:
        ensure_directories()
        root = tts_voices_dir()
        voices: list[str] = []
        for candidate in sorted(root.rglob("*.onnx")):
            try:
                rel = candidate.relative_to(root)
            except Exception:
                rel = candidate
            stem = rel.with_suffix("")
            name = str(stem).replace("\\", "/")
            clean = name.strip()
            if clean and clean not in voices:
                voices.append(clean)
        return voices

    def current_reference_audio_path(self) -> str:
        configured = str(getattr(self.config, "tts_reference_audio_path", "") or "").strip()
        if configured and Path(configured).exists():
            return configured
        for candidate in sorted(tts_reference_dir().glob("*")):
            if candidate.is_file():
                path_text = str(candidate)
                self.config.tts_reference_audio_path = path_text
                return path_text
        return ""

    def install_piper_voice(self, voice_name: str) -> str:
        cleaned = str(voice_name or "").strip()
        if not cleaned:
            return "Enter a Piper voice name, for example en_US-lessac-medium."
        if not self.piper_available():
            return "Piper is not installed yet. Install dependencies first, then try again."
        ensure_directories()
        command = [sys.executable, "-m", "piper.download_voices", "--data-dir", str(tts_voices_dir()), cleaned]
        try:
            completed = subprocess.run(command, capture_output=True, text=True, check=False)
        except Exception as exc:
            return f"Voice download failed: {exc}"
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "unknown error").strip()
            return f"Voice download failed: {detail}"
        self.voices_changed.emit()
        return (completed.stdout or completed.stderr or f"Installed Piper voice: {cleaned}").strip()

    def remove_piper_voice(self, voice_name: str) -> str:
        cleaned = str(voice_name or "").strip()
        if not cleaned:
            return "Choose a Piper voice to remove."
        root = tts_voices_dir()
        removed = 0
        patterns = [
            f"{cleaned}*",
            f"{cleaned}.onnx",
            f"{cleaned}.onnx.json",
            f"{cleaned}.json",
        ]
        seen: set[Path] = set()
        for pattern in patterns:
            for candidate in root.rglob(pattern):
                if candidate in seen:
                    continue
                seen.add(candidate)
                try:
                    if candidate.is_file():
                        candidate.unlink(missing_ok=True)
                        removed += 1
                except Exception:
                    continue
        for candidate in sorted(root.rglob("*"), reverse=True):
            try:
                if candidate.is_dir() and not any(candidate.iterdir()):
                    candidate.rmdir()
            except Exception:
                pass
        self.voices_changed.emit()
        if removed:
            return f"Removed Piper voice files for {cleaned}."
        return f"No installed Piper voice files matched {cleaned}."

    def import_reference_audio(self, source_path: str) -> str:
        source = Path(str(source_path or "").strip())
        if not source.exists() or not source.is_file():
            return "Choose a valid local audio file first."
        ensure_directories()
        suffix = source.suffix or ".wav"
        target = tts_reference_dir() / f"reference-sample{suffix}"
        try:
            shutil.copy2(source, target)
        except Exception as exc:
            return f"Could not import the reference audio: {exc}"
        self.config.tts_reference_audio_path = str(target)
        self.voices_changed.emit()
        return f"Imported reference audio: {target.name}"

    def clear_reference_audio(self) -> str:
        current = self.current_reference_audio_path()
        if current:
            try:
                Path(current).unlink(missing_ok=True)
            except Exception as exc:
                return f"Could not delete the reference audio: {exc}"
        self.config.tts_reference_audio_path = ""
        self.voices_changed.emit()
        return "Removed the saved reference audio sample."

    def start_reference_recording(self) -> str:
        multimedia = self._import_qt_multimedia()
        if multimedia is None:
            return "Qt Multimedia recording is not available in this build."
        if self._recorder is not None:
            return "Reference recording is already running."
        QAudioInput, QMediaCaptureSession, QMediaRecorder = multimedia
        ensure_directories()
        target = tts_reference_dir() / f"reference-recording-{int(time.time())}.wav"
        try:
            self._capture_session = QMediaCaptureSession()
            self._audio_input = QAudioInput(self)
            self._recorder = QMediaRecorder(self)
            self._capture_session.setAudioInput(self._audio_input)
            self._capture_session.setRecorder(self._recorder)
            self._recorder.setOutputLocation(QUrl.fromLocalFile(str(target)))
            self._recorder.record()
        except Exception as exc:
            self._capture_session = None
            self._audio_input = None
            self._recorder = None
            return f"Could not start recording: {exc}"
        self.config.tts_reference_audio_path = str(target)
        self.recording_state_changed.emit(True)
        self.voices_changed.emit()
        return f"Recording reference audio to {target.name}… Use Stop recording when you are done."

    def stop_reference_recording(self) -> str:
        recorder = self._recorder
        if recorder is None:
            return "Reference recording is not running."
        try:
            recorder.stop()
        except Exception as exc:
            return f"Could not stop recording: {exc}"
        finally:
            self._capture_session = None
            self._audio_input = None
            self._recorder = None
            self.recording_state_changed.emit(False)
            self.voices_changed.emit()
        return "Stopped recording the reference audio sample."

    def speak_text(self, text: str, *, override_engine: str | None = None) -> str:
        payload = str(text or "").strip()
        if not payload:
            return "There is no text to read aloud."
        engine = str(override_engine or getattr(self.config, "tts_engine", "system") or "system").strip().lower()
        if engine == "off":
            return "Text to speech is disabled in settings."
        if engine == "system":
            return self._speak_with_system_tts(payload)
        if engine == "piper":
            return self._speak_with_piper(payload)
        if engine == "custom_command":
            return self._speak_with_custom_command(payload)
        return f"Unknown TTS engine: {engine}"

    def stop(self) -> str:
        messages: list[str] = []
        worker = self._worker
        if worker is not None:
            worker.request_stop()
            messages.append("Stopped pending speech generation.")
        engine = self._qt_tts
        if engine is not None:
            try:
                engine.stop()
                messages.append("Stopped system speech.")
            except Exception:
                pass
        player = self._player
        if player is not None:
            try:
                player.stop()
                messages.append("Stopped audio playback.")
            except Exception:
                pass
        return " ".join(messages).strip() or "Speech stopped."

    def _speak_with_system_tts(self, text: str) -> str:
        engine = self._ensure_system_tts()
        if engine is None:
            return "Qt Text-to-Speech is not available in this build."
        try:
            self.stop()
        except Exception:
            pass
        self._apply_system_voice_settings()
        try:
            engine.say(text)
        except Exception as exc:
            return f"System speech failed: {exc}"
        return "Reading aloud with the system voice."

    def _speak_with_piper(self, text: str) -> str:
        if not self.piper_available():
            return "Piper is not installed yet. Install dependencies first, then download a voice."
        voice_name = str(getattr(self.config, "tts_piper_voice_name", "") or "").strip()
        if not voice_name:
            installed = self.installed_piper_voice_names()
            voice_name = installed[0] if installed else ""
        if not voice_name:
            return "No Piper voice is configured yet. Install a Piper voice first."
        output_wav = tts_cache_dir() / f"speech-{uuid.uuid4().hex}.wav"
        command = [
            sys.executable,
            "-m",
            "piper",
            "--data-dir",
            str(tts_voices_dir()),
            "-m",
            voice_name,
            "-f",
            str(output_wav),
            "--",
            text,
        ]
        return self._start_worker(mode="Piper", command=command, output_wav=output_wav)

    def _speak_with_custom_command(self, text: str) -> str:
        template = str(getattr(self.config, "tts_custom_command", "") or "").strip()
        if not template:
            return "Add a custom TTS command in settings first."
        ensure_directories()
        output_wav = tts_cache_dir() / f"speech-{uuid.uuid4().hex}.wav"
        text_file = tts_cache_dir() / f"speech-{uuid.uuid4().hex}.txt"
        try:
            text_file.write_text(text, encoding="utf-8")
        except Exception as exc:
            return f"Could not create the temporary text file: {exc}"
        reference_audio = self.current_reference_audio_path()
        try:
            rendered = template.format(
                text=text,
                text_file=str(text_file),
                output_wav=str(output_wav),
                reference_audio=reference_audio,
                voices_dir=str(tts_voices_dir()),
                cache_dir=str(tts_cache_dir()),
            )
        except Exception as exc:
            return f"The custom TTS command could not be formatted: {exc}"
        return self._start_worker(
            mode="Custom TTS",
            command=rendered,
            output_wav=output_wav,
            cleanup_files=[str(text_file)],
        )

    def _start_worker(
        self,
        *,
        mode: str,
        command: Sequence[str] | str,
        output_wav: Path,
        cleanup_files: Sequence[str] | None = None,
    ) -> str:
        self.stop()
        self._cleanup_worker()
        worker = SpeechCommandWorker(mode=mode, command=command, output_wav=str(output_wav), cleanup_files=cleanup_files)
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(self._on_worker_finished)
        worker.failed.connect(self._on_worker_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        thread.finished.connect(self._cleanup_worker)
        self._worker = worker
        self._worker_thread = thread
        thread.start()
        self.status.emit(f"Generating speech with {mode}…")
        return f"Generating speech with {mode}…"

    def _on_worker_finished(self, status_text: str, wav_path: str) -> None:
        self._cleanup_worker()
        played = self._play_audio_file(Path(wav_path))
        detail = status_text.strip() or "Speech generated."
        if played:
            self.status.emit(detail)
        else:
            self.status.emit(detail + " Saved the output file, but playback could not start.")

    def _on_worker_failed(self, message: str) -> None:
        self._cleanup_worker()
        self.status.emit(message or "Speech generation failed.")

    def _cleanup_worker(self) -> None:
        self._worker = None
        thread = self._worker_thread
        if thread is not None:
            self._worker_thread = None
            try:
                if thread.isRunning():
                    thread.quit()
                    thread.wait(1500)
            except Exception:
                pass
            try:
                thread.deleteLater()
            except Exception:
                pass

    def _play_audio_file(self, path: Path) -> bool:
        multimedia = self._import_qt_player()
        if multimedia is None:
            return False
        QAudioOutput, QMediaPlayer = multimedia
        try:
            if self._audio_output is None:
                self._audio_output = QAudioOutput(self)
            if self._player is None:
                self._player = QMediaPlayer(self)
                self._player.setAudioOutput(self._audio_output)
            self._apply_player_volume()
            self._player.setSource(QUrl.fromLocalFile(str(path)))
            self._player.play()
            return True
        except Exception:
            return False

    def _apply_player_volume(self) -> None:
        if self._audio_output is None:
            return
        try:
            volume = max(0.0, min(1.0, float(getattr(self.config, "tts_volume_percent", 100) or 100) / 100.0))
            self._audio_output.setVolume(volume)
        except Exception:
            pass

    def _ensure_system_tts(self):
        if self._qt_tts is not None:
            return self._qt_tts
        qt_text_to_speech = self._import_qt_text_to_speech()
        if qt_text_to_speech is None:
            return None
        try:
            self._qt_tts = qt_text_to_speech(self)
        except Exception:
            return None
        self._apply_system_voice_settings()
        return self._qt_tts

    def _apply_system_voice_settings(self) -> None:
        engine = self._qt_tts
        if engine is None:
            return
        try:
            engine.setRate(max(-1.0, min(1.0, float(getattr(self.config, "tts_rate_percent", 0) or 0) / 100.0)))
        except Exception:
            pass
        try:
            engine.setVolume(max(0.0, min(1.0, float(getattr(self.config, "tts_volume_percent", 100) or 100) / 100.0)))
        except Exception:
            pass
        try:
            pitch_percent = float(getattr(self.config, "tts_pitch_percent", 100) or 100)
            engine.setPitch(max(-1.0, min(1.0, (pitch_percent - 100.0) / 100.0)))
        except Exception:
            pass
        chosen_name = str(getattr(self.config, "tts_system_voice_name", "") or "").strip().lower()
        if not chosen_name:
            return
        try:
            for voice in engine.availableVoices():
                name_fn = getattr(voice, "name", None)
                voice_name = name_fn() if callable(name_fn) else str(voice)
                if str(voice_name or "").strip().lower() == chosen_name:
                    engine.setVoice(voice)
                    break
        except Exception:
            pass

    def _import_qt_text_to_speech(self):
        try:
            from PyQt6.QtTextToSpeech import QTextToSpeech
        except Exception:
            return None
        return QTextToSpeech

    def _import_qt_multimedia(self):
        try:
            from PyQt6.QtMultimedia import QAudioInput, QMediaCaptureSession, QMediaRecorder
        except Exception:
            return None
        return QAudioInput, QMediaCaptureSession, QMediaRecorder

    def _import_qt_player(self):
        try:
            from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer
        except Exception:
            return None
        return QAudioOutput, QMediaPlayer
