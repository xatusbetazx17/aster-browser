from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .ai import AIContext
from .local_index import BookmarkResult, IndexSearchResult, LocalIndex, default_index_roots

TEXT_EXTENSIONS = {
    '.txt', '.md', '.markdown', '.rst', '.log', '.json', '.yaml', '.yml', '.ini', '.conf', '.cfg',
    '.csv', '.tsv', '.html', '.htm', '.xml', '.py', '.js', '.ts', '.tsx', '.jsx', '.css', '.scss',
    '.java', '.c', '.cpp', '.h', '.hpp', '.rs', '.go', '.rb', '.php', '.sh', '.zsh', '.fish', '.sql',
}


@dataclass
class DocumentMatch:
    path: Path
    score: float
    snippet: str = ''


def _normalize_whitespace(text: str) -> str:
    return ' '.join((text or '').split())


def _tokenize(text: str) -> list[str]:
    cleaned = ''.join(ch.lower() if ch.isalnum() else ' ' for ch in text)
    return [part for part in cleaned.split() if len(part) >= 2]


def _split_sentences(text: str) -> list[str]:
    chunks = re.split(r'(?<=[.!?])\s+|\n+', text)
    cleaned: list[str] = []
    for chunk in chunks:
        sentence = _normalize_whitespace(chunk)
        if len(sentence) >= 18:
            cleaned.append(sentence)
    return cleaned


def _top_sentences(text: str, *, query: str = '', limit: int = 4) -> list[str]:
    sentences = _split_sentences(text)
    if not sentences:
        fallback = _normalize_whitespace(text)
        return [fallback[:220]] if fallback else []
    query_terms = _tokenize(query) if query else []
    scores: list[tuple[float, int, str]] = []
    word_counts = [_tokenize(sentence) for sentence in sentences]
    df: dict[str, int] = {}
    for words in word_counts:
        for token in set(words):
            df[token] = df.get(token, 0) + 1
    total_docs = max(1, len(sentences))
    for idx, sentence in enumerate(sentences):
        words = word_counts[idx]
        if not words:
            continue
        score = 0.0
        for token in set(words):
            tf = words.count(token) / max(1, len(words))
            idf = math.log((1 + total_docs) / (1 + df.get(token, 0))) + 1.0
            score += tf * idf
        if query_terms:
            query_hits = sum(2.5 for term in query_terms if term in words)
            score += query_hits
        if idx == 0:
            score += 0.75
        scores.append((-score, idx, sentence))
    top = sorted(scores, key=lambda item: (item[0], item[1]))[: max(limit * 2, limit)]
    ordered = sorted(top, key=lambda item: item[1])[:limit]
    return [sentence for _score, _idx, sentence in ordered]


def summarize_text(text: str, *, title: str = '', query: str = '', limit: int = 4) -> str:
    cleaned = _normalize_whitespace(text)
    if not cleaned:
        return 'I could not find enough text to summarize locally.'
    lines: list[str] = []
    if title:
        lines.append(f'Title: {title}')
    heading = 'Local summary'
    if query:
        heading = f'Local answer for: {query}'
    lines.append(f'{heading}:')
    for sentence in _top_sentences(cleaned, query=query, limit=limit):
        lines.append(f'- {sentence}')
    return '\n'.join(lines)


def answer_from_text(question: str, text: str, *, title: str = '', limit: int = 4) -> str:
    query_terms = _tokenize(question)
    if not query_terms:
        return summarize_text(text, title=title, limit=limit)
    sentences = _top_sentences(text, query=question, limit=limit)
    if not sentences:
        return 'I could not find a useful local answer in the current page text.'
    return summarize_text(' '.join(sentences), title=title, query=question, limit=min(limit, len(sentences)))


def compare_texts(current_title: str, current_text: str, other_title: str, other_text: str) -> str:
    current_sentences = _top_sentences(current_text, limit=3)
    other_sentences = _top_sentences(other_text, limit=3)
    if not current_sentences or not other_sentences:
        return 'I do not have enough text from both tabs to compare them locally.'
    lines = [
        f'Comparing "{current_title or "Current tab"}" with "{other_title or "Previous tab"}":',
        '',
        f'{current_title or "Current tab"}:',
    ]
    lines.extend(f'- {sentence}' for sentence in current_sentences)
    lines.append('')
    lines.append(f'{other_title or "Previous tab"}:')
    lines.extend(f'- {sentence}' for sentence in other_sentences)
    return '\n'.join(lines)


def _supports_text_preview(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTENSIONS


def _read_preview(path: Path, *, max_bytes: int = 250_000) -> str:
    try:
        return path.read_text(encoding='utf-8', errors='replace')[:max_bytes]
    except Exception:
        return ''


def _extract_query_after_keywords(prompt: str, keywords: Iterable[str]) -> str:
    lowered = prompt.lower()
    best = prompt.strip()
    for keyword in keywords:
        marker = f'{keyword} '
        idx = lowered.find(marker)
        if idx >= 0:
            best = prompt[idx + len(marker):].strip()
    best = re.sub(r'^(?:about|for|named|called)\s+', '', best, flags=re.I)
    return best.strip(' .')


class LocalAssistant:
    def __init__(self, index: LocalIndex | None = None, persona: str = "dr_light_lab", reasoning_mode: str = "balanced") -> None:
        self.max_files = int(os.environ.get('ASTER_INTERNAL_AI_MAX_FILES', '1200') or '1200')
        self.index = index or LocalIndex()
        self.persona = (persona or "dr_light_lab").strip().lower()
        self.reasoning_mode = (reasoning_mode or "balanced").strip().lower()

    def ask(self, prompt: str, context: AIContext) -> str:
        normalized = _normalize_whitespace(prompt)
        lowered = normalized.lower()
        if not normalized:
            return self.help_text()

        if lowered in {'help', 'what can you do', 'what do you do'} or 'what can you do' in lowered:
            return self.help_text()

        if self._is_risky_action(lowered):
            return (
                'That request looks like a risky action. The internal assistant can read the current page, search your local documents, '
                'compare tabs, organize tabs, list page links, work with bookmarks, and open safe destinations, but it will not automatically '
                'submit forms, log in, send messages, delete files, or make purchases without an explicit confirmation flow.'
            )

        if self._is_bookmark_query(lowered):
            query = self._bookmark_query(normalized)
            return self.search_bookmarks(query)

        if self._is_history_query(lowered):
            query = self._history_query(normalized)
            return self.search_history(query)

        if self._is_pdf_query(lowered):
            query = self._document_query(normalized)
            return self.search_documents(query, pdf_only=True)

        if self._is_doc_query(lowered):
            query = self._document_query(normalized)
            return self.search_documents(query)

        if self._is_path_summary_request(normalized):
            path = self._extract_path(normalized)
            if path:
                return self.summarize_file(Path(path))

        if self._is_compare_request(lowered) and context.previous_page_text.strip():
            return compare_texts(context.title, context.page_text, context.previous_title, context.previous_page_text)

        if self._is_link_request(lowered):
            return self.list_page_links(context)

        if self._is_selection_summary_request(lowered) and context.selected_text.strip():
            return self.summarize_selection(context)

        if self._is_page_summary_request(lowered):
            return self.summarize_page(context)

        if self._is_page_question(lowered):
            if context.page_text.strip():
                return answer_from_text(normalized, context.page_text, title=context.title)
            return self.general_engineer_response(normalized, context)

        if context.page_text.strip():
            return answer_from_text(normalized, context.page_text, title=context.title)

        return self.general_engineer_response(normalized, context)

    def help_text(self) -> str:
        return (
            'Aster internal assistant is running locally in Dr. Light Lab engineer-mentor mode with no external model service. '
            'I can summarize the current page or selected text, answer questions from the current page text, compare the current tab with the previous tab, '
            'list top links on the page, search common document folders like Documents, Downloads, Desktop, and Aster downloads, '
            'search your recent browsing history, search saved bookmarks, and summarize supported local text files. '
            'Engineer-mentor mode can also give structured troubleshooting steps for browser, Linux, networking, coding, and hardware questions. '
            'With AI actions enabled, Aster can list tabs, switch tabs, bookmark the current page, open page links, reload or go back, open local documents, and park background tabs. '
            'It still avoids destructive, login, financial, or privacy-sensitive actions without a confirmation flow.'
        )

    def _adaptive_header(self, prompt: str, context: AIContext | None = None) -> list[str]:
        lines = [f'Adaptive engineer-mentor answer ({self.persona}, {self.reasoning_mode}):']
        lines.append('- Goal: understand the symptom, protect the user, make the smallest safe change, then verify it.')
        if context and context.url:
            lines.append(f'- Current context URL: {context.url}')
        if context and context.title:
            lines.append(f'- Current page title: {context.title}')
        return lines

    def _diagnosis_template(self, observation: str, likely_cause: str, fix: str, verify: str, rollback: str = '') -> list[str]:
        lines = [
            f'- Observation: {observation}',
            f'- Likely cause: {likely_cause}',
            f'- Safe fix: {fix}',
            f'- Verify: {verify}',
        ]
        if rollback:
            lines.append(f'- Rollback: {rollback}')
        return lines

    def general_engineer_response(self, prompt: str, context: AIContext | None = None) -> str:
        lowered = prompt.lower()
        lines = self._adaptive_header(prompt, context)
        if any(token in lowered for token in ['https', 'certificate', 'ssl', 'tls', 'not secure', 'secure connection']):
            lines.extend(self._diagnosis_template(
                'A page can be valid HTTPS in OpenSSL but still show an Aster/Qt warning because of stale profile state, mixed HTTP resources, proxy/VPN interception, or renderer compatibility.',
                'Do not assume the site is unsafe when the main certificate probe says OK; separate main-frame certificate errors from subresource warnings and mixed-content warnings.',
                'Run Tools → Diagnose current page security. If the main certificate verifies, run Tools → Clear Aster web security/cache state, restart Aster, and reload the URL. Keep ca-certificates, libnss3, and p11-kit installed.',
                'The security label should say HTTPS secure, HTTPS mixed, HTTPS caution, or HTTPS warning with a reason instead of a vague “not secure”.',
                'Restore the old Aster profile folder if you intentionally needed old cookies/session state.'
            ))
            lines.append('- Safety rule: never use a global --ignore-certificate-errors flag for normal browsing.')
        elif any(token in lowered for token in ['custom', 'theme', 'vivaldi', 'tabs', 'toolbar', 'layout']):
            lines.extend(self._diagnosis_template(
                'Users want the browser to adapt to their workflow instead of forcing one layout.',
                'Customization needs layers: visual theme, tab position, toolbar position, density, page CSS, status/security UI, shortcuts, containers, and per-site behavior.',
                'Store preferences in the user config, apply reversible UI changes immediately, and keep reset buttons for experiments.',
                'Change tab position/density/accent/custom CSS, restart only when the setting requires it, then confirm the layout is stable on small and large screens.'
            ))
            lines.append('- Aster can follow the Vivaldi idea of deep customization without copying Vivaldi: modular panels, tab layout choices, custom page CSS, and workflow profiles.')
        elif any(token in lowered for token in ['ai', 'assistant', 'smart', 'agent', 'model', 'dr light', 'dr. light']):
            lines.extend(self._diagnosis_template(
                'A helpful browser AI needs context, memory boundaries, tool safety, and verification, not just a bigger personality prompt.',
                'The best safe design is an original “Adaptive Inventor Mentor” mode: page-aware, tab-aware, document-aware, and cautious before risky actions.',
                'Use current page text, selected text, bookmarks, history, open tabs, local documents, diagnostics, user settings, parked-tab/session state, and adblock/HTTPS/runtime settings as context. Answer with goal → evidence → diagnosis → safe fix → verify → rollback.',
                'Ask it to troubleshoot a terminal error, summarize a page, compare tabs, find a document, tune adblock rules, explain a browser warning, or design a browser workflow; it should state the evidence it used.',
                'Disable AI actions or reset memory/settings if it behaves in a way the user does not want.'
            ))
            lines.append('- Note: this is Dr. Light-inspired engineering mentorship, not a clone of a copyrighted fictional character and not a guarantee of superhuman intelligence.')
        elif any(token in lowered for token in ['streaming', 'netflix', 'prime video', 'widevine', 'chromium', 'cef', 'qt webengine', 'compatibility capsule']):
            lines.extend(self._diagnosis_template(
                'Modern sites can require a Chromium-family runtime even when the user does not want system Chromium installed.',
                'Aster should use its bundled PyQt6-WebEngine/Qt WebEngine runtime for compatibility tabs, keep profiles isolated, and avoid external browser fallback unless the user chooses it.',
                'Use DRM mode qtwebengine_capsule for special pages; keep normal pages in regular Aster tabs; keep adblock streaming allowlist on so video CDNs are not broken.',
                'Open the streaming page; if the page loads but playback fails, check Widevine/proprietary codec availability rather than disabling HTTPS or adblock globally.',
                'Switch DRM mode back to internal_preferred or external_only only if the user specifically wants external fallback.'
            ))
        elif any(token in lowered for token in ['adblock', 'ads', 'tracker', 'allowlist', 'blocklist', 'filters']):
            lines.extend(self._diagnosis_template(
                'A good adblocker must be personalizable because strict rules can break logins, streaming CDNs, downloads, and checkout pages.',
                'The safest design is layered: mode off/balanced/strict/custom, allow hosts, block hosts, custom rules, and a streaming/CDN protection allowlist.',
                'Put trusted video/CDN domains in allow hosts, put recurring tracker/ad domains in block hosts, and add custom rules only when a page proves the need.',
                'Reload the page and check whether content, login, video, and downloads still work.',
                'Turn mode back to balanced or clear the custom rule that broke the page.'
            ))
        elif any(token in lowered for token in ['park', 'parked tab', 'camel', 'save tab', 'ram']):
            lines.extend(self._diagnosis_template(
                'Parking is meant to save RAM while preserving the page address for later.',
                'A parked tab should not auto-unpark just because the user clicks it; it should remain a lightweight widget until the user explicitly restores it.',
                'Use Park Current Tab for manual parking or Auto-park for background memory pressure; parked tabs persist in parked_tabs.json and show a camel animation only while visible.',
                'Close and reopen Aster; the parked tab should still appear parked and the full web engine should not run until Unpark / restore is clicked.',
                'Disable parked-tab persistence or camel animation in Settings if the workflow is not desired.'
            ))
        elif any(token in lowered for token in ['linux', 'package', 'install', 'error', 'terminal', 'python', 'flatpak']):
            lines.extend(self._diagnosis_template(
                'Terminal failures usually have one first real error line that explains the rest.',
                'Common causes are missing distro dependencies, read-only Flatpak SDK paths, stale venv packages, wrong Python runtime, or sandbox environment variables.',
                'Copy the first error line, check whether it is system-package, venv, Flatpak, or app-code related, then patch the smallest layer.',
                'Re-run the same command, then run the app launcher and a diagnostic command so the fix is proven.'
            ))
        else:
            lines.extend([
                '- I do not have live web access from the internal assistant, but I can reason from the current page, selected text, local files, bookmarks, history, open tabs, and your prompt.',
                '- Method: define the goal, list evidence, identify the most likely cause, make a reversible fix, verify, then improve the design.',
                '- Useful prompts: summarize this page, compare this tab with the previous tab, find local documents about a topic, diagnose this terminal error, or design a safe customization/AI workflow.',
            ])
        return "\n".join(lines)

    def summarize_page(self, context: AIContext) -> str:
        source_text = context.selected_text.strip() or context.page_text.strip()
        if not source_text:
            return 'I could not capture enough readable text from this page to summarize locally.'
        title = context.title
        if context.selected_text.strip():
            title = f'{title} (selection)' if title else 'Selected text'
        result = summarize_text(source_text, title=title)
        if context.url:
            result += f'\nSource: {context.url}'
        return result

    def summarize_selection(self, context: AIContext) -> str:
        if not context.selected_text.strip():
            return 'I could not find any selected text on the current page.'
        result = summarize_text(context.selected_text, title=f'{context.title or "Current page"} (selection)')
        if context.url:
            result += f'\nSource: {context.url}'
        return result

    def list_page_links(self, context: AIContext, *, limit: int = 12) -> str:
        links = [(label.strip() or href, href) for label, href in context.page_links if href][:limit]
        if not links:
            return 'I could not find any readable page links in the current context.'
        lines = ['Top links from the current page:']
        for index, (label, href) in enumerate(links, start=1):
            shown = _normalize_whitespace(label)[:90] or href
            lines.append(f'{index}. {shown} -> {href}')
        return '\n'.join(lines)

    def _document_query(self, prompt: str) -> str:
        query = _extract_query_after_keywords(
            prompt,
            ['documents for', 'documents about', 'document for', 'document about', 'downloads for', 'downloads about', 'files for', 'files about', 'file named', 'file called', 'file for', 'notes about', 'resume', 'cv', 'pdfs about', 'pdfs for']
        )
        return query or prompt

    def _history_query(self, prompt: str) -> str:
        query = _extract_query_after_keywords(prompt, ['history for', 'history about', 'visited', 'browse history', 'recent pages about'])
        return query or prompt

    def _bookmark_query(self, prompt: str) -> str:
        query = _extract_query_after_keywords(prompt, ['bookmarks for', 'bookmarks about', 'bookmark for', 'bookmark about', 'saved pages for', 'saved pages about'])
        return query or prompt

    def _search_roots(self) -> list[Path]:
        return default_index_roots()

    def document_matches(self, query: str, *, limit: int = 6, pdf_only: bool = False) -> list[IndexSearchResult]:
        query = _normalize_whitespace(query)
        if not query:
            return []
        self.index.maybe_sync_roots(self._search_roots(), max_files=self.max_files)
        return self.index.search_documents(query, limit=limit, pdf_only=pdf_only)

    def search_documents(self, query: str, *, limit: int = 6, pdf_only: bool = False) -> str:
        query = _normalize_whitespace(query)
        if not query:
            return 'Tell me what document or topic to look for, for example: find documents about router firmware.'
        matches = self.document_matches(query, limit=limit, pdf_only=pdf_only)
        if not matches:
            searched = ', '.join(str(path) for path in self._search_roots()) or 'no configured folders'
            prefix = 'PDF matches' if pdf_only else 'document matches'
            return f'No local {prefix} found for "{query}" in: {searched}'
        heading = f'Local PDF matches for "{query}":' if pdf_only else f'Local document matches for "{query}":'
        lines = [heading]
        for idx, match in enumerate(matches, start=1):
            lines.append(f'{idx}. {match.path}')
            if match.snippet:
                lines.append(f'   {match.snippet}')
        return '\n'.join(lines)

    def search_history(self, query: str, *, limit: int = 8) -> str:
        query = _normalize_whitespace(query)
        if not query:
            return 'Tell me what to look for in your recent browsing history.'
        matches = self.index.search_history(query, limit=limit)
        if not matches:
            return f'No recent Aster history matches found for "{query}".'
        lines = [f'Recent history matches for "{query}":']
        for idx, match in enumerate(matches, start=1):
            title = _normalize_whitespace(match.title) or match.url
            lines.append(f'{idx}. {title} -> {match.url}')
        return '\n'.join(lines)

    def bookmark_matches(self, query: str, *, limit: int = 8) -> list[BookmarkResult]:
        query = _normalize_whitespace(query)
        return self.index.search_bookmarks(query, limit=limit)

    def search_bookmarks(self, query: str, *, limit: int = 8) -> str:
        query = _normalize_whitespace(query)
        matches = self.index.search_bookmarks(query, limit=limit)
        if not matches:
            if query:
                return f'No saved bookmarks found for "{query}".'
            return 'No saved bookmarks yet.'
        heading = f'Saved bookmarks for "{query}":' if query else 'Saved bookmarks:'
        lines = [heading]
        for idx, match in enumerate(matches, start=1):
            title = _normalize_whitespace(match.title) or match.url
            lines.append(f'{idx}. {title} -> {match.url}')
        return '\n'.join(lines)

    def summarize_file(self, path: Path) -> str:
        path = path.expanduser()
        if not path.exists():
            return f'Local file not found: {path}'
        if not path.is_file():
            return f'That path is not a regular file: {path}'
        if not _supports_text_preview(path):
            return f'I can summarize local text-like files directly, but not this file type yet: {path.name}'
        preview = _read_preview(path)
        if not preview.strip():
            return f'I could not read useful text from: {path}'
        result = summarize_text(preview, title=path.name)
        return result + f'\nFile: {path}'

    @staticmethod
    def _is_doc_query(text: str) -> bool:
        return bool(re.search(r'\b(documents?|files?|downloads?|notes?|resume|cv)\b', text))

    @staticmethod
    def _is_pdf_query(text: str) -> bool:
        return 'pdf' in text or 'pdfs' in text

    @staticmethod
    def _is_history_query(text: str) -> bool:
        return 'history' in text or 'visited' in text or 'recent page' in text

    @staticmethod
    def _is_bookmark_query(text: str) -> bool:
        return 'bookmark' in text or 'saved page' in text

    @staticmethod
    def _is_page_summary_request(text: str) -> bool:
        return any(token in text for token in ['summarize this page', 'summary of this page', 'what is this page about', 'summarize page'])

    @staticmethod
    def _is_selection_summary_request(text: str) -> bool:
        return any(token in text for token in ['summarize selection', 'summarize selected text', 'summary of selection'])

    @staticmethod
    def _is_page_question(text: str) -> bool:
        return 'page' in text or text.startswith('what ') or text.startswith('how ') or text.startswith('why ') or text.startswith('does ')

    @staticmethod
    def _is_link_request(text: str) -> bool:
        return 'show links' in text or 'links on this page' in text or 'list links' in text

    @staticmethod
    def _is_compare_request(text: str) -> bool:
        return 'compare these two tabs' in text or 'compare tabs' in text or 'compare current tab' in text

    @staticmethod
    def _is_path_summary_request(text: str) -> bool:
        lowered = text.lower()
        return lowered.startswith('summarize /') or ' summarize /' in lowered or lowered.startswith('summarize ~/')

    @staticmethod
    def _extract_path(text: str) -> str | None:
        match = re.search(r'(~?/[^\s]+)', text)
        if not match:
            return None
        return match.group(1)

    @staticmethod
    def _is_risky_action(text: str) -> bool:
        risky_tokens = ['delete', 'remove file', 'trash', 'send email', 'purchase', 'buy', 'checkout', 'submit form', 'upload', 'log in', 'login']
        return any(token in text for token in risky_tokens)
