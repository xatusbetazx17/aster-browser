"""Interface translation catalog for Aster Browser.

Every key is the English source string used in the code base. ``localization.tr``
looks the string up in the catalog for the active interface language and falls
back to the English source when a language or a key is missing.

The per-language catalogs live in ``aster_browser/locales``. ``tests/test_localization.py``
fails when a language is missing a key that another language defines, so the
shipped interface languages stay complete.
"""

from __future__ import annotations

from .locales import CATALOGS

# Interface languages offered in Settings -> General -> Interface language.
# "system" follows the operating system locale and falls back to English.
INTERFACE_LANGUAGE_CHOICES: list[tuple[str, str]] = [
    ("system", "System default"),
    ("en", "English"),
    ("tr", "Türkçe"),
    ("de", "Deutsch"),
    ("fr", "Français"),
    ("es", "Español"),
    ("it", "Italiano"),
    ("pt", "Português"),
    ("nl", "Nederlands"),
    ("pl", "Polski"),
    ("ru", "Русский"),
    ("uk", "Українська"),
    ("sv", "Svenska"),
]

TRANSLATIONS: dict[str, dict[str, str]] = dict(CATALOGS)

# Language families that ship a complete interface translation. "en" is the
# source language and therefore needs no catalog.
TRANSLATED_FAMILIES: frozenset[str] = frozenset({"en", *TRANSLATIONS})

__all__ = ["INTERFACE_LANGUAGE_CHOICES", "TRANSLATIONS", "TRANSLATED_FAMILIES"]
