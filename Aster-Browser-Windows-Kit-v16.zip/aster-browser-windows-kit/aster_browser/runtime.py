from __future__ import annotations

import os
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

from .paths import ensure_directories, logs_dir
from .streaming import build_qtwebengine_flags, find_widevine
from .trust import configure_system_trust_environment, system_ca_bundle


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    return default


def configure_qt_runtime(*, hardware_acceleration: bool = True, force_software: bool = False, use_system_ca: bool = True) -> None:
    ensure_directories()
    if use_system_ca:
        configure_system_trust_environment()
    widevine_path = find_widevine()
    existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
    hw = hardware_acceleration and not force_software and not _bool_env("ASTER_FORCE_SOFTWARE_RENDERING", False)
    flags = build_qtwebengine_flags(existing=existing, hardware_acceleration=hw, widevine_path=widevine_path, force_software=not hw)
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = flags
    if not hw:
        os.environ.setdefault("LIBGL_ALWAYS_SOFTWARE", "1")
        os.environ.setdefault("QT_OPENGL", "software")
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", os.environ.get("ASTER_DISABLE_SANDBOX", "0"))


def certificate_environment_summary() -> str:
    bundle = system_ca_bundle()
    bundle_text = str(bundle) if bundle else "not found"
    flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    verifier = "enabled" if "--use-system-cert-verifier" in flags.split() else "not requested"
    return f"CA bundle={bundle_text}; system verifier={verifier}"


def log_path() -> Path:
    ensure_directories()
    return logs_dir() / "aster.log"


def append_log_line(message: str) -> None:
    try:
        path = log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(message.rstrip() + "\n")
    except Exception:
        pass


def install_exception_logging() -> None:
    previous_hook = sys.excepthook

    def hook(exc_type: type[BaseException], exc: BaseException, tb: Any) -> None:
        stamp = datetime.now().isoformat(timespec="seconds")
        append_log_line(f"[{stamp}] Unhandled exception")
        append_log_line("".join(traceback.format_exception(exc_type, exc, tb)))
        if previous_hook is not None:
            previous_hook(exc_type, exc, tb)

    sys.excepthook = hook
