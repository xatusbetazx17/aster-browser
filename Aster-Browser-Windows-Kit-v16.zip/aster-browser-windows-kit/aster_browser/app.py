from __future__ import annotations

import os
import sys
from PyQt6.QtCore import QSettings
from .config import load_config
from .runtime import append_log_line, configure_qt_runtime, install_exception_logging
from .theme import apply_qt_style, stylesheet_for


def main() -> int:
    # --- QT MOTORUNA BAYRAK ENJEKSİYONU ---
    settings = QSettings("Aster", "Flags")
    
    # Flags sayfasındaki ID'ler ile karşılık gelen Chromium komutları
    flag_map = {
        "gpu_rasterization": {"Enabled": "--enable-gpu-rasterization", "Disabled": "--disable-gpu-rasterization"},
        "smooth_scrolling": {"Enabled": "--enable-features=SmoothScrolling", "Disabled": "--disable-features=SmoothScrolling"},
        "ignore_gpu_blocklist": {"Enabled": "--ignore-gpu-blocklist", "Disabled": ""},
        "dark_mode": {"Enabled": "--blink-settings=forceDarkModeEnabled=true", "Disabled": ""},
        "webrtc_pipewire": {"Enabled": "--enable-features=WebRTCPipeWireCapturer", "Disabled": ""},
        "canvas_fingerprint": {"Enabled": "--disable-reading-from-canvas", "Disabled": ""},
        "site_isolation": {"Enabled": "--site-per-process", "Disabled": "--disable-site-isolation-trials"}
    }

    active_flags = []
    for fid, options in flag_map.items():
        state = str(settings.value(fid, "Default"))
        if state in options and options[state]:
            active_flags.append(options[state])

    if active_flags:
        # Eğer kullanıcının özel çevresel bayrakları varsa bozmadan üstüne ekle
        current = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = f"{current} {' '.join(active_flags)}".strip()
    # --------
    cfg = load_config()
    configure_qt_runtime(hardware_acceleration=cfg.hardware_acceleration, force_software=cfg.force_software_rendering, use_system_ca=getattr(cfg, "trust_system_ca", True))
    install_exception_logging()
    try:
        from PyQt6.QtWidgets import QApplication, QStyleFactory
    except Exception as exc:
        print("Aster Browser needs PyQt6 and PyQt6-WebEngine installed.")
        print("Install them with: python -m pip install -r requirements.txt")
        print(f"Import error: {exc}")
        return 1

    from .paths import ensure_directories
    from .browser import BrowserWindow

    ensure_directories()
    append_log_line("Starting Aster Browser")
    app = QApplication(sys.argv)
    app.setApplicationName("Aster Browser")
    app.setOrganizationName("Aster")
    try:
        app.setStyle(QStyleFactory.create("Fusion") or app.style())
    except Exception:
        pass
    resolved_qt_style = apply_qt_style(app, getattr(cfg, "qt_style", "fusion"))
    if resolved_qt_style != getattr(cfg, "qt_style", "fusion"):
        cfg.qt_style = resolved_qt_style
    app.setStyleSheet(stylesheet_for(cfg.theme, getattr(cfg, "background_transparency_percent", 10), getattr(cfg, "accent_color", "#3b82f6"), getattr(cfg, "ui_density", "comfortable"), getattr(cfg, "window_corner_radius", 18)))
    window = BrowserWindow()
    window.show()
    return app.exec()
