
from __future__ import annotations

import os
import sys

def load_bundled_fonts() -> str:
    from PyQt6.QtGui import QFontDatabase
    fonts_dir = os.path.join(os.path.dirname(__file__), "assets", "fonts")
    loaded = False
    if os.path.exists(fonts_dir):
        for fname in os.listdir(fonts_dir):
            if fname.endswith(".ttf") or fname.endswith(".otf"):
                res = QFontDatabase.addApplicationFont(os.path.join(fonts_dir, fname))
                if res != -1:
                    loaded = True
    return "Manrope" if loaded else "Segoe UI"

from .config import load_config
from .flags import switches as experiment_switches
from .localization import set_ui_language
from .runtime import append_log_line, configure_qt_runtime, install_exception_logging
from .theme import apply_qt_style, stylesheet_for


def main() -> int:
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("org.aster.browser.desktop.v16")
        except Exception:
            pass

    # Experiments chosen on aster:flags are engine switches, so they have to
    # reach the environment before QtWebEngine reads it. Aster's own defaults
    # are merged in next, and step aside for anything contradicted here.
    chosen = experiment_switches()
    if chosen:
        current = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = " ".join([current, *chosen]).strip()
    cfg = load_config()
    set_ui_language(getattr(cfg, "interface_language", "system"))
    configure_qt_runtime(hardware_acceleration=cfg.hardware_acceleration, force_software=cfg.force_software_rendering, use_system_ca=getattr(cfg, "trust_system_ca", True))
    install_exception_logging()
    try:
        from PyQt6.QtWidgets import QApplication, QStyleFactory
    except Exception as exc:
        print("Aster Browser needs PyQt6 and PyQt6-WebEngine installed.")
        print("Install them with: python -m pip install -r requirements.txt")
        print(f"Import error: {exc}")
        return 1

    from .config import DEFAULT_ACCENT
    from .paths import ensure_directories
    from .browser import BrowserWindow

    ensure_directories()
    append_log_line("Starting Aster Browser")
    from PyQt6.QtGui import QIcon
    app = QApplication(sys.argv)
    app.setApplicationName("Aster Browser")
    app.setOrganizationName("Aster")

    # Configure Global Manrope Font
    from PyQt6.QtGui import QFont
    primary_font_family = load_bundled_fonts()
    global_font = QFont(primary_font_family, 10)
    global_font.setStyleHint(QFont.StyleHint.SansSerif)
    app.setFont(global_font)

    ico_path = os.path.join(os.path.dirname(__file__), "assets", "icons", "aster.ico")
    if not os.path.exists(ico_path):
        ico_path = os.path.join(os.path.dirname(__file__), "assets", "icons", "aster_logo.svg")
    if os.path.exists(ico_path):
        app.setWindowIcon(QIcon(ico_path))
    try:
        app.setStyle(QStyleFactory.create("Fusion") or app.style())
    except Exception:
        pass
    resolved_qt_style = apply_qt_style(app, getattr(cfg, "qt_style", "fusion"))
    if resolved_qt_style != getattr(cfg, "qt_style", "fusion"):
        cfg.qt_style = resolved_qt_style
    app.setStyleSheet(stylesheet_for(cfg.theme, getattr(cfg, "background_transparency_percent", 10), getattr(cfg, "accent_color", DEFAULT_ACCENT), getattr(cfg, "ui_density", "comfortable"), getattr(cfg, "window_corner_radius", 18)))
    window = BrowserWindow()
    # Ekrani neredeyse tamamen kaplayarak aciliyor ama MAXIMIZE DEGIL.
    # Maximize edilmis bir pencere Windows'ta kenarlarindan yeniden
    # boyutlandirilamaz; boyle acinca hem ekran dolu gorunuyor hem de
    # kenar/kose surukleyerek boyutlandirma ilk andan itibaren calisiyor.
    screen = app.primaryScreen()
    if screen is not None:
        area = screen.availableGeometry()
        width = int(area.width() * 0.94)
        height = int(area.height() * 0.94)
        window.resize(width, height)
        window.move(
            area.left() + (area.width() - width) // 2,
            area.top() + (area.height() - height) // 2,
        )
    window.show()
    return app.exec()
