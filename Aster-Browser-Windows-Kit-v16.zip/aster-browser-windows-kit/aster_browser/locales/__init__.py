"""Interface string catalogs, one module per language.

English is the source language, so it has no catalog: ``localization.tr`` returns
the key itself when no catalog covers it.
"""

from __future__ import annotations

from . import de, es, fr, it, nl, pl, pt, ru, sv, tr, uk

CATALOGS: dict[str, dict[str, str]] = {
    "de": de.STRINGS,
    "es": es.STRINGS,
    "fr": fr.STRINGS,
    "it": it.STRINGS,
    "nl": nl.STRINGS,
    "pl": pl.STRINGS,
    "pt": pt.STRINGS,
    "ru": ru.STRINGS,
    "sv": sv.STRINGS,
    "tr": tr.STRINGS,
    "uk": uk.STRINGS,
}

__all__ = ["CATALOGS"]
