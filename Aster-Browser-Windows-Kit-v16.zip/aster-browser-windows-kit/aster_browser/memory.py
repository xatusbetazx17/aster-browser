from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .models import TabSnapshot


MEDIA_HINTS = re.compile(r"(youtube|twitch|netflix|primevideo|hulu|spotify|soundcloud|steam|xbox|geforcenow)", re.I)
DOCS_HINTS = re.compile(r"(docs\.|wikipedia|readthedocs|developer|manpages|news|blog)", re.I)


@dataclass
class GovernorDecision:
    park_tab_ids: list[str]
    estimated_live_mb: int
    live_tabs: int
    parked_tabs: int
    reason: str


class MemoryGovernor:
    def __init__(self, soft_budget_mb: int = 1200, max_live_tabs: int = 6, min_live_tabs: int = 1) -> None:
        self.soft_budget_mb = max(256, soft_budget_mb)
        self.max_live_tabs = max(1, max_live_tabs)
        self.min_live_tabs = max(1, min_live_tabs)

    @staticmethod
    def estimate_cost(url: str, kind: str = "web", audible: bool = False) -> int:
        if kind == "internal":
            return 8
        if kind == "parked":
            return 6
        if kind == "lite":
            return 28
        score = 110
        if MEDIA_HINTS.search(url):
            score += 130
        elif DOCS_HINTS.search(url):
            score -= 30
        if audible:
            score += 80
        return max(50, score)

    def plan(self, tabs: Iterable[TabSnapshot]) -> GovernorDecision:
        snapshots = list(tabs)
        live = [tab for tab in snapshots if tab.live]
        parked = [tab for tab in snapshots if not tab.live]
        estimated_live_mb = sum(tab.estimated_cost_mb for tab in live)
        if not live:
            return GovernorDecision([], 0, 0, len(parked), "no-live-tabs")

        candidates = [
            tab for tab in live
            if tab.kind == "web" and not tab.visible and not tab.pinned and not tab.audible
        ]
        candidates.sort(key=lambda tab: (tab.last_active, -tab.estimated_cost_mb))

        to_park: list[str] = []
        remaining_live_count = len(live)
        remaining_live_mb = estimated_live_mb
        hit_tab_limit = remaining_live_count > self.max_live_tabs
        hit_budget = remaining_live_mb > self.soft_budget_mb

        while candidates and ((remaining_live_count > self.max_live_tabs) or (remaining_live_mb > self.soft_budget_mb and remaining_live_count > self.min_live_tabs)):
            victim = candidates.pop(0)
            to_park.append(victim.tab_id)
            remaining_live_count -= 1
            remaining_live_mb -= victim.estimated_cost_mb

        reason = "none"
        if to_park:
            if hit_tab_limit and hit_budget:
                reason = "over-tab-limit-and-budget"
            elif hit_tab_limit:
                reason = "over-tab-limit"
            else:
                reason = "over-soft-budget"
        return GovernorDecision(
            park_tab_ids=to_park,
            estimated_live_mb=max(0, remaining_live_mb),
            live_tabs=remaining_live_count,
            parked_tabs=len(parked) + len(to_park),
            reason=reason,
        )

    @staticmethod
    def process_rss_mb() -> int | None:
        status = Path("/proc/self/status")
        if not status.exists():
            return None
        try:
            for line in status.read_text(encoding="utf-8").splitlines():
                if line.startswith("VmRSS:"):
                    kb = int(line.split()[1])
                    return kb // 1024
        except Exception:
            return None
        return None
