from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from PyQt6.QtCore import QSize, QTimer, QUrl, Qt, pyqtSignal
from PyQt6.QtGui import QDesktopServices, QFont, QPainter, QPen, QColor
from PyQt6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .icons import svg_icon
from .localization import tr
from .local_index import BookmarkResult, HistoryResult
from .paths import downloads_dir
from .widgets import MenuTile

from PyQt6.QtCore import QObject, pyqtSignal, QTimer, QPoint
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout
from PyQt6.QtGui import QIcon

class FocusNotification(QWidget):
    """Sol üstte çıkacak şık bildirim pop-up'ı"""
    def __init__(self, title: str, message: str, parent=None):
        super().__init__(parent)
        # Pencere çerçevesini gizle ve her zaman üstte tut
        self.setWindowFlags(Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        
        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setStyleSheet("QFrame { background: #171b22; border: 1px solid #3b82f6; border-radius: 10px; }")
        
        inner_layout = QVBoxLayout(self.shell)
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #3b82f6; font-weight: bold; font-size: 14px; border: none; background: transparent;")
        msg_label = QLabel(message)
        msg_label.setStyleSheet("color: #e6edf3; font-size: 12px; border: none; background: transparent;")
        
        inner_layout.addWidget(title_label)
        inner_layout.addWidget(msg_label)
        layout.addWidget(self.shell)

        # 5 saniye sonra otomatik kapanır
        QTimer.singleShot(5000, self.close)

class FocusSessionManager(QObject):
    """Sayfa kapansa bile arka planda çalışan zamanlayıcı"""
    tick = pyqtSignal(int, int) # (kalan_saniye, toplam_saniye)
    finished = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.total_seconds = 5 * 60
        self.remaining_seconds = self.total_seconds
        self.is_running = False
        
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._on_tick)
        
    def set_minutes(self, minutes: int):
        self.total_seconds = max(60, int(minutes) * 60)
        if not self.is_running:
            self.remaining_seconds = self.total_seconds
            self.tick.emit(self.remaining_seconds, self.total_seconds)
            
    def toggle(self):
        if self.remaining_seconds <= 0:
            self.remaining_seconds = self.total_seconds
            
        self.is_running = not self.is_running
        if self.is_running:
            self.timer.start()
        else:
            self.timer.stop()
        self.tick.emit(self.remaining_seconds, self.total_seconds)
            
    def reset(self):
        self.is_running = False
        self.timer.stop()
        self.remaining_seconds = self.total_seconds
        self.tick.emit(self.remaining_seconds, self.total_seconds)
        
    def _on_tick(self):
        if self.remaining_seconds > 0:
            self.remaining_seconds -= 1
            self.tick.emit(self.remaining_seconds, self.total_seconds)
        else:
            self.is_running = False
            self.timer.stop()
            self.finished.emit()
            self.show_notification()
            
    def show_notification(self):
        self.notif = FocusNotification(tr("Focus Session Complete"), tr("Great job! Your focus time is up."))
        
        # Ekranın boyutlarını alıyoruz
        from PyQt6.QtWidgets import QApplication
        screen = QApplication.primaryScreen()
        
        if screen:
            screen_geometry = screen.availableGeometry()
            self.notif.adjustSize() # Metne göre pencerenin kendi boyutunu hesaplamasını sağlar
            
            # Sağdan 20px ve üstten 20px boşluk bırakarak sağ üst köşeye hizalar
            x = screen_geometry.width() - self.notif.width() - 20
            y = screen_geometry.y() + 20
            
            self.notif.move(x, y)
        else:
            self.notif.move(20, 20) # Ekran boyutu alınamazsa yedek olarak sol üste koyar
            
        self.notif.show()

# Tüm tarayıcıda tek bir örneği (Singleton) yaşayacak
global_focus_manager = FocusSessionManager()


@dataclass
class DownloadEntry:
    path: Path
    size_bytes: int
    modified_at: float


def _format_timestamp(ts: float) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return tr("Unknown")


def _format_bytes(size: int) -> str:
    value = float(max(0, int(size)))
    units = ["B", "KB", "MB", "GB", "TB"]
    unit_index = 0
    while value >= 1024.0 and unit_index < len(units) - 1:
        value /= 1024.0
        unit_index += 1
    if unit_index == 0:
        return f"{int(value)} {units[unit_index]}"
    return f"{value:.1f} {units[unit_index]}"


def _format_hms(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _format_minutes_text(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours and minutes:
        return tr("{hours} hr {minutes} min").format(hours=hours, minutes=minutes)
    if hours:
        return tr("{hours} hr").format(hours=hours)
    return tr("{minutes} min").format(minutes=minutes)


class MenuDashboardPopup(QDialog):
    history_requested = pyqtSignal()
    bookmarks_requested = pyqtSignal()
    settings_requested = pyqtSignal()
    downloads_requested = pyqtSignal()
    awareness_requested = pyqtSignal()
    extensions_requested = pyqtSignal()
    ai_requested = pyqtSignal()

    def __init__(self, stats_provider: Callable[[], str], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.stats_provider = stats_provider
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setObjectName("AsterDashboardPopupHost")
        self.setStyleSheet("""
            QDialog#AsterDashboardPopupHost {
                background: #131720;
                border: 1px solid #28303e;
                border-radius: 10px;
            }
            QFrame#AsterPageShell {
                background: transparent;
                border: none;
            }
            QLabel {
                background: transparent;
                border: none;
            }
            QFrame#AsterMenuTile QLabel {
                background: transparent;
                border: none;
            }
            QFrame#AsterStatsStrip {
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid #28303e;
                border-radius: 6px;
            }
            QPushButton#SecondaryButton {
                background: #1a202c;
                border: 1px solid #2a3344;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
                color: #e2e8f0;
            }
            QPushButton#SecondaryButton:hover {
                background: #252d3d;
                border-color: #3b4759;
            }
        """)
        self._build_ui()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(2500)
        self._refresh_timer.timeout.connect(self.refresh_stats)

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(12, 12, 12, 12)
        shell_layout.setSpacing(10)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        grid.setContentsMargins(0, 0, 0, 0)

        tiles = [
            (tr("History"), tr("Visited pages"), "history", self.history_requested),
            (tr("Bookmarks"), tr("Saved pages"), "bookmark", self.bookmarks_requested),
            (tr("Settings"), tr("Browser preferences"), "settings", self.settings_requested),
            (tr("Downloads"), tr("Files and downloads"), "download", self.downloads_requested),
            (tr("Awareness"), tr("Timers and screen time"), "awareness", self.awareness_requested),
            (tr("Extensions"), tr("Manage add-ons"), "extensions", self.extensions_requested),
        ]
        for index, (title, subtitle, icon_name, signal) in enumerate(tiles):
            tile = MenuTile(title, subtitle, icon_name, self.shell)
            tile.apply_density(1.0)
            tile.clicked.connect(lambda _checked=False, sig=signal: self._emit_then_close(sig))
            grid.addWidget(tile, index // 3, index % 3)

        shell_layout.addLayout(grid)

        self.ai_button = QPushButton(tr("Aster AI"), self.shell)
        self.ai_button.setObjectName("SecondaryButton")
        self.ai_button.setIcon(svg_icon("sparkle"))
        self.ai_button.setIconSize(QSize(15, 15))
        self.ai_button.setFixedHeight(30)
        self.ai_button.clicked.connect(lambda _checked=False: self._emit_then_close(self.ai_requested))
        shell_layout.addWidget(self.ai_button)

        self.stats_strip = QFrame(self.shell)
        self.stats_strip.setObjectName("AsterStatsStrip")
        stats_layout = QVBoxLayout(self.stats_strip)
        stats_layout.setContentsMargins(8, 6, 8, 6)
        stats_layout.setSpacing(2)
        self.stats_label = QLabel(self.stats_strip)
        self.stats_label.setObjectName("AsterFooterInfo")
        self.stats_label.setStyleSheet("font-size: 10px; color: #8f9ba8; background: transparent; border: none;")
        self.stats_label.setWordWrap(True)
        stats_layout.addWidget(self.stats_label)
        shell_layout.addWidget(self.stats_strip)

        outer.addWidget(self.shell)
        self.refresh_stats()

    def _emit_then_close(self, signal) -> None:
        try:
            signal.emit()
        finally:
            self.close()

    def refresh_stats(self) -> None:
        try:
            text = self.stats_provider()
        except Exception as exc:
            text = tr("Metrics unavailable: {error}").format(error=exc)
        self.stats_label.setText(text)
        self.adjustSize()

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_stats()
        self._refresh_timer.start()

    def hideEvent(self, event) -> None:  # type: ignore[override]
        self._refresh_timer.stop()
        super().hideEvent(event)


class _PageShell(QWidget):
    def __init__(self, title: str, subtitle: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        outer = QVBoxLayout(self)
        
        # Kenar boşluklarını 0 veya çok az (örneğin 10) yaparak tam ekran hissi veriyoruz
        outer.setContentsMargins(10, 10, 10, 10) 
        
        row = QHBoxLayout()

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        
        # KRİTİK: Genişlik ve yükseklik sınırlarını kaldırıp "Expanding" yapıyoruz
        # Bu sayede pencere büyüdükçe içerik de tüm alanı kaplar.
        self.shell.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.shell.setMinimumWidth(0)
        self.shell.setMaximumWidth(16777215) # Qt'nin sonsuz genişlik değeri
        
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(28, 26, 28, 24)
        shell_layout.setSpacing(16)

        self.title_label = QLabel(title, self.shell)
        self.title_label.setObjectName("AsterSettingsTitle")
        self.subtitle_label = QLabel(subtitle, self.shell)
        self.subtitle_label.setObjectName("AsterSettingsSubtitle")
        self.subtitle_label.setWordWrap(True)

        self.card = QFrame(self.shell)
        self.card.setObjectName("AsterSettingsCard")
        self.card_layout = QVBoxLayout(self.card)
        self.card_layout.setContentsMargins(22, 20, 22, 20)
        self.card_layout.setSpacing(14)

        # Kartın (liste kısmının) dikeyde tüm boşluğu doldurmasını sağlar
        self.card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        shell_layout.addWidget(self.title_label)
        shell_layout.addWidget(self.subtitle_label)
        shell_layout.addWidget(self.card, 1) # 1 ekleyerek kartın büyümesini sağlıyoruz

        # Stretcher'ları (addStretch) sildiğimiz için shell tüm satırı kaplayacak
        row.addWidget(self.shell)
        outer.addLayout(row)


class HistoryPageWidget(_PageShell):
    open_url_requested = pyqtSignal(str)

    def __init__(
        self,
        list_provider: Callable[[], list[HistoryResult]],
        search_provider: Callable[[str], list[HistoryResult]],
        parent: QWidget | None = None,
    ) -> None:
        self.list_provider = list_provider
        self.search_provider = search_provider
        super().__init__(tr("History"), tr("Recent pages you opened in Aster. Open any result in this tab with a double click."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Search history by title or URL"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        self.search_button = QPushButton(tr("Search"), self.card)
        self.search_button.clicked.connect(self.refresh_results)
        self.refresh_button = QPushButton(tr("Refresh"), self.card)
        self.refresh_button.setObjectName("SecondaryButton")
        self.refresh_button.clicked.connect(self.refresh_results)
        row.addWidget(self.search_edit, 1)
        row.addWidget(self.search_button)
        row.addWidget(self.refresh_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        self.list_widget.setSpacing(6)  # Öğeler arasına 6 piksellik boşluk bırakır
        self.list_widget.setIconSize(QSize(36, 22))  # Soldaki favicon/ikon boyutunu belirler
        self.list_widget.setStyleSheet(
            "QListWidget::item { padding: 6px; border-radius: 6px; }"
        )
        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def refresh_results(self) -> None:
        # İkon işlemleri için gerekli araçları dahil ediyoruz
        from PyQt6.QtGui import QPixmap, QPainter, QIcon
        from PyQt6.QtCore import Qt
        
        query = self.search_edit.text().strip()
        results = self.search_provider(query) if query else self.list_provider()
        self.list_widget.clear()
        
        for entry in results:
            title = (entry.title or entry.url or tr("Page")).strip()
            details = tr("Visited {count} time(s) · Last visited {timestamp}").format(count=entry.visit_count, timestamp=_format_timestamp(entry.last_visited))
            text = f"{title}\n{entry.url}\n{details}"
            item = QListWidgetItem(text)
            
            # --- FAVICON BOŞLUK (PADDING) AYARI ---
            # 1. Gerçek ikonu 22x22 boyutunda oluşturuyoruz
            icon_pixmap = svg_icon("history").pixmap(22, 22)
            
            # 2. 36x22 boyutunda tamamen şeffaf bir arka plan hazırlıyoruz
            padded_pixmap = QPixmap(36, 22)
            padded_pixmap.fill(Qt.GlobalColor.transparent)
            
            # 3. İkonu bu şeffaf arka planın en soluna (0, 0 noktasına) çiziyoruz
            painter = QPainter(padded_pixmap)
            painter.drawPixmap(0, 0, icon_pixmap)
            painter.end()
            
            # 4. Boşluklu yeni ikonu listeye atıyoruz
            item.setIcon(QIcon(padded_pixmap))
            # --------------------------------------
            
            item.setData(Qt.ItemDataRole.UserRole, entry.url)
            self.list_widget.addItem(item)
            
        count = self.list_widget.count()
        self.status_label.setText(tr("1 entry shown.") if count == 1 else tr("{count} entries shown.").format(count=count))

    def _open_item(self, item: QListWidgetItem) -> None:
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if url:
            self.open_url_requested.emit(url)

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()


class BookmarksPageWidget(_PageShell):
    open_url_requested = pyqtSignal(str)
    remove_requested = pyqtSignal(str)
    save_current_requested = pyqtSignal()

    def __init__(
        self,
        list_provider: Callable[[], list[BookmarkResult]],
        search_provider: Callable[[str], list[BookmarkResult]],
        parent: QWidget | None = None,
    ) -> None:
        self.list_provider = list_provider
        self.search_provider = search_provider
        super().__init__(tr("Bookmarks"), tr("Saved pages stay here so you can reopen them quickly inside Aster."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Search bookmarks by title or URL"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        search_button = QPushButton(tr("Search"), self.card)
        search_button.clicked.connect(self.refresh_results)
        refresh_button = QPushButton(tr("Refresh"), self.card)
        refresh_button.setObjectName("SecondaryButton")
        refresh_button.clicked.connect(self.refresh_results)
        save_button = QPushButton(tr("Bookmark current page"), self.card)
        save_button.clicked.connect(lambda _checked=False: self.save_current_requested.emit())
        row.addWidget(self.search_edit, 1)
        row.addWidget(search_button)
        row.addWidget(refresh_button)
        row.addWidget(save_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        remove_button = QPushButton(tr("Remove selected"), self.card)
        remove_button.setObjectName("SecondaryButton")
        remove_button.clicked.connect(self._remove_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)
        footer.addWidget(remove_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def refresh_results(self) -> None:
        query = self.search_edit.text().strip()
        results = self.search_provider(query) if query else self.list_provider()
        self.list_widget.clear()
        for entry in results:
            title = (entry.title or entry.url or tr("Bookmark")).strip()
            details = tr("Saved {created} · Last used {used}").format(created=_format_timestamp(entry.created_at), used=_format_timestamp(entry.last_used))
            text = f"{title}\n{entry.url}\n{details}"
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, entry.url)
            self.list_widget.addItem(item)
        count = self.list_widget.count()
        self.status_label.setText(tr("1 bookmark shown.") if count == 1 else tr("{count} bookmarks shown.").format(count=count))

    def _open_item(self, item: QListWidgetItem) -> None:
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if url:
            self.open_url_requested.emit(url)

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def _remove_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is None:
            return
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if not url:
            return
        self.remove_requested.emit(url)
        self.refresh_results()

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()


class DownloadsPageWidget(_PageShell):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(tr("Downloads"), tr("Your Aster downloads folder shown inside a browser tab. Double click a file to open it."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Filter downloaded files by name"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        search_button = QPushButton(tr("Search"), self.card)
        search_button.clicked.connect(self.refresh_results)
        refresh_button = QPushButton(tr("Refresh"), self.card)
        refresh_button.setObjectName("SecondaryButton")
        refresh_button.clicked.connect(self.refresh_results)
        open_folder_button = QPushButton(tr("Open downloads folder"), self.card)
        open_folder_button.clicked.connect(self.open_downloads_folder)
        row.addWidget(self.search_edit, 1)
        row.addWidget(search_button)
        row.addWidget(refresh_button)
        row.addWidget(open_folder_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        # YENİ: Geçmiş sayfasıyla tutarlı liste tasarımı ve boşluklar
        self.list_widget.setSpacing(6) # Öğeler arası 6 piksellik boşluk
        self.list_widget.setIconSize(QSize(36, 22)) # İkon için ayrılan alan
        self.list_widget.setStyleSheet(
            "QListWidget::item { padding: 6px; border-radius: 6px; }"
        )

        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def _entries(self) -> list[DownloadEntry]:
        # Bu kısım paths.py'de güncellediğimiz yeni indirme yolunu kullanır
        base = downloads_dir()
        base.mkdir(parents=True, exist_ok=True)
        entries: list[DownloadEntry] = []
        for path in base.iterdir():
            try:
                if not path.is_file():
                    continue
                stat = path.stat()
            except Exception:
                continue
            entries.append(DownloadEntry(path=path, size_bytes=int(stat.st_size), modified_at=float(stat.st_mtime)))
        entries.sort(key=lambda item: item.modified_at, reverse=True)
        query = self.search_edit.text().strip().lower()
        if query:
            entries = [item for item in entries if query in item.path.name.lower()]
        return entries

    def refresh_results(self) -> None:
        # İkon işlemleri için gerekli araçları dahil ediyoruz
        from PyQt6.QtGui import QPixmap, QPainter, QIcon
        from PyQt6.QtCore import Qt

        self.list_widget.clear()
        entries = self._entries()
        for entry in entries:
            details = tr("{size} · Modified {timestamp}").format(size=_format_bytes(entry.size_bytes), timestamp=_format_timestamp(entry.modified_at))
            text = f"{entry.path.name}\n{entry.path}\n{details}"
            item = QListWidgetItem(text)
            
            # --- DOSYA İKONU VE BOŞLUK AYARI ---
            # Geçmiş sayfasındaki pürüzsüz ikon padding mantığının aynısını uyguluyoruz
            icon_pixmap = svg_icon("download").pixmap(22, 22)
            
            # 36x22 boyutunda tamamen şeffaf bir arka plan
            padded_pixmap = QPixmap(36, 22)
            padded_pixmap.fill(Qt.GlobalColor.transparent)
            
            # İkonu bu şeffaf alanın en soluna çiziyoruz
            painter = QPainter(padded_pixmap)
            painter.drawPixmap(0, 0, icon_pixmap)
            painter.end()
            
            item.setIcon(QIcon(padded_pixmap))
            # ----------------------------------
            
            item.setData(Qt.ItemDataRole.UserRole, str(entry.path))
            self.list_widget.addItem(item)
            
        count = self.list_widget.count()
        self.status_label.setText(tr("1 file shown from {path}.").format(path=downloads_dir()) if count == 1 else tr("{count} files shown from {path}.").format(count=count, path=downloads_dir()))

    def _open_item(self, item: QListWidgetItem) -> None:
        path_text = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if not path_text:
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path_text).resolve())))

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def open_downloads_folder(self) -> None:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(downloads_dir().resolve())))

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()

class RingProgressWidget(QWidget):
    def __init__(self, accent_color: QColor, track_color: QColor, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._progress = 0.0
        self._accent_color = QColor(accent_color)
        self._track_color = QColor(track_color)
        self._center_text = ""
        self.setMinimumSize(110, 110)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def sizeHint(self) -> QSize:
        return QSize(120, 120)

    def set_progress(self, value: float) -> None:
        self._progress = max(0.0, min(1.0, float(value)))
        self.update()

    def set_center_text(self, text: str) -> None:
        self._center_text = text
        self.update()

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        side = min(self.width(), self.height())
        ring_width = max(8, int(side * 0.10))
        pad = ring_width + 4
        rect = self.rect().adjusted(pad, pad, -pad, -pad)
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Arka plan halkası
        painter.setPen(QPen(self._track_color, ring_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(rect, 0, 360 * 16)
        
        # İlerleme (Vurgu) halkası
        painter.setPen(QPen(self._accent_color, ring_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(rect, 90 * 16, int(-360 * 16 * self._progress))
        
        # Merkezdeki Metin
        font = QFont(self.font())
        font.setPointSizeF(max(13.0, side * 0.14))
        font.setWeight(QFont.Weight.Bold)
        painter.setFont(font)
        painter.setPen(QColor("#e6edf3"))
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._center_text)


class AwarenessPageWidget(_PageShell):
    def __init__(
        self,
        metrics_provider: Callable[[], dict[str, int]],
        limit_callback: Callable[[int], None],
        parent: QWidget | None = None,
    ) -> None:
        self.metrics_provider = metrics_provider
        self.limit_callback = limit_callback

        self._chrono_elapsed_seconds = 0
        self._chrono_running = False
        super().__init__(tr("Awareness Features"), tr("Focus sessions, a simple chronometer, and screen-time summaries inside the browser."), parent)
        self.shell.setMaximumWidth(520)
        if self.shell.layout():
            self.shell.layout().setContentsMargins(18, 14, 18, 14)
            self.shell.layout().setSpacing(8)
        self.card_layout.setContentsMargins(14, 10, 14, 10)
        self.card_layout.setSpacing(8)
        self.title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #f0f6fc;")
        self.subtitle_label.setStyleSheet("font-size: 11px; color: #8b949e;")
        self._build_content()
        
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(1000)
        self._refresh_timer.timeout.connect(self._tick)
        self._refresh_timer.start()
        
        global_focus_manager.tick.connect(self._on_global_focus_tick)
        global_focus_manager.finished.connect(self._on_global_focus_finished)
        
        self.refresh_screen_metrics()
        
        self.focus_minutes_spin.setValue(global_focus_manager.total_seconds // 60)
        self._on_global_focus_tick(global_focus_manager.remaining_seconds, global_focus_manager.total_seconds)
        
        self._refresh_chrono_ui()
        self.refresh_screen_metrics()

    def _build_content(self) -> None:
        # --- ÜST SEKME SEÇİCİ (Modern Segmented Control) ---
        segment_container = QFrame(self.card)
        segment_container.setStyleSheet("""
            QFrame { background: #0d1117; border: 1px solid #30363d; border-radius: 8px; padding: 2px; }
        """)
        segment_row = QHBoxLayout(segment_container)
        segment_row.setContentsMargins(3, 3, 3, 3)
        segment_row.setSpacing(3)
        
        self.segment_group = QButtonGroup(self)
        self.segment_group.setExclusive(True)
        self.segment_buttons: list[QPushButton] = []
        
        for index, title in enumerate([tr("Focus Session"), tr("Chronometer"), tr("Screen Time")]):
            button = QPushButton(title, segment_container)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setCheckable(True)
            button.clicked.connect(lambda _checked=False, value=index: self._set_mode(value))
            button.setStyleSheet("""
                QPushButton { background: transparent; color: #8b949e; border: none; border-radius: 6px; padding: 5px 16px; font-weight: 600; font-size: 11px; }
                QPushButton:hover { color: #e6edf3; }
                QPushButton:checked { background: #21262d; color: #e6edf3; border: 1px solid #30363d; }
            """)
            self.segment_group.addButton(button, index)
            self.segment_buttons.append(button)
            segment_row.addWidget(button)
            
        self.segment_buttons[0].setChecked(True)
        
        # Ortala
        segment_outer_lyt = QHBoxLayout()
        segment_outer_lyt.addStretch(1)
        segment_outer_lyt.addWidget(segment_container)
        segment_outer_lyt.addStretch(1)

        self.stack = QStackedWidget(self.card)
        self.stack.setStyleSheet("background: transparent; border: none;")

        # Ortak Girdi Stili (SpinBox için)
        spinbox_style = """
            QSpinBox { background: #21262d; color: #e6edf3; border: 1px solid #30363d; border-radius: 8px; padding: 4px 8px; font-weight: bold; min-width: 65px; font-size: 11px; }
            QSpinBox::up-button, QSpinBox::down-button { background: transparent; border: none; width: 0px; }
        """

        # --- 1. FOCUS SESSION PAGE ---
        focus_page = QWidget(self.stack)
        focus_layout = QVBoxLayout(focus_page)
        focus_layout.setContentsMargins(0, 6, 0, 0)
        focus_layout.setSpacing(10)
        
        self.focus_ring = RingProgressWidget(QColor("#2ea043"), QColor("#21262d"), focus_page)
        self.focus_ring.set_center_text("05:00")
        focus_ring_row = QHBoxLayout()
        focus_ring_row.addWidget(self.focus_ring, 0, Qt.AlignmentFlag.AlignCenter)
        
        focus_controls = QHBoxLayout()
        focus_controls.addStretch(1)
        self.focus_start_button = QPushButton(tr("Start"), focus_page)
        self.focus_start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.focus_start_button.setStyleSheet("""
            QPushButton { background: #238636; color: white; border: 1px solid #238636; border-radius: 8px; padding: 5px 22px; font-weight: bold; font-size: 12px; }
            QPushButton:hover { background: #2ea043; border-color: #2ea043; }
        """)
        self.focus_start_button.clicked.connect(self._toggle_focus)
        
        focus_reset_button = QPushButton(tr("Reset"), focus_page)
        focus_reset_button.setObjectName("SecondaryButton")
        focus_reset_button.setCursor(Qt.CursorShape.PointingHandCursor)
        focus_reset_button.clicked.connect(self._reset_focus)
        
        focus_controls.addWidget(self.focus_start_button)
        focus_controls.addWidget(focus_reset_button)
        focus_controls.addStretch(1)
        
        focus_limit_row = QHBoxLayout()
        focus_limit_row.addStretch(1)
        focus_limit_label = QLabel(tr("Duration"), focus_page)
        focus_limit_label.setStyleSheet("color: #8b949e; font-weight: bold; font-size: 11px;")
        self.focus_minutes_spin = QSpinBox(focus_page)
        self.focus_minutes_spin.setRange(1, 240)
        self.focus_minutes_spin.setSuffix(tr(" min"))
        self.focus_minutes_spin.setValue(5)
        self.focus_minutes_spin.setStyleSheet(spinbox_style)
        self.focus_minutes_spin.valueChanged.connect(self._on_focus_minutes_changed)
        focus_limit_row.addWidget(focus_limit_label)
        focus_limit_row.addWidget(self.focus_minutes_spin)
        focus_limit_row.addStretch(1)
        
        focus_layout.addLayout(focus_ring_row)
        focus_layout.addLayout(focus_controls)
        focus_layout.addLayout(focus_limit_row)
        focus_layout.addStretch(1)

        # --- 2. CHRONOMETER PAGE ---
        chrono_page = QWidget(self.stack)
        chrono_layout = QVBoxLayout(chrono_page)
        chrono_layout.setContentsMargins(0, 6, 0, 0)
        chrono_layout.setSpacing(10)
        
        self.chrono_ring = RingProgressWidget(QColor("#3b82f6"), QColor("#21262d"), chrono_page)
        self.chrono_ring.set_center_text("00:00:00")
        chrono_ring_row = QHBoxLayout()
        chrono_ring_row.addWidget(self.chrono_ring, 0, Qt.AlignmentFlag.AlignCenter)
        
        chrono_controls = QHBoxLayout()
        chrono_controls.addStretch(1)
        self.chrono_start_button = QPushButton(tr("Start"), chrono_page)
        self.chrono_start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.chrono_start_button.setStyleSheet("""
            QPushButton { background: #1f6feb; color: white; border: 1px solid #1f6feb; border-radius: 8px; padding: 5px 22px; font-weight: bold; font-size: 12px; }
            QPushButton:hover { background: #388bfd; border-color: #388bfd; }
        """)
        self.chrono_start_button.clicked.connect(self._toggle_chrono)
        
        chrono_reset_button = QPushButton(tr("Reset"), chrono_page)
        chrono_reset_button.setObjectName("SecondaryButton")
        chrono_reset_button.setCursor(Qt.CursorShape.PointingHandCursor)
        chrono_reset_button.clicked.connect(self._reset_chrono)
        
        chrono_controls.addWidget(self.chrono_start_button)
        chrono_controls.addWidget(chrono_reset_button)
        chrono_controls.addStretch(1)
        
        chrono_layout.addLayout(chrono_ring_row)
        chrono_layout.addLayout(chrono_controls)
        chrono_layout.addStretch(1)

        # --- 3. SCREEN TIME PAGE ---
        screen_page = QWidget(self.stack)
        screen_layout = QVBoxLayout(screen_page)
        screen_layout.setContentsMargins(0, 6, 0, 0)
        screen_layout.setSpacing(10)
        
        stats_row = QHBoxLayout()
        stats_row.addStretch(1)
        self.screen_ring = RingProgressWidget(QColor("#d29922"), QColor("#21262d"), screen_page)
        self.screen_ring.set_center_text("0m")
        stats_row.addWidget(self.screen_ring)
        
        stats_row.addSpacing(18)
        
        text_col = QVBoxLayout()
        text_col.setSpacing(8)
        
        def create_stat_label(title):
            lbl = QLabel(title, screen_page)
            lbl.setStyleSheet("color: #e6edf3; font-size: 11px; font-weight: 600;")
            return lbl
            
        self.today_label = create_stat_label(tr("Today") + "\n0 min")
        self.week_label = create_stat_label(tr("Weekly") + "\n0 min")
        self.avg_label = create_stat_label(tr("Weekly average") + "\n0 min")
        
        text_col.addWidget(self.today_label)
        text_col.addWidget(self.week_label)
        text_col.addWidget(self.avg_label)
        text_col.addStretch(1)
        
        stats_row.addLayout(text_col)
        stats_row.addStretch(1)
        
        limit_row = QHBoxLayout()
        limit_row.addStretch(1)
        limit_label = QLabel(tr("Daily limit"), screen_page)
        limit_label.setStyleSheet("color: #8b949e; font-weight: bold; font-size: 11px;")
        self.limit_spin = QSpinBox(screen_page)
        self.limit_spin.setRange(1, 24)
        self.limit_spin.setSuffix(tr(" hr"))
        self.limit_spin.setStyleSheet(spinbox_style)
        self.limit_spin.valueChanged.connect(self._limit_changed)
        
        limit_row.addWidget(limit_label)
        limit_row.addWidget(self.limit_spin)
        limit_row.addStretch(1)
        
        screen_layout.addLayout(stats_row)
        screen_layout.addLayout(limit_row)
        screen_layout.addStretch(1)

        self.stack.addWidget(focus_page)
        self.stack.addWidget(chrono_page)
        self.stack.addWidget(screen_page)

        # Temel Yerleşim
        self.card_layout.addLayout(segment_outer_lyt)
        self.card_layout.addSpacing(6)
        self.card_layout.addWidget(self.stack)

    def _set_mode(self, index: int) -> None:
        self.stack.setCurrentIndex(max(0, min(index, self.stack.count() - 1)))

    def _on_focus_minutes_changed(self, value: int) -> None:
        global_focus_manager.set_minutes(value)

    def _toggle_focus(self) -> None:
        global_focus_manager.toggle()

    def _reset_focus(self) -> None:
        global_focus_manager.reset()

    def _on_global_focus_tick(self, remaining: int, total: int) -> None:
        total = max(1, total)
        progress = 1.0 - (remaining / total)
        self.focus_ring.set_progress(progress)
        self.focus_ring.set_center_text(_format_hms(remaining)[3:] if total < 3600 else _format_hms(remaining))
        self.focus_start_button.setText(tr("Pause") if global_focus_manager.is_running else tr("Start"))

    def _on_global_focus_finished(self) -> None:
        self.focus_start_button.setText(tr("Start"))

    def _toggle_chrono(self) -> None:
        self._chrono_running = not self._chrono_running
        self._refresh_chrono_ui()

    def _reset_chrono(self) -> None:
        self._chrono_running = False
        self._chrono_elapsed_seconds = 0
        self._refresh_chrono_ui()

    def _refresh_chrono_ui(self) -> None:
        self.chrono_ring.set_progress(1.0)
        self.chrono_ring.set_center_text(_format_hms(self._chrono_elapsed_seconds))
        self.chrono_start_button.setText(tr("Pause") if self._chrono_running else tr("Start"))

    def _limit_changed(self, value: int) -> None:
        minutes = max(60, int(value) * 60)
        self.limit_callback(minutes)
        self.refresh_screen_metrics()

    def refresh_screen_metrics(self) -> None:
        metrics = self.metrics_provider() or {}
        today = int(metrics.get("today_seconds", 0) or 0)
        weekly = int(metrics.get("weekly_seconds", 0) or 0)
        avg = int(metrics.get("weekly_average_seconds", 0) or 0)
        limit_minutes = int(metrics.get("daily_limit_minutes", 120) or 120)
        limit_seconds = max(3600, limit_minutes * 60)
        
        self.limit_spin.blockSignals(True)
        self.limit_spin.setValue(max(1, round(limit_minutes / 60)))
        self.limit_spin.blockSignals(False)
        
        self.screen_ring.set_progress(min(1.0, today / limit_seconds))
        self.screen_ring.set_center_text(_format_minutes_text(today))
        
        self.today_label.setText(f"<span style='color:#8b949e;'>{tr('Today')}</span><br><span style='font-size: 16px;'>{_format_minutes_text(today)}</span>")
        self.week_label.setText(f"<span style='color:#8b949e;'>{tr('Weekly')}</span><br><span style='font-size: 16px;'>{_format_minutes_text(weekly)}</span>")
        self.avg_label.setText(f"<span style='color:#8b949e;'>{tr('Weekly average')}</span><br><span style='font-size: 16px;'>{_format_minutes_text(avg)}</span>")

    def _tick(self) -> None:
        if self._chrono_running:
            self._chrono_elapsed_seconds += 1
            self._refresh_chrono_ui()
        self.refresh_screen_metrics()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.refresh_screen_metrics()