from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from PyQt6.QtCore import QPointF, QRectF, QSize, QTimer, QUrl, Qt, pyqtSignal
from PyQt6.QtGui import QDesktopServices, QFont, QFontMetrics, QLinearGradient, QPainter, QPen, QColor
from PyQt6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .icons import svg_icon
from .localization import tr
from .local_index import BookmarkResult, HistoryResult
from .paths import downloads_dir
from .widgets import MenuTile

from PyQt6.QtCore import QObject, pyqtSignal, QTimer, QPoint
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout
from PyQt6.QtGui import QIcon

class FocusNotification(QWidget):
    """Sol üstte çıkacak şık bildirim pop-up'ı"""
    def __init__(self, title: str, message: str, parent=None):
        super().__init__(parent)
        # Pencere çerçevesini gizle ve her zaman üstte tut
        self.setWindowFlags(Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        
        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setStyleSheet("QFrame { background: #171b22; border: 1px solid #3b82f6; border-radius: 10px; }")
        
        inner_layout = QVBoxLayout(self.shell)
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #3b82f6; font-weight: bold; font-size: 14px; border: none; background: transparent;")
        msg_label = QLabel(message)
        msg_label.setStyleSheet("color: #e6edf3; font-size: 12px; border: none; background: transparent;")
        
        inner_layout.addWidget(title_label)
        inner_layout.addWidget(msg_label)
        layout.addWidget(self.shell)

        # 5 saniye sonra otomatik kapanır
        QTimer.singleShot(5000, self.close)

class FocusSessionManager(QObject):
    """Sayfa kapansa bile arka planda çalışan zamanlayıcı"""
    tick = pyqtSignal(int, int) # (kalan_saniye, toplam_saniye)
    finished = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.total_seconds = 5 * 60
        self.remaining_seconds = self.total_seconds
        self.is_running = False
        
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._on_tick)
        
    def set_minutes(self, minutes: int):
        self.total_seconds = max(60, int(minutes) * 60)
        if not self.is_running:
            self.remaining_seconds = self.total_seconds
            self.tick.emit(self.remaining_seconds, self.total_seconds)
            
    def toggle(self):
        if self.remaining_seconds <= 0:
            self.remaining_seconds = self.total_seconds
            
        self.is_running = not self.is_running
        if self.is_running:
            self.timer.start()
        else:
            self.timer.stop()
        self.tick.emit(self.remaining_seconds, self.total_seconds)
            
    def reset(self):
        self.is_running = False
        self.timer.stop()
        self.remaining_seconds = self.total_seconds
        self.tick.emit(self.remaining_seconds, self.total_seconds)
        
    def _on_tick(self):
        if self.remaining_seconds > 0:
            self.remaining_seconds -= 1
            self.tick.emit(self.remaining_seconds, self.total_seconds)
        else:
            self.is_running = False
            self.timer.stop()
            self.finished.emit()
            self.show_notification()
            
    def show_notification(self):
        self.notif = FocusNotification(tr("Focus Session Complete"), tr("Great job! Your focus time is up."))
        
        # Ekranın boyutlarını alıyoruz
        from PyQt6.QtWidgets import QApplication
        screen = QApplication.primaryScreen()
        
        if screen:
            screen_geometry = screen.availableGeometry()
            self.notif.adjustSize() # Metne göre pencerenin kendi boyutunu hesaplamasını sağlar
            
            # Sağdan 20px ve üstten 20px boşluk bırakarak sağ üst köşeye hizalar
            x = screen_geometry.width() - self.notif.width() - 20
            y = screen_geometry.y() + 20
            
            self.notif.move(x, y)
        else:
            self.notif.move(20, 20) # Ekran boyutu alınamazsa yedek olarak sol üste koyar
            
        self.notif.show()

# Tüm tarayıcıda tek bir örneği (Singleton) yaşayacak
global_focus_manager = FocusSessionManager()


@dataclass
class DownloadEntry:
    path: Path
    size_bytes: int
    modified_at: float


def _format_timestamp(ts: float) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return tr("Unknown")


def _format_bytes(size: int) -> str:
    value = float(max(0, int(size)))
    units = ["B", "KB", "MB", "GB", "TB"]
    unit_index = 0
    while value >= 1024.0 and unit_index < len(units) - 1:
        value /= 1024.0
        unit_index += 1
    if unit_index == 0:
        return f"{int(value)} {units[unit_index]}"
    return f"{value:.1f} {units[unit_index]}"


def _format_hms(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _format_minutes_text(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours and minutes:
        return tr("{hours} hr {minutes} min").format(hours=hours, minutes=minutes)
    if hours:
        return tr("{hours} hr").format(hours=hours)
    return tr("{minutes} min").format(minutes=minutes)


class MetricSparkBar(QWidget):
    """Olcum kartlarinin altindaki ince, renk gecisli dolum cubugu."""

    def __init__(self, accent: QColor, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._accent = QColor(accent)
        self._ratio = 0.0
        self._indeterminate = True
        self.setFixedHeight(5)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

    def set_ratio(self, ratio: float | None) -> None:
        if ratio is None:
            self._indeterminate = True
            self._ratio = 0.0
        else:
            self._indeterminate = False
            self._ratio = max(0.0, min(1.0, float(ratio)))
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        radius = self.height() / 2.0
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 22))
        painter.drawRoundedRect(QRectF(0, 0, self.width(), self.height()), radius, radius)
        if self._indeterminate:
            return
        filled = max(self.height(), self.width() * self._ratio)
        gradient = QLinearGradient(0.0, 0.0, float(filled), 0.0)
        soft = QColor(self._accent)
        soft.setAlpha(150)
        gradient.setColorAt(0.0, soft)
        gradient.setColorAt(1.0, self._accent)
        painter.setBrush(gradient)
        painter.drawRoundedRect(QRectF(0, 0, filled, self.height()), radius, radius)


class MetricChip(QFrame):
    """Dashboard pop-up'indaki tek olcum kutusu: etiket, deger, dolum cubugu."""

    def __init__(self, accent: QColor, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterMetricChip")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(3)

        self._value_text = "\u2014"
        self.label = QLabel(self)
        self.label.setStyleSheet(
            "font-size: 7.5px; font-weight: 700; letter-spacing: 0.6px;"
            " color: #74808f; background: transparent; border: none;"
        )
        self.value = QLabel("\u2014", self)
        self.value.setStyleSheet(
            "font-size: 11px; font-weight: 700; color: #e6edf3;"
            " background: transparent; border: none;"
        )
        # Uzun bir deger kutuyu genisletip pop-up'i sismesin; sigmayan kisim
        # "..." ile kisalir.
        self.value.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.value.setMinimumWidth(0)
        self.bar = MetricSparkBar(accent, self)

        layout.addWidget(self.label)
        layout.addWidget(self.value)
        layout.addWidget(self.bar)

    def _apply_value_text(self) -> None:
        available = max(8, self.value.width())
        metrics = QFontMetrics(self.value.font())
        self.value.setText(
            metrics.elidedText(self._value_text, Qt.TextElideMode.ElideRight, available)
        )

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._apply_value_text()

    def update_metric(self, entry: dict) -> None:
        self.label.setText(str(entry.get("label", "")).upper())
        self._value_text = str(entry.get("value", "\u2014"))
        self._apply_value_text()
        self.bar.set_ratio(entry.get("ratio"))
        detail = str(entry.get("detail", "") or "")
        self.setToolTip(f"{entry.get('label', '')}: {self._value_text}\n{detail}".strip())


class NetworkPulse(QWidget):
    """Ag durumunu gosteren, cevrimiciyken nefes alan nokta."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._online = True
        self._phase = 0.0
        self.setFixedSize(10, 10)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._timer = QTimer(self)
        self._timer.setInterval(90)
        self._timer.timeout.connect(self._advance)

    def set_online(self, online: bool) -> None:
        if bool(online) != self._online:
            self._phase = 0.0
        self._online = bool(online)
        self.update()

    def _advance(self) -> None:
        self._phase = (self._phase + 0.08) % 1.0
        self.update()

    def start(self) -> None:
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        core = QColor("#2ea043") if self._online else QColor("#f85149")
        painter.setPen(Qt.PenStyle.NoPen)
        center = self.rect().center()
        if self._online:
            wave = abs(0.5 - self._phase) * 2.0
            halo = QColor(core)
            halo.setAlpha(int(30 + 55 * wave))
            spread = 1.0 + 3.0 * (1.0 - wave)
            painter.setBrush(halo)
            painter.drawEllipse(QPointF(center.x() + 0.5, center.y() + 0.5),
                                2.5 + spread, 2.5 + spread)
        painter.setBrush(core)
        painter.drawEllipse(QPointF(center.x() + 0.5, center.y() + 0.5), 2.6, 2.6)


class MenuDashboardPopup(QDialog):
    history_requested = pyqtSignal()
    bookmarks_requested = pyqtSignal()
    settings_requested = pyqtSignal()
    downloads_requested = pyqtSignal()
    awareness_requested = pyqtSignal()
    extensions_requested = pyqtSignal()
    ai_requested = pyqtSignal()

    def __init__(self, stats_provider: Callable[[], dict], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.stats_provider = stats_provider
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setObjectName("AsterDashboardPopupHost")
        self.setStyleSheet("""
            QDialog#AsterDashboardPopupHost {
                background: #131720;
                border: 1px solid #28303e;
                border-radius: 10px;
            }
            QFrame#AsterPageShell {
                background: transparent;
                border: none;
            }
            QLabel {
                background: transparent;
                border: none;
            }
            QFrame#AsterMenuTile QLabel {
                background: transparent;
                border: none;
            }
            QFrame#AsterMetricChip {
                background: rgba(255, 255, 255, 0.035);
                border: 1px solid rgba(255, 255, 255, 0.055);
                border-radius: 6px;
            }
            QFrame#AsterMetricChip:hover {
                background: rgba(255, 255, 255, 0.07);
                border-color: rgba(255, 255, 255, 0.12);
            }
            QFrame#AsterStatsStrip {
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid #28303e;
                border-radius: 6px;
            }
            QPushButton#SecondaryButton {
                background: #1a202c;
                border: 1px solid #2a3344;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
                color: #e2e8f0;
            }
            QPushButton#SecondaryButton:hover {
                background: #252d3d;
                border-color: #3b4759;
            }
        """)
        self._build_ui()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(2500)
        self._refresh_timer.timeout.connect(self.refresh_stats)

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        self.shell.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(12, 12, 12, 12)
        shell_layout.setSpacing(10)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        grid.setContentsMargins(0, 0, 0, 0)

        tiles = [
            (tr("History"), tr("Visited pages"), "history", self.history_requested),
            (tr("Bookmarks"), tr("Saved pages"), "bookmark", self.bookmarks_requested),
            (tr("Settings"), tr("Browser preferences"), "settings", self.settings_requested),
            (tr("Downloads"), tr("Files and downloads"), "download", self.downloads_requested),
            (tr("Awareness"), tr("Timers and screen time"), "awareness", self.awareness_requested),
            (tr("Extensions"), tr("Manage add-ons"), "extensions", self.extensions_requested),
        ]
        for index, (title, subtitle, icon_name, signal) in enumerate(tiles):
            tile = MenuTile(title, subtitle, icon_name, self.shell)
            tile.apply_density(1.0)
            tile.clicked.connect(lambda _checked=False, sig=signal: self._emit_then_close(sig))
            grid.addWidget(tile, index // 3, index % 3)

        shell_layout.addLayout(grid)

        self.ai_button = QPushButton(tr("Aster AI"), self.shell)
        self.ai_button.setObjectName("SecondaryButton")
        self.ai_button.setIcon(svg_icon("sparkle"))
        self.ai_button.setIconSize(QSize(15, 15))
        self.ai_button.setFixedHeight(30)
        self.ai_button.clicked.connect(lambda _checked=False: self._emit_then_close(self.ai_requested))
        shell_layout.addWidget(self.ai_button)

        self.stats_strip = QFrame(self.shell)
        self.stats_strip.setObjectName("AsterStatsStrip")
        self.stats_strip.setFixedHeight(66)
        stats_layout = QHBoxLayout(self.stats_strip)
        stats_layout.setContentsMargins(7, 6, 7, 6)
        stats_layout.setSpacing(5)

        self.metric_chips: dict[str, MetricChip] = {}
        for key, accent in (
            ("memory", QColor("#3b82f6")),
            ("cpu", QColor("#a371f7")),
            ("tabs", QColor("#2ea043")),
            ("screen", QColor("#d29922")),
        ):
            chip = MetricChip(accent, self.stats_strip)
            self.metric_chips[key] = chip
            stats_layout.addWidget(chip, 1)

        network_box = QFrame(self.stats_strip)
        network_box.setObjectName("AsterMetricChip")
        network_box.setFixedWidth(64)
        network_layout = QVBoxLayout(network_box)
        network_layout.setContentsMargins(6, 6, 6, 6)
        network_layout.setSpacing(3)
        network_caption = QLabel("NET", network_box)
        network_caption.setStyleSheet(
            "font-size: 7.5px; font-weight: 700; letter-spacing: 0.6px;"
            " color: #74808f; background: transparent; border: none;"
        )
        self.network_pulse = NetworkPulse(network_box)
        self.network_label = QLabel("\u2014", network_box)
        self.network_label.setStyleSheet(
            "font-size: 9.5px; font-weight: 700; color: #e6edf3;"
            " background: transparent; border: none;"
        )
        pulse_row = QHBoxLayout()
        pulse_row.setContentsMargins(0, 0, 0, 0)
        pulse_row.setSpacing(4)
        pulse_row.addWidget(self.network_pulse)
        pulse_row.addWidget(self.network_label, 1)
        network_layout.addWidget(network_caption)
        network_layout.addLayout(pulse_row)
        network_layout.addStretch(1)
        stats_layout.addWidget(network_box)

        shell_layout.addWidget(self.stats_strip)

        outer.addWidget(self.shell)
        self.refresh_stats()

    def _emit_then_close(self, signal) -> None:
        try:
            signal.emit()
        finally:
            self.close()

    def refresh_stats(self) -> None:
        try:
            data = self.stats_provider() or {}
        except Exception:
            data = {}
        for key, chip in self.metric_chips.items():
            entry = data.get(key)
            if isinstance(entry, dict):
                chip.update_metric(entry)
            else:
                chip.update_metric({"label": key, "value": "\u2014", "ratio": None})
        network = data.get("network") if isinstance(data.get("network"), dict) else {}
        online = bool(network.get("online", False))
        self.network_pulse.set_online(online)
        self.network_label.setText(str(network.get("value", "\u2014")))
        self.network_label.setStyleSheet(
            "font-size: 9.5px; font-weight: 700; background: transparent; border: none;"
            " color: %s;" % ("#e6edf3" if online else "#f85149")
        )
        self.adjustSize()

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_stats()
        self._refresh_timer.start()
        self.network_pulse.start()

    def hideEvent(self, event) -> None:  # type: ignore[override]
        self._refresh_timer.stop()
        self.network_pulse.stop()
        super().hideEvent(event)


class _PageShell(QWidget):
    def __init__(self, title: str, subtitle: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        outer = QVBoxLayout(self)
        
        # Kenar boşluklarını 0 veya çok az (örneğin 10) yaparak tam ekran hissi veriyoruz
        outer.setContentsMargins(10, 10, 10, 10) 
        
        row = QHBoxLayout()

        self.shell = QFrame(self)
        self.shell.setObjectName("AsterPageShell")
        
        # KRİTİK: Genişlik ve yükseklik sınırlarını kaldırıp "Expanding" yapıyoruz
        # Bu sayede pencere büyüdükçe içerik de tüm alanı kaplar.
        self.shell.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.shell.setMinimumWidth(0)
        self.shell.setMaximumWidth(16777215) # Qt'nin sonsuz genişlik değeri
        
        shell_layout = QVBoxLayout(self.shell)
        shell_layout.setContentsMargins(28, 26, 28, 24)
        shell_layout.setSpacing(16)

        self.title_label = QLabel(title, self.shell)
        self.title_label.setObjectName("AsterSettingsTitle")
        self.subtitle_label = QLabel(subtitle, self.shell)
        self.subtitle_label.setObjectName("AsterSettingsSubtitle")
        self.subtitle_label.setWordWrap(True)

        self.card = QFrame(self.shell)
        self.card.setObjectName("AsterSettingsCard")
        self.card_layout = QVBoxLayout(self.card)
        self.card_layout.setContentsMargins(22, 20, 22, 20)
        self.card_layout.setSpacing(14)

        # Kartın (liste kısmının) dikeyde tüm boşluğu doldurmasını sağlar
        self.card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        shell_layout.addWidget(self.title_label)
        shell_layout.addWidget(self.subtitle_label)
        shell_layout.addWidget(self.card, 1) # 1 ekleyerek kartın büyümesini sağlıyoruz

        # Stretcher'ları (addStretch) sildiğimiz için shell tüm satırı kaplayacak
        row.addWidget(self.shell)
        outer.addLayout(row)


class HistoryPageWidget(_PageShell):
    open_url_requested = pyqtSignal(str)

    def __init__(
        self,
        list_provider: Callable[[], list[HistoryResult]],
        search_provider: Callable[[str], list[HistoryResult]],
        parent: QWidget | None = None,
    ) -> None:
        self.list_provider = list_provider
        self.search_provider = search_provider
        super().__init__(tr("History"), tr("Recent pages you opened in Aster. Open any result in this tab with a double click."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Search history by title or URL"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        self.search_button = QPushButton(tr("Search"), self.card)
        self.search_button.clicked.connect(self.refresh_results)
        self.refresh_button = QPushButton(tr("Refresh"), self.card)
        self.refresh_button.setObjectName("SecondaryButton")
        self.refresh_button.clicked.connect(self.refresh_results)
        row.addWidget(self.search_edit, 1)
        row.addWidget(self.search_button)
        row.addWidget(self.refresh_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        self.list_widget.setSpacing(6)  # Öğeler arasına 6 piksellik boşluk bırakır
        self.list_widget.setIconSize(QSize(36, 22))  # Soldaki favicon/ikon boyutunu belirler
        self.list_widget.setStyleSheet(
            "QListWidget::item { padding: 6px; border-radius: 6px; }"
        )
        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def refresh_results(self) -> None:
        # İkon işlemleri için gerekli araçları dahil ediyoruz
        from PyQt6.QtGui import QPixmap, QPainter, QIcon
        from PyQt6.QtCore import Qt
        
        query = self.search_edit.text().strip()
        results = self.search_provider(query) if query else self.list_provider()
        self.list_widget.clear()
        
        for entry in results:
            title = (entry.title or entry.url or tr("Page")).strip()
            details = tr("Visited {count} time(s) · Last visited {timestamp}").format(count=entry.visit_count, timestamp=_format_timestamp(entry.last_visited))
            text = f"{title}\n{entry.url}\n{details}"
            item = QListWidgetItem(text)
            
            # --- FAVICON BOŞLUK (PADDING) AYARI ---
            # 1. Gerçek ikonu 22x22 boyutunda oluşturuyoruz
            icon_pixmap = svg_icon("history").pixmap(22, 22)
            
            # 2. 36x22 boyutunda tamamen şeffaf bir arka plan hazırlıyoruz
            padded_pixmap = QPixmap(36, 22)
            padded_pixmap.fill(Qt.GlobalColor.transparent)
            
            # 3. İkonu bu şeffaf arka planın en soluna (0, 0 noktasına) çiziyoruz
            painter = QPainter(padded_pixmap)
            painter.drawPixmap(0, 0, icon_pixmap)
            painter.end()
            
            # 4. Boşluklu yeni ikonu listeye atıyoruz
            item.setIcon(QIcon(padded_pixmap))
            # --------------------------------------
            
            item.setData(Qt.ItemDataRole.UserRole, entry.url)
            self.list_widget.addItem(item)
            
        count = self.list_widget.count()
        self.status_label.setText(tr("1 entry shown.") if count == 1 else tr("{count} entries shown.").format(count=count))

    def _open_item(self, item: QListWidgetItem) -> None:
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if url:
            self.open_url_requested.emit(url)

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()


class BookmarksPageWidget(_PageShell):
    open_url_requested = pyqtSignal(str)
    remove_requested = pyqtSignal(str)
    save_current_requested = pyqtSignal()

    def __init__(
        self,
        list_provider: Callable[[], list[BookmarkResult]],
        search_provider: Callable[[str], list[BookmarkResult]],
        parent: QWidget | None = None,
    ) -> None:
        self.list_provider = list_provider
        self.search_provider = search_provider
        super().__init__(tr("Bookmarks"), tr("Saved pages stay here so you can reopen them quickly inside Aster."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Search bookmarks by title or URL"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        search_button = QPushButton(tr("Search"), self.card)
        search_button.clicked.connect(self.refresh_results)
        refresh_button = QPushButton(tr("Refresh"), self.card)
        refresh_button.setObjectName("SecondaryButton")
        refresh_button.clicked.connect(self.refresh_results)
        save_button = QPushButton(tr("Bookmark current page"), self.card)
        save_button.clicked.connect(lambda _checked=False: self.save_current_requested.emit())
        row.addWidget(self.search_edit, 1)
        row.addWidget(search_button)
        row.addWidget(refresh_button)
        row.addWidget(save_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        remove_button = QPushButton(tr("Remove selected"), self.card)
        remove_button.setObjectName("SecondaryButton")
        remove_button.clicked.connect(self._remove_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)
        footer.addWidget(remove_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def refresh_results(self) -> None:
        query = self.search_edit.text().strip()
        results = self.search_provider(query) if query else self.list_provider()
        self.list_widget.clear()
        for entry in results:
            title = (entry.title or entry.url or tr("Bookmark")).strip()
            details = tr("Saved {created} · Last used {used}").format(created=_format_timestamp(entry.created_at), used=_format_timestamp(entry.last_used))
            text = f"{title}\n{entry.url}\n{details}"
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, entry.url)
            self.list_widget.addItem(item)
        count = self.list_widget.count()
        self.status_label.setText(tr("1 bookmark shown.") if count == 1 else tr("{count} bookmarks shown.").format(count=count))

    def _open_item(self, item: QListWidgetItem) -> None:
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if url:
            self.open_url_requested.emit(url)

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def _remove_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is None:
            return
        url = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if not url:
            return
        self.remove_requested.emit(url)
        self.refresh_results()

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()


class DownloadsPageWidget(_PageShell):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(tr("Downloads"), tr("Your Aster downloads folder shown inside a browser tab. Double click a file to open it."), parent)
        self._build_content()
        self.refresh_results()

    def _build_content(self) -> None:
        row = QHBoxLayout()
        row.setSpacing(10)
        self.search_edit = QLineEdit(self.card)
        self.search_edit.setPlaceholderText(tr("Filter downloaded files by name"))
        self.search_edit.returnPressed.connect(self.refresh_results)
        search_button = QPushButton(tr("Search"), self.card)
        search_button.clicked.connect(self.refresh_results)
        refresh_button = QPushButton(tr("Refresh"), self.card)
        refresh_button.setObjectName("SecondaryButton")
        refresh_button.clicked.connect(self.refresh_results)
        open_folder_button = QPushButton(tr("Open downloads folder"), self.card)
        open_folder_button.clicked.connect(self.open_downloads_folder)
        row.addWidget(self.search_edit, 1)
        row.addWidget(search_button)
        row.addWidget(refresh_button)
        row.addWidget(open_folder_button)

        self.list_widget = QListWidget(self.card)
        self.list_widget.itemDoubleClicked.connect(self._open_item)
        self.list_widget.itemActivated.connect(self._open_item)

        # YENİ: Geçmiş sayfasıyla tutarlı liste tasarımı ve boşluklar
        self.list_widget.setSpacing(6) # Öğeler arası 6 piksellik boşluk
        self.list_widget.setIconSize(QSize(36, 22)) # İkon için ayrılan alan
        self.list_widget.setStyleSheet(
            "QListWidget::item { padding: 6px; border-radius: 6px; }"
        )

        footer = QHBoxLayout()
        self.status_label = QLabel("", self.card)
        self.status_label.setObjectName("AsterFooterInfo")
        self.status_label.setWordWrap(True)
        open_button = QPushButton(tr("Open selected"), self.card)
        open_button.clicked.connect(self._open_selected)
        footer.addWidget(self.status_label, 1)
        footer.addWidget(open_button)

        self.card_layout.addLayout(row)
        self.card_layout.addWidget(self.list_widget, 1)
        self.card_layout.addLayout(footer)

    def _entries(self) -> list[DownloadEntry]:
        # Bu kısım paths.py'de güncellediğimiz yeni indirme yolunu kullanır
        base = downloads_dir()
        base.mkdir(parents=True, exist_ok=True)
        entries: list[DownloadEntry] = []
        for path in base.iterdir():
            try:
                if not path.is_file():
                    continue
                stat = path.stat()
            except Exception:
                continue
            entries.append(DownloadEntry(path=path, size_bytes=int(stat.st_size), modified_at=float(stat.st_mtime)))
        entries.sort(key=lambda item: item.modified_at, reverse=True)
        query = self.search_edit.text().strip().lower()
        if query:
            entries = [item for item in entries if query in item.path.name.lower()]
        return entries

    def refresh_results(self) -> None:
        # İkon işlemleri için gerekli araçları dahil ediyoruz
        from PyQt6.QtGui import QPixmap, QPainter, QIcon
        from PyQt6.QtCore import Qt

        self.list_widget.clear()
        entries = self._entries()
        for entry in entries:
            details = tr("{size} · Modified {timestamp}").format(size=_format_bytes(entry.size_bytes), timestamp=_format_timestamp(entry.modified_at))
            text = f"{entry.path.name}\n{entry.path}\n{details}"
            item = QListWidgetItem(text)
            
            # --- DOSYA İKONU VE BOŞLUK AYARI ---
            # Geçmiş sayfasındaki pürüzsüz ikon padding mantığının aynısını uyguluyoruz
            icon_pixmap = svg_icon("download").pixmap(22, 22)
            
            # 36x22 boyutunda tamamen şeffaf bir arka plan
            padded_pixmap = QPixmap(36, 22)
            padded_pixmap.fill(Qt.GlobalColor.transparent)
            
            # İkonu bu şeffaf alanın en soluna çiziyoruz
            painter = QPainter(padded_pixmap)
            painter.drawPixmap(0, 0, icon_pixmap)
            painter.end()
            
            item.setIcon(QIcon(padded_pixmap))
            # ----------------------------------
            
            item.setData(Qt.ItemDataRole.UserRole, str(entry.path))
            self.list_widget.addItem(item)
            
        count = self.list_widget.count()
        self.status_label.setText(tr("1 file shown from {path}.").format(path=downloads_dir()) if count == 1 else tr("{count} files shown from {path}.").format(count=count, path=downloads_dir()))

    def _open_item(self, item: QListWidgetItem) -> None:
        path_text = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if not path_text:
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path_text).resolve())))

    def _open_selected(self) -> None:
        item = self.list_widget.currentItem()
        if item is not None:
            self._open_item(item)

    def open_downloads_folder(self) -> None:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(downloads_dir().resolve())))

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self.refresh_results()

class RingProgressWidget(QWidget):
    """Ortasindaki yazi halkanin icine SIGACAK sekilde kuculen ilerleme halkasi."""

    def __init__(
        self,
        accent_color: QColor,
        track_color: QColor,
        parent: QWidget | None = None,
        diameter: int = 96,
    ) -> None:
        super().__init__(parent)
        self._progress = 0.0
        self._accent_color = QColor(accent_color)
        self._track_color = QColor(track_color)
        self._center_text = ""
        self._caption = ""
        self._diameter = int(diameter)
        self.setFixedSize(self._diameter, self._diameter)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

    def sizeHint(self) -> QSize:
        return QSize(self._diameter, self._diameter)

    def set_progress(self, value: float) -> None:
        self._progress = max(0.0, min(1.0, float(value)))
        self.update()

    def set_center_text(self, text: str) -> None:
        self._center_text = text or ""
        self.update()

    def set_caption(self, text: str) -> None:
        self._caption = text or ""
        self.update()

    def set_accent(self, color: QColor) -> None:
        self._accent_color = QColor(color)
        self.update()

    def _fitted_font(self, text: str, available: float, base_ratio: float, floor: float) -> QFont:
        font = QFont(self.font())
        font.setWeight(QFont.Weight.Bold)
        size = max(floor, self.height() * base_ratio)
        font.setPointSizeF(size)
        while size > floor:
            if QFontMetrics(font).horizontalAdvance(text) <= available:
                break
            size -= 0.5
            font.setPointSizeF(size)
        return font

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        side = min(self.width(), self.height())
        ring_width = max(5.0, side * 0.085)
        pad = ring_width / 2.0 + 1.0
        rect = QRectF(pad, pad, side - 2 * pad, side - 2 * pad)

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        painter.setPen(QPen(self._track_color, ring_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(rect, 0, 360 * 16)

        if self._progress > 0.0:
            painter.setPen(QPen(self._accent_color, ring_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawArc(rect, 90 * 16, int(-360 * 16 * self._progress))

        # Yazi alani: halkanin ic capindan biraz daha dar tutuluyor.
        inner = (side - 2 * (ring_width + 3)) * 0.92
        painter.setPen(QColor("#e6edf3"))
        value_font = self._fitted_font(self._center_text, inner, 0.185, 7.0)
        painter.setFont(value_font)
        value_h = QFontMetrics(value_font).height()

        if self._caption:
            caption_font = QFont(self.font())
            caption_font.setPointSizeF(max(6.5, side * 0.085))
            caption_h = QFontMetrics(caption_font).height()
            total = value_h + caption_h
            top = (side - total) / 2.0
            painter.drawText(
                QRectF(0, top, side, value_h),
                Qt.AlignmentFlag.AlignCenter,
                self._center_text,
            )
            painter.setFont(caption_font)
            painter.setPen(QColor("#8b949e"))
            painter.drawText(
                QRectF(0, top + value_h, side, caption_h),
                Qt.AlignmentFlag.AlignCenter,
                self._caption,
            )
        else:
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._center_text)


class _AwarenessStatRow(QFrame):
    """Ekran suresi sekmesindeki tek satirlik kompakt olcum."""

    def __init__(self, label: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AsterAwarenessStat")
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        self.label = QLabel(label.upper(), self)
        self.label.setStyleSheet(
            "font-size: 7.5px; font-weight: 700; letter-spacing: 0.6px;"
            " color: #74808f; background: transparent; border: none;"
        )
        self.value = QLabel("-", self)
        self.value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.value.setStyleSheet(
            "font-size: 11.5px; font-weight: 700; color: #e6edf3;"
            " background: transparent; border: none;"
        )
        row.addWidget(self.label)
        row.addStretch(1)
        row.addWidget(self.value)

    def set_value(self, text: str) -> None:
        self.value.setText(text)


class _CompactStepper(QWidget):
    """Kucuk bir [-] deger [+] adimlayicisi.

    QSpinBox'in yukari/asagi oklari Fusion temasinda bos kare olarak
    ciziliyordu ve QSS ile duzeltilemiyordu; bunun yerine kendi
    dugmelerimizi kullaniyoruz. QSpinBox ile ayni cagri yuzeyini sunar.
    """

    valueChanged = pyqtSignal(int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._min, self._max, self._value = 1, 99, 1
        self._suffix = ''

        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)

        self.minus = QPushButton('\u2212', self)
        self.plus = QPushButton('+', self)
        for button in (self.minus, self.plus):
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFixedSize(22, 22)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            # Stili DOGRUDAN butona veriyoruz: panel duzeyindeki QSS,
            # uygulama genelindeki QPushButton kurallarinin altinda
            # kalabiliyor ve buton zeminini hic cizmiyordu.
            button.setStyleSheet(
                'QPushButton { background: #0d1117; color: #c9d1d9;'
                ' border: 1px solid #30363d; border-radius: 11px;'
                ' font-size: 14px; font-weight: 700; padding: 0px 0px 2px 0px; }'
                'QPushButton:hover { background: #21262d; color: #ffffff;'
                ' border-color: #3d4758; }'
                'QPushButton:disabled { color: #4b535f; border-color: #262c36; }'
            )

        self.display = QLabel('', self)
        self.display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.display.setMinimumWidth(56)
        self.display.setStyleSheet(
            'color: #e6edf3; font-size: 11.5px; font-weight: 700;'
            ' background: transparent; border: none;'
        )

        row.addWidget(self.minus)
        row.addWidget(self.display)
        row.addWidget(self.plus)
        self.minus.clicked.connect(lambda: self.setValue(self._value - 1))
        self.plus.clicked.connect(lambda: self.setValue(self._value + 1))

    def setRange(self, minimum: int, maximum: int) -> None:
        self._min, self._max = int(minimum), int(maximum)
        self.setValue(self._value)

    def setSuffix(self, suffix: str) -> None:
        self._suffix = suffix or ''
        self._render()

    def value(self) -> int:
        return self._value

    def setValue(self, value: int) -> None:
        clamped = max(self._min, min(self._max, int(value)))
        changed = clamped != self._value
        self._value = clamped
        self._render()
        if changed and not self.signalsBlocked():
            self.valueChanged.emit(clamped)

    def _render(self) -> None:
        self.display.setText(f'{self._value}{self._suffix}')
        self.minus.setEnabled(self._value > self._min)
        self.plus.setEnabled(self._value < self._max)


class AwarenessPageWidget(QWidget):
    """Odak / kronometre / ekran suresi: kompakt, tek karttan olusan panel."""

    ACCENTS = {0: QColor("#2ea043"), 1: QColor("#3b82f6"), 2: QColor("#d29922")}

    def __init__(
        self,
        metrics_provider: Callable[[], dict[str, int]],
        limit_callback: Callable[[int], None],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.metrics_provider = metrics_provider
        self.limit_callback = limit_callback
        self._chrono_elapsed_seconds = 0
        self._chrono_running = False

        self.setObjectName("AsterAwarenessPanel")
        self._build_ui()

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(1000)
        self._refresh_timer.timeout.connect(self._tick)
        self._refresh_timer.start()

        global_focus_manager.tick.connect(self._on_global_focus_tick)
        global_focus_manager.finished.connect(self._on_global_focus_finished)

        self.focus_minutes_spin.setValue(max(1, global_focus_manager.total_seconds // 60))
        self._on_global_focus_tick(
            global_focus_manager.remaining_seconds, global_focus_manager.total_seconds
        )
        self._refresh_chrono_ui()
        self.refresh_screen_metrics()

    # --- kurulum ----------------------------------------------------------

    def _build_ui(self) -> None:
        self.setStyleSheet("""
            QWidget#AsterAwarenessPanel { background: transparent; }
            QFrame#AsterAwarenessCard {
                background: #131720;
                border: 1px solid #28303e;
                border-radius: 10px;
            }
            QFrame#AsterAwarenessCard QLabel { background: transparent; border: none; }
            QFrame#AsterSegmentBar {
                background: #0d1117;
                border: 1px solid #28303e;
                border-radius: 8px;
            }
            QPushButton#AsterSegment {
                background: transparent; color: #8b949e; border: none;
                border-radius: 6px; padding: 4px 10px;
                font-size: 11px; font-weight: 600;
            }
            QPushButton#AsterSegment:hover { color: #e6edf3; }
            QPushButton#AsterSegment:checked {
                background: #21262d; color: #e6edf3; border: 1px solid #30363d;
            }
        """)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        card = QFrame(self)
        card.setObjectName("AsterAwarenessCard")
        card.setFixedWidth(296)
        body = QVBoxLayout(card)
        body.setContentsMargins(12, 11, 12, 12)
        body.setSpacing(10)

        segment_bar = QFrame(card)
        segment_bar.setObjectName("AsterSegmentBar")
        seg_row = QHBoxLayout(segment_bar)
        seg_row.setContentsMargins(3, 3, 3, 3)
        seg_row.setSpacing(3)
        self.segment_group = QButtonGroup(self)
        self.segment_group.setExclusive(True)
        self.segment_buttons: list[QPushButton] = []
        for index, title in enumerate(("Focus", "Timer", "Screen")):
            button = QPushButton(title, segment_bar)
            button.setObjectName("AsterSegment")
            button.setCheckable(True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _checked=False, value=index: self._set_mode(value))
            self.segment_group.addButton(button, index)
            self.segment_buttons.append(button)
            seg_row.addWidget(button, 1)
        self.segment_buttons[0].setChecked(True)
        body.addWidget(segment_bar)

        self.stack = QStackedWidget(card)
        self.stack.setStyleSheet("background: transparent; border: none;")
        self.stack.addWidget(self._build_focus_page())
        self.stack.addWidget(self._build_chrono_page())
        self.stack.addWidget(self._build_screen_page())
        body.addWidget(self.stack)

        outer.addWidget(card, 0, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)

    def _round_button(self, icon_name: str, tooltip: str, primary: bool = False) -> QPushButton:
        button = QPushButton(self)
        button.setIcon(svg_icon(icon_name))
        button.setIconSize(QSize(15, 15))
        button.setFixedSize(34, 34)
        # Stili DOGRUDAN butona veriyoruz: panel duzeyindeki QSS uygulama
        # genelindeki QPushButton kurallarinin altinda kalabiliyor ve buton
        # yuvarlak zeminini hic cizmiyordu.
        if primary:
            button.setStyleSheet(
                'QPushButton { background: #1f6feb; border: 1px solid #1f6feb;'
                ' border-radius: 17px; padding: 0px; }'
                'QPushButton:hover { background: #388bfd; border-color: #388bfd; }'
                'QPushButton:pressed { background: #1a5fd0; }'
            )
        else:
            button.setStyleSheet(
                'QPushButton { background: #0d1117; border: 1px solid #30363d;'
                ' border-radius: 17px; padding: 0px; }'
                'QPushButton:hover { background: #21262d; border-color: #3d4758; }'
                'QPushButton:pressed { background: #161b22; }'
            )
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        button.setToolTip(tooltip)
        return button

    def _ring_row(self, ring: RingProgressWidget) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addStretch(1)
        row.addWidget(ring)
        row.addStretch(1)
        return row

    def _build_focus_page(self) -> QWidget:
        page = QWidget(self.stack)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 4, 0, 0)
        layout.setSpacing(9)

        self.focus_ring = RingProgressWidget(self.ACCENTS[0], QColor("#21262d"), page)
        self.focus_ring.set_center_text("05:00")
        self.focus_ring.set_caption("remaining")

        # Kontroller halkanin soluna (sifirla) ve saguna (baslat/duraklat) aliniyor.
        self.focus_reset_button = self._round_button("media_reset", "Reset focus session")
        self.focus_reset_button.clicked.connect(self._reset_focus)
        self.focus_start_button = self._round_button("media_play", "Start focus session", primary=True)
        self.focus_start_button.clicked.connect(self._toggle_focus)

        ring_row = QHBoxLayout()
        ring_row.setContentsMargins(0, 0, 0, 0)
        ring_row.setSpacing(10)
        ring_row.addStretch(1)
        ring_row.addWidget(self.focus_reset_button, 0, Qt.AlignmentFlag.AlignVCenter)
        ring_row.addWidget(self.focus_ring)
        ring_row.addWidget(self.focus_start_button, 0, Qt.AlignmentFlag.AlignVCenter)
        ring_row.addStretch(1)
        layout.addLayout(ring_row)

        limit_row = QHBoxLayout()
        limit_row.setSpacing(8)
        limit_label = QLabel("DURATION", page)
        limit_label.setStyleSheet(
            "font-size: 7.5px; font-weight: 700; letter-spacing: 0.6px; color: #74808f;"
        )
        self.focus_minutes_spin = _CompactStepper(page)
        self.focus_minutes_spin.setRange(1, 240)
        self.focus_minutes_spin.setSuffix(" min")
        self.focus_minutes_spin.setValue(5)
        self.focus_minutes_spin.valueChanged.connect(self._on_focus_minutes_changed)
        limit_row.addWidget(limit_label)
        limit_row.addStretch(1)
        limit_row.addWidget(self.focus_minutes_spin)
        layout.addLayout(limit_row)
        return page

    def _build_chrono_page(self) -> QWidget:
        page = QWidget(self.stack)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 4, 0, 0)
        layout.setSpacing(9)

        self.chrono_ring = RingProgressWidget(self.ACCENTS[1], QColor("#21262d"), page)
        self.chrono_ring.set_progress(1.0)
        self.chrono_ring.set_center_text("00:00:00")
        self.chrono_ring.set_caption("elapsed")

        self.chrono_reset_button = self._round_button("media_reset", "Reset timer")
        self.chrono_reset_button.clicked.connect(self._reset_chrono)
        self.chrono_start_button = self._round_button("media_play", "Start timer", primary=True)
        self.chrono_start_button.clicked.connect(self._toggle_chrono)

        ring_row = QHBoxLayout()
        ring_row.setContentsMargins(0, 0, 0, 0)
        ring_row.setSpacing(10)
        ring_row.addStretch(1)
        ring_row.addWidget(self.chrono_reset_button, 0, Qt.AlignmentFlag.AlignVCenter)
        ring_row.addWidget(self.chrono_ring)
        ring_row.addWidget(self.chrono_start_button, 0, Qt.AlignmentFlag.AlignVCenter)
        ring_row.addStretch(1)
        layout.addLayout(ring_row)
        layout.addStretch(1)
        return page

    def _build_screen_page(self) -> QWidget:
        page = QWidget(self.stack)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 4, 0, 0)
        layout.setSpacing(9)

        top = QHBoxLayout()
        top.setSpacing(12)
        self.screen_ring = RingProgressWidget(self.ACCENTS[2], QColor("#21262d"), page, diameter=84)
        self.screen_ring.set_center_text("0%")
        self.screen_ring.set_caption("of limit")
        top.addWidget(self.screen_ring, 0, Qt.AlignmentFlag.AlignVCenter)

        stats = QVBoxLayout()
        stats.setSpacing(7)
        self.today_row = _AwarenessStatRow("Today", page)
        self.week_row = _AwarenessStatRow("This week", page)
        self.avg_row = _AwarenessStatRow("Daily average", page)
        stats.addWidget(self.today_row)
        stats.addWidget(self.week_row)
        stats.addWidget(self.avg_row)
        top.addLayout(stats, 1)
        layout.addLayout(top)

        limit_row = QHBoxLayout()
        limit_row.setSpacing(8)
        limit_label = QLabel("DAILY LIMIT", page)
        limit_label.setStyleSheet(
            "font-size: 7.5px; font-weight: 700; letter-spacing: 0.6px; color: #74808f;"
        )
        self.limit_spin = _CompactStepper(page)
        self.limit_spin.setRange(1, 24)
        self.limit_spin.setSuffix(" hr")
        self.limit_spin.valueChanged.connect(self._limit_changed)
        limit_row.addWidget(limit_label)
        limit_row.addStretch(1)
        limit_row.addWidget(self.limit_spin)
        layout.addLayout(limit_row)
        return page

    # --- davranis ---------------------------------------------------------

    @staticmethod
    def _set_play_state(button: QPushButton, running: bool) -> None:
        button.setIcon(svg_icon("media_pause" if running else "media_play"))
        button.setToolTip("Pause" if running else "Start")

    def _set_mode(self, index: int) -> None:
        self.stack.setCurrentIndex(max(0, min(index, self.stack.count() - 1)))

    def _on_focus_minutes_changed(self, value: int) -> None:
        global_focus_manager.set_minutes(value)

    def _toggle_focus(self) -> None:
        global_focus_manager.toggle()

    def _reset_focus(self) -> None:
        global_focus_manager.reset()

    def _on_global_focus_tick(self, remaining: int, total: int) -> None:
        total = max(1, total)
        self.focus_ring.set_progress(1.0 - (remaining / total))
        text = _format_hms(remaining)
        self.focus_ring.set_center_text(text[3:] if total < 3600 else text)
        self._set_play_state(self.focus_start_button, global_focus_manager.is_running)

    def _on_global_focus_finished(self) -> None:
        self._set_play_state(self.focus_start_button, False)

    def _toggle_chrono(self) -> None:
        self._chrono_running = not self._chrono_running
        self._refresh_chrono_ui()

    def _reset_chrono(self) -> None:
        self._chrono_running = False
        self._chrono_elapsed_seconds = 0
        self._refresh_chrono_ui()

    def _refresh_chrono_ui(self) -> None:
        self.chrono_ring.set_progress(1.0)
        self.chrono_ring.set_center_text(_format_hms(self._chrono_elapsed_seconds))
        self._set_play_state(self.chrono_start_button, self._chrono_running)

    def _limit_changed(self, value: int) -> None:
        self.limit_callback(max(60, int(value) * 60))
        self.refresh_screen_metrics()

    def refresh_screen_metrics(self) -> None:
        metrics = self.metrics_provider() or {}
        today = int(metrics.get("today_seconds", 0) or 0)
        weekly = int(metrics.get("weekly_seconds", 0) or 0)
        avg = int(metrics.get("weekly_average_seconds", 0) or 0)
        limit_minutes = int(metrics.get("daily_limit_minutes", 120) or 120)
        limit_seconds = max(3600, limit_minutes * 60)

        self.limit_spin.blockSignals(True)
        self.limit_spin.setValue(max(1, round(limit_minutes / 60)))
        self.limit_spin.blockSignals(False)

        ratio = today / limit_seconds
        self.screen_ring.set_progress(min(1.0, ratio))
        self.screen_ring.set_center_text(f"{round(ratio * 100)}%")
        # Limit asildiysa halka kirmiziya doner.
        self.screen_ring.set_accent(QColor("#f85149") if ratio >= 1.0 else self.ACCENTS[2])

        self.today_row.set_value(_format_minutes_text(today))
        self.week_row.set_value(_format_minutes_text(weekly))
        self.avg_row.set_value(_format_minutes_text(avg))

    def _tick(self) -> None:
        if self._chrono_running:
            self._chrono_elapsed_seconds += 1
            self._refresh_chrono_ui()
        self.refresh_screen_metrics()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.refresh_screen_metrics()


class AwarenessPopup(QDialog):
    """Awareness panelini tasiyan pop-up.

    Onceden QMenu + QWidgetAction kullaniliyordu; QMenu, uzerindeki herhangi bir
    tiklamayi kendi kapanma jesti sayiyor, bu yuzden panelin bos bir yerine
    tiklamak pop-up'i kapatiyordu. QDialog + Popup bayragi ile yalnizca DISARI
    tiklayinca kapaniyor, icerideki tiklamalar widget'lara gidiyor.
    """

    def __init__(
        self,
        metrics_provider: Callable[[], dict[str, int]],
        limit_callback: Callable[[int], None],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setObjectName("AsterAwarenessPopupHost")
        self.setStyleSheet(
            "QDialog#AsterAwarenessPopupHost { background: transparent; border: none; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.panel = AwarenessPageWidget(metrics_provider, limit_callback, self)
        layout.addWidget(self.panel)
        self.adjustSize()
