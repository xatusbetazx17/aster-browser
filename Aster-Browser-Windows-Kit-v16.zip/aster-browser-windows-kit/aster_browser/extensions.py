from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import zipfile
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .paths import ensure_directories, extensions_dir

_SAFE_ID = re.compile(r"[^a-zA-Z0-9._-]+")
_SCRIPT_PREFIX = "aster-ext-"
_SUPPORTED_ARCHIVES = {".zip", ".xpi", ".crx"}


@dataclass
class ExtensionRecord:
    ext_id: str
    name: str
    version: str
    description: str
    manifest_version: int
    source_kind: str
    runtime_kind: str
    enabled: bool
    source_path: str
    managed_path: str
    status: str = "ready"
    note: str = ""

    @property
    def short_label(self) -> str:
        return f"{self.name} {self.version}".strip()

    def display_line(self) -> str:
        enabled = "enabled" if self.enabled else "disabled"
        status = self.status or "ready"
        base = f"{self.name} {self.version} [{self.runtime_kind} | {self.source_kind} | {enabled} | {status}]"
        if self.note:
            return f"{base}\n  {self.note}"
        return base


class WebExtensionRegistry:
    def __init__(self, root: Path | None = None) -> None:
        ensure_directories()
        self.root = (root or extensions_dir()).expanduser().resolve()
        self.sources_dir = self.root / "sources"
        self.registry_path = self.root / "registry.json"
        self.sources_dir.mkdir(parents=True, exist_ok=True)
        self.records: dict[str, ExtensionRecord] = {}
        self._load_registry()
        self._native_connections: set[int] = set()
        self._generation: int = 1

    def _load_registry(self) -> None:
        self.records = {}
        if not self.registry_path.exists():
            return
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
        except Exception:
            return
        if not isinstance(data, list):
            return
        for item in data:
            if not isinstance(item, dict):
                continue
            try:
                record = ExtensionRecord(**item)
            except Exception:
                continue
            self.records[record.ext_id] = record

    def _save_registry(self) -> None:
        payload = [asdict(record) for record in sorted(self.records.values(), key=lambda item: item.name.lower())]
        self.registry_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        self._generation += 1

    def list_records(self) -> list[ExtensionRecord]:
        return sorted(self.records.values(), key=lambda item: item.name.lower())

    def summary_text(self) -> str:
        records = self.list_records()
        if not records:
            return (
                "No browser extensions installed yet. Open the Extensions dialog or use /install-extension with a path to an unpacked extension, .zip, .xpi, or .crx file. "
                "Manifest V3 extensions can use Qt WebEngine's native loader when Qt/PyQt6-WebEngine 6.10+ is available; simpler Manifest V2 content-script extensions can fall back to Aster injection. Aster defaults to safe mode for stability and lets you opt into the native MV3 loader later."
            )
        lines = ["Installed extensions:"]
        for index, record in enumerate(records, start=1):
            lines.append(f"{index}. {record.display_line()}")
        return "\n".join(lines)

    def find_record(self, query: str) -> ExtensionRecord | None:
        query = (query or "").strip().lower()
        if not query:
            return None
        if query in self.records:
            return self.records[query]
        best: ExtensionRecord | None = None
        best_score = -1
        for record in self.list_records():
            haystack = f"{record.ext_id} {record.name} {record.version} {record.description}".lower()
            score = 0
            if query == record.ext_id.lower() or query == record.name.lower():
                score = 100
            elif query in record.name.lower():
                score = 80
            elif query in haystack:
                score = 50
            else:
                terms = [term for term in query.split() if term]
                score = sum(5 for term in terms if term in haystack)
            if score > best_score:
                best = record
                best_score = score
        return best if best_score > 0 else None

    def install(self, source: str | os.PathLike[str]) -> ExtensionRecord:
        source_path = Path(source).expanduser().resolve()
        if not source_path.exists():
            raise FileNotFoundError(source_path)
        temp_root = Path(tempfile.mkdtemp(prefix="aster-ext-", dir=str(self.root)))
        try:
            unpacked_root = temp_root / "source"
            self._materialize_source(source_path, unpacked_root)
            extension_root = self._discover_manifest_root(unpacked_root)
            manifest = self._read_manifest(extension_root)
            record = self._build_record(source_path, extension_root, manifest)
            target_root = self.sources_dir / record.ext_id
            if target_root.exists():
                shutil.rmtree(target_root)
            shutil.copytree(extension_root, target_root)
            record.managed_path = str(target_root)
            record.status = "ready"
            record.note = self._compat_note(manifest, record.runtime_kind, record.source_kind)
            self.records[record.ext_id] = record
            self._save_registry()
            return record
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def install_from_url(self, source_url: str, suggested_name: str = "") -> ExtensionRecord:
        parsed = urlparse(source_url.strip())
        if parsed.scheme not in {"http", "https", "file"}:
            raise ValueError(f"Unsupported extension source URL: {source_url}")
        if parsed.scheme == "file":
            return self.install(Path(unquote(parsed.path)))
        request = Request(
            source_url,
            headers={
                "User-Agent": "Mozilla/5.0 AsterBrowser/0.1",
                "Accept": "application/x-xpinstall, application/x-chrome-extension, application/zip, application/octet-stream, */*",
            },
        )
        fd, temp_name = tempfile.mkstemp(prefix="aster-ext-dl-", suffix=".zip", dir=str(self.root))
        os.close(fd)
        temp_path = Path(temp_name)
        try:
            with urlopen(request, timeout=60) as response:
                final_url = str(response.geturl() or source_url)
                headers = response.headers
                suffix = self._guess_download_suffix(final_url, headers.get("Content-Disposition", ""), str(headers.get_content_type() or ""), suggested_name)
                if suffix not in _SUPPORTED_ARCHIVES:
                    raise ValueError(
                        "This page did not expose a supported extension package. Aster needs a direct .zip, .xpi, or .crx download."
                    )
                desired = temp_path.with_suffix(suffix)
                if desired != temp_path:
                    temp_path.unlink(missing_ok=True)
                    temp_path = desired
                with temp_path.open("wb") as handle:
                    shutil.copyfileobj(response, handle)
            return self.install(temp_path)
        finally:
            temp_path.unlink(missing_ok=True)

    def remove(self, query: str) -> ExtensionRecord | None:
        record = self.find_record(query)
        if record is None:
            return None
        self.records.pop(record.ext_id, None)
        if record.managed_path:
            shutil.rmtree(Path(record.managed_path), ignore_errors=True)
        self._save_registry()
        return record

    def set_enabled(self, query: str, enabled: bool) -> ExtensionRecord | None:
        record = self.find_record(query)
        if record is None:
            return None
        record.enabled = enabled
        if not enabled:
            record.status = "disabled"
        elif record.status == "disabled":
            record.status = "ready"
        self._save_registry()
        return record

    def supports_native_loader(self, profile: Any) -> bool:
        return self._extension_manager(profile) is not None

    def generation(self) -> int:
        return self._generation

    def sync_profile(self, profile: Any, notifier=None, native_enabled: bool = False) -> None:
        self._sync_script_fallback(profile)
        if native_enabled:
            self._sync_native_extensions(profile, notifier=notifier)
        else:
            self._disable_native_extensions(profile)

    def _sync_script_fallback(self, profile: Any) -> None:
        scripts_accessor = getattr(profile, "scripts", None)
        if scripts_accessor is None:
            return
        try:
            script_collection = scripts_accessor() if callable(scripts_accessor) else scripts_accessor
        except Exception:
            return
        if script_collection is None:
            return
        try:
            existing = list(script_collection.toList()) if hasattr(script_collection, "toList") else []
        except Exception:
            existing = []
        for script in existing:
            try:
                name = str(script.name()) if callable(getattr(script, "name", None)) else str(getattr(script, "name", ""))
            except Exception:
                name = ""
            if name.startswith(_SCRIPT_PREFIX):
                try:
                    script_collection.remove(script)
                except Exception:
                    pass
        for record in self.list_records():
            if not record.enabled or record.runtime_kind != "content_script_fallback":
                continue
            for generated in self.build_qt_scripts(record):
                try:
                    script_collection.insert(generated)
                except Exception:
                    continue
            record.status = "loaded"
        self._save_registry()

    def _disable_native_extensions(self, profile: Any) -> None:
        manager = self._extension_manager(profile)
        native_records = [record for record in self.list_records() if record.runtime_kind == "qt_native"]
        if manager is not None:
            try:
                extensions = manager.extensions() if callable(getattr(manager, "extensions", None)) else []
            except Exception:
                extensions = []
            managed_root = str(self.sources_dir.resolve())
            for info in extensions or []:
                path = self._info_path(info)
                if not path or not path.startswith(managed_root):
                    continue
                try:
                    if hasattr(manager, "setExtensionEnabled"):
                        manager.setExtensionEnabled(info, False)
                except Exception:
                    pass
        changed = False
        for record in native_records:
            note = (
                "Native MV3 loading is disabled in Aster safe mode for stability. "
                "Switch Extension backend to native_when_available if you want Qt WebEngine to try loading this extension."
            )
            if record.note != note or record.status != ("disabled" if record.enabled else record.status):
                record.status = "disabled" if record.enabled else record.status
                record.note = note
                changed = True
        if changed:
            self._save_registry()

    def _sync_native_extensions(self, profile: Any, notifier=None) -> None:
        manager = self._extension_manager(profile)
        native_records = [record for record in self.list_records() if record.runtime_kind == "qt_native"]
        if manager is None:
            if native_records:
                for record in native_records:
                    if record.enabled:
                        record.status = "waiting"
                        record.note = (
                            "Native WebExtension loading needs Qt WebEngine/PyQt6-WebEngine 6.10+ with QWebEngineExtensionManager. "
                            "This browser can still use simple content-script fallback extensions."
                        )
                self._save_registry()
            return
        self._connect_native_signals(manager, notifier=notifier)
        loaded_by_path: dict[str, Any] = {}
        try:
            extensions = manager.extensions() if callable(getattr(manager, "extensions", None)) else []
        except Exception:
            extensions = []
        for info in extensions or []:
            path = self._info_path(info)
            if path:
                loaded_by_path[path] = info
        managed_paths = {str(Path(record.managed_path).resolve()): record for record in native_records}
        managed_root = str(self.sources_dir.resolve())
        for path, info in list(loaded_by_path.items()):
            record = managed_paths.get(path)
            if record is None:
                if path.startswith(managed_root):
                    try:
                        if hasattr(manager, "setExtensionEnabled"):
                            manager.setExtensionEnabled(info, False)
                    except Exception:
                        pass
                    try:
                        if hasattr(manager, "unloadExtension"):
                            manager.unloadExtension(info)
                    except Exception:
                        pass
                continue
            try:
                manager.setExtensionEnabled(info, bool(record.enabled))
            except Exception:
                pass
            if record.enabled:
                record.status = "loaded"
                if not record.note or "loaded" not in record.note.lower():
                    record.note = "Native Manifest V3 extension loaded through Qt WebEngine."
            else:
                record.status = "disabled"
                record.note = "Native extension is installed but disabled."
        for record in native_records:
            if not record.enabled:
                continue
            path = str(Path(record.managed_path).resolve())
            if path in loaded_by_path:
                continue
            try:
                manager.loadExtension(record.managed_path)
                record.status = "loading"
                record.note = "Loading native Manifest V3 extension through Qt WebEngine."
            except Exception as exc:
                record.status = "error"
                record.note = f"Native load failed: {exc}"
        self._save_registry()

    def _connect_native_signals(self, manager: Any, notifier=None) -> None:
        manager_id = id(manager)
        if manager_id in self._native_connections:
            return
        self._native_connections.add(manager_id)
        signal = getattr(manager, "loadFinished", None)
        if signal is not None and hasattr(signal, "connect"):
            try:
                signal.connect(lambda info, mgr=manager, note=notifier: self._on_native_load_finished(mgr, info, note))
            except Exception:
                pass
        install_signal = getattr(manager, "installFinished", None)
        if install_signal is not None and hasattr(install_signal, "connect"):
            try:
                install_signal.connect(lambda info, mgr=manager, note=notifier: self._on_native_load_finished(mgr, info, note))
            except Exception:
                pass

    def _on_native_load_finished(self, manager: Any, info: Any, notifier=None) -> None:
        path = self._info_path(info)
        if not path:
            return
        record = None
        resolved = str(Path(path).resolve())
        for item in self.records.values():
            if item.managed_path and str(Path(item.managed_path).resolve()) == resolved:
                record = item
                break
        if record is None:
            return
        error_text = self._info_error(info)
        loaded = self._info_loaded(info)
        if error_text:
            record.status = "error"
            record.note = f"Native load failed: {error_text}"
            if notifier is not None:
                try:
                    notifier(f"Extension load failed for {record.name}: {error_text}")
                except Exception:
                    pass
        else:
            record.status = "loaded" if loaded else "ready"
            record.note = "Native Manifest V3 extension loaded through Qt WebEngine." if loaded else record.note
            if loaded and record.enabled:
                try:
                    manager.setExtensionEnabled(info, True)
                except Exception:
                    pass
            if notifier is not None:
                try:
                    notifier(f"Extension ready: {record.name}")
                except Exception:
                    pass
        self._save_registry()

    def build_qt_scripts(self, record: ExtensionRecord) -> list[Any]:
        from PyQt6.QtWebEngineCore import QWebEngineScript

        manifest = self._read_manifest(Path(record.managed_path))
        scripts: list[Any] = []
        for index, content_script in enumerate(manifest.get("content_scripts", []) or []):
            if not isinstance(content_script, dict):
                continue
            script = QWebEngineScript()
            script.setName(f"{_SCRIPT_PREFIX}{record.ext_id}-{index}")
            script.setRunsOnSubFrames(bool(content_script.get("all_frames", False)))
            try:
                script.setWorldId(int(QWebEngineScript.ScriptWorldId.ApplicationWorld))
            except Exception:
                try:
                    script.setWorldId(1)
                except Exception:
                    pass
            injection = str(content_script.get("run_at", "document_idle") or "document_idle").lower().strip()
            try:
                if injection == "document_start":
                    script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
                elif injection == "document_end":
                    script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
                else:
                    script.setInjectionPoint(QWebEngineScript.InjectionPoint.Deferred)
            except Exception:
                pass
            script.setSourceCode(self._build_content_script_source(record, content_script, index))
            scripts.append(script)
        return scripts

    def _build_content_script_source(self, record: ExtensionRecord, content_script: dict[str, Any], index: int) -> str:
        matches = [str(item) for item in content_script.get("matches", []) if str(item).strip()]
        excludes = [str(item) for item in content_script.get("exclude_matches", []) if str(item).strip()]
        css_payload: list[str] = []
        js_payload: list[str] = []
        base = Path(record.managed_path)
        for css_name in content_script.get("css", []) or []:
            target = (base / str(css_name)).resolve()
            if target.exists() and target.is_file():
                try:
                    css_payload.append(target.read_text(encoding="utf-8"))
                except Exception:
                    continue
        for js_name in content_script.get("js", []) or []:
            target = (base / str(js_name)).resolve()
            if target.exists() and target.is_file():
                try:
                    js_payload.append(target.read_text(encoding="utf-8"))
                except Exception:
                    continue
        payload = {
            "extId": record.ext_id,
            "extName": record.name,
            "matches": matches,
            "excludes": excludes,
            "css": css_payload,
            "js": js_payload,
            "index": index,
        }
        data = json.dumps(payload)
        return fr"""
(() => {{
  const payload = {data};
  const href = String(location.href || '');
  const host = String(location.hostname || '');
  const toRegex = (pattern) => {{
    if (!pattern || pattern === '<all_urls>') return /^https?:\/\//i;
    const escaped = String(pattern)
      .replace(/[.+?^${{}}()|[\]\\]/g, '\\\\$&')
      .replace(/\\\*/g, '.*');
    return new RegExp('^' + escaped + '$');
  }};
  const allowed = payload.matches.length === 0 || payload.matches.some((pattern) => {{
    try {{ return toRegex(pattern).test(href); }} catch (e) {{ return false; }}
  }});
  const blocked = payload.excludes.some((pattern) => {{
    try {{ return toRegex(pattern).test(href); }} catch (e) {{ return false; }}
  }});
  if (!allowed || blocked) return;
  try {{
    window.chrome = window.chrome || {{}};
    window.browser = window.browser || window.chrome;
    window.chrome.runtime = window.chrome.runtime || {{ id: payload.extId, getURL: (p) => String(p || '') }};
  }} catch (e) {{}}
  if (Array.isArray(payload.css)) {{
    for (const cssText of payload.css) {{
      try {{
        const style = document.createElement('style');
        style.setAttribute('data-aster-extension', payload.extId + ':' + payload.index);
        style.textContent = String(cssText || '');
        (document.head || document.documentElement).appendChild(style);
      }} catch (e) {{}}
    }}
  }}
  if (Array.isArray(payload.js)) {{
    for (const code of payload.js) {{
      try {{
        (0, eval)(String(code || ''));
      }} catch (e) {{
        console.warn('Aster content-script extension error:', payload.extName, e);
      }}
    }}
  }}
}})();
""".strip()

    def _build_record(self, source_path: Path, extension_root: Path, manifest: dict[str, Any]) -> ExtensionRecord:
        name = str(manifest.get("name", extension_root.name) or extension_root.name).strip()
        version = str(manifest.get("version", "0") or "0").strip()
        description = str(manifest.get("description", "") or "").strip()
        manifest_version = self._coerce_manifest_version(manifest.get("manifest_version", 0))
        source_kind = self._source_kind(manifest)
        runtime_kind = self._runtime_kind(manifest)
        ext_id = self._build_extension_id(source_path, manifest, name, version)
        return ExtensionRecord(
            ext_id=ext_id,
            name=name,
            version=version,
            description=description,
            manifest_version=manifest_version,
            source_kind=source_kind,
            runtime_kind=runtime_kind,
            enabled=True,
            source_path=str(source_path),
            managed_path=str(extension_root),
        )

    def _build_extension_id(self, source_path: Path, manifest: dict[str, Any], name: str, version: str) -> str:
        gecko = manifest.get("browser_specific_settings") or manifest.get("applications") or {}
        gecko_id = ""
        if isinstance(gecko, dict):
            gecko_section = gecko.get("gecko") if isinstance(gecko.get("gecko"), dict) else gecko
            if isinstance(gecko_section, dict):
                gecko_id = str(gecko_section.get("id", "") or "").strip()
        raw = gecko_id or f"{name}-{version}"
        safe = _SAFE_ID.sub("-", raw).strip("-._").lower() or "extension"
        digest = hashlib.sha256((str(source_path.resolve()) + json.dumps(manifest, sort_keys=True)).encode("utf-8")).hexdigest()[:8]
        return f"{safe[:48]}-{digest}"

    def _coerce_manifest_version(self, value: Any) -> int:
        try:
            return int(value)
        except Exception:
            return 0

    def _source_kind(self, manifest: dict[str, Any]) -> str:
        if any(key in manifest for key in ("browser_specific_settings", "applications")):
            return "firefox_webextension"
        if "minimum_chrome_version" in manifest or "key" in manifest or "update_url" in manifest:
            return "chrome_extension"
        return "webextension"

    def _runtime_kind(self, manifest: dict[str, Any]) -> str:
        manifest_version = self._coerce_manifest_version(manifest.get("manifest_version", 0))
        has_content_scripts = bool(manifest.get("content_scripts"))
        if manifest_version >= 3:
            return "qt_native"
        if has_content_scripts:
            return "content_script_fallback"
        return "metadata_only"

    def _compat_note(self, manifest: dict[str, Any], runtime_kind: str, source_kind: str) -> str:
        manifest_version = self._coerce_manifest_version(manifest.get("manifest_version", 0))
        if runtime_kind == "qt_native":
            base = (
                "Manifest V3 extension. Aster can use Qt WebEngine's native extension loader when Qt/PyQt6-WebEngine 6.10+ is available and the Extension backend is set to native_when_available."
            )
            if source_kind == "firefox_webextension":
                return base + " Firefox-style WebExtensions can work when they stay within Chromium-compatible APIs."
            return base
        if runtime_kind == "content_script_fallback":
            return (
                "Manifest V2/content-script extension. Aster will import content scripts and CSS with a fallback injector. "
                "Background pages, service workers, toolbar popups, and many privileged browser APIs are not fully emulated in fallback mode."
            )
        return "This extension was imported, but it does not expose a supported runtime path in Aster yet."

    def _materialize_source(self, source_path: Path, unpacked_root: Path) -> None:
        if source_path.is_dir():
            shutil.copytree(source_path, unpacked_root)
            return
        suffix = source_path.suffix.lower()
        if suffix not in _SUPPORTED_ARCHIVES:
            raise ValueError(f"Unsupported extension package: {source_path.name}. Use an unpacked folder, .zip, .xpi, or .crx file.")
        unpacked_root.mkdir(parents=True, exist_ok=True)
        if suffix == ".crx":
            self._extract_crx(source_path, unpacked_root)
            return
        with zipfile.ZipFile(source_path, "r") as zf:
            zf.extractall(unpacked_root)

    def _guess_download_suffix(self, final_url: str, content_disposition: str, content_type: str, suggested_name: str) -> str:
        candidates = [
            suggested_name,
            self._filename_from_content_disposition(content_disposition),
            Path(unquote(urlparse(final_url).path)).name,
        ]
        for candidate in candidates:
            suffix = Path(candidate or "").suffix.lower()
            if suffix in _SUPPORTED_ARCHIVES:
                return suffix
        normalized = str(content_type or "").split(";", 1)[0].strip().lower()
        return {
            "application/x-xpinstall": ".xpi",
            "application/x-chrome-extension": ".crx",
            "application/zip": ".zip",
            "application/x-zip-compressed": ".zip",
        }.get(normalized, "")

    def _filename_from_content_disposition(self, value: str) -> str:
        raw = str(value or "")
        if not raw:
            return ""
        for token in raw.split(";"):
            token = token.strip()
            lowered = token.lower()
            if lowered.startswith("filename*="):
                _, rhs = token.split("=", 1)
                rhs = rhs.strip().strip('"')
                if "''" in rhs:
                    rhs = rhs.split("''", 1)[1]
                return unquote(rhs)
            if lowered.startswith("filename="):
                _, rhs = token.split("=", 1)
                return rhs.strip().strip('"')
        return ""

    def _extract_crx(self, source_path: Path, unpacked_root: Path) -> None:
        raw = source_path.read_bytes()
        if not raw.startswith(b"Cr24"):
            raise ValueError("Unsupported CRX package: invalid header")
        version = int.from_bytes(raw[4:8], "little")
        if version == 2:
            pubkey_len = int.from_bytes(raw[8:12], "little")
            sig_len = int.from_bytes(raw[12:16], "little")
            offset = 16 + pubkey_len + sig_len
        elif version == 3:
            header_len = int.from_bytes(raw[8:12], "little")
            offset = 12 + header_len
        else:
            raise ValueError(f"Unsupported CRX version: {version}")
        payload = raw[offset:]
        fd, temp_name = tempfile.mkstemp(prefix="aster-ext-", suffix=".zip", dir=str(self.root))
        os.close(fd)
        temp_zip = Path(temp_name)
        try:
            temp_zip.write_bytes(payload)
            with zipfile.ZipFile(temp_zip, "r") as zf:
                zf.extractall(unpacked_root)
        finally:
            temp_zip.unlink(missing_ok=True)

    def _discover_manifest_root(self, unpacked_root: Path) -> Path:
        direct = unpacked_root / "manifest.json"
        if direct.exists():
            return unpacked_root
        matches = list(unpacked_root.rglob("manifest.json"))
        if not matches:
            raise FileNotFoundError("manifest.json not found in extension package")
        matches.sort(key=lambda item: len(item.parts))
        return matches[0].parent

    def _read_manifest(self, extension_root: Path) -> dict[str, Any]:
        manifest_path = extension_root / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(manifest_path)
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("manifest.json must contain a JSON object")
        return data

    def _extension_manager(self, profile: Any) -> Any | None:
        accessor = getattr(profile, "extensionManager", None)
        if accessor is None:
            return None
        try:
            manager = accessor() if callable(accessor) else accessor
        except Exception:
            return None
        if manager is None or not hasattr(manager, "loadExtension"):
            return None
        return manager

    def _info_path(self, info: Any) -> str:
        try:
            path_attr = getattr(info, "path", None)
            if callable(path_attr):
                return str(path_attr() or "")
            if path_attr is not None:
                return str(path_attr)
        except Exception:
            pass
        return ""

    def _info_error(self, info: Any) -> str:
        try:
            error_attr = getattr(info, "error", None)
            if callable(error_attr):
                return str(error_attr() or "")
            if error_attr is not None:
                return str(error_attr)
        except Exception:
            pass
        return ""

    def _info_loaded(self, info: Any) -> bool:
        try:
            loaded_attr = getattr(info, "isLoaded", None)
            if callable(loaded_attr):
                return bool(loaded_attr())
            if loaded_attr is not None:
                return bool(loaded_attr)
        except Exception:
            pass
        return False
