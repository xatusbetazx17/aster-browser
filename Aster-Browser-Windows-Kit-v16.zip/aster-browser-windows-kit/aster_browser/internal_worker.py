from __future__ import annotations

import json
import sys

from .ai import AIContext
from .local_assistant import LocalAssistant


def main() -> int:
    raw = sys.stdin.read()
    if not raw.strip():
        print(json.dumps({"ok": False, "error": "No request payload received."}))
        return 1
    try:
        payload = json.loads(raw)
        prompt = str(payload.get('prompt', '')).strip()
        context_data = payload.get('context', {})
        if not isinstance(context_data, dict):
            context_data = {}
        context = AIContext(**{k: v for k, v in context_data.items() if k in AIContext.__dataclass_fields__})
        persona = str(payload.get("persona", "dr_light_lab") or "dr_light_lab")
        reasoning_mode = str(payload.get("reasoning_mode", "balanced") or "balanced")
        assistant = LocalAssistant(persona=persona, reasoning_mode=reasoning_mode)
        text = assistant.ask(prompt, context)
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 1
    print(json.dumps({"ok": True, "text": text}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
