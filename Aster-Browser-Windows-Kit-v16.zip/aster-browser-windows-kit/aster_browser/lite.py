from __future__ import annotations

import re
import urllib.request
from dataclasses import dataclass
from html.parser import HTMLParser


@dataclass
class LitePage:
    url: str
    title: str
    html: str
    links: list[tuple[str, str]]


class _LiteHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_title = False
        self.capture_text = False
        self.title = ""
        self.current_href = ""
        self.links: list[tuple[str, str]] = []
        self.text_chunks: list[str] = []
        self.link_text_chunks: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_dict = dict(attrs)
        if tag == "title":
            self.in_title = True
        if tag in {"p", "article", "section", "li", "h1", "h2", "h3", "pre", "blockquote"}:
            self.capture_text = True
        if tag == "a":
            self.current_href = attrs_dict.get("href") or ""
            self.link_text_chunks = []

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self.in_title = False
        if tag in {"p", "article", "section", "li", "h1", "h2", "h3", "pre", "blockquote"}:
            self.capture_text = False
            self.text_chunks.append("\n")
        if tag == "a" and self.current_href:
            label = " ".join(part.strip() for part in self.link_text_chunks if part.strip()).strip()
            if label:
                self.links.append((label, self.current_href))
            self.current_href = ""
            self.link_text_chunks = []

    def handle_data(self, data: str) -> None:
        text = re.sub(r"\s+", " ", data).strip()
        if not text:
            return
        if self.in_title and not self.title:
            self.title = text
        if self.capture_text:
            self.text_chunks.append(text)
        if self.current_href:
            self.link_text_chunks.append(text)


def fetch_html(url: str, timeout: int = 10) -> str:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "AsterLite/0.1 (+https://example.local/aster)",
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        return response.read().decode(charset, errors="replace")


def render_lite_page(url: str, html_source: str | None = None) -> LitePage:
    html_source = html_source if html_source is not None else fetch_html(url)
    parser = _LiteHTMLParser()
    parser.feed(html_source)
    title = parser.title or url
    text = " ".join(chunk for chunk in parser.text_chunks if chunk.strip())
    text = re.sub(r"\n\s+", "\n", text)
    paragraphs = [chunk.strip() for chunk in re.split(r"\n+", text) if chunk.strip()]
    body_parts = [f"<h1>{_escape(title)}</h1>", f"<p><b>Source:</b> {_escape(url)}</p>"]
    if paragraphs:
        for paragraph in paragraphs[:25]:
            body_parts.append(f"<p>{_escape(paragraph)}</p>")
    else:
        body_parts.append("<p>No readable text was extracted for this page.</p>")
    if parser.links:
        body_parts.append("<h2>Links</h2><ul>")
        for label, href in parser.links[:30]:
            body_parts.append(f'<li><a href="{_escape(href)}">{_escape(label)}</a></li>')
        body_parts.append("</ul>")
    html = "\n".join(body_parts)
    return LitePage(url=url, title=title, html=html, links=parser.links)


def _escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
