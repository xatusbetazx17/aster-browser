from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from PyQt6.QtGui import QIcon


_ICON_DIR = Path(__file__).resolve().parent / 'assets' / 'icons'


@lru_cache(maxsize=64)
def icon_path(name: str) -> str:
    path = _ICON_DIR / f'{name}.svg'
    return str(path)


@lru_cache(maxsize=64)
def svg_icon(name: str) -> QIcon:
    return QIcon(icon_path(name))
