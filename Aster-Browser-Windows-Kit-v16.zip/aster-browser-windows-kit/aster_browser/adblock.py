from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

try:
    from PyQt6.QtCore import QUrl
    from PyQt6.QtWebEngineCore import QWebEngineUrlRequestInterceptor
    PYQT_AVAILABLE = True
except Exception:  # pragma: no cover - optional in headless tests
    QWebEngineUrlRequestInterceptor = object
    QUrl = object
    PYQT_AVAILABLE = False

_STREAMING_ALLOW_SUFFIXES = (
    "primevideo.com",
    "amazon.com",
    "netflix.com",
    "disneyplus.com",
    "max.com",
    "hbomax.com",
    "hulu.com",
    "peacocktv.com",
    "paramountplus.com",
    "tv.youtube.com",
    "crunchyroll.com",
    "tv.apple.com",
)

_KNOWN_TRACKER_SUFFIXES = (
    "doubleclick.net",
    "googlesyndication.com",
    "googleadservices.com",
    "facebook.com",
    "scorecardresearch.com",
    "adservice.google.com",
    "adsystem.com",
    "taboola.com",
    "outbrain.com",
)


@dataclass
class BlockRule:
    kind: str
    value: str
    allow: bool = False


def _clean_host(value: str) -> str:
    text = str(value or "").strip().lower().strip(".")
    text = text.replace("https://", "").replace("http://", "").split("/", 1)[0]
    return text.strip().strip(".")


def _host_matches(host: str, suffix: str) -> bool:
    suffix = _clean_host(suffix)
    return bool(suffix) and (host == suffix or host.endswith("." + suffix))


def parse_adblock_lines(lines: list[str] | tuple[str, ...]) -> list[BlockRule]:
    """Parse a compact, user-editable subset of filter-list syntax.

    Supported examples:
      ||tracker.example^        block host suffix
      @@||cdn.example^          allow host suffix
      block:ads.example.com     block host suffix
      allow:video-cdn.site      allow host suffix
      https://bad.example/ad    block URL substring
      /banner.js                block URL substring
    """
    rules: list[BlockRule] = []
    for raw_line in lines:
        line = str(raw_line or "").strip()
        if not line:
            continue
        if line.startswith("!"):
            continue
        if line.startswith("#") and not line.startswith("##"):
            continue
        allow = False
        lowered = line.lower()
        if lowered.startswith("allow:"):
            allow = True
            line = line.split(":", 1)[1].strip()
        elif lowered.startswith("block:"):
            allow = False
            line = line.split(":", 1)[1].strip()
        elif line.startswith("@@"):
            allow = True
            line = line[2:]
        if line.startswith("||") and line.endswith("^"):
            rules.append(BlockRule("host", _clean_host(line[2:-1]), allow=allow))
            continue
        if line.startswith("http://") or line.startswith("https://"):
            rules.append(BlockRule("substring", line.lower(), allow=allow))
            continue
        if "." in line and " " not in line and "/" not in line and "*" not in line:
            rules.append(BlockRule("host", _clean_host(line), allow=allow))
            continue
        rules.append(BlockRule("substring", line.lower(), allow=allow))
    return [rule for rule in rules if rule.value]


class AdblockRuleset:
    def __init__(
        self,
        rules: list[BlockRule] | None = None,
        strict: bool = False,
        *,
        mode: str = "balanced",
        allow_hosts: list[str] | None = None,
        block_hosts: list[str] | None = None,
        streaming_allowlist: bool = True,
    ) -> None:
        self.rules = rules or []
        self.mode = (mode or "balanced").strip().lower()
        if self.mode not in {"off", "balanced", "strict", "custom"}:
            self.mode = "balanced"
        self.strict = bool(strict or self.mode == "strict")
        self.allow_hosts = [_clean_host(item) for item in (allow_hosts or []) if _clean_host(item)]
        self.block_hosts = [_clean_host(item) for item in (block_hosts or []) if _clean_host(item)]
        self.streaming_allowlist = bool(streaming_allowlist)

    @classmethod
    def from_file(cls, path: Path, strict: bool = False, **kwargs) -> "AdblockRuleset":
        lines: list[str] = []
        if path.exists():
            lines = path.read_text(encoding="utf-8").splitlines()
        return cls(parse_adblock_lines(lines), strict=strict, **kwargs)

    @classmethod
    def from_sources(
        cls,
        default_path: Path,
        *,
        strict: bool = False,
        mode: str = "balanced",
        custom_rules: str = "",
        allow_hosts: list[str] | None = None,
        block_hosts: list[str] | None = None,
        streaming_allowlist: bool = True,
    ) -> "AdblockRuleset":
        lines: list[str] = []
        if default_path.exists() and mode != "custom":
            lines.extend(default_path.read_text(encoding="utf-8").splitlines())
        if custom_rules:
            lines.extend(str(custom_rules).splitlines())
        return cls(
            parse_adblock_lines(lines),
            strict=strict,
            mode=mode,
            allow_hosts=allow_hosts or [],
            block_hosts=block_hosts or [],
            streaming_allowlist=streaming_allowlist,
        )

    def should_block(self, url: str) -> bool:
        if self.mode == "off":
            return False
        try:
            parsed = urlparse(url)
        except Exception:
            return False
        host = (parsed.hostname or "").lower().strip(".")
        if not host:
            return False
        if any(_host_matches(host, suffix) for suffix in self.allow_hosts):
            return False
        if self.streaming_allowlist and any(_host_matches(host, suffix) for suffix in _STREAMING_ALLOW_SUFFIXES):
            return False
        if any(_host_matches(host, suffix) for suffix in self.block_hosts):
            return True
        whole = url.lower()
        matched_allow = False
        matched_block = False
        for rule in self.rules:
            if rule.kind == "host":
                hit = _host_matches(host, rule.value)
            else:
                hit = rule.value in whole
            if not hit:
                continue
            if rule.allow:
                matched_allow = True
            else:
                matched_block = True
        if matched_allow:
            return False
        if matched_block:
            return True
        if self.strict and any(_host_matches(host, suffix) for suffix in _KNOWN_TRACKER_SUFFIXES):
            return True
        return False

    def summary(self) -> str:
        return (
            f"mode={self.mode}; rules={len(self.rules)}; strict={self.strict}; "
            f"allow_hosts={len(self.allow_hosts)}; block_hosts={len(self.block_hosts)}; "
            f"streaming_allowlist={self.streaming_allowlist}"
        )


if PYQT_AVAILABLE:
    class AdblockInterceptor(QWebEngineUrlRequestInterceptor):
        def __init__(self, ruleset: AdblockRuleset, enabled: bool = True) -> None:
            super().__init__()
            self.ruleset = ruleset
            self.enabled = enabled

        def interceptRequest(self, info) -> None:  # type: ignore[override]
            if not self.enabled:
                return
            try:
                url = info.requestUrl().toString()
            except Exception:
                return
            if self.ruleset.should_block(url):
                info.block(True)
else:
    class AdblockInterceptor:  # pragma: no cover - only used without PyQt installed
        def __init__(self, *args, **kwargs) -> None:
            raise RuntimeError("PyQt6-WebEngine is required for the request interceptor")
