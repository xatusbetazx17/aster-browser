"""Animated wheel scrolling for Aster's own panels.

Web pages get this from Chromium once --enable-smooth-scrolling is passed, but
Aster's settings, experiments, reader and task lists are Qt widgets: Qt sends
the scroll bar straight to its new value, which reads as a hard jump on every
notch. The distance stays exactly the one Qt would have scrolled - only the way
there is animated, and a second notch extends the run instead of restarting it.
"""
from __future__ import annotations

from PyQt6.QtCore import QEasingCurve, QEvent, QObject, Qt, QVariantAnimation
from PyQt6.QtWidgets import QAbstractItemView, QAbstractScrollArea, QApplication

DURATION_MS = 170


class SmoothWheelFilter(QObject):
    """Turn each wheel notch on a scroll area into a short animated run."""

    def __init__(self, area: QAbstractScrollArea) -> None:
        super().__init__(area)
        self._area = area
        self._target: int | None = None
        self._applied: int | None = None
        self._animation = QVariantAnimation(self)
        self._animation.setDuration(DURATION_MS)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animation.valueChanged.connect(self._apply)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if event.type() != QEvent.Type.Wheel:
            return False
        bar = self._area.verticalScrollBar()
        if bar is None or bar.maximum() <= bar.minimum():
            return False
        # Ctrl is zoom, Shift is sideways, and a touchpad already sends smooth
        # pixel deltas of its own. None of those are ours to animate.
        if event.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier):
            return False
        if not event.pixelDelta().isNull():
            return False
        notches = event.angleDelta().y() / 120.0
        if not notches:
            return False
        step = min(QApplication.wheelScrollLines() * bar.singleStep(), bar.pageStep())
        if step <= 0:
            return False
        start = bar.value()
        if self._target is None or self._applied != start:
            self._target = start  # Something else moved the bar; carry on from there.
        target = int(self._target - notches * step)
        self._target = max(bar.minimum(), min(bar.maximum(), target))
        if self._target == start:
            return False  # Already at the end of this area, so let the parent have it.
        self._animation.stop()
        self._animation.setStartValue(start)
        self._animation.setEndValue(self._target)
        self._animation.start()
        return True

    def _apply(self, value: object) -> None:
        bar = self._area.verticalScrollBar()
        if bar is None:
            return
        self._applied = int(value)  # type: ignore[arg-type]
        bar.setValue(self._applied)


def attach_smooth_scroll(area: QAbstractScrollArea) -> QAbstractScrollArea:
    """Give this area animated wheel scrolling, by pixel rather than by item."""
    set_scroll_mode = getattr(area, "setVerticalScrollMode", None)
    if set_scroll_mode is not None:  # Item views step a whole row at a time.
        set_scroll_mode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    viewport = area.viewport()
    if viewport is not None:
        viewport.installEventFilter(SmoothWheelFilter(area))
    return area
