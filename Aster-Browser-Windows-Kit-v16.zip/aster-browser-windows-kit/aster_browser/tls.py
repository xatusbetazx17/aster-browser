from __future__ import annotations

import os
import socket
import ssl
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse


_CERT_BUNDLE_CANDIDATES = [
    "/etc/ssl/certs/ca-certificates.crt",
    "/etc/pki/tls/certs/ca-bundle.crt",
    "/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",
    "/etc/ssl/ca-bundle.pem",
    "/usr/local/share/ca-certificates/ca-certificates.crt",
]
_CERT_DIR_CANDIDATES = [
    "/etc/ssl/certs",
    "/etc/pki/tls/certs",
    "/etc/pki/ca-trust/extracted/pem",
]


@dataclass
class HTTPSProbeResult:
    url: str
    host: str
    port: int
    ok: bool
    error: str = ""
    issuer: str = ""
    subject: str = ""
    not_after: str = ""
    bundle: str = ""
    ca_dir: str = ""

    def as_lines(self) -> list[str]:
        lines = [f"HTTPS probe host: {self.host}:{self.port}"]
        lines.append(f"Python/OpenSSL trusted: {'yes' if self.ok else 'no'}")
        if self.bundle:
            lines.append(f"CA bundle: {self.bundle}")
        if self.ca_dir:
            lines.append(f"CA directory: {self.ca_dir}")
        if self.subject:
            lines.append(f"Certificate subject: {self.subject}")
        if self.issuer:
            lines.append(f"Certificate issuer: {self.issuer}")
        if self.not_after:
            lines.append(f"Certificate expires: {self.not_after}")
        if self.error:
            lines.append(f"Probe error: {self.error}")
        return lines


def _first_existing(paths: list[str], *, directory: bool = False) -> str:
    for candidate in paths:
        path = Path(candidate)
        if directory:
            if path.is_dir():
                return str(path)
        elif path.is_file():
            return str(path)
    return ""


def configure_certificate_environment() -> tuple[str, str]:
    """Expose the distro CA bundle to Python helpers without touching NSS DBs.

    Qt WebEngine/Chromium may use NSS or its own certificate plumbing, but these
    variables help Python downloaders, extension installers, and diagnostics.
    The function intentionally never calls certutil and never edits a user NSS DB.
    """
    bundle = os.environ.get("SSL_CERT_FILE", "").strip() or _first_existing(_CERT_BUNDLE_CANDIDATES)
    ca_dir = os.environ.get("SSL_CERT_DIR", "").strip() or _first_existing(_CERT_DIR_CANDIDATES, directory=True)
    if bundle:
        os.environ.setdefault("SSL_CERT_FILE", bundle)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", bundle)
        os.environ.setdefault("CURL_CA_BUNDLE", bundle)
    if ca_dir:
        os.environ.setdefault("SSL_CERT_DIR", ca_dir)
    return bundle, ca_dir


def _format_name(value) -> str:
    try:
        parts: list[str] = []
        for group in value or []:
            for key, item in group:
                if key in {"commonName", "organizationName", "countryName"}:
                    parts.append(f"{key}={item}")
        return ", ".join(parts)
    except Exception:
        return str(value or "")


def probe_https(url: str, timeout: float = 5.0) -> HTTPSProbeResult:
    bundle, ca_dir = configure_certificate_environment()
    parsed = urlparse(url if "://" in url else "https://" + url)
    host = (parsed.hostname or "").strip()
    port = int(parsed.port or 443)
    result = HTTPSProbeResult(url=url, host=host, port=port, ok=False, bundle=bundle, ca_dir=ca_dir)
    if not host:
        result.error = "No HTTPS host was found in the URL."
        return result
    try:
        context = ssl.create_default_context(cafile=bundle or None, capath=ca_dir or None)
        with socket.create_connection((host, port), timeout=timeout) as raw:
            with context.wrap_socket(raw, server_hostname=host) as tls:
                cert = tls.getpeercert() or {}
        result.ok = True
        result.subject = _format_name(cert.get("subject"))
        result.issuer = _format_name(cert.get("issuer"))
        result.not_after = str(cert.get("notAfter", ""))
        return result
    except Exception as exc:
        result.error = str(exc)
        return result
