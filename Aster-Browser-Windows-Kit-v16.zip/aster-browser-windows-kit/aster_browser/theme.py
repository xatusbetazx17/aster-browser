from __future__ import annotations

import re
from typing import Iterable


#: The one surface the window is painted in: the strip the tabs sit in, the
#: selected tab, the toolbar, every aster: page and the ground the new tab
#: page's light is thrown across. The window itself has always been painted
#: black behind all of that, so anything lighter only ever showed up as a grey
#: patch sitting on it.
PAGE_BACKGROUND = '#000000'
#: Surfaces that sit on top of it and want to be seen as sitting on top: cards,
#: tiles, the hovered tab.
RAISED_SURFACE = '#12161C'

#: The interface accent: the white of Aster's own mark. Buttons, checked boxes,
#: focus rings and progress all draw in it, so whatever sits on top of it is
#: painted in ACCENT_TEXT rather than left to fade into the white.
ACCENT = '#FFFFFF'
ACCENT_HOVER = '#E3E8F1'
ACCENT_PRESSED = '#C2CAD8'
ACCENT_TEXT = '#0C0E12'


def _rgba(hex_color: str, alpha: int) -> str:
    color = hex_color.lstrip('#')
    if len(color) != 6:
        raise ValueError(f'Expected 6-digit hex color, got {hex_color!r}')
    r = int(color[0:2], 16)
    g = int(color[2:4], 16)
    b = int(color[4:6], 16)
    return f'rgba({r}, {g}, {b}, {alpha})'


_BASE_TEMPLATE = """
/* ==========================================================================
   Aster Browser - Firefox-Inspired Modern Dark Qt Theme
   ========================================================================== */

QWidget {
    background: {window_bg};
    color: {primary_text};
    font-family: "Manrope", "Segoe UI", Arial, sans-serif;
    font-size: 13px;
    selection-background-color: {selected_surface};
    selection-color: {primary_text};
}

QLabel {
    background: transparent;
    border: none;
    color: {primary_text};
}

QMainWindow#AsterWindow {
    background: {window_bg};
}

/* --- Window Title Bar & Navigation Header --- */
QWidget#AsterTitleBar {
    background: {window_bg};
    border: none;
    border-bottom: none;
}

QToolButton#TitleLogoButton {
    background: transparent;
    border: none;
    padding: 0;
}

QLabel#AsterTitleLabel {
    color: {primary_text};
    font-size: 12px;
    font-weight: 600;
}

QLabel#AsterContextLabel {
    color: {muted_text};
    font-size: 11px;
}

QToolButton#HeaderMenuButton,
QToolButton#HeaderCompactButton {
    background: transparent;
    border: none;
    border-radius: 10px;
    padding: 3px 8px;
    color: {secondary_text};
    font-size: 12px;
    font-weight: 500;
}

QToolButton#HeaderMenuButton:hover,
QToolButton#HeaderCompactButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QToolButton#HeaderMenuButton:pressed,
QToolButton#HeaderCompactButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

QToolButton#WindowButton {
    background: transparent;
    border: none;
    border-radius: 9px;
    padding: 4px;
    color: {secondary_text};
}

QToolButton#WindowButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QToolButton#WindowButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

QToolButton#WindowCloseButton {
    background: transparent;
    border: none;
    border-radius: 9px;
    padding: 4px;
    color: {secondary_text};
}

QToolButton#WindowCloseButton:hover {
    background: #e81123;
    color: #ffffff;
    border: none;
}

QToolButton#WindowCloseButton:pressed {
    background: #bf0f1d;
    color: #ffffff;
    border: none;
}

/* --- Toolbar (Firefox Navigation Bar) --- */
QToolBar#AsterToolbar {
    background: {window_bg};
    border: none;
    border-top: none;
    border-bottom: none;
    spacing: 3px;
    padding: 3px 6px;
}

QToolBar#AsterToolbar::separator {
    width: 1px;
    margin: 4px 6px;
    background: transparent;
    border: none;
}

QToolBar#AsterToolbar > QToolButton,
QToolButton#ToolbarOverflowButton {
    min-height: 28px;
    max-height: 28px;
    min-width: 28px;
    max-width: 28px;
    padding: 0px;
    margin: 1px 2px;
    background: transparent;
    border: none;
    border-radius: 14px;
    color: {secondary_text};
    qproperty-iconSize: 16px 16px;
}

QToolBar#AsterToolbar > QToolButton:hover,
QToolButton#ToolbarOverflowButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QToolBar#AsterToolbar > QToolButton:pressed,
QToolButton#ToolbarOverflowButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

QToolBar#AsterToolbar > QToolButton:checked,
QToolButton#ToolbarOverflowButton:checked {
    background: rgba(255, 255, 255, 0.14);
    color: {accent};
    border: none;
}

QToolBar#AsterToolbar > QToolButton:disabled,
QToolButton#ToolbarOverflowButton:disabled {
    background: transparent;
    color: {muted_text};
    border: none;
    opacity: 0.4;
}

/* --- Tab System (Firefox Compact Tabs) --- */
QTabWidget#AsterTabs::pane {
    background: {page_bg};
    border: none;
}

/* Every aster: page - new tab, settings, history, downloads, awareness, flags,
   the task manager, and the parked/lite/error pages - shares the tab colour. */
QWidget#AsterInternalPage {
    background: {page_bg};
}

/* Lists on those pages sit on the page rather than in a black well of their
   own; their border is what marks them out. */
QWidget#AsterInternalPage QListView,
QWidget#AsterInternalPage QTreeView,
QWidget#AsterInternalPage QTableView,
QWidget#AsterInternalPage QListWidget {
    background: {page_bg};
}

/* So do the scrollable panels: the settings sections, the experiment list and
   the task manager all scroll their own content inside the page. */
QWidget#AsterInternalPage QScrollArea,
QWidget#AsterInternalPage QScrollArea > QWidget#qt_scrollarea_viewport,
QWidget#AsterInternalPage QScrollArea > QWidget#qt_scrollarea_viewport > QWidget,
QWidget#AsterInternalPage QStackedWidget {
    background: {page_bg};
}

QTabBar {
    background: transparent;
    border: none;
    qproperty-drawBase: 0;
}

QTabBar::tab {
    background: transparent;
    color: {secondary_text};
    border: 1px solid transparent;
    border-bottom: none;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
    padding: 5px 14px;
    /* The strip is the same colour as the toolbar above it now, so without a
       little air the tab's shoulders run straight into the address bar. */
    margin: 5px 3px 0 0;
    font-size: 12.5px;
    font-weight: 500;
    min-height: 26px;
}

QTabBar::tab:hover {
    background: {secondary_surface};
    color: {primary_text};
    border: 1px solid {secondary_border};
    border-bottom: none;
}

QTabBar::tab:selected {
    background: {page_bg};
    color: {primary_text};
    border: 1px solid {primary_border};
    border-bottom: 1px solid {page_bg};
    font-weight: 600;
}

QTabBar::close-button {
    background: transparent;
    border: none;
    min-width: 0px;
    max-width: 0px;
    width: 0px;
    height: 0px;
    margin: 0px;
    padding: 0px;
}

QToolButton#NewTabButton {
    background: transparent;
    border: none;
    border-radius: 11px;
    color: {secondary_text};
}

QToolButton#NewTabButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QToolButton#NewTabButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

/* --- Address Bar (URL Input) --- */
QLineEdit#AddressBar {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 14px;
    color: {primary_text};
    padding: 2px 14px;
    font-size: 12.5px;
    min-height: 26px;
    max-height: 28px;
    selection-background-color: {selected_surface};
    selection-color: {primary_text};
}

QLineEdit#AddressBar:hover {
    border: 1px solid #3d4758;
}

QLineEdit#AddressBar:focus {
    border: 1px solid {accent};
    background: {input_surface};
}

QLineEdit#AddressBar QToolButton {
    min-width: 16px;
    max-width: 16px;
    min-height: 16px;
    max-height: 16px;
    width: 16px;
    height: 16px;
    border: none;
    background: transparent;
    border-radius: 8px;
    padding: 0px;
    margin: 0px 3px 0px 0px;
    color: {secondary_text};
}

QLineEdit#AddressBar QToolButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QLineEdit#AddressBar QToolButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

QLineEdit#ModeBadge {
    background: {input_surface};
    color: {accent};
    font-weight: 600;
    font-size: 11px;
    border-radius: 9px;
    padding: 1px 6px;
    border: 1px solid rgba(255, 255, 255, 0.25);
}

/* --- QComboBox (Container / Profile Selector & Inputs) --- */
QComboBox {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 13px;
    color: {primary_text};
    padding: 3px 26px 3px 10px;
    font-size: 12px;
    min-height: 22px;
    selection-background-color: {selected_surface};
    selection-color: {primary_text};
}

QComboBox:hover {
    background: {hover_surface};
    border: 1px solid #3d4758;
}

QComboBox:focus {
    border: 1px solid {accent};
    background: {input_surface};
}

QComboBox:disabled {
    background: {main_surface};
    color: {muted_text};
    border-color: {secondary_border};
}

QComboBox#ContainerCombo {
    min-width: 90px;
    max-height: 28px;
    border-radius: 14px;
    padding: 2px 24px 2px 12px;
    font-size: 11.5px;
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 22px;
    border: none;
    background: transparent;
}

QComboBox::down-arrow {
    /* Qt's stylesheet engine has no fast path for the CSS border triangle: it
       drew those three borders literally, as a thick dash where the arrow
       should be. The chevron the scrollbars use is a real icon. */
    image: url({scroll_down_icon_path});
    width: 10px;
    height: 10px;
    margin-right: 9px;
}

QComboBox::down-arrow:hover {
    border-top-color: {primary_text};
}

QComboBox QAbstractItemView {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 14px;
    padding: 4px;
    color: {secondary_text};
    selection-background-color: {selected_surface};
    selection-color: {primary_text};
    outline: 0;
}

QComboBox QAbstractItemView::item {
    min-height: 24px;
    padding: 4px 8px;
    border-radius: 9px;
}

QComboBox QAbstractItemView::item:hover {
    background: {hover_surface};
    color: {primary_text};
}

QComboBox QAbstractItemView::item:selected {
    background: {selected_surface};
    color: {primary_text};
}

/* --- Menu Bar & Menus (Firefox-Style Desktop Menus) --- */
QMenuBar {
    background: transparent;
    color: {secondary_text};
}

QMenuBar::item {
    background: transparent;
    padding: 4px 8px;
    border-radius: 10px;
    color: {secondary_text};
    font-size: 12px;
    font-weight: 500;
}

QMenuBar::item:selected {
    background: {hover_surface};
    color: {primary_text};
}

QMenuBar::item:pressed {
    background: {pressed_surface};
    color: {primary_text};
}

QMenu {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 16px;
    padding: 4px;
    color: {secondary_text};
    font-size: 12.5px;
}

QMenu::item {
    padding: 6px 24px 6px 10px;
    border-radius: 10px;
    color: {secondary_text};
}

QMenu::item:selected {
    background: {hover_surface};
    color: {primary_text};
}

QMenu::item:disabled {
    color: {muted_text};
    background: transparent;
}

QMenu::separator {
    height: 1px;
    background: {primary_border};
    margin: 4px 6px;
}

QMenu::right-arrow {
    border-top: 4px solid transparent;
    border-bottom: 4px solid transparent;
    border-left: 5px solid {secondary_text};
    width: 0;
    height: 0;
    margin-right: 6px;
}

/* --- Standard Buttons (QPushButton) --- */
QPushButton {
    background: {accent};
    color: {accent_text};
    border: 1px solid {accent};
    border-radius: 13px;
    padding: 6px 16px;
    font-weight: 600;
    font-size: 12.5px;
}

QPushButton:hover {
    background: {accent_hover};
    border-color: {accent_hover};
    color: {accent_text};
}

QPushButton:pressed {
    background: {accent_pressed};
    border-color: {accent_pressed};
    color: {accent_text};
}

QPushButton:disabled {
    background: {input_surface};
    border-color: {primary_border};
    color: {muted_text};
}

QPushButton#SecondaryButton,
QPushButton#GhostButton,
QDialogButtonBox QPushButton {
    background: {secondary_surface};
    color: {primary_text};
    border: 1px solid {primary_border};
    border-radius: 13px;
    padding: 6px 14px;
    font-weight: 500;
    font-size: 12px;
}

QPushButton#SecondaryButton:hover,
QPushButton#GhostButton:hover,
QDialogButtonBox QPushButton:hover {
    background: {hover_surface};
    border-color: #3d4758;
    color: #ffffff;
}

QPushButton#SecondaryButton:pressed,
QPushButton#GhostButton:pressed,
QDialogButtonBox QPushButton:pressed {
    background: {pressed_surface};
    border-color: #3d4758;
}

QPushButton#SecondaryButton:disabled,
QPushButton#GhostButton:disabled,
QDialogButtonBox QPushButton:disabled {
    background: {main_surface};
    border-color: {secondary_border};
    color: {muted_text};
}

QToolButton {
    background: transparent;
    border: none;
    border-radius: 10px;
    color: {secondary_text};
    padding: 2px;
}

QToolButton:hover {
    background: {hover_surface};
    color: {primary_text};
    border: none;
}

QToolButton:pressed {
    background: {pressed_surface};
    color: {primary_text};
    border: none;
}

QToolButton:disabled {
    color: {muted_text};
    opacity: 0.4;
}

/* --- Input Fields (QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox) --- */
QLineEdit,
QTextEdit,
QPlainTextEdit,
QSpinBox {
    background: {input_surface};
    border: 1px solid {primary_border};
    border-radius: 13px;
    color: {primary_text};
    padding: 6px 10px;
    font-size: 12.5px;
    selection-background-color: {selected_surface};
    selection-color: {primary_text};
}

QLineEdit:hover,
QTextEdit:hover,
QPlainTextEdit:hover,
QSpinBox:hover {
    border: 1px solid #3d4758;
}

QLineEdit:focus,
QTextEdit:focus,
QPlainTextEdit:focus,
QSpinBox:focus {
    border: 1px solid {accent};
}

QLineEdit:disabled,
QTextEdit:disabled,
QPlainTextEdit:disabled,
QSpinBox:disabled {
    background: {main_surface};
    color: {muted_text};
    border-color: {secondary_border};
}

QSpinBox::up-button,
QSpinBox::down-button {
    background: transparent;
    border: none;
    width: 16px;
    border-radius: 6px;
    margin: 1px;
}

QSpinBox::up-button:hover,
QSpinBox::down-button:hover {
    background: {hover_surface};
}

QSpinBox::up-arrow {
    border-left: 3px solid transparent;
    border-right: 3px solid transparent;
    border-bottom: 4px solid {secondary_text};
    width: 0;
    height: 0;
}

QSpinBox::down-arrow {
    border-left: 3px solid transparent;
    border-right: 3px solid transparent;
    border-top: 4px solid {secondary_text};
    width: 0;
    height: 0;
}

/* --- CheckBox & RadioButton --- */
QCheckBox, QRadioButton {
    color: {secondary_text};
    font-size: 12.5px;
    spacing: 8px;
    background: transparent;
}

QCheckBox:hover, QRadioButton:hover {
    color: {primary_text};
}

QCheckBox:disabled, QRadioButton:disabled {
    color: {muted_text};
}

QCheckBox::indicator {
    width: 15px;
    height: 15px;
    border: 1px solid {primary_border};
    border-radius: 6px;
    background: {input_surface};
}

QCheckBox::indicator:hover {
    border-color: #3d4758;
    background: {hover_surface};
}

QCheckBox::indicator:checked {
    background: {accent};
    border-color: {accent};
    image: url({check_icon_path});
}

QCheckBox::indicator:disabled {
    background: {main_surface};
    border-color: {secondary_border};
}

QRadioButton::indicator {
    width: 15px;
    height: 15px;
    border-radius: 8px;
    border: 1px solid {primary_border};
    background: {input_surface};
}

QRadioButton::indicator:hover {
    border-color: #3d4758;
    background: {hover_surface};
}

QRadioButton::indicator:checked {
    background: {accent};
    border-color: {accent};
    image: url({radio_icon_path});
}

QRadioButton::indicator:disabled {
    background: {main_surface};
    border-color: {secondary_border};
}

/* --- Sliders & Progress Bars --- */
QSlider::groove:horizontal {
    height: 4px;
    background: {input_surface};
    border-radius: 3px;
}

QSlider::sub-page:horizontal {
    background: {accent};
    border-radius: 3px;
}

QSlider::handle:horizontal {
    background: {primary_text};
    width: 12px;
    height: 12px;
    margin: -4px 0;
    border-radius: 8px;
}

QSlider::handle:horizontal:hover {
    background: #ffffff;
    border: 1px solid {accent};
}

QProgressBar {
    background: {input_surface};
    border: 1px solid {primary_border};
    border-radius: 10px;
    height: 6px;
    text-align: center;
    color: {primary_text};
}

QProgressBar::chunk {
    background: {accent};
    border-radius: 9px;
}

/* --- Scrollbars --- */
QScrollBar:vertical {
    background: {scrollbar_track};
    width: 14px;
    margin: 14px 0 14px 0;
    border: none;
}

QScrollBar::handle:vertical {
    background: {scrollbar_handle};
    border: 2px solid {scrollbar_track};
    border-radius: 7px;
    min-height: 32px;
}

QScrollBar::handle:vertical:hover {
    background: {scrollbar_handle_hover};
}

QScrollBar::handle:vertical:pressed {
    background: {accent};
}

QScrollBar::sub-line:vertical {
    background: {scrollbar_track};
    height: 14px;
    border: none;
    subcontrol-origin: margin;
    subcontrol-position: top;
}

QScrollBar::add-line:vertical {
    background: {scrollbar_track};
    height: 14px;
    border: none;
    subcontrol-origin: margin;
    subcontrol-position: bottom;
}

QScrollBar::sub-line:vertical:hover,
QScrollBar::add-line:vertical:hover {
    background: {scrollbar_button_hover};
}

QScrollBar::up-arrow:vertical {
    image: url({scroll_up_icon_path});
    width: 10px;
    height: 10px;
}

QScrollBar::down-arrow:vertical {
    image: url({scroll_down_icon_path});
    width: 10px;
    height: 10px;
}

QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical {
    background: {scrollbar_track};
}

QScrollBar:horizontal {
    background: {scrollbar_track};
    height: 14px;
    margin: 0 14px 0 14px;
    border: none;
}

QScrollBar::handle:horizontal {
    background: {scrollbar_handle};
    border: 2px solid {scrollbar_track};
    border-radius: 7px;
    min-width: 32px;
}

QScrollBar::handle:horizontal:hover {
    background: {scrollbar_handle_hover};
}

QScrollBar::handle:horizontal:pressed {
    background: {accent};
}

QScrollBar::sub-line:horizontal {
    background: {scrollbar_track};
    width: 14px;
    border: none;
    subcontrol-origin: margin;
    subcontrol-position: left;
}

QScrollBar::add-line:horizontal {
    background: {scrollbar_track};
    width: 14px;
    border: none;
    subcontrol-origin: margin;
    subcontrol-position: right;
}

QScrollBar::sub-line:horizontal:hover,
QScrollBar::add-line:horizontal:hover {
    background: {scrollbar_button_hover};
}

QScrollBar::left-arrow:horizontal {
    image: url({scroll_left_icon_path});
    width: 10px;
    height: 10px;
}

QScrollBar::right-arrow:horizontal {
    image: url({scroll_right_icon_path});
    width: 10px;
    height: 10px;
}

QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal {
    background: {scrollbar_track};
}

/* --- Lists, Trees, Tables --- */
QListView,
QTreeView,
QTableView,
QListWidget {
    background: {main_surface};
    color: {primary_text};
    border: 1px solid {primary_border};
    border-radius: 13px;
    outline: none;
    gridline-color: {secondary_border};
}

QListView::item,
QTreeView::item,
QTableView::item,
QListWidget::item {
    min-height: 24px;
    padding: 4px 8px;
    border-radius: 9px;
}

QListView::item:hover,
QTreeView::item:hover,
QTableView::item:hover,
QListWidget::item:hover {
    background: #202731;
    color: {primary_text};
}

QListView::item:selected,
QTreeView::item:selected,
QTableView::item:selected,
QListWidget::item:selected {
    background: {selected_surface};
    color: {primary_text};
}

QHeaderView::section {
    background: {secondary_surface};
    color: {secondary_text};
    border: none;
    border-bottom: 1px solid {primary_border};
    padding: 4px 8px;
    font-weight: 600;
    font-size: 11.5px;
}

/* --- Tooltip & Dialogs --- */
QToolTip {
    background: #20262E;
    color: {primary_text};
    border: 1px solid {primary_border};
    border-radius: 10px;
    padding: 4px 8px;
    font-size: 12px;
}

QDialog, QMessageBox {
    background: {main_surface};
    color: {primary_text};
}

/* --- Side Dock & Utility Panels --- */
QDockWidget#AsterAIDock,
QDockWidget#AsterSideDock {
    background: {main_surface};
    border-left: 1px solid {primary_border};
}

QDockWidget#AsterAIDock::title,
QDockWidget#AsterSideDock::title {
    background: {secondary_surface};
    color: {primary_text};
    padding: 8px 12px;
    font-weight: 600;
    font-size: 13px;
    border-bottom: 1px solid {primary_border};
}

/* --- Homepage & Internal Pages --- */
QFrame#AsterPageShell,
QFrame#AsterCard,
QFrame#AsterSettingsCard,
QFrame#AsterSidePanelCard {
    background: transparent;
    border: none;
    border-radius: 0;
}

QLabel#AsterCardTitle,
QLabel#AsterErrorTitle,
QLabel#AsterSettingsTitle {
    color: {primary_text};
    font-size: 24px;
    font-weight: 600;
}

QLabel#AsterCardSubtitle,
QLabel#AsterErrorSubtitle,
QLabel#AsterSettingsSubtitle {
    color: {secondary_text};
    font-size: 12.5px;
}

QFrame#AsterQuickLinkButton,
QFrame#AsterMenuTile {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 16px;
}

QFrame#AsterQuickLinkButton:hover,
QFrame#AsterMenuTile:hover {
    background: {hover_surface};
    border-color: #3d4758;
}

QFrame#AsterQuickLinkButton QLabel,
QFrame#AsterMenuTile QLabel {
    background: transparent;
    border: none;
}

QLabel#AsterQuickLinkIcon,
QLabel#AsterMenuTileIcon {
    background: transparent;
    border: none;
}

QLabel#AsterQuickLinkTitle,
QLabel#AsterMenuTileTitle {
    color: {primary_text};
    font-weight: 600;
    background: transparent;
    border: none;
}

QLabel#AsterQuickLinkSubtitle,
QLabel#AsterMenuTileSubtitle {
    color: {muted_text};
    background: transparent;
    border: none;
}

QToolButton#AsterCustomizeButton {
    background: {secondary_surface};
    border: 1px solid {primary_border};
    border-radius: 18px;
    color: {secondary_text};
}

QToolButton#AsterCustomizeButton:hover {
    background: {hover_surface};
    border-color: {accent};
    color: {primary_text};
}

QFrame#HomePageCustomizerDrawer {
    background: {main_surface};
    border-left: 1px solid {primary_border};
}

QStatusBar#AsterStatusBar {
    background: transparent;
    border: none;
    min-height: 0px;
    max-height: 0px;
    height: 0px;
    color: transparent;
}

/* --- Settings: left tab rail --- */
QFrame#AsterSettingsNav {
    background: transparent;
    border: none;
}

QFrame#AsterFormSection {
    background: transparent;
    border: none;
}

QLabel#AsterSectionTitle {
    color: {primary_text};
    font-size: 15px;
    font-weight: 700;
}

QLabel#AsterMutedLabel {
    color: {muted_text};
    font-size: 11.5px;
}

QPushButton#AsterSettingsNavItem {
    background: transparent;
    border: none;
    border-left: 2px solid transparent;
    border-radius: 8px;
    padding: 7px 10px;
    text-align: left;
    color: {secondary_text};
    font-size: 12.5px;
    font-weight: 600;
}

QPushButton#AsterSettingsNavItem:hover {
    background: {hover_surface};
    color: {primary_text};
}

QPushButton#AsterSettingsNavItem:checked {
    background: {selected_surface};
    border-left: 2px solid {accent};
    color: {primary_text};
}

QScrollArea#AsterSettingsSectionScroll {
    background: transparent;
    border: none;
}

/* Acilir-ok/gosterge isaretleri: butun temalarda kapali */
QToolButton::menu-indicator,
QToolButton::menu-arrow,
QPushButton::menu-indicator {
    image: none;
    width: 0px;
    height: 0px;
    border: none;
}
""".strip()


_THEME_TOKENS = {
    'firefox_dark': {
        'accent': ACCENT,
        'accent_hover': ACCENT_HOVER,
        'accent_pressed': ACCENT_PRESSED,
        'window_bg': PAGE_BACKGROUND,
        'main_surface': PAGE_BACKGROUND,
        'secondary_surface': RAISED_SURFACE,
        'input_surface': '#171B22',
        'hover_surface': '#1E242C',
        'pressed_surface': '#262E38',
        'selected_surface': '#2C3541',
        'scrollbar_track': PAGE_BACKGROUND,
        'scrollbar_handle': '#6B7686',
        'scrollbar_handle_hover': '#8F9BAC',
        'scrollbar_button_hover': '#1E242C',
        'primary_border': '#262E38',
        'secondary_border': 'rgba(255, 255, 255, 0.06)',
        'primary_text': '#F2F4F7',
        'secondary_text': '#ADB5C0',
        'muted_text': '#77818E',
        'accent_text': ACCENT_TEXT,
        'title_top': PAGE_BACKGROUND,
        'title_bottom': PAGE_BACKGROUND,
        'shell_hex': PAGE_BACKGROUND,
        'panel_bg': '#0E1116',
        'field_bg': '#171B22',
        'tile_bg': '#0E1116',
        'page_bg': PAGE_BACKGROUND,
        'dock_hex': PAGE_BACKGROUND,
    },
    'black_arc': {
        'accent': ACCENT,
        'accent_hover': ACCENT_HOVER,
        'accent_pressed': ACCENT_PRESSED,
        'window_bg': PAGE_BACKGROUND,
        'main_surface': PAGE_BACKGROUND,
        'secondary_surface': RAISED_SURFACE,
        'input_surface': '#171B22',
        'hover_surface': '#1E242C',
        'pressed_surface': '#262E38',
        'selected_surface': '#2C3541',
        'scrollbar_track': PAGE_BACKGROUND,
        'scrollbar_handle': '#6B7686',
        'scrollbar_handle_hover': '#8F9BAC',
        'scrollbar_button_hover': '#1E242C',
        'primary_border': '#262E38',
        'secondary_border': 'rgba(255, 255, 255, 0.06)',
        'primary_text': '#F2F4F7',
        'secondary_text': '#ADB5C0',
        'muted_text': '#77818E',
        'accent_text': ACCENT_TEXT,
        'title_top': PAGE_BACKGROUND,
        'title_bottom': PAGE_BACKGROUND,
        'shell_hex': PAGE_BACKGROUND,
        'panel_bg': '#0E1116',
        'field_bg': '#171B22',
        'tile_bg': '#0E1116',
        'page_bg': PAGE_BACKGROUND,
        'dock_hex': PAGE_BACKGROUND,
    },
    'aster_dark': {
        'accent': '#31c48d',
        'accent_hover': '#43d79a',
        'accent_pressed': '#21966a',
        'window_bg': PAGE_BACKGROUND,
        'main_surface': PAGE_BACKGROUND,
        'secondary_surface': RAISED_SURFACE,
        'input_surface': '#171B22',
        'hover_surface': '#1E242C',
        'pressed_surface': '#262E38',
        'selected_surface': '#2C3541',
        'scrollbar_track': PAGE_BACKGROUND,
        'scrollbar_handle': '#6B7686',
        'scrollbar_handle_hover': '#8F9BAC',
        'scrollbar_button_hover': '#1E242C',
        'primary_border': '#262E38',
        'secondary_border': 'rgba(255, 255, 255, 0.06)',
        'primary_text': '#F2F4F7',
        'secondary_text': '#ADB5C0',
        'muted_text': '#77818E',
        'accent_text': ACCENT_TEXT,
        'title_top': PAGE_BACKGROUND,
        'title_bottom': PAGE_BACKGROUND,
        'shell_hex': PAGE_BACKGROUND,
        'panel_bg': '#0E1116',
        'field_bg': '#171B22',
        'tile_bg': '#0E1116',
        'page_bg': PAGE_BACKGROUND,
        'dock_hex': PAGE_BACKGROUND,
    }
}


_SYSTEM_TEMPLATE = """
QWidget {
    font-size: 13px;
}
QMainWindow#AsterWindow,
QToolBar#AsterToolbar,
QTabWidget#AsterTabs::pane,
QStatusBar#AsterStatusBar,
QMenu {
    background: palette(window);
    color: palette(window-text);
}

/* The pages Aster draws itself follow the selected tab, as in the dark themes. */
QTabWidget#AsterTabs::pane,
QWidget#AsterInternalPage {
    background: palette(base);
}
QFrame#AsterMobileShell,
QFrame#AsterCard,
QFrame#AsterStatsStrip,
QFrame#AsterErrorCard,
QFrame#AsterSettingsCard,
QFrame#AsterSidePanelCard,
QFrame#AsterPageShell,
QFrame#AsterFooterStrip {
    background: transparent;
    border: none;
}
QWidget#AsterTitleBar {
    background: palette(window);
    color: palette(window-text);
    border: 1px solid palette(mid);
    border-bottom: 0;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}
QToolBar#AsterToolbar {
    border-left: 1px solid palette(mid);
    border-right: 1px solid palette(mid);
    border-bottom: 1px solid palette(mid);
    spacing: 2px;
    padding: 3px 6px;
}
QToolBar#AsterToolbar::separator {
    width: 6px;
    background: transparent;
}
QToolBar#AsterToolbar > QToolButton, QToolButton#ToolbarOverflowButton {
    min-height: 28px; max-height: 28px; min-width: 28px; max-width: 28px;
    padding: 0px; margin: 1px 2px; background: transparent; border: none;
    qproperty-iconSize: 16px 16px;
}
QToolBar#AsterToolbar > QToolButton:hover,
QToolButton#ToolbarOverflowButton:hover {
    background: rgba(255, 255, 255, 0.10);
    border: none;
}
QToolBar#AsterToolbar > QToolButton:pressed,
QToolButton#ToolbarOverflowButton:pressed {
    background: rgba(255, 255, 255, 0.18);
    border: none;
}
QToolButton#HeaderMenuButton,
QToolButton#HeaderCompactButton,
QToolButton#WindowButton,
QToolButton#WindowCloseButton,
QPushButton,
QPushButton#GhostButton,
QPushButton#SecondaryButton {
    border-radius: 14px;
    padding: 6px 14px;
}
QTabWidget#AsterTabs::pane {
    border-left: 1px solid palette(mid);
    border-right: 1px solid palette(mid);
    border-bottom: 1px solid palette(mid);
    border-bottom-left-radius: 18px;
    border-bottom-right-radius: 18px;
    top: -1px;
}
QTabBar::tab {
    border: 1px solid palette(mid);
    border-bottom: 0;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
    padding: 5px 12px;
    margin-right: 2px;
    background: palette(button);
    color: palette(button-text);
}
QTabBar::tab:selected {
    background: palette(base);
}
QLabel#AsterCardTitle,
QLabel#AsterErrorTitle,
QLabel#AsterSettingsTitle {
    font-size: 28px;
    font-weight: 800;
}
QLabel#AsterCardSubtitle,
QLabel#AsterErrorSubtitle,
QLabel#AsterSettingsSubtitle,
QLabel#AsterFooterInfo,
QLabel#AsterMutedLabel,
QLabel#AsterContextLabel,
QLabel#StatusInfoLabel {
    color: palette(mid);
}
QFrame#AsterFormSection {
    background: transparent;
    border: none;
    border-bottom: 1px solid palette(mid);
    border-radius: 0;
    padding: 8px 0;
    margin-bottom: 4px;
}
QFrame#AsterQuickLinkButton,
QFrame#AsterErrorIconWrap,
QFrame#AsterMobileFrame {
    background: palette(base);
    border: 1px solid palette(mid);
    border-radius: 16px;
}
QLabel#AsterQuickLinkIcon,
QLabel#AsterQuickLinkTitle,
QLabel#AsterQuickLinkSubtitle,
QCheckBox,
QLabel {
    background: transparent;
}
QScrollArea#AsterSettingsScroll {
    background: transparent;
    border: 0;
}
QProgressBar#LoadProgress {
    min-height: 18px;
    border-radius: 12px;
    text-align: center;
}

/* Yeni Sekme Butonu Stili */
QToolButton#NewTabButton {
    background: transparent;
    border: none;
    border-radius: 11px;
    min-width: 22px;
    max-width: 22px;
    min-height: 22px;
    max-height: 22px;
    padding: 0px;
    margin: 0px;
}
QToolButton#NewTabButton:hover {
    background: rgba(255, 255, 255, 0.12);
    border: none;
}
QToolButton#NewTabButton:pressed {
    background: rgba(255, 255, 255, 0.20);
    border: none;
}

QScrollArea#AsterSettingsSectionScroll {
    background: transparent;
    border: 0;
}
QStackedWidget#AsterSettingsStack QFrame#AsterFormSection {
    border-bottom: 0;
    margin-bottom: 0;
}
QFrame#AsterSettingsNav {
    background: transparent;
    border: none;
}
QPushButton#AsterSettingsNavItem {
    background: transparent;
    border: none;
    border-left: 2px solid transparent;
    border-radius: 8px;
    padding: 7px 10px;
    text-align: left;
    font-weight: 600;
}
QPushButton#AsterSettingsNavItem:hover {
    background: palette(button);
}
QPushButton#AsterSettingsNavItem:checked {
    background: palette(highlight);
    border-left: 2px solid palette(highlight);
    color: palette(highlighted-text);
}

/* Acilir-ok/gosterge isaretleri: butun temalarda kapali */
QToolButton::menu-indicator,
QToolButton::menu-arrow,
QPushButton::menu-indicator {
    image: none;
    width: 0px;
    height: 0px;
    border: none;
}
""".strip()


def available_qt_styles() -> list[str]:
    base = ['system', 'fusion']
    try:
        from PyQt6.QtWidgets import QStyleFactory
        keys = [str(key).strip().lower() for key in QStyleFactory.keys()]
    except Exception:
        keys = []
    ordered: list[str] = []
    for name in base + keys:
        clean = name.strip().lower()
        if clean and clean not in ordered:
            ordered.append(clean)
    return ordered or base



_HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def _normalize_hex(value: str | None, default: str = "") -> str:
    clean = str(value or "").strip()
    if clean.startswith("0x") and len(clean) == 8:
        clean = "#" + clean[2:]
    if clean and not clean.startswith("#"):
        clean = "#" + clean
    if _HEX_RE.match(clean):
        return "#" + clean[1:].lower()
    return default


def _is_light(value: str) -> bool:
    """Whether dark text reads better than light text on this colour."""
    base = _normalize_hex(value, ACCENT)
    red, green, blue = (int(base[i:i + 2], 16) for i in (1, 3, 5))
    return (0.299 * red + 0.587 * green + 0.114 * blue) > 150


def _shift_hex(value: str, amount: int) -> str:
    base = _normalize_hex(value, ACCENT)
    try:
        r = max(0, min(255, int(base[1:3], 16) + amount))
        g = max(0, min(255, int(base[3:5], 16) + amount))
        b = max(0, min(255, int(base[5:7], 16) + amount))
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return base


def _density_overrides(ui_density: str) -> str:
    density = str(ui_density or "comfortable").strip().lower()
    if density == "compact":
        return """
QToolBar#AsterToolbar { padding: 2px 6px; spacing: 2px; }
QLineEdit#AddressBar { min-height: 24px; max-height: 26px; padding: 2px 12px; border-radius: 13px; }
QTabBar::tab { min-height: 24px; padding: 4px 12px; }
"""
    if density == "spacious":
        return """
QToolBar#AsterToolbar { padding: 4px 8px; spacing: 4px; }
QLineEdit#AddressBar { min-height: 28px; max-height: 30px; padding: 3px 16px; border-radius: 15px; }
QTabBar::tab { min-height: 28px; padding: 6px 16px; }
"""
    return """
QToolBar#AsterToolbar { padding: 3px 6px; spacing: 3px; }
QLineEdit#AddressBar { min-height: 26px; max-height: 28px; padding: 2px 14px; border-radius: 14px; }
QTabBar::tab { min-height: 26px; padding: 4px 14px; }
"""


def _corner_overrides(radius: int) -> str:
    return """
QTabBar::tab { border-top-left-radius: 18px; border-top-right-radius: 18px; border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }
QFrame#AsterPageShell, QFrame#AsterCard, QFrame#AsterSettingsCard, QFrame#AsterFormSection, QWidget#AsterHomeBlock { background: transparent; border: none; }
QLabel { background: transparent; }
"""

def normalize_qt_style(style_name: str) -> str:
    clean = (style_name or 'fusion').strip().lower()
    if not clean:
        return 'fusion'
    if clean == 'system_default':
        return 'system'
    return clean


def apply_qt_style(app, style_name: str) -> str:
    clean = normalize_qt_style(style_name)
    try:
        from PyQt6.QtWidgets import QStyleFactory
    except Exception:
        return clean
    available = {str(key).strip().lower(): str(key) for key in QStyleFactory.keys()}
    if clean in {'', 'system'}:
        system_preferences = ['breeze', 'windowsvista', 'windows11', 'windows', 'gtk+', 'gtk', 'macos', 'macintosh']
        chosen = None
        for name in system_preferences:
            chosen = available.get(name)
            if chosen:
                break
        if not chosen:
            for lowered_name, original in available.items():
                if lowered_name != 'fusion':
                    chosen = original
                    break
        if chosen:
            try:
                app.setStyle(QStyleFactory.create(chosen) or app.style())
                return 'system'
            except Exception:
                pass
        try:
            app.setStyle(QStyleFactory.create('Fusion') or app.style())
            return 'fusion'
        except Exception:
            return clean
    chosen = available.get(clean)
    if not chosen and clean == 'fusion':
        chosen = 'Fusion'
    if chosen:
        try:
            app.setStyle(QStyleFactory.create(chosen) or app.style())
            return clean
        except Exception:
            pass
    try:
        app.setStyle(QStyleFactory.create('Fusion') or app.style())
        return 'fusion'
    except Exception:
        return clean


def stylesheet_for(theme_name: str, background_transparency_percent: int = 10, accent_color: str = "", ui_density: str = "comfortable", window_corner_radius: int = 18) -> str:
    import os
    theme = (theme_name or 'firefox_dark').strip().lower()
    if theme not in _THEME_TOKENS and theme != 'system':
        theme = 'firefox_dark'
    if theme == 'system':
        rendered = _SYSTEM_TEMPLATE
    else:
        tokens = dict(_THEME_TOKENS.get(theme, _THEME_TOKENS['firefox_dark']))
        accent = _normalize_hex(accent_color, "")
        if accent:
            # A light accent has no room to brighten, so it darkens on hover
            # instead, and text on it flips to whichever end stays readable.
            light = _is_light(accent)
            tokens['accent'] = accent
            tokens['accent_hover'] = _shift_hex(accent, -24 if light else 22)
            tokens['accent_pressed'] = _shift_hex(accent, -56 if light else -22)
            tokens['accent_text'] = ACCENT_TEXT if light else '#F2F4F7'
            tokens['accent_soft'] = _rgba(accent, 46)
            tokens['accent_faint'] = _rgba(accent, 24)
            tokens['focus_ring'] = _rgba(accent, 105)
        try:
            transparency = int(background_transparency_percent)
        except Exception:
            transparency = 10
        transparency = max(0, min(60, transparency))
        alpha = max(170, round(255 * (100 - transparency) / 100))
        page_alpha = min(255, alpha + 4)
        dock_alpha = min(255, alpha + 6)
        if transparency > 0 and window_translucency_allowed(theme, 'fusion', transparency):
            tokens.update(
                {
                    'window_bg': _rgba(tokens.get('window_bg', '#0C0E12'), min(255, alpha + 8)),
                    'shell_bg': _rgba(tokens['shell_hex'], alpha),
                    'page_bg': _rgba(tokens['page_bg'], page_alpha),
                    'dock_bg': _rgba(tokens['dock_hex'], dock_alpha),
                }
            )
        else:
            tokens.update(
                {
                    'window_bg': tokens.get('window_bg', '#0C0E12'),
                    'shell_bg': tokens['shell_hex'],
                    'page_bg': tokens['page_bg'],
                    'dock_bg': tokens['dock_hex'],
                }
            )
        rendered = _BASE_TEMPLATE
        icons_dir = os.path.join(os.path.dirname(__file__), "assets", "icons")
        check_path = os.path.join(icons_dir, "check.svg").replace("\\", "/")
        radio_path = os.path.join(icons_dir, "radio_dot.svg").replace("\\", "/")
        rendered = rendered.replace("{check_icon_path}", check_path)
        rendered = rendered.replace("{radio_icon_path}", radio_path)
        for direction in ("up", "down", "left", "right"):
            arrow_path = os.path.join(icons_dir, f"scroll_arrow_{direction}.svg").replace("\\", "/")
            rendered = rendered.replace("{scroll_" + direction + "_icon_path}", arrow_path)
        for key, value in tokens.items():
            rendered = rendered.replace("{" + key + "}", str(value))
    return rendered + "\n" + _density_overrides(ui_density) + "\n" + _corner_overrides(window_corner_radius)


def window_translucency_allowed(theme_name: str, qt_style: str, background_transparency_percent: int = 10) -> bool:
    theme = (theme_name or 'black_arc').strip().lower()
    style = normalize_qt_style(qt_style)
    try:
        transparency = int(background_transparency_percent)
    except Exception:
        transparency = 0
    if transparency <= 0:
        return False
    return theme in {'black_arc', 'aster_dark'} and style == 'fusion'
