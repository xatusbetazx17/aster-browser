from __future__ import annotations

import re
from typing import Iterable


def _rgba(hex_color: str, alpha: int) -> str:
    color = hex_color.lstrip('#')
    if len(color) != 6:
        raise ValueError(f'Expected 6-digit hex color, got {hex_color!r}')
    r = int(color[0:2], 16)
    g = int(color[2:4], 16)
    b = int(color[4:6], 16)
    return f'rgba({r}, {g}, {b}, {alpha})'


_BASE_TEMPLATE = """
QWidget {
    background: {window_bg};
    color: #d7dce2;
    font-size: 13px;
}
QMainWindow#AsterWindow {
    background: {window_bg};
}
QWidget#AsterTitleBar {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {title_top}, stop:1 {title_bottom});
    border: 1px solid #2a2f39;
    border-bottom: 0;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
}
QToolButton#TitleLogoButton {
    background: transparent;
    border: 0;
    padding: 0;
}
QLabel#AsterTitleLabel {
    color: #f3f5f8;
    font-size: 15px;
    font-weight: 700;
}
QLabel#AsterContextLabel {
    color: #8e98a7;
    font-size: 11px;
}
QToolButton#HeaderMenuButton,
QToolButton#HeaderCompactButton {
    background: {panel_bg};
    border: 1px solid #303744;
    border-radius: 10px;
    padding: 7px 12px;
    color: #edf1f5;
    font-weight: 600;
}
QToolButton#HeaderMenuButton:hover,
QToolButton#HeaderCompactButton:hover {
    background: #232935;
}
QToolButton#HeaderMenuButton:pressed,
QToolButton#HeaderCompactButton:pressed {
    background: #181d26;
}
QToolButton#WindowButton {
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid #2f3642;
    border-radius: 10px;
    padding: 0;
}
QToolButton#WindowButton:hover {
    background: rgba(255, 255, 255, 0.08);
}
QToolButton#WindowButton:pressed {
    background: rgba(255, 255, 255, 0.12);
}
QToolButton#WindowCloseButton {
    background: transparent;
    border: 1px solid #2f3642;
    border-radius: 10px;
    padding: 0;
}
QToolButton#WindowCloseButton:hover {
    background: rgba(255, 120, 120, 0.10);
    border-color: #6f4b4b;
}
QToolButton#WindowCloseButton:pressed {
    background: rgba(255, 120, 120, 0.18);
}
QToolBar#AsterToolbar {
    background: {shell_bg};
    border-left: 1px solid #2a2f39;
    border-right: 1px solid #2a2f39;
    border-bottom: 1px solid #2a2f39;
    spacing: 6px;
    padding: 8px 10px;
}
QToolBar#AsterToolbar::separator {
    width: 12px;
    background: transparent;
}
QToolBar#AsterToolbar QToolButton,
QToolButton#ToolbarOverflowButton {
    background: {panel_bg};
    border: 1px solid #313946;
    border-radius: 11px;
    padding: 8px;
    margin: 0 1px;
    color: #eef2f7;
}
QToolBar#AsterToolbar QToolButton:hover,
QToolButton#ToolbarOverflowButton:hover {
    background: #242b37;
}
QToolBar#AsterToolbar QToolButton:pressed,
QToolButton#ToolbarOverflowButton:pressed {
    background: #171c24;
}
QLineEdit,
QTextEdit,
QTextBrowser,
QListWidget,
QComboBox,
QSpinBox,
QPlainTextEdit {
    background: {field_bg};
    border: 1px solid #313946;
    border-radius: 12px;
    padding: 7px 10px;
    selection-background-color: {accent};
    selection-color: #ffffff;
}
QLineEdit:focus,
QTextEdit:focus,
QTextBrowser:focus,
QListWidget:focus,
QComboBox:focus,
QSpinBox:focus,
QPlainTextEdit:focus {
    border: 1px solid #6f95ff;
}
QComboBox {
    padding-right: 26px;
    min-height: 18px;
}
QComboBox#ContainerCombo {
    min-width: 164px;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 26px;
    border: 0;
    border-left: 1px solid #2f3642;
    border-top-right-radius: 12px;
    border-bottom-right-radius: 12px;
    background: {panel_bg};
}
QComboBox::down-arrow {
    width: 10px;
    height: 10px;
}
QComboBox QAbstractItemView {
    background: {shell_bg};
    border: 1px solid #2d333e;
    border-radius: 12px;
    padding: 6px;
    selection-background-color: #243547;
    selection-color: #ffffff;
    outline: 0;
}
QAbstractItemView {
    outline: 0;
}
QLineEdit#AddressBar {
    min-height: 18px;
    font-size: 14px;
}
QLineEdit#ModeBadge {
    background: #161c26;
    color: #9cbcf7;
    font-weight: 700;
}
QLabel#StatusInfoLabel {
    color: #9eb1cf;
    padding: 2px 6px;
}
QPushButton {
    background: {accent};
    color: white;
    border: 0;
    border-radius: 12px;
    padding: 8px 14px;
    font-weight: 600;
}
QPushButton:hover {
    background: {accent_hover};
}
QPushButton:pressed {
    background: {accent_pressed};
}
QPushButton#GhostButton,
QPushButton#SecondaryButton {
    background: {panel_bg};
    border: 1px solid #313946;
    color: #e7ecf2;
}
QPushButton#GhostButton:hover,
QPushButton#SecondaryButton:hover {
    background: #242b37;
}
QPushButton#GhostButton:pressed,
QPushButton#SecondaryButton:pressed {
    background: #171c24;
}
QWidget#AsterMobileView {
    background: transparent;
}
QLabel#AsterMobileBadge {
    color: #9cbcf7;
    font-weight: 700;
}
QFrame#AsterMobileShell,
QFrame#AsterCard,
QFrame#AsterStatsStrip,
QFrame#AsterErrorCard,
QFrame#AsterSettingsCard,
QFrame#AsterSidePanelCard,
QFrame#AsterPageShell,
QFrame#AsterFooterStrip {
    background: {shell_bg};
    border: 1px solid #2d333e;
    border-radius: 20px;
}
QLabel#AsterCardTitle,
QLabel#AsterErrorTitle,
QLabel#AsterSettingsTitle {
    color: #f5f7fa;
    font-size: 28px;
    font-weight: 800;
}
QLabel#AsterCardSubtitle,
QLabel#AsterErrorSubtitle,
QLabel#AsterSettingsSubtitle,
QLabel#AsterFooterInfo {
    color: #a6b0be;
    font-size: 13px;
}
QFrame#AsterQuickLinkButton {
    background: {tile_bg};
    border: 1px solid #2f3642;
    border-radius: 16px;
}
QFrame#AsterQuickLinkButton:hover {
    background: #181d26;
    border-color: #3a4556;
}
QLabel#AsterQuickLinkTitle {
    color: #eef2f7;
    font-size: 15px;
    font-weight: 700;
}
QLabel#AsterQuickLinkSubtitle {
    color: #9aa4b2;
    font-size: 11px;
}
QLabel#AsterQuickLinkIcon {
    background: transparent;
}
QFrame#AsterMobileFrame {
    background: #090d14;
    border: 1px solid #313d55;
    border-radius: 22px;
    padding: 0;
}
QLabel#AsterMobileHeader {
    color: #98a8c8;
    font-size: 11px;
    font-weight: 600;
}
QTabWidget#AsterTabs::pane {
    background: {page_bg};
    border-left: 1px solid #2a2f39;
    border-right: 1px solid #2a2f39;
    border-bottom: 1px solid #2a2f39;
    border-bottom-left-radius: 18px;
    border-bottom-right-radius: 18px;
    top: -1px;
}
QTabBar::tab {
    background: #171b23;
    color: #cbd3de;
    border: 1px solid #303744;
    border-bottom: 0;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    padding: 9px 16px;
    margin-right: 6px;
}
QTabBar::tab:hover {
    background: #1d232d;
}
QTabBar::tab:selected {
    background: #202733;
    color: #ffffff;
}
QTabBar::close-button {
    background: transparent;
    border-radius: 7px;
}
QTabBar::close-button:hover {
    background: rgba(255, 255, 255, 0.08);
}
QStatusBar#AsterStatusBar {
    background: {shell_bg};
    border-left: 1px solid #2a2f39;
    border-right: 1px solid #2a2f39;
    border-bottom: 1px solid #2a2f39;
    border-top: 0;
    border-bottom-left-radius: 18px;
    border-bottom-right-radius: 18px;
    color: #97a4bb;
}
QDockWidget#AsterAIDock,
QDockWidget#AsterSideDock {
    border-left: 1px solid #2b364b;
    background: {dock_bg};
}
QDockWidget#AsterAIDock::title,
QDockWidget#AsterSideDock::title {
    background: {shell_bg};
    padding: 10px 12px;
    text-align: left;
    font-weight: 700;
}
QMenu {
    background: {shell_bg};
    border: 1px solid #2d333e;
    border-radius: 12px;
    padding: 6px;
}
QMenu::item {
    padding: 8px 18px;
    border-radius: 8px;
}
QMenu::item:selected {
    background: #253040;
}
QProgressBar#LoadProgress {
    background: #0f1218;
    border: 1px solid #2d333e;
    border-radius: 10px;
    text-align: center;
    min-height: 18px;
}
QProgressBar#LoadProgress::chunk {
    background: {accent};
    border-radius: 9px;
}
QCheckBox, QLabel {
    background: transparent;
}
QScrollArea#AsterSettingsScroll {
    background: transparent;
    border: 0;
}
QFrame#AsterFormSection {
    background: {panel_bg};
    border: 1px solid #2d333e;
    border-radius: 16px;
}
QLabel#AsterSectionTitle {
    color: #edf2f7;
    font-size: 15px;
    font-weight: 700;
}
QLabel#AsterMutedLabel {
    color: #92a0b2;
    font-size: 12px;
}
QFrame#AsterErrorIconWrap {
    background: {field_bg};
    border: 1px solid #2d333e;
    border-radius: 18px;
}
QScrollBar:vertical {
    background: transparent;
    width: 12px;
    margin: 4px 0 4px 0;
}
QScrollBar::handle:vertical {
    background: #2b3544;
    border-radius: 6px;
    min-height: 24px;
}
QScrollBar::handle:vertical:hover {
    background: #3a4558;
}
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical,
QScrollBar::left-arrow:vertical,
QScrollBar::right-arrow:vertical,
QScrollBar::up-arrow:vertical,
QScrollBar::down-arrow:vertical {
    background: transparent;
    border: 0;
    height: 0;
}
QScrollBar:horizontal {
    background: transparent;
    height: 12px;
    margin: 0 4px 0 4px;
}
QScrollBar::handle:horizontal {
    background: #2b3544;
    border-radius: 6px;
    min-width: 24px;
}
QScrollBar::handle:horizontal:hover {
    background: #3a4558;
}
QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal,
QScrollBar::left-arrow:horizontal,
QScrollBar::right-arrow:horizontal,
QScrollBar::up-arrow:horizontal,
QScrollBar::down-arrow:horizontal {
    background: transparent;
    border: 0;
    width: 0;
}
""".strip()


_THEME_TOKENS = {
    'black_arc': {
        'accent': '#3b82f6',
        'accent_hover': '#4a8ef8',
        'accent_pressed': '#2e67c3',
        'title_top': '#171b23',
        'title_bottom': '#11151b',
        'shell_hex': '#171b23',
        'panel_bg': '#1a1f28',
        'field_bg': '#11151c',
        'tile_bg': '#12161d',
        'page_bg': '#0d1117',
        'dock_hex': '#11151c',
    },
    'aster_dark': {
        'accent': '#31c48d',
        'accent_hover': '#43d79a',
        'accent_pressed': '#21966a',
        'title_top': '#151b20',
        'title_bottom': '#10151a',
        'shell_hex': '#151b20',
        'panel_bg': '#182027',
        'field_bg': '#10161b',
        'tile_bg': '#12181d',
        'page_bg': '#0c1114',
        'dock_hex': '#10161b',
    },
}


_SYSTEM_TEMPLATE = """
QWidget {
    font-size: 13px;
}
QMainWindow#AsterWindow,
QToolBar#AsterToolbar,
QTabWidget#AsterTabs::pane,
QStatusBar#AsterStatusBar,
QFrame#AsterMobileShell,
QFrame#AsterCard,
QFrame#AsterStatsStrip,
QFrame#AsterErrorCard,
QFrame#AsterSettingsCard,
QFrame#AsterSidePanelCard,
QFrame#AsterPageShell,
QFrame#AsterFooterStrip,
QMenu {
    background: palette(window);
    color: palette(window-text);
}
QWidget#AsterTitleBar {
    background: palette(window);
    color: palette(window-text);
    border: 1px solid palette(mid);
    border-bottom: 0;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
}
QToolBar#AsterToolbar {
    border-left: 1px solid palette(mid);
    border-right: 1px solid palette(mid);
    border-bottom: 1px solid palette(mid);
    spacing: 6px;
    padding: 8px 10px;
}
QToolBar#AsterToolbar::separator {
    width: 12px;
    background: transparent;
}
QToolBar#AsterToolbar QToolButton,
QToolButton#ToolbarOverflowButton,
QToolButton#HeaderMenuButton,
QToolButton#HeaderCompactButton,
QToolButton#WindowButton,
QToolButton#WindowCloseButton,
QPushButton#GhostButton,
QPushButton#SecondaryButton {
    border-radius: 10px;
    padding: 7px 12px;
}
QTabWidget#AsterTabs::pane {
    border-left: 1px solid palette(mid);
    border-right: 1px solid palette(mid);
    border-bottom: 1px solid palette(mid);
    border-bottom-left-radius: 18px;
    border-bottom-right-radius: 18px;
    top: -1px;
}
QTabBar::tab {
    border: 1px solid palette(mid);
    border-bottom: 0;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    padding: 8px 16px;
    margin-right: 6px;
    background: palette(button);
    color: palette(button-text);
}
QTabBar::tab:selected {
    background: palette(base);
}
QLabel#AsterCardTitle,
QLabel#AsterErrorTitle,
QLabel#AsterSettingsTitle {
    font-size: 28px;
    font-weight: 800;
}
QLabel#AsterCardSubtitle,
QLabel#AsterErrorSubtitle,
QLabel#AsterSettingsSubtitle,
QLabel#AsterFooterInfo,
QLabel#AsterMutedLabel,
QLabel#AsterContextLabel,
QLabel#StatusInfoLabel {
    color: palette(mid);
}
QFrame#AsterFormSection,
QFrame#AsterQuickLinkButton,
QFrame#AsterErrorIconWrap,
QFrame#AsterMobileFrame {
    background: palette(base);
    border: 1px solid palette(mid);
    border-radius: 16px;
}
QLabel#AsterQuickLinkIcon,
QLabel#AsterQuickLinkTitle,
QLabel#AsterQuickLinkSubtitle,
QCheckBox,
QLabel {
    background: transparent;
}
QScrollArea#AsterSettingsScroll {
    background: transparent;
    border: 0;
}
QProgressBar#LoadProgress {
    min-height: 18px;
    border-radius: 10px;
    text-align: center;
}

/* Yeni Sekme Butonu Stili */
QToolButton#NewTabButton {
    background: transparent;
    border: none;
    border-radius: 6px;
    margin-right: 15px; /* Sağdan biraz boşluk bırakır */
    margin-top: 2px;
    padding: 4px;
}

QToolButton#NewTabButton:hover {
    background: rgba(255, 255, 255, 0.1); /* Fare üzerindeyken hafif parlama */
}

QToolButton#NewTabButton:pressed {
    background: rgba(255, 255, 255, 0.05);
}

QToolButton#NewTabButton {
    background: transparent;
    border: none;
    border-radius: 4px;
    padding: 0px; /* İç boşlukları sıfırla ki ikon tam merkeze otursun */
}

QToolButton#NewTabButton:hover {
    background: rgba(255, 255, 255, 0.1);
}
""".strip()


def available_qt_styles() -> list[str]:
    base = ['system', 'fusion']
    try:
        from PyQt6.QtWidgets import QStyleFactory
        keys = [str(key).strip().lower() for key in QStyleFactory.keys()]
    except Exception:
        keys = []
    ordered: list[str] = []
    for name in base + keys:
        clean = name.strip().lower()
        if clean and clean not in ordered:
            ordered.append(clean)
    return ordered or base



_HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def _normalize_hex(value: str | None, default: str = "") -> str:
    clean = str(value or "").strip()
    if clean.startswith("0x") and len(clean) == 8:
        clean = "#" + clean[2:]
    if clean and not clean.startswith("#"):
        clean = "#" + clean
    if _HEX_RE.match(clean):
        return "#" + clean[1:].lower()
    return default


def _shift_hex(value: str, amount: int) -> str:
    base = _normalize_hex(value, "#3b82f6")
    try:
        r = max(0, min(255, int(base[1:3], 16) + amount))
        g = max(0, min(255, int(base[3:5], 16) + amount))
        b = max(0, min(255, int(base[5:7], 16) + amount))
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return base


def _density_overrides(ui_density: str) -> str:
    density = str(ui_density or "comfortable").strip().lower()
    if density == "compact":
        return """
QToolBar { padding: 4px 6px; spacing: 4px; }
QToolButton { min-height: 28px; padding: 4px 8px; }
QLineEdit#AddressBar { min-height: 30px; padding: 4px 10px; }
QTabBar::tab { min-height: 26px; padding: 5px 10px; }
QStatusBar { min-height: 22px; }
"""
    if density == "spacious":
        return """
QToolBar { padding: 10px 12px; spacing: 8px; }
QToolButton { min-height: 40px; padding: 8px 14px; }
QLineEdit#AddressBar { min-height: 42px; padding: 8px 14px; }
QTabBar::tab { min-height: 38px; padding: 9px 16px; }
QStatusBar { min-height: 30px; }
"""
    return """
QToolBar { padding: 7px 9px; spacing: 6px; }
QToolButton { min-height: 34px; padding: 6px 11px; }
QLineEdit#AddressBar { min-height: 36px; padding: 6px 12px; }
QTabBar::tab { min-height: 32px; padding: 7px 13px; }
"""


def _corner_overrides(radius: int) -> str:
    try:
        radius = max(0, min(32, int(radius)))
    except Exception:
        radius = 18
    return f"""
QWidget#AsterFormSection, QFrame#AsterFormSection, QLineEdit, QTextEdit, QTextBrowser, QComboBox, QMenu, QPushButton, QToolButton {{ border-radius: {radius}px; }}
QTabBar::tab {{ border-radius: {max(0, radius - 6)}px; }}
"""


def normalize_qt_style(style_name: str) -> str:
    clean = (style_name or 'fusion').strip().lower()
    if not clean:
        return 'fusion'
    if clean == 'system_default':
        return 'system'
    return clean


def apply_qt_style(app, style_name: str) -> str:
    clean = normalize_qt_style(style_name)
    try:
        from PyQt6.QtWidgets import QStyleFactory
    except Exception:
        return clean
    available = {str(key).strip().lower(): str(key) for key in QStyleFactory.keys()}
    if clean in {'', 'system'}:
        system_preferences = ['breeze', 'windowsvista', 'windows11', 'windows', 'gtk+', 'gtk', 'macos', 'macintosh']
        chosen = None
        for name in system_preferences:
            chosen = available.get(name)
            if chosen:
                break
        if not chosen:
            for lowered_name, original in available.items():
                if lowered_name != 'fusion':
                    chosen = original
                    break
        if chosen:
            try:
                app.setStyle(QStyleFactory.create(chosen) or app.style())
                return 'system'
            except Exception:
                pass
        try:
            app.setStyle(QStyleFactory.create('Fusion') or app.style())
            return 'fusion'
        except Exception:
            return clean
    chosen = available.get(clean)
    if not chosen and clean == 'fusion':
        chosen = 'Fusion'
    if chosen:
        try:
            app.setStyle(QStyleFactory.create(chosen) or app.style())
            return clean
        except Exception:
            pass
    try:
        app.setStyle(QStyleFactory.create('Fusion') or app.style())
        return 'fusion'
    except Exception:
        return clean


def stylesheet_for(theme_name: str, background_transparency_percent: int = 10, accent_color: str = "", ui_density: str = "comfortable", window_corner_radius: int = 18) -> str:
    theme = (theme_name or 'black_arc').strip().lower()
    if theme == 'system':
        rendered = _SYSTEM_TEMPLATE
    else:
        tokens = dict(_THEME_TOKENS.get(theme, _THEME_TOKENS['black_arc']))
        accent = _normalize_hex(accent_color, "")
        if accent:
            tokens['accent'] = accent
            tokens['accent_hover'] = _shift_hex(accent, 22)
            tokens['accent_soft'] = _rgba(accent, 46)
            tokens['accent_faint'] = _rgba(accent, 24)
            tokens['focus_ring'] = _rgba(accent, 105)
        try:
            transparency = int(background_transparency_percent)
        except Exception:
            transparency = 10
        transparency = max(0, min(60, transparency))
        alpha = max(170, round(255 * (100 - transparency) / 100))
        page_alpha = min(255, alpha + 4)
        dock_alpha = min(255, alpha + 6)
        tokens.update(
            {
                'window_bg': _rgba('#0b0f14', min(255, alpha + 8)),
                'shell_bg': _rgba(tokens['shell_hex'], alpha),
                'page_bg': _rgba(tokens['page_bg'], page_alpha),
                'dock_bg': _rgba(tokens['dock_hex'], dock_alpha),
            }
        )
        rendered = _BASE_TEMPLATE
        for key, value in tokens.items():
            rendered = rendered.replace("{" + key + "}", str(value))
    return rendered + "\n" + _density_overrides(ui_density) + "\n" + _corner_overrides(window_corner_radius)


def window_translucency_allowed(theme_name: str, qt_style: str, background_transparency_percent: int = 10) -> bool:
    theme = (theme_name or 'black_arc').strip().lower()
    style = normalize_qt_style(qt_style)
    try:
        transparency = int(background_transparency_percent)
    except Exception:
        transparency = 0
    if transparency <= 0:
        return False
    return theme in {'black_arc', 'aster_dark'} and style == 'fusion'
