from __future__ import annotations

import os
import sqlite3
import time
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .paths import data_dir, downloads_dir

TEXT_EXTENSIONS = {
    '.txt', '.md', '.markdown', '.rst', '.log', '.json', '.yaml', '.yml', '.ini', '.conf', '.cfg',
    '.csv', '.tsv', '.html', '.htm', '.xml', '.py', '.js', '.ts', '.tsx', '.jsx', '.css', '.scss',
    '.java', '.c', '.cpp', '.h', '.hpp', '.rs', '.go', '.rb', '.php', '.sh', '.zsh', '.fish', '.sql',
}
NAME_ONLY_EXTENSIONS = {'.pdf', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx', '.odt', '.ods', '.odp'}
SKIP_DIR_NAMES = {
    '__pycache__', 'node_modules', '.git', '.hg', '.svn', '.cache', '.venv', 'venv',
    '.cargo', '.rustup', '.steam', '.local', '.var', '.flatpak', 'dist', 'build',
}


@dataclass
class IndexSearchResult:
    path: Path
    score: float
    snippet: str = ''
    source: str = 'documents'
    kind: str = 'document'


@dataclass
class HistoryResult:
    url: str
    title: str
    visit_count: int
    last_visited: float


@dataclass
class BookmarkResult:
    url: str
    title: str
    created_at: float
    last_used: float


class LocalIndex:
    def __init__(self, db_path: Path | None = None) -> None:
        assistant_dir = data_dir() / 'assistant'
        assistant_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path or (assistant_dir / 'local_index.sqlite3')
        self._fts_enabled = False
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        return conn

    def _ensure_schema(self) -> None:
        with closing(self._connect()) as conn:
            conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS docs (
                    path TEXT PRIMARY KEY,
                    root TEXT NOT NULL,
                    name TEXT NOT NULL,
                    ext TEXT NOT NULL,
                    size INTEGER NOT NULL,
                    mtime REAL NOT NULL,
                    snippet TEXT NOT NULL,
                    preview TEXT NOT NULL,
                    indexed_at REAL NOT NULL
                )
                '''
            )
            conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS history (
                    url TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    visit_count INTEGER NOT NULL DEFAULT 1,
                    last_visited REAL NOT NULL
                )
                '''
            )
            conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS bookmarks (
                    url TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    last_used REAL NOT NULL
                )
                '''
            )
            conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                '''
            )
            try:
                conn.execute(
                    '''
                    CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(
                        path UNINDEXED,
                        name,
                        snippet,
                        preview
                    )
                    '''
                )
                self._fts_enabled = True
            except sqlite3.OperationalError:
                self._fts_enabled = False
            conn.commit()

    def _set_meta(self, key: str, value: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute('INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, value))
            conn.commit()

    def _get_meta(self, key: str, default: str = '') -> str:
        with closing(self._connect()) as conn:
            row = conn.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
            return str(row['value']) if row else default

    def record_history(self, url: str, title: str = '') -> None:
        url = (url or '').strip()
        if not url or url.startswith('aster:') or url == 'about:blank':
            return
        now = time.time()
        title = (title or '').strip()[:500]
        with closing(self._connect()) as conn:
            row = conn.execute('SELECT visit_count FROM history WHERE url=?', (url,)).fetchone()
            if row:
                visit_count = int(row['visit_count']) + 1
                conn.execute(
                    'UPDATE history SET title=?, visit_count=?, last_visited=? WHERE url=?',
                    (title, visit_count, now, url),
                )
            else:
                conn.execute(
                    'INSERT INTO history(url, title, visit_count, last_visited) VALUES(?, ?, 1, ?)',
                    (url, title, now),
                )
            conn.commit()

    def list_history(self, *, limit: int = 80) -> list[HistoryResult]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                '''
                SELECT url, title, visit_count, last_visited
                FROM history
                ORDER BY last_visited DESC, visit_count DESC
                LIMIT ?
                ''',
                (limit,),
            ).fetchall()
        return [
            HistoryResult(
                url=str(row['url']),
                title=str(row['title']),
                visit_count=int(row['visit_count']),
                last_visited=float(row['last_visited']),
            )
            for row in rows
        ]

    def search_history(self, query: str, *, limit: int = 8) -> list[HistoryResult]:
        query = ' '.join(query.split())
        if not query:
            return []
        like = f'%{query.lower()}%'
        with closing(self._connect()) as conn:
            rows = conn.execute(
                '''
                SELECT url, title, visit_count, last_visited
                FROM history
                WHERE lower(url) LIKE ? OR lower(title) LIKE ?
                ORDER BY visit_count DESC, last_visited DESC
                LIMIT ?
                ''',
                (like, like, limit),
            ).fetchall()
        return [
            HistoryResult(
                url=str(row['url']),
                title=str(row['title']),
                visit_count=int(row['visit_count']),
                last_visited=float(row['last_visited']),
            )
            for row in rows
        ]

    def add_bookmark(self, url: str, title: str = '') -> None:
        url = (url or '').strip()
        if not url or url.startswith('aster:') or url == 'about:blank':
            return
        now = time.time()
        title = (title or '').strip()[:500]
        with closing(self._connect()) as conn:
            conn.execute(
                '''
                INSERT INTO bookmarks(url, title, created_at, last_used)
                VALUES(?, ?, ?, ?)
                ON CONFLICT(url) DO UPDATE SET
                    title=excluded.title,
                    last_used=excluded.last_used
                ''',
                (url, title, now, now),
            )
            conn.commit()

    def remove_bookmark(self, url: str) -> bool:
        url = (url or '').strip()
        if not url:
            return False
        with closing(self._connect()) as conn:
            cursor = conn.execute('DELETE FROM bookmarks WHERE url=?', (url,))
            conn.commit()
            return cursor.rowcount > 0

    def touch_bookmark(self, url: str) -> None:
        url = (url or '').strip()
        if not url:
            return
        with closing(self._connect()) as conn:
            conn.execute('UPDATE bookmarks SET last_used=? WHERE url=?', (time.time(), url))
            conn.commit()

    def list_bookmarks(self, *, limit: int = 12) -> list[BookmarkResult]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                '''
                SELECT url, title, created_at, last_used
                FROM bookmarks
                ORDER BY last_used DESC, created_at DESC
                LIMIT ?
                ''',
                (limit,),
            ).fetchall()
        return [
            BookmarkResult(
                url=str(row['url']),
                title=str(row['title']),
                created_at=float(row['created_at']),
                last_used=float(row['last_used']),
            )
            for row in rows
        ]

    def search_bookmarks(self, query: str, *, limit: int = 8) -> list[BookmarkResult]:
        query = ' '.join(query.split())
        if not query:
            return self.list_bookmarks(limit=limit)
        like = f'%{query.lower()}%'
        with closing(self._connect()) as conn:
            rows = conn.execute(
                '''
                SELECT url, title, created_at, last_used
                FROM bookmarks
                WHERE lower(url) LIKE ? OR lower(title) LIKE ?
                ORDER BY last_used DESC, created_at DESC
                LIMIT ?
                ''',
                (like, like, limit),
            ).fetchall()
        return [
            BookmarkResult(
                url=str(row['url']),
                title=str(row['title']),
                created_at=float(row['created_at']),
                last_used=float(row['last_used']),
            )
            for row in rows
        ]

    def maybe_sync_roots(self, roots: Iterable[Path], *, max_files: int = 1200, min_interval_seconds: int = 300) -> None:
        try:
            last_sync = float(self._get_meta('last_sync', '0') or '0')
        except Exception:
            last_sync = 0.0
        if time.time() - last_sync < max(10, min_interval_seconds):
            return
        self.sync_roots(list(roots), max_files=max_files)

    def sync_roots(self, roots: list[Path], *, max_files: int = 1200) -> None:
        normalized_roots = [Path(root).expanduser() for root in roots if Path(root).expanduser().exists()]
        indexed_at = time.time()
        seen_paths: set[str] = set()
        visited = 0
        with closing(self._connect()) as conn:
            for root in normalized_roots:
                for dirpath, dirnames, filenames in os.walk(root):
                    dirnames[:] = [name for name in dirnames if name not in SKIP_DIR_NAMES and not name.startswith('.')]
                    for filename in filenames:
                        path = Path(dirpath) / filename
                        ext = path.suffix.lower()
                        if ext not in TEXT_EXTENSIONS and ext not in NAME_ONLY_EXTENSIONS:
                            continue
                        visited += 1
                        if visited > max_files:
                            break
                        try:
                            stat = path.stat()
                        except Exception:
                            continue
                        path_str = str(path)
                        seen_paths.add(path_str)
                        row = conn.execute('SELECT mtime, size FROM docs WHERE path=?', (path_str,)).fetchone()
                        if row and float(row['mtime']) == float(stat.st_mtime) and int(row['size']) == int(stat.st_size):
                            continue
                        preview = self._read_preview(path) if ext in TEXT_EXTENSIONS else ''
                        snippet = self._best_snippet(preview, path.name)
                        conn.execute(
                            '''
                            INSERT INTO docs(path, root, name, ext, size, mtime, snippet, preview, indexed_at)
                            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(path) DO UPDATE SET
                                root=excluded.root,
                                name=excluded.name,
                                ext=excluded.ext,
                                size=excluded.size,
                                mtime=excluded.mtime,
                                snippet=excluded.snippet,
                                preview=excluded.preview,
                                indexed_at=excluded.indexed_at
                            ''',
                            (path_str, str(root), path.name, ext, int(stat.st_size), float(stat.st_mtime), snippet, preview, indexed_at),
                        )
                        if self._fts_enabled:
                            rowid_row = conn.execute('SELECT rowid FROM docs WHERE path=?', (path_str,)).fetchone()
                            if rowid_row:
                                rowid = int(rowid_row['rowid'])
                                conn.execute('DELETE FROM docs_fts WHERE rowid=?', (rowid,))
                                conn.execute(
                                    'INSERT INTO docs_fts(rowid, path, name, snippet, preview) VALUES(?, ?, ?, ?, ?)',
                                    (rowid, path_str, path.name, snippet, preview[:12000]),
                                )
                    if visited > max_files:
                        break
                if visited > max_files:
                    break

            root_strings = {str(root) for root in normalized_roots}
            stale_rows = conn.execute('SELECT path, root, rowid FROM docs').fetchall()
            for row in stale_rows:
                path_str = str(row['path'])
                root_str = str(row['root'])
                if root_str in root_strings and path_str not in seen_paths:
                    if self._fts_enabled:
                        conn.execute('DELETE FROM docs_fts WHERE rowid=?', (int(row['rowid']),))
                    conn.execute('DELETE FROM docs WHERE path=?', (path_str,))
            conn.commit()
        self._set_meta('last_sync', str(indexed_at))

    def search_documents(self, query: str, *, limit: int = 6, pdf_only: bool = False) -> list[IndexSearchResult]:
        query = ' '.join(query.split())
        if not query:
            return []
        tokens = [self._sanitize_token(token) for token in self._tokenize(query)]
        with closing(self._connect()) as conn:
            if self._fts_enabled and tokens:
                match_query = ' OR '.join(f'"{token}"' for token in tokens if token)
                if match_query:
                    sql = (
                        'SELECT docs.path AS path, docs.snippet AS snippet, docs.ext AS ext, '
                        'bm25(docs_fts, 1.5, 4.0, 0.3) AS score '
                        'FROM docs_fts JOIN docs ON docs.rowid = docs_fts.rowid '
                        'WHERE docs_fts MATCH ? '
                    )
                    params: list[object] = [match_query]
                    if pdf_only:
                        sql += 'AND docs.ext = ? '
                        params.append('.pdf')
                    sql += 'ORDER BY score LIMIT ?'
                    params.append(limit)
                    try:
                        rows = conn.execute(sql, params).fetchall()
                        if rows:
                            return [
                                IndexSearchResult(path=Path(str(row['path'])), score=float(row['score']), snippet=str(row['snippet'] or ''))
                                for row in rows
                            ]
                    except sqlite3.OperationalError:
                        pass
            like_parts = [f'%{token}%' for token in tokens] or [f'%{query.lower()}%']
            conditions = []
            params: list[object] = []
            for like in like_parts:
                conditions.append('(lower(path) LIKE ? OR lower(name) LIKE ? OR lower(snippet) LIKE ? OR lower(preview) LIKE ?)')
                params.extend([like, like, like, like])
            sql = 'SELECT path, snippet, ext FROM docs WHERE ' + ' OR '.join(conditions)
            if pdf_only:
                sql += ' AND ext = ?'
                params.append('.pdf')
            sql += ' ORDER BY mtime DESC LIMIT ?'
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
        results: list[IndexSearchResult] = []
        for row in rows:
            score = 0.0
            path_text = str(row['path']).lower()
            snippet = str(row['snippet'] or '')
            for token in tokens:
                if token and token in path_text:
                    score -= 4.0
                if token and token in snippet.lower():
                    score -= 2.0
            results.append(IndexSearchResult(path=Path(str(row['path'])), score=score, snippet=snippet))
        return results[:limit]

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        cleaned = ''.join(ch.lower() if ch.isalnum() else ' ' for ch in text)
        return [part for part in cleaned.split() if len(part) >= 2]

    @staticmethod
    def _sanitize_token(token: str) -> str:
        return ''.join(ch for ch in token if ch.isalnum() or ch in {'_', '-', '.'})

    @staticmethod
    def _read_preview(path: Path, *, max_bytes: int = 250_000) -> str:
        try:
            return path.read_text(encoding='utf-8', errors='replace')[:max_bytes]
        except Exception:
            return ''

    @staticmethod
    def _best_snippet(text: str, fallback: str) -> str:
        for line in text.splitlines():
            clean = ' '.join(line.split())
            if clean:
                return clean[:180]
        return fallback[:180]


def default_index_roots() -> list[Path]:
    env_roots = os.environ.get('ASTER_INTERNAL_AI_ROOTS', '').strip()
    if env_roots:
        return [Path(part).expanduser() for part in env_roots.split(os.pathsep) if part.strip()]
    home = Path.home()
    roots = [home / 'Documents', home / 'Downloads', home / 'Desktop', downloads_dir()]
    return [root for root in roots if root.exists()]
