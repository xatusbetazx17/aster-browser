from __future__ import annotations

import re
from typing import Callable

from PyQt6.QtWebEngineCore import QWebEngineProfile

from .paths import cache_dir, containers_dir, downloads_dir


_SAFE_NAME = re.compile(r"[^a-zA-Z0-9_.-]+")
_QTWEBENGINE_TOKEN = re.compile(r"\s*QtWebEngine/[^\s]+")


def _sanitize(name: str) -> str:
    cleaned = _SAFE_NAME.sub("-", name.strip().lower())
    return cleaned or "default"


def _compat_user_agent(profile: QWebEngineProfile) -> str:
    try:
        current = profile.httpUserAgent() or ""
    except Exception:
        return ""
    return _QTWEBENGINE_TOKEN.sub("", current).strip()


def _mobile_user_agent() -> str:
    return (
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Mobile Safari/537.36"
    )


class ContainerManager:
    def __init__(self, names: list[str], interceptor_factory: Callable[[], object], download_callback: Callable | None = None) -> None:
        self.names = list(dict.fromkeys(names))
        self.interceptor_factory = interceptor_factory
        self.download_callback = download_callback
        self._profiles: dict[str, QWebEngineProfile] = {}
        self._interceptors: dict[str, object] = {}
        containers_dir().mkdir(parents=True, exist_ok=True)
        cache_dir().mkdir(parents=True, exist_ok=True)
        downloads_dir().mkdir(parents=True, exist_ok=True)

    def available(self) -> list[str]:
        return list(self.names)

    def ensure(self, name: str) -> str:
        name = name.strip() or "default"
        if name not in self.names:
            self.names.append(name)
        return name


    def profiles(self) -> list[QWebEngineProfile]:
        return list(self._profiles.values())

    def mobile_profile_name(self, name: str) -> str:
        return f"{self.ensure(name)}__mobile__"

    def compatibility_profile_name(self, name: str) -> str:
        return f"{self.ensure(name)}__compatibility__"

    def profile(self, name: str, *, mobile: bool = False, compatibility: bool = False) -> QWebEngineProfile:
        name = self.ensure(name)
        if compatibility:
            profile_name = self.compatibility_profile_name(name)
        else:
            profile_name = self.mobile_profile_name(name) if mobile else name
        if profile_name in self._profiles:
            return self._profiles[profile_name]
        safe_name = _sanitize(profile_name)
        profile = QWebEngineProfile(profile_name)
        profile.setPersistentStoragePath(str(containers_dir() / safe_name))
        profile.setCachePath(str(cache_dir() / f"profile-{safe_name}"))
        if hasattr(QWebEngineProfile.HttpCacheType, "DiskHttpCache"):
            profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        if hasattr(QWebEngineProfile.PersistentCookiesPolicy, "AllowPersistentCookies"):
            profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies)
        compat_ua = _mobile_user_agent() if mobile else _compat_user_agent(profile)
        if compat_ua:
            try:
                profile.setHttpUserAgent(compat_ua)
            except Exception:
                pass
        interceptor = self.interceptor_factory()
        self._interceptors[profile_name] = interceptor
        try:
            profile.setUrlRequestInterceptor(interceptor)
        except Exception:
            pass
        if self.download_callback is not None:
            try:
                profile.downloadRequested.connect(self.download_callback)
            except Exception:
                pass
        self._profiles[profile_name] = profile
        return profile
