from __future__ import annotations

import importlib.util
import json
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any

from .ai import CommandRouter


@dataclass
class PluginInfo:
    name: str
    version: str
    permissions: list[str]
    path: Path
    instance: Any = None


class AppAPI:
    def __init__(self, callbacks: dict[str, Any], command_router: CommandRouter) -> None:
        self.callbacks = callbacks
        self.command_router = command_router

    def show_message(self, text: str) -> None:
        self.callbacks["show_message"](text)

    def open_url(self, url: str, background: bool = False) -> None:
        self.callbacks["open_url"](url, background=background)

    def park_background_tabs(self) -> int:
        return int(self.callbacks["park_background_tabs"]())

    def register_command(self, name: str, help_text: str, handler) -> None:
        self.command_router.register(name, help_text, handler)


class PluginManager:
    def __init__(self, plugin_dirs: list[Path], api: AppAPI) -> None:
        self.plugin_dirs = plugin_dirs
        self.api = api
        self.plugins: list[PluginInfo] = []

    def load_all(self) -> list[PluginInfo]:
        loaded: list[PluginInfo] = []
        for directory in self.plugin_dirs:
            if not directory.exists():
                continue
            for plugin_dir in directory.iterdir():
                if not plugin_dir.is_dir():
                    continue
                manifest_path = plugin_dir / "plugin.json"
                if not manifest_path.exists():
                    continue
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                    info = self._load_plugin(plugin_dir, manifest)
                except Exception as exc:
                    self.api.show_message(f"Plugin load failed for {plugin_dir.name}: {exc}")
                    continue
                self.plugins.append(info)
                loaded.append(info)
        return loaded

    def _load_plugin(self, plugin_dir: Path, manifest: dict[str, Any]) -> PluginInfo:
        entry_name = manifest.get("entry", "main.py")
        entry_path = plugin_dir / entry_name
        if not entry_path.exists():
            raise FileNotFoundError(entry_path)
        spec = importlib.util.spec_from_file_location(f"aster_plugin_{plugin_dir.name}", entry_path)
        if not spec or not spec.loader:
            raise RuntimeError(f"Could not build import spec for {entry_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        instance = self._instantiate(module)
        if hasattr(instance, "register"):
            instance.register(self.api)
        info = PluginInfo(
            name=str(manifest.get("name", plugin_dir.name)),
            version=str(manifest.get("version", "0.0.0")),
            permissions=list(manifest.get("permissions", [])),
            path=plugin_dir,
            instance=instance,
        )
        return info

    @staticmethod
    def _instantiate(module: ModuleType) -> Any:
        if hasattr(module, "Plugin"):
            return module.Plugin()
        if hasattr(module, "register"):
            return module
        raise RuntimeError("Plugin must expose Plugin class or register(api)")

    def invoke(self, hook_name: str, *args, **kwargs) -> None:
        for plugin in self.plugins:
            try:
                hook = getattr(plugin.instance, hook_name, None)
                if callable(hook):
                    hook(*args, **kwargs)
            except Exception as exc:
                self.api.show_message(f"Plugin {plugin.name} hook {hook_name} failed: {exc}")
