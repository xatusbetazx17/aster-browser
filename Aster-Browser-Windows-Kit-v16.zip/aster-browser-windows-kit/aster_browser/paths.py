from __future__ import annotations

import os
from pathlib import Path

try:  # Keep non-GUI tests usable even before PyQt6 is installed.
    from PyQt6.QtCore import QStandardPaths  # type: ignore
except Exception:  # pragma: no cover - exercised only on systems without PyQt6.
    QStandardPaths = None  # type: ignore

APP_NAME = "aster-browser"


def project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def is_portable_mode() -> bool:
    marker = project_root() / ".portable"
    return os.environ.get("ASTER_PORTABLE", "0") == "1" or marker.exists()


def portable_root() -> Path:
    env = os.environ.get("ASTER_PORTABLE_ROOT", "").strip()
    if env:
        return Path(env).expanduser()
    return project_root() / "data"


def config_dir() -> Path:
    if is_portable_mode():
        return portable_root() / "config"
    return Path.home() / ".config" / APP_NAME


def data_dir() -> Path:
    if is_portable_mode():
        return portable_root() / "data"
    return Path.home() / ".local" / "share" / APP_NAME


def cache_dir() -> Path:
    if is_portable_mode():
        return portable_root() / "cache"
    return Path.home() / ".cache" / APP_NAME


def config_path() -> Path:
    return config_dir() / "config.json"


def session_path() -> Path:
    return data_dir() / "parked_tabs.json"


def rules_dir() -> Path:
    return project_root() / "rules"


def bundled_plugins_dir() -> Path:
    return project_root() / "plugins"


def user_plugins_dir() -> Path:
    return data_dir() / "plugins"


def containers_dir() -> Path:
    return data_dir() / "containers"


def downloads_dir() -> Path:
    """Return the platform Downloads directory, with a safe fallback."""
    if QStandardPaths is not None:
        try:
            system_download_path = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)
            if system_download_path:
                return Path(system_download_path)
        except Exception:
            pass
    return Path.home() / "Downloads"


def capsules_dir() -> Path:
    return data_dir() / "capsules"


def extensions_dir() -> Path:
    return data_dir() / "extensions"


def logs_dir() -> Path:
    return data_dir() / "logs"


def tts_dir() -> Path:
    return data_dir() / "tts"


def tts_voices_dir() -> Path:
    return tts_dir() / "voices"


def tts_cache_dir() -> Path:
    return tts_dir() / "cache"


def tts_reference_dir() -> Path:
    return tts_dir() / "reference"


def ensure_directories() -> None:
    for path in [
        config_dir(),
        data_dir(),
        cache_dir(),
        user_plugins_dir(),
        containers_dir(),
        downloads_dir(),
        capsules_dir(),
        extensions_dir(),
        logs_dir(),
        tts_dir(),
        tts_voices_dir(),
        tts_cache_dir(),
        tts_reference_dir(),
    ]:
        path.mkdir(parents=True, exist_ok=True)
