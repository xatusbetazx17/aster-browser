from __future__ import annotations

import os
import ssl
from dataclasses import dataclass
from pathlib import Path

CA_BUNDLE_CANDIDATES = [
    "/etc/ssl/certs/ca-certificates.crt",
    "/etc/pki/tls/certs/ca-bundle.crt",
    "/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",
    "/etc/ssl/ca-bundle.pem",
    "/etc/ssl/cert.pem",
]
CA_DIR_CANDIDATES = [
    "/etc/ssl/certs",
    "/etc/pki/tls/certs",
    "/etc/pki/ca-trust/extracted/pem",
]

@dataclass(frozen=True)
class CertificateEnvironment:
    ca_file: str = ""
    ca_dir: str = ""
    source: str = "none"

    def render(self) -> str:
        parts: list[str] = []
        if self.ca_file:
            parts.append(f"CA file: {self.ca_file}")
        if self.ca_dir:
            parts.append(f"CA dir: {self.ca_dir}")
        parts.append(f"source: {self.source}")
        return " | ".join(parts)


def _readable_file(path: str) -> bool:
    try:
        return bool(path) and Path(path).is_file() and os.access(path, os.R_OK)
    except Exception:
        return False


def _readable_dir(path: str) -> bool:
    try:
        return bool(path) and Path(path).is_dir() and os.access(path, os.R_OK | os.X_OK)
    except Exception:
        return False


def _first_file(paths: list[str]) -> str:
    for path in paths:
        if _readable_file(path):
            return path
    return ""


def _first_dir(paths: list[str]) -> str:
    for path in paths:
        if _readable_dir(path):
            return path
    return ""


def detect_certificate_environment() -> CertificateEnvironment:
    env_file = os.environ.get("SSL_CERT_FILE", "").strip()
    env_dir = os.environ.get("SSL_CERT_DIR", "").strip()
    if _readable_file(env_file):
        return CertificateEnvironment(env_file, env_dir if _readable_dir(env_dir) else _first_dir(CA_DIR_CANDIDATES), "environment")

    defaults = ssl.get_default_verify_paths()
    openssl_file = str(defaults.cafile or "")
    openssl_dir = str(defaults.capath or "")
    if _readable_file(openssl_file):
        return CertificateEnvironment(openssl_file, openssl_dir if _readable_dir(openssl_dir) else _first_dir(CA_DIR_CANDIDATES), "python/openssl")

    ca_file = _first_file(CA_BUNDLE_CANDIDATES)
    ca_dir = _first_dir(CA_DIR_CANDIDATES)
    return CertificateEnvironment(ca_file, ca_dir, "system scan" if ca_file or ca_dir else "none")


def configure_certificate_environment() -> CertificateEnvironment:
    """Share one safe CA trust setup across QtWebEngine, Python, curl, and helper tools.

    This never imports certificates into the user's NSS DB, so it avoids repeated password/PIN prompts.
    """
    cert_env = detect_certificate_environment()
    if cert_env.ca_file:
        os.environ.setdefault("SSL_CERT_FILE", cert_env.ca_file)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", cert_env.ca_file)
        os.environ.setdefault("CURL_CA_BUNDLE", cert_env.ca_file)
    if cert_env.ca_dir:
        os.environ.setdefault("SSL_CERT_DIR", cert_env.ca_dir)
    os.environ.setdefault("QTWEBENGINE_DISABLE_CERTIFICATE_ERROR_REPORTING", "1")
    return cert_env
