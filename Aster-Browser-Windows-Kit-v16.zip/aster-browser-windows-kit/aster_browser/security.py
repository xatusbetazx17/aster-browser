from __future__ import annotations

from typing import Any

from PyQt6.QtWebEngineCore import QWebEngineSettings


def _set_attr(settings: QWebEngineSettings, name: str, value: bool) -> None:
    attr = getattr(QWebEngineSettings.WebAttribute, name, None)
    if attr is not None:
        settings.setAttribute(attr, value)


def apply_security_profile(settings: QWebEngineSettings, mode: str) -> None:
    mode = (mode or "balanced").lower().strip()

    # Sensible defaults for modern sites, media, and gaming.
    defaults: dict[str, bool] = {
        "JavascriptEnabled": True,
        "JavascriptCanOpenWindows": False,
        "JavascriptCanAccessClipboard": False,
        "LocalContentCanAccessRemoteUrls": False,
        "LocalContentCanAccessFileUrls": False,
        "AllowRunningInsecureContent": False,
        "FullScreenSupportEnabled": True,
        "WebGLEnabled": True,
        "Accelerated2dCanvasEnabled": True,
        "AutoLoadImages": True,
        "DnsPrefetchEnabled": True,
        "ScrollAnimatorEnabled": True,
        "PlaybackRequiresUserGesture": True,
        "ScreenCaptureEnabled": False,
        "HyperlinkAuditingEnabled": False,
        "PluginsEnabled": False,
        "PdfViewerEnabled": True,
        "ErrorPageEnabled": True,
    }
    for name, value in defaults.items():
        _set_attr(settings, name, value)

    if mode == "strict":
        strict_values = {
            "PlaybackRequiresUserGesture": True,
            "WebRTCPublicInterfacesOnly": True,
            "JavascriptCanOpenWindows": False,
            "AutoLoadImages": True,
        }
        for name, value in strict_values.items():
            _set_attr(settings, name, value)
    elif mode == "permissive":
        permissive_values = {
            "PlaybackRequiresUserGesture": False,
            "JavascriptCanAccessClipboard": True,
        }
        for name, value in permissive_values.items():
            _set_attr(settings, name, value)
