"""The aster:flags experiments, and the Chromium switches they turn into.

The two ends of that page pointed at different stores: FlagsPageWidget wrote
~/.config/Aster/flags.json while startup read a QSettings("Aster", "Flags")
nothing ever wrote, so a choice made on the page never reached the engine. The
page and app.main now share the list, the file and the switches kept here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .paths import config_dir

DEFAULT = "Default"
ENABLED = "Enabled"
DISABLED = "Disabled"
STATES: tuple[str, ...] = (DEFAULT, ENABLED, DISABLED)

# Older builds wrote here directly, outside the directory paths.py owns and
# without portable mode. It is read once, while the current file is absent.
LEGACY_FILE = Path.home() / ".config" / "Aster" / "flags.json"


@dataclass(frozen=True)
class Experiment:
    id: str
    name: str
    description: str
    enable: str
    disable: str = ""

    def switch(self, state: str) -> str:
        if state == ENABLED:
            return self.enable
        if state == DISABLED:
            return self.disable
        return ""


EXPERIMENTS: tuple[Experiment, ...] = (
    Experiment(
        "disable_gpu",
        "Disable GPU Acceleration",
        "Turns off graphics card use completely, to prevent crashes caused by Linux hardware "
        "incompatibilities (GLX/GBM). Scrolling and video playback get slower without it.",
        "--disable-gpu",
    ),
    Experiment(
        "gpu_rasterization",
        "GPU Rasterization",
        "Uses the GPU to render web content. Improves scrolling and page load performance.",
        "--enable-gpu-rasterization",
        "--disable-gpu-rasterization",
    ),
    Experiment(
        "smooth_scrolling",
        "Smooth Scrolling",
        "Animates page scrolling instead of jumping several lines per wheel notch. "
        "Aster turns this on by default; disable it for instant, stepped scrolling.",
        "--enable-smooth-scrolling",
        "--disable-smooth-scrolling",
    ),
    Experiment(
        "overlay_scrollbars",
        "Overlay Scrollbars",
        "Uses thin, modern scrollbars that appear on hover.",
        "--enable-features=OverlayScrollbar",
        "--disable-features=OverlayScrollbar",
    ),
)


def flags_file() -> Path:
    return config_dir() / "flags.json"


def _read(path: Path) -> dict[str, str]:
    """The states this file holds, dropping ids and values Aster does not know."""
    try:
        stored = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(stored, dict):
        return {}
    known = {experiment.id for experiment in EXPERIMENTS}
    return {str(key): str(value) for key, value in stored.items()
            if str(key) in known and str(value) in STATES}


def load_flags() -> dict[str, str]:
    """The saved experiment states, reading the pre-paths.py file as a fallback."""
    current = flags_file()
    if current.exists():
        return _read(current)
    return _read(LEGACY_FILE)


def save_flags(flags: Mapping[str, str]) -> dict[str, str]:
    """Write the states worth keeping, and return exactly what was written."""
    kept = {experiment.id: flags[experiment.id] for experiment in EXPERIMENTS
            if flags.get(experiment.id) in (ENABLED, DISABLED)}
    path = flags_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(kept, indent=4), encoding="utf-8")
    return kept


def switches(flags: Mapping[str, str] | None = None) -> list[str]:
    """The Chromium switches these states ask for, in EXPERIMENTS order."""
    states = load_flags() if flags is None else flags
    chosen = (experiment.switch(states.get(experiment.id, DEFAULT)) for experiment in EXPERIMENTS)
    return [switch for switch in chosen if switch]
