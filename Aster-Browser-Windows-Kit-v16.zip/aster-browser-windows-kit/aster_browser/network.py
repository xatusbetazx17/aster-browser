from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass


@dataclass
class WireGuardSummary:
    available: bool
    interfaces: list[str]
    raw_output: str

    def render(self) -> str:
        if not self.available:
            return "WireGuard helper unavailable. Install the 'wg' command or use NetworkManager integration on your distro."
        if not self.interfaces:
            return "WireGuard is available, but no active interfaces were reported."
        head = ", ".join(self.interfaces)
        return f"WireGuard interfaces: {head}\n\n{self.raw_output.strip()}"


class WireGuardHelper:
    @staticmethod
    def available() -> bool:
        return shutil.which("wg") is not None

    @staticmethod
    def status() -> WireGuardSummary:
        if not WireGuardHelper.available():
            return WireGuardSummary(False, [], "")
        try:
            interfaces_result = subprocess.run(
                ["wg", "show", "interfaces"],
                check=False,
                capture_output=True,
                text=True,
            )
            interfaces = [item.strip() for item in interfaces_result.stdout.split() if item.strip()]
            raw = subprocess.run(
                ["wg", "show"],
                check=False,
                capture_output=True,
                text=True,
            ).stdout
        except Exception as exc:
            return WireGuardSummary(True, [], f"Could not read WireGuard status: {exc}")
        return WireGuardSummary(True, interfaces, raw)
