class Plugin:
    def register(self, api):
        self.api = api
        api.register_command("focus", "Park background tabs and keep the current task clean.", self.focus)

    def focus(self, _args):
        count = self.api.park_background_tabs()
        self.api.show_message(f"Focus mode parked {count} background tab(s).")
        return f"Focus mode parked {count} background tab(s)."

    def on_page_loaded(self, url, title):
        # Placeholder for future smart focus rules.
        return None
