# Black Arc Centered UI update

This update refines Aster's everyday UI and navigation behavior.

## What changed

- Default theme switched to **black_arc** with Qt Fusion styling.
- New tab page is now **centered** inside a card layout instead of stretching edge to edge.
- Added a dedicated **Settings tab** (`aster:settings`) instead of opening settings as a popup dialog from the main workflow.
- Added **custom internal error pages** for:
  - no internet connection
  - page unreachable
  - secure connection failure
  - local file unavailable
- **Lite mode now toggles off** when clicked again on a Lite tab.
- Added a **Lite debounce guard** to prevent repeated-click collapses.
- Added a persistent setting for **active-tab left-click menu** and a tab menu action to disable or re-enable it.
- Improved icon set for the centered new tab quick links.

## Notes

- The settings dialog class still exists for compatibility, but Aster now opens settings in a browser tab.
- Error pages do not bypass certificate or DRM restrictions.
- Existing installs may still be on `system` theme until the updater or hotfix rewrites the config to `black_arc`.
