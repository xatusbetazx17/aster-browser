# Aster Browser v12 HTTPS, customization, and assistant update

This update focuses on three areas requested after the v8/v9 installer tests.

## HTTPS and certificate handling

- The installer still avoids `certutil` and never edits user NSS certificate databases, so it cannot loop on an NSS password/PIN prompt.
- Runtime CA discovery points Python helpers and Qt WebEngine launch flags at normal Linux CA bundle/directories when enabled.
- The settings page includes system CA path usage and per-host HTTPS exception fields.
- Certificate errors are not bypassed globally. Saved exceptions are host-limited and only used for overridable certificate errors.
- The error page now separates a real certificate/trust failure from a normal HTTPS page-load failure when Python/OpenSSL can verify the site.
- Tools → Diagnose current page security reports the current URL, CA paths, Python/OpenSSL probe result, and recent Qt certificate error detail.

## Vivaldi-style customization work

- Appearance controls: theme, accent color, Qt widget style, transparency, corner radius, page zoom, UI density, toolbar text, and tab position.
- Visibility toggles: status bar, Home button, New Tab button, container selector, and loading progress bar.
- Workflow controls: active-tab click menu, containers, extension backend, DRM mode, external/capsule browser override, and page CSS injection.
- Power-user page CSS can be enabled from Settings → Advanced customization.

## Assistant upgrades

- Internal assistant persona and reasoning mode are configurable.
- Dr. Light Lab / engineer-mentor mode gives structured troubleshooting for HTTPS, Linux packaging, networking, hardware/software, browser, and AI questions.
- The assistant can use current page text, selected text, previous tab text, links, history, bookmarks, and local documents.
- AI command routing includes tabs, links, bookmarks, documents, PDFs, history, extensions, containers, streaming/capsules, mobile/lite mode, diagnostics, and safe navigation.

## Important safety note

The browser should not use a global `--ignore-certificate-errors` flag. That would make fake HTTPS pages look safe. v12 tries to diagnose and fix trust discovery while preserving HTTPS protection.
