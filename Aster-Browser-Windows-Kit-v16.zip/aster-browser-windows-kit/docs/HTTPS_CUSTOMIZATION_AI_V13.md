# Aster Browser v13 HTTPS, customization, and adaptive AI notes

## HTTPS/security label fix

v13 separates main-frame certificate failures from subresource warnings and mixed-content warnings. A valid HTTPS page should no longer be labeled with a vague “not secure” state just because an older profile remembered a warning or a blocked subresource had a problem.

New behavior:

- `HTTPS secure`: main page is HTTPS and no current main-frame certificate warning is recorded.
- `HTTPS mixed`: main page is HTTPS, but HTTP resources or insecure forms were detected.
- `HTTPS caution`: main page is HTTPS, but a subresource warning, proxy issue, or insecure JavaScript context was detected.
- `HTTPS warning`: Qt WebEngine reported a main-page certificate error.
- `HTTP not secure`: the page is plain HTTP.

Use **Tools → Diagnose current page security** to see CA paths, OpenSSL probe output, mixed-content counts, and the latest Qt WebEngine warning. Use **Tools → Clear Aster web security/cache state** when a stale warning stays after the site verifies successfully.

The installer still does not edit protected NSS certificate databases and does not enable global certificate bypassing.

## Vivaldi-style customization direction

v13 keeps the browser open to deep customization while staying reversible: tab position, toolbar behavior, density, accent color, custom app QSS, custom page CSS, status/security UI, containers, page zoom, and workflow settings all live in user configuration.

## Adaptive Inventor Mentor AI

The internal AI mode is an original engineering mentor inspired by lab-assistant problem solving. It uses goal → evidence → likely cause → safe fix → verification → rollback. It can use captured page text, selected text, bookmarks, history, open tabs, local documents, and browser diagnostics as context.

It is not a clone of a fictional character and it does not claim superhuman intelligence. It is designed to be safer and more useful by adapting to the user’s current browser/workflow context.
