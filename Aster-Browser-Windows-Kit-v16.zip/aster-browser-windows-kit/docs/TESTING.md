# Testing Aster Browser Alpha

## GUI smoke test

On a Linux machine with Qt WebEngine available:

```bash
python -m pip install -r requirements.txt
python run_aster.py
```

Then test these flows:

### Memory behavior

- open 8 to 12 regular tabs
- press `Ctrl+Shift+P`
- verify background tabs convert into parked tabs
- run `/stats` in the AI panel

### Lite mode

- open a text-heavy page
- press `Ctrl+Shift+L`
- confirm the Lite tab opens and links still work

### Streaming compatibility

- run `/streaming`
- open YouTube or Twitch
- open Prime Video
- if Prime is routed externally, confirm the compatibility message appears
- in Settings, try `external_only` and repeat

### Local AI actions

With **Allow AI actions** enabled, try:

- `open youtube`
- `search linux network engineer jobs`
- `find network on this page`
- `save memory`
- `streaming status`

### Local AI model

If you enabled Ollama, ask a question about the current page and confirm the answer uses the page context.

## Headless tests

These tests only cover non-GUI pieces so they run without PyQt:

```bash
python -m unittest discover -s tests -v
```

Covered areas:

- block rules parsing and matching
- memory governor parking decisions
- AI command routing
- lightweight intent routing
- DRM helper decisions
- config env overrides
- Lite engine text extraction
