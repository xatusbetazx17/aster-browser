# Persistent parked tabs in v15

Parking a tab removes the live web engine from that tab and replaces it with a lightweight parked widget.

Behavior:

- Parked tabs do not auto-restore when clicked.
- The user must click **Unpark / restore full tab**.
- Parked tabs are persisted in `parked_tabs.json` when enabled in Settings.
- The camel animation runs only while the parked tab widget is visible, then stops when hidden.
- Parked tabs survive browser restart until restored or closed.

Commands:

- Toolbar/menu: **Park Current**
- View menu: **Park current tab for later**
- Assistant: `/park-current`
- Assistant natural language: “park this tab” or “save this tab for later”
