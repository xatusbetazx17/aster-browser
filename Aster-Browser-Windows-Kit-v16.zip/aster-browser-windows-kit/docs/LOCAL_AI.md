# AI in Aster

Aster keeps AI optional.

By default, the AI provider is **internal** so the browser gets a built-in local assistant without any extra service.

## Two AI layers

### 1. Built-in internal assistant

This is the default and it requires no separate install.

It can:

- summarize the current page
- summarize selected text
- compare the current tab with the previous tab
- search local documents and PDFs
- search recent Aster history
- list links from the current page
- answer simple questions from the current page text

### 2. Optional AI actions

These are deterministic browser actions and also do not require an external model:

- `open youtube`
- `open prime video`
- `search network engineer jobs`
- `find router on this page`
- `switch to banking container`
- `open downloads`
- `save memory`
- `streaming status`

Enable them with the **Allow AI actions** checkbox in the AI dock, or in Settings.

### 3. Optional heavier external providers later

If you want a larger local model later, Aster can still talk to an Ollama server.

Interactive helper:

```bash
./tools/enable_local_ai.sh
```

Auto-install and configure helper:

```bash
./tools/auto_setup_local_ai_and_capsules.sh
```

Portable install helper:

```bash
~/.local/share/aster-browser-portable/aster-localai-setup.sh
```

The auto helper can:

- install Ollama if it is missing
- start the local Ollama server
- try a small local model
- create a low-memory alias model for Aster
- switch the Aster config to `provider = ollama`
- enable lightweight AI actions by default

## Switch an install back to internal AI

```bash
./tools/enable_internal_ai.sh
```

For a portable install:

```bash
~/.local/share/aster-browser-portable/aster-internalai-setup.sh
```

## Disable AI again

Open **Settings** and set:

- AI provider: `disabled`

That returns Aster to normal-browser behavior.
