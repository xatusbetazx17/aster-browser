# Language and packaging notes

This merged build adds a language preference to Settings.

## Language behavior

Aster now stores `language_code` in the browser config. Users can select a common language from Settings, or type any valid BCP-47 language tag such as `es-MX`, `pt-BR`, `ar-SA`, `hi-IN`, `zh-Hant`, or `ja-JP`.

The selected language is applied to Qt WebEngine profiles with the browser `Accept-Language` preference, so websites that respect language negotiation can return localized pages. Aster also includes starter translations for common browser UI labels in English, Spanish, Turkish, Portuguese, French, German, Arabic, Chinese, Japanese, and Korean. Languages without a built-in UI dictionary still work as webpage language preferences.

Environment override:

```bash
export ASTER_LANGUAGE="es-MX"
```

## Linux `.sh` installer

The generated `Aster-Browser-Merged-Linux.sh` file is a self-extracting installer. It:

- extracts the merged app source into `~/.local/share/aster-browser-portable/app`
- creates a private Python virtual environment
- installs Python dependencies only when needed
- detects common Linux package managers and installs missing system packages where supported
- creates a desktop launcher and icon

Examples:

```bash
chmod +x Aster-Browser-Merged-Linux.sh
./Aster-Browser-Merged-Linux.sh -y
./Aster-Browser-Merged-Linux.sh --run
./Aster-Browser-Merged-Linux.sh --no-system-deps
./Aster-Browser-Merged-Linux.sh --uninstall
```

## Flatpak

The Flatpak manifest is in `packaging/flatpak/org.aster.Browser.yml`.

Build a local bundle from Linux with Flatpak Builder:

```bash
./packaging/flatpak/build-flatpak.sh
```

The resulting bundle is written to `build/Aster-Browser.flatpak`.

## Windows

The Windows installer kit is in `packaging/windows`.

Install from source on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1 -UseWinget
```

Build a PyInstaller executable on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\build_windows_exe.ps1
```

Then use `AsterBrowser.nsi` with NSIS to build `Aster-Browser-Setup.exe`.
