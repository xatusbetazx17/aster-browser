# Language and packaging notes

This merged build adds a language preference to Settings.

## Language behavior

Aster keeps two separate language settings in **Settings → General**, one directly under the other:

| Setting | Config key | What it changes |
| --- | --- | --- |
| **Language** | `language_code` | The language Aster asks *websites* for, via the Qt WebEngine `Accept-Language` preference. Any valid BCP-47 tag works (`es-MX`, `pt-BR`, `ar-SA`, `hi-IN`, `zh-Hant`, `ja-JP`, …). |
| **Interface language** | `interface_language` | The language of *Aster's own* interface: menus, toolbar, settings, dialogs, internal pages, error pages and status messages. |

### Interface language

`Interface language` is a fixed list, because each entry ships a complete translation catalog:

`System default`, English, Türkçe, Deutsch, Français, Español, Italiano, Português, Nederlands, Polski, Русский, Українська, Svenska.

`System default` follows the operating system locale and falls back to English when that locale has no catalog. A saved language that Aster no longer ships falls back to `System default` as well.

Changing it applies immediately: the title bar, menus, toolbar, tooltips, status bar and the open settings page are re-labelled without a restart. Tabs that were already open keep the label they were created with until they are reopened.

Environment overrides:

```bash
export ASTER_LANGUAGE="es-MX"        # webpage language
export ASTER_UI_LANGUAGE="tr"        # interface language
```

### Adding or editing a translation

Catalogs live in `aster_browser/locales/<lang>.py`, one module per language, each exporting a `STRINGS` dict keyed by the English source string. `aster_browser/locales/__init__.py` registers them and `aster_browser/translations.py` exposes the merged catalog plus the picker list.

To add a language: drop in `aster_browser/locales/<code>.py` with a complete `STRINGS` dict, register it in `locales/__init__.py`, and add `(code, native name)` to `INTERFACE_LANGUAGE_CHOICES` in `translations.py`.

`tests/test_localization.py` enforces the invariants: every offered language has a catalog, every catalog covers the same keys with no blanks, `{placeholder}` names survive translation, and every string passed to `tr()` in `widgets.py`, `browser.py` and `internal_pages.py` exists in the catalog.

```bash
python -m unittest tests.test_localization
```

## Linux `.sh` installer

The generated `Aster-Browser-Merged-Linux.sh` file is a self-extracting installer. It:

- extracts the merged app source into `~/.local/share/aster-browser-portable/app`
- creates a private Python virtual environment
- installs Python dependencies only when needed
- detects common Linux package managers and installs missing system packages where supported
- creates a desktop launcher and icon

Examples:

```bash
chmod +x Aster-Browser-Merged-Linux.sh
./Aster-Browser-Merged-Linux.sh -y
./Aster-Browser-Merged-Linux.sh --run
./Aster-Browser-Merged-Linux.sh --no-system-deps
./Aster-Browser-Merged-Linux.sh --uninstall
```

## Flatpak

The Flatpak manifest is in `packaging/flatpak/org.aster.Browser.yml`.

Build a local bundle from Linux with Flatpak Builder:

```bash
./packaging/flatpak/build-flatpak.sh
```

The resulting bundle is written to `build/Aster-Browser.flatpak`.

## Windows

The Windows installer kit is in `packaging/windows`.

Install from source on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1 -UseWinget
```

Build a PyInstaller executable on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\build_windows_exe.ps1
```

Then use `AsterBrowser.nsi` with NSIS to build `Aster-Browser-Setup.exe`.
