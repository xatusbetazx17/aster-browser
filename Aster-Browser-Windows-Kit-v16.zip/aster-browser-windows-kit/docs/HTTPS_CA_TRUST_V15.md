# HTTPS and CA trust in v15

Aster uses the system certificate store and safe environment variables such as `SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`, and `CURL_CA_BUNDLE` to help Python and Qt WebEngine find the distro trust store.

The v15 installer refreshes system CA trust by default, but it does not touch protected NSS user certificate databases. This prevents the repeated `Enter Password or Pin for NSS Certificate DB` loop.

Manual Linux helper:

```bash
tools/refresh_ca_trust.sh --auto
```

Installer options:

```bash
./Aster-Browser-Merged-Linux-v15.sh -y --refresh-ca
./Aster-Browser-Merged-Linux-v15.sh -y --no-refresh-ca
```

Aster still refuses to globally ignore certificate errors. Invalid certificates must be fixed at the OS/network/site level or accepted only through explicit per-site exception handling.
