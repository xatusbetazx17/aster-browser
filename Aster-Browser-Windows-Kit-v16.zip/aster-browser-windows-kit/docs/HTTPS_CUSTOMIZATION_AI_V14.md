# Aster Browser v14 HTTPS/profile-state notes

The Linux diagnostic can show `Verify return code: 0 (ok)` while the browser still displays an old warning if QtWebEngine is reading stale profile/security cache. v14 makes the installed launcher and reset tool agree on the same profile root.

Recommended Linux update command:

```bash
./Aster-Browser-Merged-Linux-v14.sh -y --reset-network-state --run
```

For manual reset after install:

```bash
ASTER_INSTALL_ROOT="$HOME/.local/share/aster-browser-portable" \
ASTER_PORTABLE_ROOT="$HOME/.local/share/aster-browser-portable/state" \
"$HOME/.local/share/aster-browser-portable/app/tools/reset_aster_network_state.sh"
```

The browser should now show one of these clearer labels: HTTPS secure, HTTPS mixed, HTTPS caution, HTTPS warning, or HTTP not secure.

The adaptive mentor assistant remains original and local-first. It adapts through browser context, selected/page text, diagnostics, history/bookmarks when available, and a safer troubleshooting structure: goal, evidence, likely cause, safe fix, verification, rollback.
