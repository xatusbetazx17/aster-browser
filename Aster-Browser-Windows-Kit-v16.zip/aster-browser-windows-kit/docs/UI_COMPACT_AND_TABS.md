# UI compact mode, tab actions, and mobile view

This update adds three interface improvements:

- **Tab quick actions:** left-click the active tab or right-click any tab to open a quick menu.
- **Mobile view:** open the current page in a narrow mobile viewport with a mobile user agent.
- **Compact layout:** when the window gets narrower, toolbar actions and top menus collapse into overflow menus.

## Tab quick actions

Open the tab quick menu by:

- left-clicking the **currently active** tab
- right-clicking **any** tab

Actions available there:

- mute or unmute sound
- reload
- duplicate tab
- open mobile view or return to desktop view
- open in Lite mode
- park tab
- close other tabs
- close tab

## Mobile view

Use any of these:

- toolbar mobile button
- `Ctrl+Shift+M`
- **View → Open current page in Mobile view**
- local assistant command: `/mobile`

To go back:

- click **Desktop view** inside the mobile view page
- **View → Return current page to Desktop view**
- local assistant command: `/desktop`

## Compact layout

Aster now responds to smaller window widths by:

- replacing **File / View / Tools** buttons with one **Menu** button in the title bar
- moving lower-priority toolbar actions into an overflow menu
- hiding wide status controls before the address bar gets squeezed

This makes the browser easier to use in smaller floating windows without losing the main tools.
