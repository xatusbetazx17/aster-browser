# Aster Streaming Capsules

Streaming capsules are Aster's way of staying unique without pretending a pure custom engine can satisfy every premium DRM service by itself.

## Model

- **Aster Native** handles normal browsing, adblock, containers, AI, tab parking, and standard HTML5/MSE video sites.
- **Aster Capsules** handle premium protected streaming paths that usually expect a mainstream browser/runtime and DRM stack.

The user experience still feels like one browser because Aster shows a capsule-control tab, but the playback runtime is separated.

## What capsules isolate

- runtime selection
- service-specific profile directories
- premium streaming login/session state separate from ordinary Aster tabs
- relaunch/reset controls when a service gets stuck

## What capsules do not do

- bypass DRM
- bypass age checks
- bypass paywalls
- guarantee that every premium service will accept every runtime forever

## Adult sites and ordinary video sites

Aster does **not** add special bypass logic for adult sites.

If a site uses ordinary HTML5 video or MSE and does not depend on a premium DRM path, it can stay in **Aster Native** like any other non-DRM video site.

## Commands

```text
/capsule <url>
/capsules
/streaming
```

## Profiles

Capsule profiles live under Aster's data directory or, for Flatpak runtimes, under the runtime's app-data area.

Each premium service gets its own capsule profile so resetting one service does not wipe every other service.
