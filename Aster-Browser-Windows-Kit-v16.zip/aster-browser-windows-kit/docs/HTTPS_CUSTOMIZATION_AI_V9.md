# Aster Browser v9: HTTPS trust, customization, and assistant upgrades

## HTTPS trust fixes

Aster v9 avoids writing to protected NSS user certificate databases. It never calls `certutil` during install. The Linux launcher and Flatpak launcher now point Python, curl-style helpers, and the runtime environment to normal system CA bundle locations when available:

- `/etc/ssl/certs/ca-certificates.crt`
- `/etc/pki/tls/certs/ca-bundle.crt`
- `/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem`
- `/etc/ssl/ca-bundle.pem`
- `/etc/ssl/cert.pem`

The installer also supports a safe optional CA refresh:

```bash
./Aster-Browser-Merged-Linux-v9.sh -y --refresh-ca
```

This only uses `update-ca-certificates`, `update-ca-trust extract`, or `trust extract-compat`. It does not touch user NSS databases.

Inside Aster, use:

```text
/diagnose
```

or Tools → Diagnose current page security to test the current HTTPS page with Python/OpenSSL and show the CA bundle being used.

## Vivaldi-style customization additions

Settings now includes these appearance controls:

- Accent color, such as `#3b82f6`
- Tab position: top, bottom, left, or right
- Toolbar density: compact, comfortable, or spacious
- Show/hide status bar
- Show/hide Home button
- Show/hide New Tab button
- Show/hide container selector
- Show/hide loading progress
- Existing theme, Qt style, transparency, default zoom, page CSS injection, and container settings remain available

## Assistant upgrades

The assistant now has persona settings including Dr. Light Lab, Network Engineer, Cyber Guardian, Browser Helper, and Concise. Dr. Light Lab is a structured engineering mentor mode, not a true fictional-character clone or AGI. It favors this debugging format:

```text
Problem → Diagnosis → Fix → Verify
```

It also adds the `/diagnose` command for browser runtime and HTTPS checks.


## Certificate exceptions

For local devices or lab sites with self-signed certificates, Settings → Browsing can store certificate exception hostnames. This is safer than a global ignore flag because it only applies to specific hosts and only when Qt reports the certificate error as overridable.
