# Streaming and compatibility in v15

Aster v15 defaults to `qtwebengine_capsule` for known DRM-heavy streaming sites. This keeps the user inside Aster and uses the PyQt6-WebEngine / Qt WebEngine runtime already installed by Aster's private Python environment.

This is not the same as installing Chrome or Chromium as the user's main browser. Qt WebEngine provides an embedded Chromium-family engine used by the Aster app.

Premium streaming still has constraints:

- Some services require Widevine CDM.
- Some services require H.264/AAC/proprietary codec support.
- Some services only approve specific browser/runtime combinations.
- Aster does not bypass DRM or certificate checks.

Modes:

- `qtwebengine_capsule`: use Aster's bundled Qt WebEngine compatibility profile for known protected services.
- `internal_preferred`: try internal playback when Widevine is detected; otherwise use managed external fallback.
- `internal_only`: never redirect externally.
- `external_only`: always use managed external capsule for protected services.
- `auto`: route known protected services to managed external capsule.
