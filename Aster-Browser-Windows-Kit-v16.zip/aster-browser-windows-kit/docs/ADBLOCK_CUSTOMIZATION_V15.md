# Adblock customization in v15

Aster now supports user-personalized adblock behavior from Settings.

Available options:

- Enable/disable adblock.
- Mode: `off`, `balanced`, `strict`, or `custom`.
- Streaming/CDN protection allowlist so video services are less likely to break.
- Allow hosts list.
- Block hosts list.
- Custom rules.

Supported custom rule examples:

```text
||tracker.example^
@@||trusted-cdn.example^
block:ads.example.com
allow:video-cdn.example.com
https://bad.example/ad-script.js
```

For broken websites, use balanced mode, add the needed CDN to allow hosts, and reload the page.
