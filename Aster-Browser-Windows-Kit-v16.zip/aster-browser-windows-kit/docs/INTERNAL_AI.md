# Aster Internal Assistant

Aster now includes a built-in **internal assistant** that runs with **no external API and no Ollama service**.

This mode is designed for low-memory Linux machines and Steam Deck setups where a full external model can be too heavy or fragile.

## What the internal assistant can do

- summarize the current page locally
- summarize selected text from the current page
- answer simple questions from the current page text
- compare the current tab with the previous tab
- list top links from the current page
- search common local folders such as `Documents`, `Downloads`, `Desktop`, and Aster's own downloads folder
- search local PDFs by name
- search recent Aster browsing history
- summarize supported text-like files from a local path
- work together with **AI actions** for browser control such as listing or switching tabs, bookmarking pages, opening page links, reloading or navigating back/forward, opening sites, searching the web, parking tabs, switching containers, and opening downloads

## What it does not try to be

This is not a large general-purpose language model.

It is a lightweight built-in browser assistant focused on:

- privacy
- speed
- low RAM usage
- useful browser automation
- local summaries and file lookup

If you need broader open-ended chat quality later, you can still switch Aster to Ollama or an API-backed provider.

## Internal architecture in this build

- **Action core:** deterministic commands and intent routing for common safe browser tasks, including tab management, bookmarks, links, navigation, and local document opening
- **Local index:** SQLite-backed search for approved local folders and Aster history
- **Bundled utility process:** the internal assistant is launched on demand through `python -m aster_browser.internal_worker` over stdio, not through a user-managed local server
- **Permissions layer:** risky requests such as logging in, deleting files, purchasing, or submitting forms are not performed automatically

## Recommended settings

- AI provider: `internal`
- AI model: `aster-internal`
- AI base URL: empty
- AI key env var: empty
- Allow AI actions: on if you want the browser to perform safe tasks for you

## Example prompts

- `summarize this page`
- `summarize selected text`
- `what does this page say about firewalls?`
- `compare these two tabs`
- `show links on this page`
- `find documents about router firmware`
- `find pdfs about resume`
- `find history for prime video`
- `summarize /home/deck/Documents/notes/router.txt`
- `open youtube`
- `open prime video in this tab and park the other tabs`
- `search network engineer jobs`
- `show tabs`
- `switch to tab 2`
- `bookmark this page`
- `show bookmarks for github`
- `open link 2`
- `reload this page`
- `open downloads`
- `save memory`

## Slash commands

- `/help`
- `/docs router firmware`
- `/pdfs resume`
- `/history prime video`
- `/downloads`
- `/summarize`
- `/compare`
- `/tabs`
- `/switch 2`
- `/bookmark`
- `/bookmarks github`
- `/open-doc router firmware`
- `/open-pdf resume`
- `/links`
- `/open-link 2`
- `/reload`
- `/back`
- `/forward`
- `/duplicate`
- `/find firewall`
- `/search linux networking`
- `/park`
- `/lite`
- `/streaming`

## Optional local document roots

By default, Aster searches these folders if they exist:

- `~/Documents`
- `~/Downloads`
- `~/Desktop`
- Aster's own downloads folder

You can override the search roots with:

```bash
export ASTER_INTERNAL_AI_ROOTS="$HOME/Documents:$HOME/Downloads"
```

You can also cap the maximum number of files scanned:

```bash
export ASTER_INTERNAL_AI_MAX_FILES=800
```
