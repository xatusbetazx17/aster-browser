# Aster UI Refresh

This build updates the browser chrome itself.

## What changed

- Embedded title bar inside the application window
- Rounded visual edges for the browser shell
- Custom SVG toolbar and window-control icons
- Softer close button styling with no harsh solid red block
- Cleaner dark toolbar styling and better tab/header hierarchy

## Notes

- The window now uses a frameless layout with an in-app title bar.
- Double-click the title area to maximize or restore the window.
- Drag the title area to move the window.
- The bottom-right resize grip in the status bar still provides a resize handle.

## Shortcuts

- `Ctrl+L` focus address bar
- `Ctrl+T` new tab
- `Ctrl+W` close tab
- `Ctrl+Shift+E` extensions
- `Ctrl+,` settings
