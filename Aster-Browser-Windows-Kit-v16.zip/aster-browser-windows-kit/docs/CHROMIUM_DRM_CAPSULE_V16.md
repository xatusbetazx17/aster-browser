# Aster Chromium DRM Capsule v16

## Goal

v16 adds a realistic streaming and cloud-gaming compatibility path without requiring Google Chrome to be installed as the user's browser.

```text
Aster Browser
├── Normal tabs: PyQt6 / Qt WebEngine
├── Parked tabs: saved lightweight placeholders
├── Compatibility tabs: Qt WebEngine compatibility profile
└── DRM/gaming capsule: bundled CastLabs/Electron Chromium runtime in a separate profile
```

## Why this solves more than Qt WebEngine alone

Qt WebEngine is Chromium-based and good for most modern web apps, but premium streaming often needs Widevine CDM plus proprietary codecs. Qt WebEngine does not ship Widevine by default. The v16 capsule uses CastLabs Electron for Content Security because it is specifically built to facilitate Widevine CDM playback in an Electron/Chromium runtime.

## Linux install

```bash
./Aster-Browser-Merged-Linux-v16.sh -y --refresh-ca --reset-network-state --with-drm-capsule --run
```

Or after installing:

```bash
~/.local/share/aster-browser-portable/app/tools/setup_chromium_drm_capsule.sh -y
```

Then choose:

```text
Settings → Browsing and streaming → DRM mode → chromium_drm_capsule
```

## What this does not do

It does not bypass DRM, remove subscriptions, defeat service checks, or fake licenses. Some services may still require production VMP signing, service approval, codec/platform support, or a device/browser policy that allows playback.

## Gaming mode benefits

The capsule enables a Chromium-family runtime with GPU flags, WebRTC PipeWire capture support where available, fullscreen, pointer-lock handling, gamepad-friendly permission behavior, and a separate capsule profile so cloud-gaming cookies/cache do not mix with normal browsing.
