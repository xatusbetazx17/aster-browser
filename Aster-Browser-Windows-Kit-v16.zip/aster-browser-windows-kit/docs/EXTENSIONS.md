# Aster Extensions

Aster supports browser-extension imports in two ways.

## Safe backend

Default: `safe`

This is the recommended mode when you care most about browser stability.

- Manifest V2 / content-script style extensions can inject CSS and JavaScript.
- Firefox-style `.xpi` packages that mainly use content scripts work best here.
- Complex Manifest V3 extensions may install as metadata, but not every browser API is available.

## Native backend

Setting: `native_when_available`

This tells Aster to let Qt WebEngine try native Manifest V3 loading when the runtime supports it.

- strongest path for Chrome-style MV3 extensions
- requires Qt / PyQt6-WebEngine 6.10+
- can still be less stable than mainstream browsers on some systems

## Install methods

- `Ctrl+Shift+E` → open Extensions manager
- **Install file** → `.zip`, `.xpi`, `.crx`
- **Install folder** → unpacked extension directory
- `Ctrl+Shift+A` → detect an installable extension package on the current page

## Honest limits

Aster is not a full Chrome or Firefox clone.

- background/service-worker APIs are not fully emulated in safe fallback mode
- native messaging is not implemented
- Chrome Web Store’s real `Add to Chrome` flow is not reproduced directly
- direct package downloads and unpacked extensions work much better than store-specific install flows
