# Streaming in Aster

Aster now defaults to `internal_preferred` DRM mode.

## What that means

- if Aster finds a usable **Widevine** CDM, it tries protected playback **inside Aster first**
- if Widevine is missing, Aster falls back to its compatibility path instead of silently failing
- normal non-DRM HTML5 video sites stay inside Aster as usual

## Recommended settings

- **DRM mode:** `internal_preferred`
- **Extension backend:** `safe`
- **Strict adblock:** off for streaming tests
- **Force software rendering:** only if your GPU stack is unstable

## Why some services can still fail

Protected video on Linux does not depend on HTML alone. It depends on a combination of:

- Widevine availability
- codecs
- driver stack
- the exact runtime and browser checks used by the streaming service

Aster improves the inside-browser path, but it cannot guarantee that every premium service will treat it exactly like Chrome or Firefox.

## First things to test

1. open Settings
2. set DRM mode to `internal_preferred`
3. restart Aster
4. test Prime Video or another service
5. if playback still fails, check whether Widevine is installed on the machine

## Quick reality check

- standard video sites: usually much easier
- DRM-heavy premium services: depends on Widevine and service compatibility
