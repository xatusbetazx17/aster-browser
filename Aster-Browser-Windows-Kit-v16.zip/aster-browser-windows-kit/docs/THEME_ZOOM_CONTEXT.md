# Theme, scaling, context menu, and zoom update

This update adds:

- Changeable **Qt widget style** in Settings, saved in the Aster config.
- Saved **window transparency** setting. Default is **10% transparency**.
- Saved **default page zoom** setting.
- Better high-DPI / 150% scaling for home-screen quick-link icons.
- Wider and more rounded home-screen and combo-box layout.
- Status bar information for the current page, zoom, and memory usage.
- Custom right-click context menu for web pages.
- Keyboard zoom shortcuts:
  - `Ctrl+=` zoom in
  - `Ctrl+-` zoom out
  - `Ctrl+0` reset zoom

Notes:

- Qt style availability depends on the styles shipped by the local Qt build.
- Right-click actions are implemented for web pages loaded in the embedded engine.
- The update was validated with Python compile checks in the build environment.
