# Aster Browser v9 Fix Pack

## HTTPS trust repair

- Removes the dangerous/annoying NSS certificate database refresh path.
- Never calls `certutil` or edits the user's protected NSS certificate DB.
- Detects normal Linux CA bundle locations and exports `SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`, `CURL_CA_BUNDLE`, and `SSL_CERT_DIR`.
- Adds the Chromium/QtWebEngine system-verifier hint `--use-system-cert-verifier` when a system CA bundle is found.
- Adds Tools → Diagnose current page security to compare Qt WebEngine errors with Python/OpenSSL trust.
- Adds per-host HTTPS exception settings for local/self-signed hosts only; Aster still does not bypass bad certificates globally.

## Vivaldi-style customization additions

- Accent color.
- Qt widget style selector.
- Tab position: top, bottom, left, right.
- Toolbar density: compact, comfortable, spacious.
- Window transparency.
- Default page zoom.
- Rounded-corner radius.
- Show/hide status bar, toolbar text, Home button, New Tab button, container selector, and load progress bar.
- Optional custom page CSS for power users.

## AI upgrades

- Adds persona selection: Dr Light Lab, Network Engineer, Cyber Guardian, Browser Helper, and Concise.
- Adds reasoning mode: fast, balanced, deep.
- Keeps the internal assistant local-first.
- External AI providers remain optional through Ollama, OpenAI, or OpenAI-compatible endpoints.

## Notes

Aster can be made more helpful and more customizable, but it cannot become literally as intelligent as a fictional character without connecting it to a strong external model. The new Dr Light Lab mode is an engineering-mentor behavior profile, not a copyrighted character clone.
