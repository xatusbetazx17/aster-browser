# Aster Browser v13

v13 focuses on the HTTPS/security-label bug Marcelo reported, deeper customization, and a more adaptive internal assistant.

Highlights:

- Separates main-frame HTTPS certificate errors from subresource certificate warnings.
- Clears stale certificate warning records after a successful HTTPS load.
- Adds status-bar security labels: HTTPS secure, HTTPS mixed, HTTPS caution, HTTPS warning, HTTP not secure.
- Adds page security diagnostics for mixed HTTP resources, insecure forms, and JavaScript secure context.
- Adds Tools → Clear Aster web security/cache state.
- Adds tools/reset_aster_network_state.sh and tools/diagnose_https.sh.
- Keeps Qt WebEngine's real desktop user agent instead of forcing an old fake Chrome desktop UA.
- Strengthens the local Inventor Mentor/Dr. Light-inspired assistant behavior with observation → likely cause → safe fix → verify → rollback answers.
- Keeps Vivaldi-style customization direction: tab layout, toolbar behavior, density, accent color, custom app QSS, custom page CSS, containers, zoom, status/security UI.

Validation performed in the build environment:

- Python compileall for aster_browser and tests.
- unittest discovery: 54 tests OK.
- bash syntax checks for Linux installer builder and diagnostic tools.
- self-extracting Linux installer build and extraction smoke test.
- ZIP integrity checks for source, Flatpak kit, and Windows kit.
