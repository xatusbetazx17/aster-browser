#!/usr/bin/env bash
set -euo pipefail
url="${1:-https://example.com}"
host_port="$(python3 - "$url" <<'PY_INNER'
import sys
from urllib.parse import urlparse
url=sys.argv[1]
p=urlparse(url if '://' in url else 'https://'+url)
host=p.hostname or ''
port=p.port or 443
print(f"{host}:{port}")
PY_INNER
)"
host="${host_port%:*}"
port="${host_port##*:}"
ca_bundle="${SSL_CERT_FILE:-}"
if [[ -z "$ca_bundle" ]]; then
  for f in /etc/ssl/certs/ca-certificates.crt /etc/pki/tls/certs/ca-bundle.crt /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem /etc/ssl/ca-bundle.pem /etc/ssl/cert.pem; do
    [[ -f "$f" ]] && ca_bundle="$f" && break
  done
fi
if [[ -n "$ca_bundle" ]]; then export SSL_CERT_FILE="$ca_bundle" REQUESTS_CA_BUNDLE="$ca_bundle" CURL_CA_BUNDLE="$ca_bundle"; fi
printf '[Aster HTTPS diagnostics] Host: %s
' "$host_port"
printf '[Aster HTTPS diagnostics] Date: %s
' "$(date -Is)"
printf '[Aster HTTPS diagnostics] CA bundle: %s

' "${ca_bundle:-not found}"
printf '[Aster HTTPS diagnostics] openssl certificate chain check:
'
if [[ -n "$host" && -n "$ca_bundle" ]] && command -v openssl >/dev/null 2>&1; then
  openssl s_client -connect "$host:$port" -servername "$host" -verify_return_error -CAfile "$ca_bundle" </dev/null || true
else
  echo 'openssl or CA bundle not available.'
fi
printf '
[Aster HTTPS diagnostics] Python SSL default paths:
'
python3 - <<'PY_INNER'
import os, ssl
print(ssl.get_default_verify_paths())
for key in ('SSL_CERT_FILE','SSL_CERT_DIR','REQUESTS_CA_BUNDLE','CURL_CA_BUNDLE','NSS_DEFAULT_DB_TYPE'):
    print(f"{key}={os.environ.get(key) or 'not set'}")
PY_INNER

printf '
[Aster HTTPS diagnostics] Aster profile paths:
'
printf 'ASTER_INSTALL_ROOT=%s
' "${ASTER_INSTALL_ROOT:-${XDG_DATA_HOME:-$HOME/.local/share}/aster-browser-portable}"
printf 'ASTER_PORTABLE_ROOT=%s
' "${ASTER_PORTABLE_ROOT:-not set}"
