#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CAPSULE_DIR="${ASTER_ECS_CAPSULE_ROOT:-$ROOT_DIR/packaging/electron-drm-capsule}"
ECS_VERSION="${ASTER_ECS_VERSION:-v42.0.0+wvcus}"
ASSUME_YES=0
NO_SYSTEM_DEPS=0

msg() { printf '[Aster DRM Capsule] %s\n' "$*"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -y|--yes) ASSUME_YES=1; shift ;;
    --no-system-deps) NO_SYSTEM_DEPS=1; shift ;;
    --version) ECS_VERSION="$2"; shift 2 ;;
    --capsule-dir) CAPSULE_DIR="$2"; shift 2 ;;
    -h|--help)
      cat <<USAGE
Install/update the optional Aster Chromium DRM Capsule.

Options:
  -y, --yes          Non-interactive package-manager installs
  --no-system-deps   Do not install nodejs/npm automatically
  --version TAG      CastLabs ECS release tag, default: $ECS_VERSION
  --capsule-dir DIR  Capsule source/runtime directory
USAGE
      exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

choose_sudo() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then printf ''; elif command -v sudo >/dev/null 2>&1; then printf 'sudo'; else return 1; fi
}

install_node() {
  [[ $NO_SYSTEM_DEPS -eq 1 ]] && return 0
  command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1 && return 0
  local sudo_cmd=""; sudo_cmd="$(choose_sudo || true)"
  if [[ "${EUID:-$(id -u)}" -ne 0 && -z "$sudo_cmd" ]]; then
    msg "node/npm not found and sudo is unavailable. Install nodejs and npm manually, then rerun."
    return 0
  fi
  msg "Installing nodejs/npm for the optional DRM capsule."
  if command -v apt-get >/dev/null 2>&1; then
    $sudo_cmd apt-get update
    if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd apt-get install -y nodejs npm; else $sudo_cmd apt-get install nodejs npm; fi
  elif command -v dnf >/dev/null 2>&1; then
    if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd dnf install -y nodejs npm; else $sudo_cmd dnf install nodejs npm; fi
  elif command -v yum >/dev/null 2>&1; then
    if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd yum install -y nodejs npm; else $sudo_cmd yum install nodejs npm; fi
  elif command -v pacman >/dev/null 2>&1; then
    if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd pacman -S --needed --noconfirm nodejs npm; else $sudo_cmd pacman -S --needed nodejs npm; fi
  elif command -v zypper >/dev/null 2>&1; then
    if [[ $ASSUME_YES -eq 1 ]]; then $sudo_cmd zypper --non-interactive install nodejs npm; else $sudo_cmd zypper install nodejs npm; fi
  else
    msg "No supported package manager found. Install nodejs/npm manually if missing."
  fi
}

install_node
command -v node >/dev/null 2>&1 || { msg "node not found."; exit 1; }
command -v npm >/dev/null 2>&1 || { msg "npm not found."; exit 1; }
mkdir -p "$CAPSULE_DIR"
cd "$CAPSULE_DIR"
msg "Installing CastLabs Electron for Content Security $ECS_VERSION into $CAPSULE_DIR"
npm install "https://github.com/castlabs/electron-releases#$ECS_VERSION" --save-dev --no-audit --fund=false
npm run check
msg "Done. In Aster, use DRM mode: chromium_drm_capsule"
