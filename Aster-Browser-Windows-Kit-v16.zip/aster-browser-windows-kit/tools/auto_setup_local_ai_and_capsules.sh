#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PORTABLE_INSTALL_ROOT="${HOME}/.local/share/aster-browser-portable"
PORTABLE_STATE_DIR="$PORTABLE_INSTALL_ROOT/state"
PORTABLE_LAUNCHER="$PORTABLE_INSTALL_ROOT/aster-launch.sh"
PORTABLE_WRAPPER="$PORTABLE_INSTALL_ROOT/aster-localai-launch.sh"
PORTABLE_DESKTOP_FILE="${HOME}/.local/share/applications/org.aster.Browser.desktop"
LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/aster-browser"
OLLAMA_LOG="$LOG_DIR/ollama-serve.log"
DEFAULT_BASE_URL="http://127.0.0.1:11434"
DEFAULT_ALIAS="${ASTER_LOCALAI_ALIAS:-aster-liteai}"
DEFAULT_NUM_CTX="${ASTER_OLLAMA_NUM_CTX:-2048}"
DEFAULT_KEEP_ALIVE="${ASTER_OLLAMA_KEEP_ALIVE:-0}"
CONFIG_ROOT=""

msg() {
  printf '[Aster Auto Setup] %s\n' "$*"
}

die() {
  printf '[Aster Auto Setup] %s\n' "$*" >&2
  exit 1
}

have() {
  command -v "$1" >/dev/null 2>&1
}

choose_python() {
  local candidate=""
  for candidate in python3 python; do
    if have "$candidate"; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

download_to() {
  local url="$1"
  local out="$2"
  if have curl; then
    curl -fsSL "$url" -o "$out"
    return 0
  fi
  if have wget; then
    wget -qO "$out" "$url"
    return 0
  fi
  return 1
}

api_ok() {
  if have curl; then
    curl -fsS "$DEFAULT_BASE_URL/api/version" >/dev/null 2>&1
    return $?
  fi
  if have wget; then
    wget -qO- "$DEFAULT_BASE_URL/api/version" >/dev/null 2>&1
    return $?
  fi
  return 1
}

wait_for_ollama() {
  local tries="${1:-25}"
  local i=0
  while [[ "$i" -lt "$tries" ]]; do
    if api_ok; then
      return 0
    fi
    sleep 1
    i=$((i + 1))
  done
  return 1
}

install_ollama_if_needed() {
  if have ollama; then
    return 0
  fi
  msg "Ollama not found. Downloading the official Linux installer."
  local tmp
  tmp="$(mktemp)"
  download_to "https://ollama.com/install.sh" "$tmp" || die "Need curl or wget to download Ollama."
  sh "$tmp" || die "Ollama install failed. If your distro blocks system install, install Ollama manually and rerun this helper."
  rm -f "$tmp"
  have ollama || die "Ollama was still not found on PATH after install."
}

start_ollama_if_needed() {
  mkdir -p "$LOG_DIR"
  if wait_for_ollama 2; then
    msg "Ollama API already responding on $DEFAULT_BASE_URL"
    return 0
  fi
  msg "Starting a local Ollama server with low-memory defaults."
  nohup env \
    OLLAMA_KEEP_ALIVE="$DEFAULT_KEEP_ALIVE" \
    OLLAMA_NUM_PARALLEL=1 \
    OLLAMA_MAX_LOADED_MODELS=1 \
    ollama serve >"$OLLAMA_LOG" 2>&1 &
  wait_for_ollama 30 || die "Ollama server did not start. Check $OLLAMA_LOG"
}

pick_model() {
  local candidate
  if [[ -n "${ASTER_LOCALAI_BASE_MODEL:-}" ]]; then
    printf '%s' "$ASTER_LOCALAI_BASE_MODEL"
    return 0
  fi
  for candidate in qwen3:0.6b qwen3:1.7b gemma3:1b llama3.2:1b; do
    if ollama pull "$candidate" >/dev/null 2>&1; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  printf '%s' "qwen3:1.7b"
  return 0
}

write_low_memory_model() {
  local alias="$1"
  local base_model="$2"
  local num_ctx="$3"
  local tmpdir
  tmpdir="$(mktemp -d)"
  cat >"$tmpdir/Modelfile" <<EOM
FROM $base_model
PARAMETER num_ctx $num_ctx
EOM
  if ollama create "$alias" -f "$tmpdir/Modelfile" >/dev/null 2>&1; then
    rm -rf "$tmpdir"
    printf '%s' "$alias"
    return 0
  fi
  rm -rf "$tmpdir"
  printf '%s' "$base_model"
  return 0
}

detect_config_root() {
  if [[ -n "${ASTER_PORTABLE_ROOT:-}" ]]; then
    printf '%s' "$ASTER_PORTABLE_ROOT"
    return 0
  fi
  if [[ -d "$PORTABLE_STATE_DIR" ]]; then
    printf '%s' "$PORTABLE_STATE_DIR"
    return 0
  fi
  printf '%s' "$PROJECT_ROOT/data"
}

write_config() {
  local python_cmd="$1"
  local config_file="$2"
  local model="$3"
  local base_url="$4"
  local allow_actions="$5"
  "$python_cmd" - "$config_file" "$model" "$base_url" "$allow_actions" <<'PY'
import json
import sys
from pathlib import Path

config_path = Path(sys.argv[1])
model = sys.argv[2]
base_url = sys.argv[3]
allow_actions = sys.argv[4] == '1'

payload = {
    "homepage": "aster:newtab",
    "search_engine": "https://duckduckgo.com/?q={query}",
    "adblock_enabled": True,
    "strict_adblock": False,
    "security_mode": "balanced",
    "max_live_tabs": 6,
    "soft_memory_budget_mb": 1200,
    "auto_park": True,
    "default_container": "default",
    "hardware_acceleration": True,
    "containers": ["default", "work", "media", "banking"],
    "drm_mode": "auto",
    "external_browser_cmd": "",
    "allow_ai_actions": allow_actions,
    "ai_page_context_chars": 6000,
    "ai": {
        "provider": "ollama",
        "model": model,
        "base_url": base_url,
        "api_key_env": "ASTER_OPENAI_API_KEY",
        "system_prompt": (
            "You are Aster Assistant inside a Linux browser. Be concise, privacy-aware, "
            "and prefer low-resource workflows when possible. When the user asks about the current page, "
            "use the provided page excerpt instead of inventing details."
        ),
    },
}

if config_path.exists():
    try:
        data = json.loads(config_path.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            payload.update({k: v for k, v in data.items() if k in payload and k != 'ai'})
            ai = payload['ai'].copy()
            if isinstance(data.get('ai'), dict):
                ai.update(data['ai'])
            ai['provider'] = 'ollama'
            ai['model'] = model
            ai['base_url'] = base_url
            payload['ai'] = ai
            payload['allow_ai_actions'] = allow_actions
    except Exception:
        pass

config_path.parent.mkdir(parents=True, exist_ok=True)
config_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding='utf-8')
print(config_path)
PY
}

write_wrapper() {
  local model="$1"
  local base_url="$2"
  local allow_actions="$3"
  [[ -x "$PORTABLE_LAUNCHER" ]] || return 0
  cat > "$PORTABLE_WRAPPER" <<EOF
#!/usr/bin/env bash
set -euo pipefail
if ! curl -fsS "$base_url/api/version" >/dev/null 2>&1; then
  mkdir -p "$LOG_DIR"
  nohup env OLLAMA_KEEP_ALIVE="$DEFAULT_KEEP_ALIVE" OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 ollama serve >"$OLLAMA_LOG" 2>&1 &
  sleep 2
fi
export ASTER_PORTABLE="1"
export ASTER_PORTABLE_ROOT="$CONFIG_ROOT"
export ASTER_AI_PROVIDER="ollama"
export ASTER_AI_MODEL="$model"
export ASTER_AI_BASE_URL="$base_url"
export ASTER_ALLOW_AI_ACTIONS="$allow_actions"
export ASTER_OLLAMA_KEEP_ALIVE="$DEFAULT_KEEP_ALIVE"
export ASTER_OLLAMA_NUM_CTX="$DEFAULT_NUM_CTX"
exec "$PORTABLE_LAUNCHER" "\$@"
EOF
  chmod 700 "$PORTABLE_WRAPPER"
  if [[ -f "$PORTABLE_DESKTOP_FILE" ]]; then
    python3 - <<PY
from pathlib import Path
p = Path(r"$PORTABLE_DESKTOP_FILE")
text = p.read_text(encoding='utf-8')
lines = []
changed = False
for line in text.splitlines():
    if line.startswith('Exec=') and not changed:
        lines.append('Exec=$PORTABLE_WRAPPER %U')
        changed = True
    else:
        lines.append(line)
p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
PY
  fi
}

main() {
  local python_cmd=""
  python_cmd="$(choose_python || true)"
  [[ -n "$python_cmd" ]] || die "Python was not found."

  CONFIG_ROOT="$(detect_config_root)"
  local config_file="$CONFIG_ROOT/config/config.json"
  mkdir -p "$(dirname "$config_file")"

  install_ollama_if_needed
  start_ollama_if_needed

  local base_model final_model allow_actions
  base_model="$(pick_model)"
  if ! ollama pull "$base_model" >/dev/null 2>&1; then
    msg "Could not auto-pull $base_model. The browser will still be configured, but you may need to run 'ollama pull $base_model' later."
  fi
  final_model="$(write_low_memory_model "$DEFAULT_ALIAS" "$base_model" "$DEFAULT_NUM_CTX")"
  allow_actions="${ASTER_ALLOW_AI_ACTIONS:-1}"

  write_config "$python_cmd" "$config_file" "$final_model" "$DEFAULT_BASE_URL" "$allow_actions"
  write_wrapper "$final_model" "$DEFAULT_BASE_URL" "$allow_actions"

  msg "Done."
  msg "Config updated: $config_file"
  msg "Local AI model: $final_model"
  msg "Ollama base URL: $DEFAULT_BASE_URL"
  msg "Streaming capsules remain enabled in auto mode for premium DRM sites."
}

main "$@"
