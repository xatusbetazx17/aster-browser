#!/usr/bin/env bash
set -euo pipefail
AUTO=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --auto|-y|--yes) AUTO=1; shift ;;
    --help|-h)
      cat <<'USAGE'
Refresh Aster HTTPS certificate dependencies safely.

This helper updates OS CA certificate packages and refreshes the system trust
extracts. It never touches protected NSS user certificate databases.

Usage:
  tools/refresh_ca_trust.sh --auto
USAGE
      exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

msg() { printf '[Aster CA Trust] %s\n' "$*"; }
choose_sudo() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then printf ''; return 0; fi
  if command -v sudo >/dev/null 2>&1; then printf 'sudo'; return 0; fi
  return 1
}
run_pkg() {
  local sudo_cmd=""
  sudo_cmd="$(choose_sudo || true)"
  if [[ "${EUID:-$(id -u)}" -ne 0 && -z "$sudo_cmd" ]]; then
    msg "sudo/root unavailable. Manual command: $*"
    return 0
  fi
  msg "Running: $*"
  $sudo_cmd "$@" || true
}

msg "Refreshing system CA packages/trust only; NSS user DBs will not be touched."
if command -v apt-get >/dev/null 2>&1; then
  run_pkg apt-get update
  if [[ $AUTO -eq 1 ]]; then run_pkg apt-get install -y ca-certificates openssl libnss3 p11-kit; else run_pkg apt-get install ca-certificates openssl libnss3 p11-kit; fi
elif command -v dnf >/dev/null 2>&1; then
  if [[ $AUTO -eq 1 ]]; then run_pkg dnf install -y ca-certificates openssl nss p11-kit p11-kit-trust; else run_pkg dnf install ca-certificates openssl nss p11-kit p11-kit-trust; fi
elif command -v yum >/dev/null 2>&1; then
  if [[ $AUTO -eq 1 ]]; then run_pkg yum install -y ca-certificates openssl nss p11-kit p11-kit-trust; else run_pkg yum install ca-certificates openssl nss p11-kit p11-kit-trust; fi
elif command -v pacman >/dev/null 2>&1; then
  if [[ $AUTO -eq 1 ]]; then run_pkg pacman -S --needed --noconfirm ca-certificates ca-certificates-utils openssl nss p11-kit; else run_pkg pacman -S --needed ca-certificates ca-certificates-utils openssl nss p11-kit; fi
elif command -v zypper >/dev/null 2>&1; then
  if [[ $AUTO -eq 1 ]]; then run_pkg zypper --non-interactive install ca-certificates openssl mozilla-nss p11-kit; else run_pkg zypper install ca-certificates openssl mozilla-nss p11-kit; fi
elif command -v apk >/dev/null 2>&1; then
  run_pkg apk add --no-cache ca-certificates openssl nss p11-kit
else
  msg "No supported package manager detected. Continuing with trust extract checks."
fi

sudo_cmd="$(choose_sudo || true)"
if command -v update-ca-certificates >/dev/null 2>&1; then
  msg "Running update-ca-certificates"
  $sudo_cmd update-ca-certificates || true
elif command -v update-ca-trust >/dev/null 2>&1; then
  msg "Running update-ca-trust extract"
  $sudo_cmd update-ca-trust extract || true
elif command -v trust >/dev/null 2>&1; then
  msg "Running trust extract-compat"
  $sudo_cmd trust extract-compat || true
else
  msg "No CA trust extract command found."
fi

for ca_file in \
  /etc/ssl/certs/ca-certificates.crt \
  /etc/pki/tls/certs/ca-bundle.crt \
  /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem \
  /etc/ssl/ca-bundle.pem \
  /var/lib/ca-certificates/ca-bundle.pem \
  /etc/ssl/cert.pem; do
  if [[ -f "$ca_file" ]]; then
    msg "Detected CA bundle: $ca_file"
    exit 0
  fi
done
msg "No common CA bundle path detected. HTTPS may still fail until the OS trust store is fixed."
