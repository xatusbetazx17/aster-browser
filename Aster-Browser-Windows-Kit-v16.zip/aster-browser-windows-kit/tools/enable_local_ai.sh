#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PORTABLE_INSTALL_ROOT="${HOME}/.local/share/aster-browser-portable"
PORTABLE_STATE_DIR="$PORTABLE_INSTALL_ROOT/state"
PORTABLE_WRAPPER="$PORTABLE_INSTALL_ROOT/aster-localai-launch.sh"
PORTABLE_DESKTOP_FILE="${HOME}/.local/share/applications/org.aster.Browser.desktop"
PORTABLE_DESKTOP_HELPER="${HOME}/.local/share/applications/org.aster.Browser.LocalAI.desktop"

msg() {
  printf '[Aster Local AI Setup] %s\n' "$*"
}

die() {
  printf '[Aster Local AI Setup] %s\n' "$*" >&2
  exit 1
}

choose_python() {
  local candidate=""
  for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

prompt_default() {
  local prompt="$1"
  local default="$2"
  local value=""
  read -r -p "$prompt [$default]: " value
  if [[ -z "$value" ]]; then
    value="$default"
  fi
  printf '%s' "$value"
}

prompt_yes_no() {
  local prompt="$1"
  local default="$2"
  local answer=""
  read -r -p "$prompt [$default]: " answer
  if [[ -z "$answer" ]]; then
    answer="$default"
  fi
  case "${answer,,}" in
    y|yes|1|true|on)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

detect_portable_root() {
  if [[ -n "${ASTER_PORTABLE_ROOT:-}" ]]; then
    printf '%s' "$ASTER_PORTABLE_ROOT"
    return 0
  fi
  if [[ -d "$PORTABLE_STATE_DIR" ]]; then
    printf '%s' "$PORTABLE_STATE_DIR"
    return 0
  fi
  printf '%s' "$PROJECT_ROOT/data"
}

main() {
  local python_cmd=""
  python_cmd="$(choose_python || true)"
  [[ -n "$python_cmd" ]] || die "Python was not found."

  local portable_root config_dir config_file model base_url allow_actions pull_now
  portable_root="$(detect_portable_root)"
  config_dir="$portable_root/config"
  config_file="$config_dir/config.json"

  mkdir -p "$config_dir"

  msg "This will configure Aster to use a local Ollama model."
  msg "If you do not want AI later, set AI provider back to 'disabled' in Aster settings."
  printf '\n'

  model="$(prompt_default 'Local model name' 'qwen3:1.7b')"
  base_url="$(prompt_default 'Ollama base URL' 'http://127.0.0.1:11434')"
  if prompt_yes_no 'Enable lightweight AI actions by default?' 'Y'; then
    allow_actions=1
  else
    allow_actions=0
  fi

  "$python_cmd" - "$config_file" "$model" "$base_url" "$allow_actions" <<'PY'
import json
import sys
from pathlib import Path

config_path = Path(sys.argv[1])
model = sys.argv[2]
base_url = sys.argv[3]
allow_actions = sys.argv[4] == '1'

payload = {
    "homepage": "aster:newtab",
    "search_engine": "https://duckduckgo.com/?q={query}",
    "adblock_enabled": True,
    "strict_adblock": False,
    "security_mode": "balanced",
    "max_live_tabs": 6,
    "soft_memory_budget_mb": 1200,
    "auto_park": True,
    "default_container": "default",
    "hardware_acceleration": True,
    "containers": ["default", "work", "media", "banking"],
    "drm_mode": "auto",
    "external_browser_cmd": "",
    "allow_ai_actions": allow_actions,
    "ai_page_context_chars": 6000,
    "ai": {
        "provider": "ollama",
        "model": model,
        "base_url": base_url,
        "api_key_env": "ASTER_OPENAI_API_KEY",
        "system_prompt": (
            "You are Aster Assistant inside a Linux browser. Be concise, privacy-aware, "
            "and prefer low-resource workflows when possible. When the user asks about the current page, "
            "use the provided page excerpt instead of inventing details."
        ),
    },
}

if config_path.exists():
    try:
        data = json.loads(config_path.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            payload.update({k: v for k, v in data.items() if k in payload and k != 'ai'})
            ai = payload['ai'].copy()
            if isinstance(data.get('ai'), dict):
                ai.update(data['ai'])
            ai['provider'] = 'ollama'
            ai['model'] = model
            ai['base_url'] = base_url
            payload['ai'] = ai
            payload['allow_ai_actions'] = allow_actions
    except Exception:
        pass

config_path.parent.mkdir(parents=True, exist_ok=True)
config_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding='utf-8')
print(config_path)
PY

  if command -v ollama >/dev/null 2>&1; then
    if prompt_yes_no "Pull model '$model' now with ollama?" 'Y'; then
      ollama pull "$model"
    fi
  else
    msg "Ollama was not found on PATH. Install Ollama first if you want local model chat."
  fi

  if [[ -d "$PORTABLE_INSTALL_ROOT" ]]; then
    cat > "$PORTABLE_WRAPPER" <<EOF
#!/usr/bin/env bash
set -euo pipefail
export ASTER_PORTABLE="1"
export ASTER_PORTABLE_ROOT="$portable_root"
export ASTER_AI_PROVIDER="ollama"
export ASTER_AI_MODEL="$model"
export ASTER_AI_BASE_URL="$base_url"
export ASTER_ALLOW_AI_ACTIONS="$allow_actions"
exec "$PORTABLE_INSTALL_ROOT/aster-launch.sh" "\$@"
EOF
    chmod 700 "$PORTABLE_WRAPPER"

    mkdir -p "$(dirname "$PORTABLE_DESKTOP_HELPER")"
    cat > "$PORTABLE_DESKTOP_HELPER" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Aster Browser Local AI Setup
Comment=Configure Aster Browser to use a local Ollama model
Exec=$PORTABLE_INSTALL_ROOT/aster-localai-setup.sh
Icon=aster-browser
Categories=Utility;
Terminal=true
StartupNotify=false
EOF

    if [[ -f "$PORTABLE_DESKTOP_FILE" ]]; then
      msg "Portable Aster install detected."
      msg "Local AI setup script: $PORTABLE_INSTALL_ROOT/aster-localai-setup.sh"
      msg "Local AI launcher: $PORTABLE_WRAPPER"
    fi
  fi

  msg "Done."
  msg "Config updated: $config_file"
  msg "In Aster, you can now use local chat or keep using only lightweight AI actions."
}

main "$@"
