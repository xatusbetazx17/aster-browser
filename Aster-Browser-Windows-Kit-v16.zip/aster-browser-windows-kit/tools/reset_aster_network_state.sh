#!/usr/bin/env bash
set -euo pipefail
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
ROOT="${ASTER_INSTALL_ROOT:-$DATA_HOME/aster-browser-portable}"
PRIMARY_STATE="${ASTER_PORTABLE_ROOT:-$ROOT/state}"
removed=0
roots=()
add_root() {
  local p="$1"
  [[ -n "$p" ]] || return 0
  roots+=("$p")
}
add_root "$PRIMARY_STATE"
add_root "$ROOT/state"
# Legacy v10-v13 builds could store profile/cache below the installed app because
# ASTER_PORTABLE_ROOT was not exported by the launcher. Scan those locations too.
add_root "$ROOT/app/data"
add_root "$ROOT/app/cache"
printf '[Aster reset] Clearing Aster web cache/security state.
'
seen=""
for state_root in "${roots[@]}"; do
  [[ -d "$state_root" ]] || continue
  case ":$seen:" in *":$state_root:"*) continue ;; esac
  seen="$seen:$state_root"
  printf '[Aster reset] Scanning %s
' "$state_root"
  while IFS= read -r -d '' path; do
    rm -rf "$path" && removed=$((removed+1)) || true
  done < <(find "$state_root" -type d \( -name Cache -o -name 'Code Cache' -o -name GPUCache -o -name DawnCache -o -name ShaderCache -o -name GrShaderCache \) -print0 2>/dev/null)
  while IFS= read -r -d '' path; do
    rm -f "$path" && removed=$((removed+1)) || true
  done < <(find "$state_root" -type f \( -name 'Network Persistent State' -o -name TransportSecurity -o -name CertificateRevocation -o -name 'Trust Tokens' -o -name 'Trust Tokens-journal' -o -name 'Reporting and NEL' -o -name 'Reporting and NEL-journal' \) -print0 2>/dev/null)
done
printf '[Aster reset] Removed cache/security items: %s
' "$removed"
printf '[Aster reset] Restart Aster Browser, then reload the site.
'
