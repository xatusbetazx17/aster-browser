#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PORTABLE_INSTALL_ROOT="${HOME}/.local/share/aster-browser-portable"
PORTABLE_STATE_DIR="$PORTABLE_INSTALL_ROOT/state"
PORTABLE_WRAPPER="$PORTABLE_INSTALL_ROOT/aster-internal-launch.sh"
PURGE_OLLAMA=0

msg() {
  printf '[Aster Internal AI Setup] %s\n' "$*"
}

die() {
  printf '[Aster Internal AI Setup] %s\n' "$*" >&2
  exit 1
}

choose_python() {
  local candidate=""
  for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

detect_portable_root() {
  if [[ -n "${ASTER_PORTABLE_ROOT:-}" ]]; then
    printf '%s' "$ASTER_PORTABLE_ROOT"
    return 0
  fi
  if [[ -d "$PORTABLE_STATE_DIR" ]]; then
    printf '%s' "$PORTABLE_STATE_DIR"
    return 0
  fi
  printf '%s' "$PROJECT_ROOT/data"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge-ollama)
      PURGE_OLLAMA=1
      ;;
    *)
      die "Unknown option: $1"
      ;;
  esac
  shift
done

main() {
  local python_cmd="" portable_root config_dir config_file
  python_cmd="$(choose_python || true)"
  [[ -n "$python_cmd" ]] || die "Python was not found."

  portable_root="$(detect_portable_root)"
  config_dir="$portable_root/config"
  config_file="$config_dir/config.json"
  mkdir -p "$config_dir"

  "$python_cmd" - "$config_file" <<'PY'
import json
import sys
from pathlib import Path

config_path = Path(sys.argv[1])
payload = {
    "homepage": "aster:newtab",
    "search_engine": "https://duckduckgo.com/?q={query}",
    "adblock_enabled": True,
    "strict_adblock": False,
    "security_mode": "balanced",
    "max_live_tabs": 6,
    "soft_memory_budget_mb": 1200,
    "auto_park": True,
    "default_container": "default",
    "hardware_acceleration": True,
    "containers": ["default", "work", "media", "banking"],
    "drm_mode": "internal_preferred",
    "external_browser_cmd": "",
    "allow_ai_actions": True,
    "theme": "aster_dark",
    "extension_backend": "safe",
    "force_software_rendering": False,
    "ai_page_context_chars": 5000,
    "ai": {
        "provider": "internal",
        "model": "aster-internal",
        "base_url": "",
        "api_key_env": "",
        "system_prompt": (
            "You are Aster Assistant inside a Linux browser. Be concise, privacy-aware, "
            "and prefer low-resource workflows when possible. When the user asks about the current page, "
            "use the provided page excerpt instead of inventing details."
        ),
    },
}

if config_path.exists():
    try:
        data = json.loads(config_path.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            payload.update({k: v for k, v in data.items() if k in payload and k != 'ai'})
            ai = payload['ai'].copy()
            if isinstance(data.get('ai'), dict):
                ai.update(data['ai'])
            ai['provider'] = 'internal'
            ai['model'] = 'aster-internal'
            ai['base_url'] = ''
            ai['api_key_env'] = ''
            payload['ai'] = ai
            payload['allow_ai_actions'] = True
            payload['ai_page_context_chars'] = max(3000, min(8000, int(data.get('ai_page_context_chars', 5000) or 5000)))
    except Exception:
        pass

config_path.parent.mkdir(parents=True, exist_ok=True)
config_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding='utf-8')
print(config_path)
PY

  if [[ -d "$PORTABLE_INSTALL_ROOT" ]]; then
    cat > "$PORTABLE_WRAPPER" <<EOF
#!/usr/bin/env bash
set -euo pipefail
export ASTER_PORTABLE="1"
export ASTER_PORTABLE_ROOT="$portable_root"
export ASTER_AI_PROVIDER="internal"
export ASTER_AI_MODEL="aster-internal"
export ASTER_AI_BASE_URL=""
export ASTER_AI_KEY_ENV=""
export ASTER_ALLOW_AI_ACTIONS="1"
exec "$PORTABLE_INSTALL_ROOT/aster-launch.sh" "\$@"
EOF
    chmod 700 "$PORTABLE_WRAPPER"
  fi

  if systemctl --user list-unit-files 2>/dev/null | grep -q '^aster-ollama-safe.service'; then
    systemctl --user stop aster-ollama-safe.service >/dev/null 2>&1 || true
    systemctl --user disable aster-ollama-safe.service >/dev/null 2>&1 || true
    msg "Stopped Aster's dedicated Ollama service."
  fi

  if [[ "$PURGE_OLLAMA" -eq 1 ]]; then
    rm -rf "$HOME/.local/share/aster-browser/ollama-models" >/dev/null 2>&1 || true
    rm -rf "$HOME/.ollama/models" >/dev/null 2>&1 || true
    msg "Removed local Ollama model directories that Aster may have used."
  fi

  msg "Done."
  msg "Config updated: $config_file"
  msg "Aster now uses the built-in internal assistant with no external model service."
  if [[ -f "$PORTABLE_WRAPPER" ]]; then
    msg "Wrapper: $PORTABLE_WRAPPER"
  fi
  msg "Restart Aster completely before testing the AI panel."
}

main "$@"
