#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CAPSULE_DIR="${ASTER_ECS_CAPSULE_ROOT:-$ROOT_DIR/packaging/electron-drm-capsule}"
URL="${1:-https://bitmovin.com/demos/drm}"
SERVICE="${2:-Manual}"
PROFILE="${3:-${ASTER_PORTABLE_ROOT:-$ROOT_DIR/data}/data/capsules/manual-drm}"
mkdir -p "$PROFILE"
if [[ -x "$CAPSULE_DIR/node_modules/.bin/electron" ]]; then
  exec "$CAPSULE_DIR/node_modules/.bin/electron" "$CAPSULE_DIR" -- --aster-url="$URL" --aster-service="$SERVICE" --aster-profile="$PROFILE"
elif [[ -x "$CAPSULE_DIR/node_modules/electron/dist/electron" ]]; then
  exec "$CAPSULE_DIR/node_modules/electron/dist/electron" "$CAPSULE_DIR" -- --aster-url="$URL" --aster-service="$SERVICE" --aster-profile="$PROFILE"
else
  echo "Aster DRM capsule runtime is not installed. Run: $ROOT_DIR/tools/setup_chromium_drm_capsule.sh" >&2
  exit 1
fi
