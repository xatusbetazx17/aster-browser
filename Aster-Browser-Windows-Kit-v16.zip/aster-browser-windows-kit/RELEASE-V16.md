# Aster Browser v16

v16 adds an optional Chromium DRM capsule for streaming/cloud-gaming compatibility without installing Google Chrome as the user's main browser.

New items:

- `chromium_drm_capsule` DRM mode
- `packaging/electron-drm-capsule/` CastLabs/Electron capsule source
- `tools/setup_chromium_drm_capsule.sh`
- `tools/run_chromium_drm_capsule.sh`
- Windows setup helper: `packaging/windows/setup_chromium_drm_capsule_windows.ps1`
- Linux installer flag: `--with-drm-capsule`

The optional capsule downloads/installs a bundled Chromium-family runtime through npm. It does not install Chrome or set Chrome as default. DRM playback still depends on Widevine/CDM/service rules and is not guaranteed for every service.
