from pathlib import Path
import unittest

from aster_browser.adblock import AdblockRuleset


RULES = Path(__file__).resolve().parents[1] / 'rules' / 'default_blocklist.txt'


class AdblockTests(unittest.TestCase):
    def test_blocks_known_tracker_host(self):
        ruleset = AdblockRuleset.from_file(RULES)
        self.assertTrue(ruleset.should_block('https://doubleclick.net/pagead/ads'))

    def test_does_not_block_normal_site(self):
        ruleset = AdblockRuleset.from_file(RULES)
        self.assertFalse(ruleset.should_block('https://example.com/about'))

    def test_does_not_block_known_streaming_hosts(self):
        ruleset = AdblockRuleset.from_file(RULES, strict=True)
        self.assertFalse(ruleset.should_block('https://www.primevideo.com/detail/abc'))
        self.assertFalse(ruleset.should_block('https://www.netflix.com/watch/123'))

    def test_custom_allow_and_block_hosts(self):
        ruleset = AdblockRuleset.from_sources(RULES, custom_rules='block:ads.example.com\nallow:cdn.example.com', allow_hosts=['good.example'], block_hosts=['bad.example'])
        self.assertTrue(ruleset.should_block('https://ads.example.com/script.js'))
        self.assertTrue(ruleset.should_block('https://bad.example/pixel'))
        self.assertFalse(ruleset.should_block('https://cdn.example.com/video.js'))
        self.assertFalse(ruleset.should_block('https://good.example/ad.js'))

    def test_adblock_off_mode_blocks_nothing(self):
        ruleset = AdblockRuleset.from_sources(RULES, mode='off', block_hosts=['bad.example'])
        self.assertFalse(ruleset.should_block('https://bad.example/pixel'))


if __name__ == '__main__':
    unittest.main()
