import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from aster_browser import flags
from aster_browser.runtime import graphics_state
from aster_browser.streaming import build_qtwebengine_flags, opposite_switch


class FlagStoreTests(unittest.TestCase):
    """The page writes where startup reads. It did not, and every choice was lost."""

    def test_saved_states_come_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(flags, "config_dir", return_value=Path(tmp)):
                flags.save_flags({"smooth_scrolling": flags.DISABLED})
                self.assertEqual(flags.load_flags(), {"smooth_scrolling": flags.DISABLED})

    def test_default_states_are_not_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(flags, "config_dir", return_value=Path(tmp)):
                flags.save_flags({"smooth_scrolling": flags.DEFAULT, "disable_gpu": flags.ENABLED})
                self.assertEqual(flags.load_flags(), {"disable_gpu": flags.ENABLED})

    def test_unknown_ids_and_values_are_dropped(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "flags.json"
            path.write_text(json.dumps({"site_isolation": "Enabled", "smooth_scrolling": "Maybe"}), encoding="utf-8")
            with mock.patch.object(flags, "config_dir", return_value=Path(tmp)):
                self.assertEqual(flags.load_flags(), {})

    def test_damaged_file_does_not_stop_startup(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "flags.json").write_text("{not json", encoding="utf-8")
            with mock.patch.object(flags, "config_dir", return_value=Path(tmp)):
                self.assertEqual(flags.load_flags(), {})

    def test_the_older_file_is_read_until_one_is_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            legacy = Path(tmp) / "legacy" / "flags.json"
            legacy.parent.mkdir(parents=True)
            legacy.write_text(json.dumps({"overlay_scrollbars": "Enabled"}), encoding="utf-8")
            current = Path(tmp) / "current"
            with mock.patch.object(flags, "config_dir", return_value=current), \
                    mock.patch.object(flags, "LEGACY_FILE", legacy):
                self.assertEqual(flags.load_flags(), {"overlay_scrollbars": flags.ENABLED})
                flags.save_flags({"overlay_scrollbars": flags.DISABLED})
                self.assertEqual(flags.load_flags(), {"overlay_scrollbars": flags.DISABLED})


class FlagSwitchTests(unittest.TestCase):
    def test_states_turn_into_the_switches_chromium_knows(self):
        self.assertEqual(flags.switches({"smooth_scrolling": flags.ENABLED}), ["--enable-smooth-scrolling"])
        self.assertEqual(flags.switches({"smooth_scrolling": flags.DISABLED}), ["--disable-smooth-scrolling"])
        self.assertEqual(flags.switches({"smooth_scrolling": flags.DEFAULT}), [])

    def test_an_experiment_without_an_off_switch_stays_quiet(self):
        self.assertEqual(flags.switches({"disable_gpu": flags.ENABLED}), ["--disable-gpu"])
        self.assertEqual(flags.switches({"disable_gpu": flags.DISABLED}), [])

    def test_every_experiment_has_a_switch_and_its_own_id(self):
        ids = [experiment.id for experiment in flags.EXPERIMENTS]
        self.assertEqual(len(ids), len(set(ids)))
        for experiment in flags.EXPERIMENTS:
            self.assertTrue(experiment.enable.startswith("--"))


class EngineFlagTests(unittest.TestCase):
    def test_wheel_scrolling_animates_by_default(self):
        """ScrollAnimatorEnabled covers the keyboard; the wheel needs this switch."""
        self.assertIn("--enable-smooth-scrolling", build_qtwebengine_flags().split())

    def test_turning_it_off_on_the_page_beats_the_default(self):
        built = build_qtwebengine_flags(existing="--disable-smooth-scrolling").split()
        self.assertIn("--disable-smooth-scrolling", built)
        self.assertNotIn("--enable-smooth-scrolling", built)

    def test_disabling_the_gpu_drops_the_acceleration_switches(self):
        built = build_qtwebengine_flags(existing="--disable-gpu", hardware_acceleration=True).split()
        self.assertIn("--disable-gpu", built)
        self.assertNotIn("--enable-gpu-rasterization", built)
        self.assertNotIn("--ignore-gpu-blocklist", built)

    def test_acceleration_and_widevine_still_arrive(self):
        built = build_qtwebengine_flags(widevine_path="/tmp/libwidevinecdm.so").split()
        self.assertIn("--enable-gpu-rasterization", built)
        self.assertIn("--widevine-path=/tmp/libwidevinecdm.so", built)

    def test_a_switch_is_never_repeated(self):
        built = build_qtwebengine_flags(existing="--enable-smooth-scrolling --enable-zero-copy").split()
        self.assertEqual(len(built), len(set(built)))

    def test_opposites(self):
        self.assertEqual(opposite_switch("--enable-smooth-scrolling"), "--disable-smooth-scrolling")
        self.assertEqual(opposite_switch("--disable-features=OverlayScrollbar"), "--enable-features=OverlayScrollbar")
        self.assertEqual(opposite_switch("--widevine-path=/tmp/x"), "")


class GraphicsStateTests(unittest.TestCase):
    def test_it_reports_what_the_engine_was_given(self):
        with mock.patch.dict("os.environ", {"QTWEBENGINE_CHROMIUM_FLAGS": "--enable-smooth-scrolling --enable-zero-copy"}):
            self.assertEqual(graphics_state(), {"gpu": True, "smooth_scrolling": True})
        with mock.patch.dict("os.environ", {"QTWEBENGINE_CHROMIUM_FLAGS": "--disable-gpu --disable-smooth-scrolling"}):
            self.assertEqual(graphics_state(), {"gpu": False, "smooth_scrolling": False})


if __name__ == "__main__":
    unittest.main()
