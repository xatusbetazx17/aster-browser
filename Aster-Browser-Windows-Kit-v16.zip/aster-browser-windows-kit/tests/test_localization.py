import unittest

from aster_browser.localization import accept_language_for, normalize_language_code


class LocalizationTests(unittest.TestCase):
    def test_normalizes_language_codes(self):
        self.assertEqual(normalize_language_code('es_mx'), 'es-MX')
        self.assertEqual(normalize_language_code('zh-hant'), 'zh-Hant')
        self.assertEqual(normalize_language_code('system'), 'system')

    def test_accept_language_header_contains_primary_fallback(self):
        header = accept_language_for('pt-BR')
        self.assertIn('pt-BR', header)
        self.assertIn('pt;q=0.9', header)


if __name__ == '__main__':
    unittest.main()
