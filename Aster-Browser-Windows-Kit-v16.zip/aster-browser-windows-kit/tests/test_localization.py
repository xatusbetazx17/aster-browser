import ast
import os
import pathlib
import re
import unittest
from unittest.mock import patch

from aster_browser.config import coerce_browser_config
from aster_browser.localization import (
    accept_language_for,
    active_translation_family,
    interface_language_choices,
    interface_language_label,
    normalize_interface_language,
    normalize_language_code,
    set_ui_language,
    tr,
    ui_language,
)
from aster_browser.translations import INTERFACE_LANGUAGE_CHOICES, TRANSLATIONS

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
UI_MODULES = ("widgets.py", "browser.py", "internal_pages.py")


def _tr_literals(path: pathlib.Path) -> set[str]:
    """Every literal the code base passes to tr()."""
    found: set[str] = set()
    for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.id if isinstance(node.func, ast.Name) else getattr(node.func, "attr", None)
        if name != "tr" or not node.args:
            continue
        first = node.args[0]
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            found.add(first.value)
    return found


class LocalizationTests(unittest.TestCase):
    def setUp(self):
        self.addCleanup(set_ui_language, "system")

    def test_normalizes_language_codes(self):
        self.assertEqual(normalize_language_code('es_mx'), 'es-MX')
        self.assertEqual(normalize_language_code('zh-hant'), 'zh-Hant')
        self.assertEqual(normalize_language_code('system'), 'system')

    def test_accept_language_header_contains_primary_fallback(self):
        header = accept_language_for('pt-BR')
        self.assertIn('pt-BR', header)
        self.assertIn('pt;q=0.9', header)


class InterfaceLanguageTests(unittest.TestCase):
    def setUp(self):
        self.addCleanup(set_ui_language, "system")

    def test_at_least_ten_interface_languages_ship(self):
        codes = [code for code, _ in INTERFACE_LANGUAGE_CHOICES if code != "system"]
        self.assertGreaterEqual(len(codes), 10)
        self.assertIn("tr", codes)
        self.assertEqual(len(codes), len(set(codes)))

    def test_every_offered_language_has_a_catalog(self):
        for code, _ in INTERFACE_LANGUAGE_CHOICES:
            if code in {"system", "en"}:
                continue
            self.assertIn(code, TRANSLATIONS, f"no catalog for {code}")

    def test_catalogs_are_complete_and_translated(self):
        reference = set(TRANSLATIONS["tr"])
        for code, entries in TRANSLATIONS.items():
            missing = reference - set(entries)
            self.assertFalse(missing, f"{code} is missing {sorted(missing)[:3]}")
            self.assertFalse(set(entries) - reference, f"{code} has unknown keys")
            blank = [key for key, value in entries.items() if not str(value).strip()]
            self.assertFalse(blank, f"{code} has blank translations: {blank[:3]}")

    def test_format_placeholders_survive_translation(self):
        placeholders = re.compile(r"\{[a-z_]+\}")
        for code, entries in TRANSLATIONS.items():
            for key, value in entries.items():
                self.assertEqual(
                    sorted(placeholders.findall(key)),
                    sorted(placeholders.findall(value)),
                    f"{code}: placeholders differ for {key!r}",
                )

    def test_every_translated_ui_string_is_in_the_catalog(self):
        package = REPO_ROOT / "aster_browser"
        used: set[str] = set()
        for name in UI_MODULES:
            used |= _tr_literals(package / name)
        self.assertTrue(used, "no tr() literals found")
        unknown = sorted(used - set(TRANSLATIONS["tr"]))
        self.assertFalse(unknown, f"strings used with tr() but never translated: {unknown[:5]}")

    def test_tr_switches_with_the_active_language(self):
        set_ui_language("tr")
        self.assertEqual(ui_language(), "tr")
        self.assertEqual(tr("Settings"), "Ayarlar")
        self.assertEqual(tr("Interface language"), "Arayüz dili")
        set_ui_language("de")
        self.assertEqual(tr("Settings"), "Einstellungen")
        set_ui_language("en")
        self.assertEqual(tr("Settings"), "Settings")
        self.assertEqual(active_translation_family(), "en")

    def test_tr_falls_back_to_the_english_source(self):
        set_ui_language("tr")
        self.assertEqual(tr("A string nobody translated"), "A string nobody translated")

    def test_unsupported_interface_language_falls_back_to_system(self):
        self.assertEqual(normalize_interface_language("kl-GL"), "system")
        self.assertEqual(normalize_interface_language("de-AT"), "de")
        self.assertEqual(normalize_interface_language(""), "system")

    def test_interface_language_choices_follow_the_active_language(self):
        set_ui_language("tr")
        labels = dict(interface_language_choices())
        self.assertEqual(labels["system"], "Sistem varsayılanı")
        self.assertEqual(labels["de"], "Deutsch")
        self.assertEqual(interface_language_label("fr"), "Français")

    def test_config_round_trips_the_interface_language(self):
        cfg = coerce_browser_config({"interface_language": "PT-br"})
        self.assertEqual(cfg.interface_language, "pt")
        cfg = coerce_browser_config({})
        self.assertEqual(cfg.interface_language, "system")
        cfg = coerce_browser_config({"interface_language": "not-a-language-we-ship"})
        self.assertEqual(cfg.interface_language, "system")

    def test_env_override_sets_the_interface_language(self):
        with patch.dict(os.environ, {"ASTER_UI_LANGUAGE": "sv"}, clear=False):
            cfg = coerce_browser_config({})
        self.assertEqual(cfg.interface_language, "sv")


if __name__ == '__main__':
    unittest.main()
