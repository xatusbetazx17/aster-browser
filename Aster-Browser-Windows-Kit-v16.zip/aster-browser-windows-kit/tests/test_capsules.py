import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from aster_browser.capsules import CapsuleRuntime, StreamingCapsuleManager


class CapsuleManagerTests(unittest.TestCase):
    def test_chromium_runtime_uses_app_mode_and_profile(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ['ASTER_PORTABLE'] = '1'
            os.environ['ASTER_PORTABLE_ROOT'] = tmp
            runtime = CapsuleRuntime(
                label='Chromium',
                argv_prefix=('chromium',),
                family='chromium',
                source='native',
                supports_app_mode=True,
                supports_profile_dir=True,
            )
            manager = StreamingCapsuleManager(forced_runtime=runtime)
            command, profile_dir, service = manager.build_launch_command('https://www.primevideo.com/detail/xyz')
            self.assertEqual(service, 'Prime Video')
            self.assertIsNotNone(profile_dir)
            self.assertTrue(any(part.startswith('--user-data-dir=') for part in command))
            self.assertIn('--app=https://www.primevideo.com/detail/xyz', command)
            self.assertTrue(Path(profile_dir).exists())

    def test_firefox_runtime_uses_profile(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ['ASTER_PORTABLE'] = '1'
            os.environ['ASTER_PORTABLE_ROOT'] = tmp
            runtime = CapsuleRuntime(
                label='Firefox',
                argv_prefix=('firefox',),
                family='firefox',
                source='native',
                supports_app_mode=False,
                supports_profile_dir=True,
            )
            manager = StreamingCapsuleManager(forced_runtime=runtime)
            command, profile_dir, service = manager.build_launch_command('https://www.netflix.com/watch/123')
            self.assertEqual(service, 'Netflix')
            self.assertIsNotNone(profile_dir)
            self.assertIn('--profile', command)
            self.assertIn(profile_dir, command)
            self.assertIn('https://www.netflix.com/watch/123', command)

    def test_override_with_placeholder_substitutes_url(self):
        manager = StreamingCapsuleManager(command_override='custom-launcher --url {url}')
        command, profile_dir, service = manager.build_launch_command('https://example.com/video')
        self.assertEqual(service, 'example.com')
        self.assertIsNone(profile_dir)
        self.assertEqual(command, ['custom-launcher', '--url', 'https://example.com/video'])

    def test_reset_profile_removes_profile_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ['ASTER_PORTABLE'] = '1'
            os.environ['ASTER_PORTABLE_ROOT'] = tmp
            runtime = CapsuleRuntime(
                label='Chromium',
                argv_prefix=('chromium',),
                family='chromium',
                source='native',
                supports_app_mode=True,
                supports_profile_dir=True,
            )
            manager = StreamingCapsuleManager(forced_runtime=runtime)
            profile = manager.capsule_profile_dir('Prime Video')
            self.assertTrue(profile.exists())
            self.assertTrue(manager.reset_capsule_profile('Prime Video'))
            self.assertFalse(profile.exists())

    def test_launch_reports_runtime(self):
        runtime = CapsuleRuntime(
            label='Chromium',
            argv_prefix=('chromium',),
            family='chromium',
            source='native',
            supports_app_mode=True,
            supports_profile_dir=False,
        )
        manager = StreamingCapsuleManager(forced_runtime=runtime)
        with mock.patch('subprocess.Popen') as popen:
            result = manager.launch('https://www.primevideo.com/detail/xyz')
        popen.assert_called_once()
        self.assertTrue(result.ok)
        self.assertIn('managed streaming capsule', result.note)
        self.assertEqual(result.runtime_label, 'Chromium')

    def test_render_mentions_native_video_sites(self):
        runtime = CapsuleRuntime(
            label='Chromium',
            argv_prefix=('chromium',),
            family='chromium',
            source='native',
            supports_app_mode=True,
            supports_profile_dir=False,
        )
        manager = StreamingCapsuleManager(forced_runtime=runtime)
        text = manager.render()
        self.assertIn('Streaming capsules: enabled', text)
        self.assertIn('standard HTML5/MSE video sites stay inside Aster Native', text)

    def test_electron_ecs_runtime_uses_capsule_arguments(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ['ASTER_PORTABLE'] = '1'
            os.environ['ASTER_PORTABLE_ROOT'] = tmp
            runtime = CapsuleRuntime(
                label='Aster Chromium DRM Capsule',
                argv_prefix=('electron', '/opt/aster/electron-drm-capsule'),
                family='electron_ecs',
                source='packaged',
                supports_app_mode=True,
                supports_profile_dir=True,
            )
            manager = StreamingCapsuleManager(forced_runtime=runtime)
            command, profile_dir, service = manager.build_launch_command('https://www.netflix.com/watch/123')
            self.assertEqual(service, 'Netflix')
            self.assertIsNotNone(profile_dir)
            self.assertEqual(command[:3], ['electron', '/opt/aster/electron-drm-capsule', '--'])
            self.assertIn('--aster-url=https://www.netflix.com/watch/123', command)
            self.assertIn('--aster-service=Netflix', command)
            self.assertTrue(any(part.startswith('--aster-profile=') for part in command))


if __name__ == '__main__':
    unittest.main()
