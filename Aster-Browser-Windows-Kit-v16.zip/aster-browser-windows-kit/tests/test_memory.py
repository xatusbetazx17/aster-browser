import time
import unittest

from aster_browser.memory import MemoryGovernor
from aster_browser.models import TabSnapshot


class MemoryGovernorTests(unittest.TestCase):
    def test_parks_old_background_tabs(self):
        governor = MemoryGovernor(soft_budget_mb=300, max_live_tabs=2)
        now = time.time()
        tabs = [
            TabSnapshot('1', 'web', 'Visible', 'https://example.com', True, True, False, False, now, 120),
            TabSnapshot('2', 'web', 'Old bg', 'https://news.example.com', True, False, False, False, now - 300, 120),
            TabSnapshot('3', 'web', 'Newer bg', 'https://mail.example.com', True, False, False, False, now - 120, 120),
        ]
        decision = governor.plan(tabs)
        self.assertEqual(decision.park_tab_ids, ['2'])

    def test_protects_audible_tabs(self):
        governor = MemoryGovernor(soft_budget_mb=200, max_live_tabs=1)
        now = time.time()
        tabs = [
            TabSnapshot('1', 'web', 'Current', 'https://example.com', True, True, False, False, now, 120),
            TabSnapshot('2', 'web', 'Video', 'https://youtube.com/watch?v=1', True, False, False, True, now - 300, 220),
            TabSnapshot('3', 'web', 'Docs', 'https://docs.python.org', True, False, False, False, now - 500, 80),
        ]
        decision = governor.plan(tabs)
        self.assertEqual(decision.park_tab_ids, ['3'])


if __name__ == '__main__':
    unittest.main()
