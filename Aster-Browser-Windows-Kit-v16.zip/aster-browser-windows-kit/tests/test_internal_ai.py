import os
import tempfile
import unittest
from pathlib import Path

from aster_browser.ai import AIBroker, AIContext
from aster_browser.local_assistant import LocalAssistant
from aster_browser.local_index import LocalIndex


class InternalAIBrokerTests(unittest.TestCase):
    def test_page_summary(self):
        broker = AIBroker('internal', 'aster-internal', '', '', 'system')
        context = AIContext(
            url='https://example.com/article',
            title='Router Guide',
            page_text=(
                'Routers connect devices and forward packets between networks. '
                'A home router usually combines switching, basic firewall features, and Wi-Fi. '
                'Firmware updates can fix security issues and improve stability. '
                'You should back up your settings before flashing new firmware.'
            ),
        )
        result = broker.ask('summarize this page', context)
        self.assertIn('Router Guide', result)
        self.assertIn('Firmware updates', result)

    def test_compare_tabs(self):
        broker = AIBroker('internal', 'aster-internal', '', '', 'system')
        context = AIContext(
            title='Router Guide',
            page_text='Routers connect devices and route packets. Firmware updates improve stability.',
            previous_title='Firewall Guide',
            previous_page_text='Firewalls inspect traffic and apply rules. Stateful firewalls track established connections.',
        )
        result = broker.ask('compare these two tabs', context)
        self.assertIn('Router Guide', result)
        self.assertIn('Firewall Guide', result)


class LocalAssistantIndexTests(unittest.TestCase):
    def test_document_search_uses_sqlite_index(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            docs = root / 'Documents'
            docs.mkdir()
            (docs / 'router-notes.md').write_text('Router firmware checklist\nUpdate backup config\n', encoding='utf-8')
            old = os.environ.get('ASTER_INTERNAL_AI_ROOTS')
            os.environ['ASTER_INTERNAL_AI_ROOTS'] = str(docs)
            try:
                index = LocalIndex(db_path=root / 'index.sqlite3')
                assistant = LocalAssistant(index)
                result = assistant.search_documents('router')
            finally:
                if old is None:
                    os.environ.pop('ASTER_INTERNAL_AI_ROOTS', None)
                else:
                    os.environ['ASTER_INTERNAL_AI_ROOTS'] = old
            self.assertIn('router-notes.md', result)
            self.assertIn('Local document matches', result)

    def test_history_search(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            index = LocalIndex(db_path=root / 'index.sqlite3')
            index.record_history('https://www.primevideo.com', 'Prime Video')
            index.record_history('https://example.com/router-guide', 'Router Guide')
            assistant = LocalAssistant(index)
            result = assistant.search_history('prime')
            self.assertIn('Prime Video', result)
            self.assertIn('primevideo.com', result)

    def test_bookmark_search(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            index = LocalIndex(db_path=root / 'index.sqlite3')
            index.add_bookmark('https://github.com/example/aster', 'Aster Repo')
            index.add_bookmark('https://example.com/router-guide', 'Router Guide')
            assistant = LocalAssistant(index)
            result = assistant.search_bookmarks('aster')
            self.assertIn('Aster Repo', result)
            self.assertIn('github.com/example/aster', result)



if __name__ == '__main__':
    unittest.main()
