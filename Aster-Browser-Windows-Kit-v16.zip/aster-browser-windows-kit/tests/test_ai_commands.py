import unittest

from aster_browser.ai import CommandRouter, IntentRouter


class CommandRouterTests(unittest.TestCase):
    def setUp(self):
        self.calls = {
            "open": [], "open_here": [], "external": [], "capsule": [], "search": [], "find": [],
            "containers": [], "docs": [], "pdfs": [], "history": [], "downloads": 0,
            "summaries": 0, "compare": 0, "switch": [], "close": 0, "close_matching": [],
            "close_others": 0, "bookmarks": [], "bookmark_save": 0, "open_doc": [], "open_pdf": [],
            "links": [], "nav": [], "duplicate": 0, "extensions": 0, "toggle_ext": [], "remove_ext": [], "reload_ext": 0,
        }
        self.router = CommandRouter(
            {
                "open_url": lambda url: self.calls["open"].append(url),
                "open_in_current": lambda url: self.calls["open_here"].append(url) or f"Opening {url}",
                "open_external": lambda url=None: self.calls["external"].append(url) or True,
                "open_capsule": lambda url=None: self.calls["capsule"].append(url) or True,
                "search": lambda query: self.calls["search"].append(query),
                "find_in_page": lambda query: self.calls["find"].append(query),
                "search_local_documents": lambda query: self.calls["docs"].append(query) or f"docs:{query}",
                "search_local_pdfs": lambda query: self.calls["pdfs"].append(query) or f"pdfs:{query}",
                "search_history": lambda query: self.calls["history"].append(query) or f"history:{query}",
                "open_downloads": lambda: self._downloads(),
                "summarize_selection_or_page": lambda: self._summaries(),
                "compare_tabs": lambda: self._compare(),
                "list_tabs": lambda: "Open tabs:\n1. * Router Guide [web | default]",
                "switch_tab": lambda target: self.calls["switch"].append(target) or f"Switched to tab {target}",
                "close_current_tab": lambda: self._close_current(),
                "close_tabs_matching": lambda query: self.calls["close_matching"].append(query) or 2,
                "close_other_tabs": lambda: self._close_others(),
                "bookmark_current_page": lambda: self._bookmark_save(),
                "search_bookmarks": lambda query: self.calls["bookmarks"].append(query) or f"bookmarks:{query}",
                "open_first_document": lambda query: self.calls["open_doc"].append(query) or f"open-doc:{query}",
                "open_first_pdf": lambda query: self.calls["open_pdf"].append(query) or f"open-pdf:{query}",
                "list_page_links": lambda: "Top links from the current page:\n1. Pricing -> https://example.com/pricing",
                "open_page_link": lambda target: self.calls["links"].append(target) or f"Opening page link: {target}",
                "navigate_back": lambda: self.calls["nav"].append("back") or True,
                "navigate_forward": lambda: self.calls["nav"].append("forward") or True,
                "reload_current": lambda: self.calls["nav"].append("reload") or True,
                "duplicate_current_tab": lambda: self._duplicate(),
                "park_background_tabs": lambda: 2,
                "open_lite_current": lambda: True,
                "get_current_container": lambda: "default",
                "set_container": lambda name: self.calls["containers"].append(name),
                "stats": lambda: "Live tabs: 3",
                "streaming_status": lambda: "DRM mode: auto",
                "capsule_status": lambda: "Streaming capsules: enabled",
                "list_extensions": lambda: self._list_extensions(),
                "toggle_extension": lambda name: self.calls["toggle_ext"].append(name) or f"Toggled {name}",
                "remove_extension": lambda name: self.calls["remove_ext"].append(name) or f"Removed {name}",
                "reload_extensions": lambda: self._reload_extensions(),
                "install_extension": lambda path: f"Installed {path}",
            }
        )

    def _downloads(self):
        self.calls["downloads"] += 1
        return True

    def _summaries(self):
        self.calls["summaries"] += 1
        return "Local summary"

    def _compare(self):
        self.calls["compare"] += 1
        return "Comparison result"

    def _close_current(self):
        self.calls["close"] += 1
        return True

    def _close_others(self):
        self.calls["close_others"] += 1
        return 3

    def _bookmark_save(self):
        self.calls["bookmark_save"] += 1
        return "Saved bookmark: Router Guide"

    def _duplicate(self):
        self.calls["duplicate"] += 1
        return True

    def _list_extensions(self):
        self.calls["extensions"] += 1
        return 'Installed extensions:\n1. Test MV3'

    def _reload_extensions(self):
        self.calls["reload_ext"] += 1
        return 'Reloaded extension runtime across open profiles.'

    def _list_extensions(self):
        self.calls["extensions"] += 1
        return "Installed extensions:\n1. Test MV3"

    def _reload_extensions(self):
        self.calls["reload_ext"] += 1
        return "Reloaded extension runtime across open profiles."

    def test_stats_command(self):
        self.assertEqual(self.router.execute('/stats'), 'Live tabs: 3')
        self.assertIn('Available commands', self.router.execute('/help'))

    def test_find_command(self):
        self.assertEqual(self.router.execute('/find router firmware'), 'Searching the current page for: router firmware')
        self.assertEqual(self.calls['find'], ['router firmware'])

    def test_streaming_command(self):
        self.assertEqual(self.router.execute('/streaming'), 'DRM mode: auto')

    def test_extension_commands(self):
        self.assertIn('Installed extensions', self.router.execute('/extensions'))
        self.assertEqual(self.router.execute('/toggle-extension test mv3'), 'Toggled test mv3')
        self.assertEqual(self.router.execute('/remove-extension test mv3'), 'Removed test mv3')
        self.assertEqual(self.router.execute('/reload-extensions'), 'Reloaded extension runtime across open profiles.')
        self.assertEqual(self.router.execute('/install-extension /tmp/test.zip'), 'Installed /tmp/test.zip')
        self.assertEqual(self.calls['extensions'], 1)
        self.assertEqual(self.calls['toggle_ext'], ['test mv3'])
        self.assertEqual(self.calls['remove_ext'], ['test mv3'])
        self.assertEqual(self.calls['reload_ext'], 1)

    def test_capsule_command(self):
        self.assertEqual(self.router.execute('/capsule https://www.primevideo.com'), 'Opening in capsule: https://www.primevideo.com')
        self.assertEqual(self.calls['capsule'], ['https://www.primevideo.com'])

    def test_docs_pdfs_history_and_downloads_commands(self):
        self.assertEqual(self.router.execute('/docs router notes'), 'docs:router notes')
        self.assertEqual(self.router.execute('/pdfs resume'), 'pdfs:resume')
        self.assertEqual(self.router.execute('/history prime video'), 'history:prime video')
        self.assertEqual(self.router.execute('/downloads'), 'Opened the downloads folder.')
        self.assertEqual(self.calls['docs'], ['router notes'])
        self.assertEqual(self.calls['pdfs'], ['resume'])
        self.assertEqual(self.calls['history'], ['prime video'])
        self.assertEqual(self.calls['downloads'], 1)

    def test_summarize_and_compare_commands(self):
        self.assertEqual(self.router.execute('/summarize'), 'Local summary')
        self.assertEqual(self.router.execute('/compare'), 'Comparison result')
        self.assertEqual(self.calls['summaries'], 1)
        self.assertEqual(self.calls['compare'], 1)

    def test_tab_bookmark_link_navigation_and_open_commands(self):
        self.assertIn('Open tabs', self.router.execute('/tabs'))
        self.assertEqual(self.router.execute('/switch 2'), 'Switched to tab 2')
        self.assertEqual(self.router.execute('/bookmark'), 'Saved bookmark: Router Guide')
        self.assertEqual(self.router.execute('/bookmarks github'), 'bookmarks:github')
        self.assertEqual(self.router.execute('/open-doc router notes'), 'open-doc:router notes')
        self.assertEqual(self.router.execute('/open-pdf resume'), 'open-pdf:resume')
        self.assertEqual(self.router.execute('/links'), 'Top links from the current page:\n1. Pricing -> https://example.com/pricing')
        self.assertEqual(self.router.execute('/open-link 2'), 'Opening page link: 2')
        self.assertEqual(self.router.execute('/reload'), 'Reloading the current tab.')
        self.assertEqual(self.router.execute('/back'), 'Went back in the current tab.')
        self.assertEqual(self.router.execute('/forward'), 'Went forward in the current tab.')
        self.assertEqual(self.router.execute('/duplicate'), 'Duplicated the current tab.')
        self.assertEqual(self.router.execute('/close-others'), 'Closed 3 other tab(s).')
        self.assertEqual(self.router.execute('/close router'), 'Closed 2 matching background tab(s).')
        self.assertEqual(self.router.execute('/open-here prime video'), 'Opening prime video')
        self.assertEqual(self.calls['switch'], ['2'])
        self.assertEqual(self.calls['bookmark_save'], 1)
        self.assertEqual(self.calls['open_doc'], ['router notes'])
        self.assertEqual(self.calls['open_pdf'], ['resume'])
        self.assertEqual(self.calls['links'], ['2'])
        self.assertEqual(self.calls['nav'], ['reload', 'back', 'forward'])
        self.assertEqual(self.calls['duplicate'], 1)
        self.assertEqual(self.calls['close_others'], 1)
        self.assertEqual(self.calls['close_matching'], ['router'])
        self.assertEqual(self.calls['open_here'], ['prime video'])


class IntentRouterTests(unittest.TestCase):
    def setUp(self):
        self.calls = {
            "open": [], "open_here": [], "external": [], "search": [], "find": [], "containers": [],
            "park": 0, "docs": [], "pdfs": [], "history": [], "downloads": 0,
            "summaries": 0, "compare": 0, "switch": [], "close_current": 0,
            "close_matching": [], "close_others": 0, "bookmark_save": 0, "bookmark_search": [],
            "bookmark_open": [], "link_open": [], "nav": [], "duplicate": 0,
            "open_doc": [], "open_pdf": [], "extensions": 0, "toggle_ext": [], "remove_ext": [], "reload_ext": 0,
        }
        self.router = IntentRouter(
            {
                "open_url": lambda url: self.calls["open"].append(url),
                "open_in_current": lambda url: self.calls["open_here"].append(url) or f"Opening {url}",
                "open_external": lambda url=None: self.calls["external"].append(url) or True,
                "open_capsule": lambda url=None: True,
                "search": lambda query: self.calls["search"].append(query),
                "find_in_page": lambda query: self.calls["find"].append(query),
                "search_local_documents": lambda query: self.calls["docs"].append(query) or f"docs:{query}",
                "search_local_pdfs": lambda query: self.calls["pdfs"].append(query) or f"pdfs:{query}",
                "search_history": lambda query: self.calls["history"].append(query) or f"history:{query}",
                "open_downloads": lambda: self._downloads(),
                "summarize_selection_or_page": lambda: self._summaries(),
                "compare_tabs": lambda: self._compare(),
                "list_tabs": lambda: "Open tabs:\n1. * Router Guide [web | default]\n2.   Prime Video [web | media]",
                "switch_tab": lambda target: self.calls["switch"].append(target) or f"Switched to tab {target}",
                "close_current_tab": lambda: self._close_current(),
                "close_tabs_matching": lambda query: self.calls["close_matching"].append(query) or 2,
                "close_other_tabs": lambda: self._close_others(),
                "bookmark_current_page": lambda: self._bookmark_save(),
                "search_bookmarks": lambda query: self.calls["bookmark_search"].append(query) or f"bookmarks:{query}",
                "open_first_bookmark": lambda query: self.calls["bookmark_open"].append(query) or f"Opening bookmark: {query}",
                "list_page_links": lambda: "Top links from the current page:\n1. Pricing -> https://example.com/pricing",
                "open_page_link": lambda target: self.calls["link_open"].append(target) or f"Opening page link: {target}",
                "navigate_back": lambda: self.calls["nav"].append('back') or True,
                "navigate_forward": lambda: self.calls["nav"].append('forward') or True,
                "reload_current": lambda: self.calls["nav"].append('reload') or True,
                "duplicate_current_tab": lambda: self._duplicate(),
                "park_background_tabs": lambda: self._park(),
                "open_lite_current": lambda: True,
                "set_container": lambda name: self.calls["containers"].append(name),
                "stats": lambda: "Live tabs: 3",
                "streaming_status": lambda: "Widevine not detected",
                "open_first_document": lambda query: self.calls["open_doc"].append(query) or f"Opened local document: {query}",
                "open_first_pdf": lambda query: self.calls["open_pdf"].append(query) or f"Opened local PDF: {query}",
                "list_extensions": lambda: self._list_extensions(),
                "toggle_extension": lambda name: self.calls["toggle_ext"].append(name) or f"Toggled {name}",
                "remove_extension": lambda name: self.calls["remove_ext"].append(name) or f"Removed {name}",
                "reload_extensions": lambda: self._reload_extensions(),
            }
        )

    def _park(self):
        self.calls["park"] += 1
        return 2

    def _downloads(self):
        self.calls["downloads"] += 1
        return True

    def _summaries(self):
        self.calls["summaries"] += 1
        return 'Local summary'

    def _compare(self):
        self.calls["compare"] += 1
        return 'Comparison result'

    def _close_current(self):
        self.calls["close_current"] += 1
        return True

    def _close_others(self):
        self.calls["close_others"] += 1
        return 3

    def _bookmark_save(self):
        self.calls["bookmark_save"] += 1
        return 'Saved bookmark: Router Guide'

    def _duplicate(self):
        self.calls["duplicate"] += 1
        return True

    def _list_extensions(self):
        self.calls["extensions"] += 1
        return "Installed extensions:\n1. Test MV3"

    def _reload_extensions(self):
        self.calls["reload_ext"] += 1
        return "Reloaded extension runtime across open profiles."

    def test_open_common_destination(self):
        result = self.router.execute('open prime video')
        self.assertEqual(result, 'Opening https://www.primevideo.com')
        self.assertEqual(self.calls['open'], ['https://www.primevideo.com'])

    def test_general_search(self):
        result = self.router.execute('search network engineer jobs')
        self.assertEqual(result, 'Searching for: network engineer jobs')
        self.assertEqual(self.calls['search'], ['network engineer jobs'])

    def test_page_find(self):
        result = self.router.execute('find router on this page')
        self.assertEqual(result, 'Searching the current page for: router')
        self.assertEqual(self.calls['find'], ['router'])

    def test_container_switch(self):
        result = self.router.execute('switch to banking container')
        self.assertEqual(result, 'Switched active container to banking')
        self.assertEqual(self.calls['containers'], ['banking'])

    def test_park_intent(self):
        result = self.router.execute('save memory')
        self.assertEqual(result, 'Parked 2 background tab(s).')
        self.assertEqual(self.calls['park'], 1)

    def test_streaming_status_intent(self):
        result = self.router.execute('streaming status')
        self.assertEqual(result, 'Widevine not detected')

    def test_extension_intents(self):
        self.assertIn('Installed extensions', self.router.execute('show extensions'))
        self.assertEqual(self.router.execute('toggle extension test mv3'), 'Toggled test mv3')
        self.assertEqual(self.router.execute('remove extension test mv3'), 'Removed test mv3')
        self.assertEqual(self.router.execute('reload extensions'), 'Reloaded extension runtime across open profiles.')
        self.assertEqual(self.calls['extensions'], 1)
        self.assertEqual(self.calls['toggle_ext'], ['test mv3'])
        self.assertEqual(self.calls['remove_ext'], ['test mv3'])
        self.assertEqual(self.calls['reload_ext'], 1)

    def test_document_pdf_history_downloads_summary_compare_intents(self):
        self.assertEqual(self.router.execute('find documents about router firmware'), 'docs:router firmware')
        self.assertEqual(self.router.execute('find pdfs about resume'), 'pdfs:resume')
        self.assertEqual(self.router.execute('find history for prime video'), 'history:prime video')
        self.assertEqual(self.router.execute('open downloads'), 'Opened the downloads folder.')
        self.assertEqual(self.router.execute('summarize this page'), 'Local summary')
        self.assertEqual(self.router.execute('compare these two tabs'), 'Comparison result')
        self.assertEqual(self.calls['docs'], ['router firmware'])
        self.assertEqual(self.calls['pdfs'], ['resume'])
        self.assertEqual(self.calls['history'], ['prime video'])
        self.assertEqual(self.calls['downloads'], 1)
        self.assertEqual(self.calls['summaries'], 1)
        self.assertEqual(self.calls['compare'], 1)

    def test_tab_bookmark_link_navigation_and_local_open_intents(self):
        self.assertIn('Open tabs', self.router.execute('show tabs'))
        self.assertEqual(self.router.execute('switch to tab 2'), 'Switched to tab 2')
        self.assertEqual(self.router.execute('close current tab'), 'Closed the current tab.')
        self.assertEqual(self.router.execute('close other tabs'), 'Closed 3 other tab(s).')
        self.assertEqual(self.router.execute('close tabs about prime'), 'Closed 2 matching background tab(s).')
        self.assertEqual(self.router.execute('bookmark this page'), 'Saved bookmark: Router Guide')
        self.assertEqual(self.router.execute('show bookmarks for github'), 'bookmarks:github')
        self.assertEqual(self.router.execute('open bookmark for github'), 'Opening bookmark: github')
        self.assertEqual(self.router.execute('list links on this page'), 'Top links from the current page:\n1. Pricing -> https://example.com/pricing')
        self.assertEqual(self.router.execute('open link 1'), 'Opening page link: 1')
        self.assertEqual(self.router.execute('reload this page'), 'Reloading the current tab.')
        self.assertEqual(self.router.execute('go back'), 'Went back in the current tab.')
        self.assertEqual(self.router.execute('go forward'), 'Went forward in the current tab.')
        self.assertEqual(self.router.execute('duplicate this tab'), 'Duplicated the current tab.')
        self.assertEqual(self.router.execute('open my resume pdf'), 'Opened local PDF: resume')
        self.assertEqual(self.router.execute('open documents about router firmware'), 'Opened local document: router firmware')
        self.assertEqual(self.calls['switch'], ['2'])
        self.assertEqual(self.calls['close_current'], 1)
        self.assertEqual(self.calls['close_others'], 1)
        self.assertEqual(self.calls['close_matching'], ['prime'])
        self.assertEqual(self.calls['bookmark_save'], 1)
        self.assertEqual(self.calls['bookmark_search'], ['github'])
        self.assertEqual(self.calls['bookmark_open'], ['github'])
        self.assertEqual(self.calls['link_open'], ['1'])
        self.assertEqual(self.calls['nav'], ['reload', 'back', 'forward'])
        self.assertEqual(self.calls['duplicate'], 1)
        self.assertEqual(self.calls['open_pdf'], ['resume'])
        self.assertEqual(self.calls['open_doc'], ['router firmware'])

    def test_chain_intent(self):
        result = self.router.execute('open prime video in this tab and park the other tabs')
        self.assertEqual(result, 'Opening https://www.primevideo.com\nParked 2 background tab(s).')
        self.assertEqual(self.calls['open_here'], ['https://www.primevideo.com'])
        self.assertEqual(self.calls['park'], 1)

    def test_risky_action_is_blocked(self):
        self.assertEqual(
            self.router.execute('log in to my bank and submit the form'),
            'That request needs confirmation and is not performed automatically by the internal assistant.'
        )


if __name__ == '__main__':
    unittest.main()
