import http.server
import io
import json
import socketserver
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path

from aster_browser.extensions import WebExtensionRegistry


class WebExtensionRegistryTests(unittest.TestCase):
    def test_install_manifest_v3_directory_prefers_native_runtime(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            ext_dir = root / 'mv3-ext'
            ext_dir.mkdir()
            (ext_dir / 'manifest.json').write_text(
                json.dumps(
                    {
                        'manifest_version': 3,
                        'name': 'Test MV3',
                        'version': '1.2.3',
                        'description': 'Native loader candidate',
                        'action': {'default_title': 'Test'},
                    }
                ),
                encoding='utf-8',
            )
            registry = WebExtensionRegistry(root / 'registry')
            record = registry.install(ext_dir)
            self.assertEqual(record.runtime_kind, 'qt_native')
            self.assertEqual(record.manifest_version, 3)
            self.assertIn('Manifest V3', record.note)
            self.assertTrue((Path(record.managed_path) / 'manifest.json').exists())

    def test_install_firefox_xpi_uses_content_script_fallback_for_mv2(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            source = root / 'reader.xpi'
            with zipfile.ZipFile(source, 'w') as zf:
                zf.writestr(
                    'manifest.json',
                    json.dumps(
                        {
                            'manifest_version': 2,
                            'name': 'Reader Mode',
                            'version': '0.8',
                            'browser_specific_settings': {'gecko': {'id': 'reader@example.com'}},
                            'content_scripts': [
                                {
                                    'matches': ['https://example.com/*'],
                                    'css': ['style.css'],
                                    'js': ['content.js'],
                                    'run_at': 'document_end',
                                }
                            ],
                        }
                    ),
                )
                zf.writestr('style.css', 'body { background: #111; color: #eee; }')
                zf.writestr('content.js', 'document.body.dataset.reader = "1";')
            registry = WebExtensionRegistry(root / 'registry')
            record = registry.install(source)
            self.assertEqual(record.source_kind, 'firefox_webextension')
            self.assertEqual(record.runtime_kind, 'content_script_fallback')
            script_source = registry._build_content_script_source(
                record,
                {
                    'matches': ['https://example.com/*'],
                    'css': ['style.css'],
                    'js': ['content.js'],
                    'run_at': 'document_end',
                },
                0,
            )
            self.assertIn('example.com', script_source)
            self.assertIn('dataset.reader', script_source)
            self.assertIn('background: #111', script_source)

    def test_find_record_matches_by_name(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            ext_dir = root / 'bookmarker'
            ext_dir.mkdir()
            (ext_dir / 'manifest.json').write_text(
                json.dumps(
                    {
                        'manifest_version': 3,
                        'name': 'Quick Bookmarker',
                        'version': '2.0',
                    }
                ),
                encoding='utf-8',
            )
            registry = WebExtensionRegistry(root / 'registry')
            record = registry.install(ext_dir)
            found = registry.find_record('bookmarker')
            self.assertIsNotNone(found)
            assert found is not None
            self.assertEqual(found.ext_id, record.ext_id)


class _TestHandler(http.server.BaseHTTPRequestHandler):
    payload = b""

    def do_GET(self):  # noqa: N802
        self.send_response(200)
        self.send_header('Content-Type', 'application/x-xpinstall')
        self.send_header('Content-Disposition', 'attachment; filename="reader.xpi"')
        self.end_headers()
        self.wfile.write(self.payload)

    def log_message(self, format, *args):  # noqa: A003
        return


class WebExtensionRegistryDownloadTests(unittest.TestCase):
    def test_install_from_url_downloads_xpi(self):
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, 'w') as zf:
            zf.writestr('manifest.json', json.dumps({'manifest_version': 2, 'name': 'Remote Reader', 'version': '1.0', 'browser_specific_settings': {'gecko': {'id': 'remote@example.com'}}, 'content_scripts': [{'matches': ['https://example.com/*'], 'js': ['content.js']}] }))
            zf.writestr('content.js', 'document.body.dataset.remote = "1";')
        _TestHandler.payload = archive.getvalue()
        with tempfile.TemporaryDirectory() as tmpdir:
            registry = WebExtensionRegistry(Path(tmpdir) / 'registry')
            with socketserver.TCPServer(('127.0.0.1', 0), _TestHandler) as server:
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                try:
                    url = f'http://127.0.0.1:{server.server_address[1]}/reader.xpi'
                    record = registry.install_from_url(url, suggested_name='Remote Reader.xpi')
                finally:
                    server.shutdown()
                    thread.join(timeout=5)
            self.assertEqual(record.name, 'Remote Reader')
            self.assertEqual(record.source_kind, 'firefox_webextension')
            self.assertTrue((Path(record.managed_path) / 'manifest.json').exists())


if __name__ == '__main__':
    unittest.main()
