import unittest

from aster_browser.lite import render_lite_page


HTML = """
<html>
  <head><title>Example</title></head>
  <body>
    <article>
      <h1>Hello World</h1>
      <p>This is a lightweight article.</p>
      <a href="https://example.com/more">More</a>
    </article>
  </body>
</html>
"""


class LiteEngineTests(unittest.TestCase):
    def test_extracts_title_and_links(self):
        page = render_lite_page('https://example.com', html_source=HTML)
        self.assertEqual(page.title, 'Example')
        self.assertIn('Hello World', page.html)
        self.assertEqual(page.links[0][1], 'https://example.com/more')


if __name__ == '__main__':
    unittest.main()
