import unittest

from aster_browser.streaming import (
    StreamingSupport,
    build_qtwebengine_flags,
    compatibility_reason,
    known_drm_service,
    known_streaming_service,
    should_redirect_externally,
)


class StreamingTests(unittest.TestCase):
    def test_known_streaming_services(self):
        self.assertEqual(known_drm_service('https://www.primevideo.com/detail/xyz'), 'Prime Video')
        self.assertEqual(known_drm_service('https://www.netflix.com/watch/123'), 'Netflix')
        self.assertIsNone(known_drm_service('https://tv.apple.com/us/show/foo'))
        self.assertEqual(known_streaming_service('https://tv.apple.com/us/show/foo'), 'Apple TV+')
        self.assertEqual(known_streaming_service('https://www.crunchyroll.com/watch/G6J0KQ6YR'), 'Crunchyroll')
        self.assertIsNone(known_streaming_service('https://example.com'))

    def test_prime_video_path_match_does_not_catch_store_pages(self):
        self.assertIsNone(known_drm_service('https://www.amazon.com/gp/product/B09XYZ'))
        self.assertEqual(known_drm_service('https://www.amazon.com/gp/video/storefront/'), 'Prime Video')

    def test_auto_mode_routes_known_protected_services_even_with_widevine(self):
        support = StreamingSupport(widevine_path='/tmp/libwidevinecdm.so', external_browser_command='firefox', drm_mode='auto')
        self.assertTrue(should_redirect_externally('https://www.primevideo.com', support))
        self.assertTrue(should_redirect_externally('https://www.netflix.com', support))
        self.assertFalse(should_redirect_externally('https://tv.apple.com', support))

    def test_internal_preferred_keeps_known_protected_services_inside_when_widevine_exists(self):
        support = StreamingSupport(widevine_path='/tmp/libwidevinecdm.so', external_browser_command='firefox', drm_mode='internal_preferred')
        self.assertFalse(should_redirect_externally('https://www.primevideo.com', support))
        self.assertFalse(should_redirect_externally('https://www.netflix.com', support))

    def test_internal_preferred_redirects_when_widevine_is_missing(self):
        support = StreamingSupport(widevine_path=None, external_browser_command='firefox', drm_mode='internal_preferred')
        self.assertTrue(should_redirect_externally('https://www.primevideo.com', support))

    def test_non_drm_streaming_site_is_not_forced_external(self):
        support = StreamingSupport(widevine_path=None, external_browser_command='firefox', drm_mode='auto')
        self.assertFalse(should_redirect_externally('https://www.crunchyroll.com/watch/G6J0KQ6YR', support))
        self.assertFalse(should_redirect_externally('https://www.youtube.com/watch?v=123', support))

    def test_internal_only_disables_redirect(self):
        support = StreamingSupport(widevine_path=None, external_browser_command='firefox', drm_mode='internal_only')
        self.assertFalse(should_redirect_externally('https://www.primevideo.com', support))

    def test_qtwebengine_capsule_disables_external_redirect(self):
        support = StreamingSupport(widevine_path=None, external_browser_command='firefox', drm_mode='qtwebengine_capsule')
        self.assertFalse(should_redirect_externally('https://www.primevideo.com', support))
        self.assertIn('Qt WebEngine', compatibility_reason('https://www.primevideo.com', support))

    def test_reason_text_mentions_capsule(self):
        support = StreamingSupport(widevine_path='/tmp/libwidevinecdm.so', external_browser_command='firefox', drm_mode='auto')
        text = compatibility_reason('https://www.primevideo.com', support)
        self.assertIn('streaming capsule', text)

    def test_build_flags_deduplicates(self):
        flags = build_qtwebengine_flags('--enable-gpu-rasterization', hardware_acceleration=True, widevine_path='/tmp/libwidevinecdm.so')
        self.assertEqual(flags.count('--enable-gpu-rasterization'), 1)
        self.assertIn('--widevine-path=/tmp/libwidevinecdm.so', flags)

    def test_build_flags_can_force_software(self):
        flags = build_qtwebengine_flags('', hardware_acceleration=False, widevine_path=None, force_software=True)
        self.assertIn('--disable-gpu', flags)


if __name__ == '__main__':
    unittest.main()
