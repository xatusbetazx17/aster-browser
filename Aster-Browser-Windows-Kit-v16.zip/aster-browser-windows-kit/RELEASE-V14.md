# Aster Browser v14

v14 is a targeted fix for the persistent HTTPS “not secure” label after a valid OpenSSL certificate check.

Highlights:

- Linux launcher now exports `ASTER_PORTABLE_ROOT` to the same state directory that the installer reset tool uses.
- `--reset-network-state` clears both the new state directory and legacy v10-v13 `app/data` / `app/cache` profile locations.
- Flatpak launcher now uses a writable Flatpak data profile root instead of relying on `/app`.
- Windows source installer now writes Aster profile state under `%LOCALAPPDATA%\AsterBrowser\state`.
- Keeps the v13 HTTPS security-label fix: main-frame certificate warnings, subresource warnings, mixed content, and load failures are separated instead of all becoming one vague “not secure” label.
- Keeps the adaptive Inventor Mentor AI mode for safer observe → diagnose → fix → verify troubleshooting.

This release still does not edit protected NSS certificate databases and does not globally bypass certificate errors.
