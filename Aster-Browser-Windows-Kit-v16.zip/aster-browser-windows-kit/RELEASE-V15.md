# Aster Browser v15

## Main changes

- Default compatibility route is now `qtwebengine_capsule`.
  - Aster uses the bundled PyQt6-WebEngine / Qt WebEngine Chromium runtime for compatibility tabs.
  - The user does **not** need Chromium or Chrome installed as the system browser for ordinary modern websites.
  - DRM streaming may still require a valid Widevine/proprietary-codec path depending on the service and platform.
- Added persistent parked tabs.
  - Parked tabs remain parked until the user explicitly clicks **Unpark / restore full tab**.
  - Parked tabs are saved in `parked_tabs.json` and restored after restarting Aster.
  - A visible parked tab shows a lightweight camel animation; the timer stops when hidden.
- Added **Park Current Tab for Later** and `/park-current` assistant command.
- Expanded adblock personalization.
  - Modes: `off`, `balanced`, `strict`, `custom`.
  - User allow-host list, block-host list, custom rules, and streaming/CDN protection allowlist.
- Added safe CA trust refresh helper.
  - `tools/refresh_ca_trust.sh --auto`
  - Linux installer refreshes system CA trust by default and never touches protected NSS user certificate databases.
- Improved internal assistant guidance for streaming compatibility, HTTPS diagnostics, adblock tuning, and parked-tab workflows.
- Added Android Lite build kit sources under `packaging/android/aster-android-lite`.

## Important limitation

Aster can embed a Chromium-family runtime through Qt WebEngine, but premium DRM playback can still require Widevine/proprietary codec support and service approval. Aster does not bypass DRM, does not disable HTTPS verification globally, and does not silently trust invalid certificates.
