# Aster Stable Modern hotfix

This hotfix fixes a PyQt6 startup crash caused by passing `QMenu.addAction()` arguments in the wrong order for the `Extensions` and `Add extension from page` menu items.

The fix creates explicit `QAction` objects, assigns shortcuts, connects signals, and then adds them to the Tools menu.
