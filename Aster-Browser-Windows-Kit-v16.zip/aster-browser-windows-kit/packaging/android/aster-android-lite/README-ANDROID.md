# Aster Android Lite Kit

This is an Android WebView-based Lite companion for Aster Browser v15.

Features included in the starter app:

- HTTPS-only default behavior through Android WebView.
- JavaScript, DOM storage, media playback, and Safe Browsing enabled.
- Simple host-based adblock interception.
- Park / Unpark page workflow with persistent parked page storage.
- Lightweight camel animation while a page is parked.
- No desktop Chrome/Chromium dependency. Android uses the platform WebView provider.

Build on a machine with Android Studio or the Android SDK:

```bash
cd packaging/android/aster-android-lite
gradle assembleDebug
```

The debug APK will be under:

```text
app/build/outputs/apk/debug/app-debug.apk
```

This Android Lite app is not a full port of the PyQt desktop UI. It is a mobile starter implementation that shares the v15 ideas: HTTPS safety, adblock personalization foundation, and persistent parked pages.


## v16 streaming note

Android uses the platform WebView/MediaDRM path when the device and service allow it. Aster Lite does not bypass DRM; premium services may still require a certified device, approved app/browser policy, and valid subscription.
