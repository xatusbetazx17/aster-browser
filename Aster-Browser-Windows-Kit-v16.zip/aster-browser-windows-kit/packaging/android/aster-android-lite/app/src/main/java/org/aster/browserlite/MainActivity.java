package org.aster.browserlite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText address;
    private TextView parkedPanel;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int camelFrame = 0;
    private String parkedUrl = "";
    private String parkedTitle = "";
    private final String[] camelFrames = new String[] {
            "🐪    Parked - web engine paused",
            " 🐪   Parked - web engine paused",
            "  🐪  Parked - web engine paused",
            "   🐪 Parked - web engine paused",
            "    🐪 Parked - web engine paused",
            "   🐪 Parked - web engine paused",
            "  🐪  Parked - web engine paused",
            " 🐪   Parked - web engine paused"
    };

    private final Runnable camelTick = new Runnable() {
        @Override public void run() {
            if (parkedPanel.getVisibility() == View.VISIBLE) {
                camelFrame = (camelFrame + 1) % camelFrames.length;
                parkedPanel.setText(camelFrames[camelFrame] + "\n\n" + parkedTitle + "\n" + parkedUrl + "\n\nTap Unpark to restore.");
                handler.postDelayed(this, 700);
            }
        }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aster-lite", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setText(prefs.getString("lastUrl", "https://duckduckgo.com"));
        bar.addView(address, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button go = new Button(this); go.setText("Go"); bar.addView(go);
        Button park = new Button(this); park.setText("Park"); bar.addView(park);
        Button unpark = new Button(this); unpark.setText("Unpark"); bar.addView(unpark);
        root.addView(bar);

        parkedPanel = new TextView(this);
        parkedPanel.setTextSize(20);
        parkedPanel.setPadding(24, 32, 24, 32);
        parkedPanel.setVisibility(View.GONE);
        root.addView(parkedPanel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDatabaseEnabled(true);
        settings.setSafeBrowsingEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new AsterClient());
        go.setOnClickListener(v -> loadAddress());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (event == null || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) { loadAddress(); return true; }
            return false;
        });
        park.setOnClickListener(v -> parkCurrent());
        unpark.setOnClickListener(v -> unparkCurrent());

        String restored = prefs.getString("currentParkedUrl", "");
        if (!restored.isEmpty()) {
            parkedUrl = restored;
            parkedTitle = prefs.getString("currentParkedTitle", restored);
            showParked();
        } else {
            webView.loadUrl(normalizeUrl(address.getText().toString()));
        }
    }

    private void loadAddress() {
        String url = normalizeUrl(address.getText().toString());
        prefs.edit().putString("lastUrl", url).remove("currentParkedUrl").remove("currentParkedTitle").apply();
        parkedPanel.setVisibility(View.GONE);
        handler.removeCallbacks(camelTick);
        webView.setVisibility(View.VISIBLE);
        webView.loadUrl(url);
    }

    private String normalizeUrl(String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) return "https://duckduckgo.com";
        if (text.startsWith("http://") || text.startsWith("https://")) return text;
        if (text.contains(".") && !text.contains(" ")) return "https://" + text;
        return "https://duckduckgo.com/?q=" + text.replace(" ", "+");
    }

    private void parkCurrent() {
        parkedUrl = webView.getUrl() == null ? normalizeUrl(address.getText().toString()) : webView.getUrl();
        parkedTitle = webView.getTitle() == null ? parkedUrl : webView.getTitle();
        saveParked(parkedTitle, parkedUrl);
        prefs.edit().putString("currentParkedUrl", parkedUrl).putString("currentParkedTitle", parkedTitle).apply();
        webView.stopLoading();
        webView.loadUrl("about:blank");
        showParked();
        Toast.makeText(this, "Page parked and saved until you unpark it.", Toast.LENGTH_LONG).show();
    }

    private void unparkCurrent() {
        if (parkedUrl.isEmpty()) parkedUrl = prefs.getString("currentParkedUrl", "");
        if (parkedUrl.isEmpty()) return;
        prefs.edit().remove("currentParkedUrl").remove("currentParkedTitle").putString("lastUrl", parkedUrl).apply();
        parkedPanel.setVisibility(View.GONE);
        handler.removeCallbacks(camelTick);
        webView.setVisibility(View.VISIBLE);
        address.setText(parkedUrl);
        webView.loadUrl(parkedUrl);
        Toast.makeText(this, "Unparked page.", Toast.LENGTH_SHORT).show();
    }

    private void showParked() {
        webView.setVisibility(View.GONE);
        parkedPanel.setVisibility(View.VISIBLE);
        camelFrame = 0;
        parkedPanel.setText(camelFrames[0] + "\n\n" + parkedTitle + "\n" + parkedUrl + "\n\nTap Unpark to restore.");
        handler.removeCallbacks(camelTick);
        handler.postDelayed(camelTick, 700);
    }

    private void saveParked(String title, String url) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("parkedTabs", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("title", title); obj.put("url", url); obj.put("savedAt", System.currentTimeMillis());
            arr.put(obj);
            prefs.edit().putString("parkedTabs", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private Set<String> blockHosts() {
        Set<String> hosts = new HashSet<>();
        String raw = prefs.getString("blockHosts", "doubleclick.net,googlesyndication.com,googleadservices.com,scorecardresearch.com");
        for (String h : raw.split(",")) { h = h.trim().toLowerCase(); if (!h.isEmpty()) hosts.add(h); }
        return hosts;
    }

    private class AsterClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return false;
        }

        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            try {
                String host = new URI(request.getUrl().toString()).getHost();
                if (host != null) {
                    host = host.toLowerCase();
                    for (String blocked : blockHosts()) {
                        if (host.equals(blocked) || host.endsWith("." + blocked)) {
                            return new WebResourceResponse("text/plain", "utf-8", null);
                        }
                    }
                }
            } catch (Exception ignored) {}
            return super.shouldInterceptRequest(view, request);
        }

        @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            Toast.makeText(MainActivity.this, "HTTPS certificate warning blocked. Check date/network/certificates.", Toast.LENGTH_LONG).show();
        }

        @Override public void onPageFinished(WebView view, String url) {
            address.setText(url);
            prefs.edit().putString("lastUrl", url).apply();
        }
    }
}
