#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BASE_MANIFEST="$ROOT_DIR/packaging/flatpak/org.aster.Browser.yml"
BUILD_ROOT="$ROOT_DIR/build"
SRC_DIR="$BUILD_ROOT/flatpak-source"
MANIFEST_DIR="$BUILD_ROOT/flatpak-manifest"
GENERATED_MANIFEST="$MANIFEST_DIR/org.aster.Browser.yml"
BUILD_DIR="$BUILD_ROOT/flatpak-build"
REPO_DIR="$BUILD_ROOT/flatpak-repo"
BUNDLE="$BUILD_ROOT/Aster-Browser.flatpak"

command -v flatpak >/dev/null 2>&1 || { echo "flatpak is required." >&2; exit 1; }
command -v flatpak-builder >/dev/null 2>&1 || { echo "flatpak-builder is required." >&2; exit 1; }

flatpak --user remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo >/dev/null 2>&1 || true
mkdir -p "$BUILD_ROOT"
rm -rf "$SRC_DIR" "$MANIFEST_DIR" "$BUILD_DIR" "$ROOT_DIR/.flatpak-builder"
mkdir -p "$SRC_DIR" "$MANIFEST_DIR"

# Build from a clean source snapshot so failed build caches, repo files, venvs,
# and .flatpak-builder state are not copied into /app/share/aster-browser.
(
  cd "$ROOT_DIR"
  tar \
    --exclude='./build' \
    --exclude='./.flatpak-builder' \
    --exclude='./.git' \
    --exclude='./.venv' \
    --exclude='./venv' \
    --exclude='./runtime' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    -cf - .
) | (cd "$SRC_DIR" && tar -xf -)

# The checked-in manifest is useful for manual builds from packaging/flatpak.
# This generated manifest points to the clean source snapshot instead.
sed 's#path: ../../#path: ../flatpak-source#' "$BASE_MANIFEST" > "$GENERATED_MANIFEST"

flatpak-builder --force-clean --user --install-deps-from=flathub --repo="$REPO_DIR" "$BUILD_DIR" "$GENERATED_MANIFEST"
flatpak build-bundle "$REPO_DIR" "$BUNDLE" org.aster.Browser
printf 'Flatpak bundle created: %s\n' "$BUNDLE"
