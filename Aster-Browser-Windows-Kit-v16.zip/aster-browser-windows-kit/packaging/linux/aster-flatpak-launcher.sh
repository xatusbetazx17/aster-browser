#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/app/share/aster-browser"
export ASTER_PORTABLE=1
export ASTER_PORTABLE_ROOT="${ASTER_PORTABLE_ROOT:-${XDG_DATA_HOME:-$HOME/.var/app/org.aster.Browser/data}/aster-browser}"
mkdir -p "$ASTER_PORTABLE_ROOT"
export NSS_DEFAULT_DB_TYPE="${NSS_DEFAULT_DB_TYPE:-sql}"
if [[ -z "${SSL_CERT_FILE:-}" ]]; then
  for ca_file in /etc/ssl/certs/ca-certificates.crt /etc/pki/tls/certs/ca-bundle.crt /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem /etc/ssl/ca-bundle.pem /var/lib/ca-certificates/ca-bundle.pem /etc/ssl/cert.pem; do
    if [[ -f "$ca_file" ]]; then export SSL_CERT_FILE="$ca_file" REQUESTS_CA_BUNDLE="$ca_file" CURL_CA_BUNDLE="$ca_file"; break; fi
  done
fi
if [[ -z "${SSL_CERT_DIR:-}" ]]; then
  for ca_dir in /etc/ssl/certs /etc/pki/tls/certs /etc/pki/ca-trust/extracted/pem; do
    if [[ -d "$ca_dir" ]]; then export SSL_CERT_DIR="$ca_dir"; break; fi
  done
fi
export QTWEBENGINE_CHROMIUM_FLAGS="${QTWEBENGINE_CHROMIUM_FLAGS:-} --ozone-platform-hint=auto"
PYVER="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
SITE_PACKAGES="/app/lib/python${PYVER}/site-packages"
if [[ -d "$SITE_PACKAGES" ]]; then
  export PYTHONPATH="$SITE_PACKAGES:${PYTHONPATH:-}"
fi
cd "$APP_DIR"
exec python3 "$APP_DIR/run_aster.py" "$@"
