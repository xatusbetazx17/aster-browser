# Aster Chromium DRM Capsule v16

This folder contains the optional Chromium DRM capsule for Aster Browser.

It uses CastLabs Electron for Content Security as a bundled Chromium-family runtime. It is not Google Chrome, and it does not make Chrome the default browser. It gives Aster a separate compatibility space for premium streaming and cloud-gaming sites.

Install/update it from the Aster source root:

```bash
./tools/setup_chromium_drm_capsule.sh
```

Then set Aster Settings → Browsing and streaming → DRM mode to:

```text
chromium_drm_capsule
```

Notes:
- Widevine/DRM is not bypassed.
- Production streaming services may still require app signing, service approval, supported codecs, and platform support.
- Linux support for persistent licenses can be limited compared with Windows/macOS.
