const fs = require('fs');
const path = require('path');
const candidates = [
  path.join(__dirname, '..', 'node_modules', '.bin', process.platform === 'win32' ? 'electron.cmd' : 'electron'),
  path.join(__dirname, '..', 'node_modules', 'electron', 'dist', process.platform === 'win32' ? 'electron.exe' : 'electron')
];
let ok = false;
for (const candidate of candidates) {
  if (fs.existsSync(candidate)) {
    console.log('Aster DRM capsule runtime:', candidate);
    ok = true;
  }
}
if (!ok) {
  console.error('Aster DRM capsule runtime not installed. Run ../../tools/setup_chromium_drm_capsule.sh');
  process.exit(1);
}
