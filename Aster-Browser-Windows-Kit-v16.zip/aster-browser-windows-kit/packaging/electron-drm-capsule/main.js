const { app, BrowserWindow, session, dialog } = require('electron');
let components = null;
try { components = require('electron').components; } catch (_) { components = null; }

function argValue(name, fallback = '') {
  const prefix = `${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length) : fallback;
}

const targetUrl = argValue('--aster-url', 'https://bitmovin.com/demos/drm');
const serviceName = argValue('--aster-service', 'Streaming service');
const profileDir = argValue('--aster-profile', '');

app.name = 'Aster Chromium DRM Capsule';
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('enable-features', 'VaapiVideoDecoder,VaapiIgnoreDriverChecks,WebRTCPipeWireCapturer');
app.commandLine.appendSwitch('disable-features', 'HardwareMediaKeyHandling');

if (profileDir) {
  app.setPath('userData', profileDir);
}

function installPermissionHandler() {
  const ses = session.defaultSession;
  ses.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const allowedWithoutPrompt = new Set(['fullscreen', 'pointerLock']);
    if (allowedWithoutPrompt.has(permission)) {
      callback(true);
      return;
    }
    const origin = details && details.requestingUrl ? details.requestingUrl : webContents.getURL();
    dialog.showMessageBox({
      type: 'question',
      buttons: ['Allow once', 'Deny'],
      defaultId: 1,
      cancelId: 1,
      title: 'Aster Capsule Permission',
      message: `${serviceName} asks for ${permission}`,
      detail: origin || targetUrl,
      noLink: true
    }).then((result) => callback(result.response === 0)).catch(() => callback(false));
  });
}

function createWindow() {
  installPermissionHandler();
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    title: `${serviceName} - Aster DRM Capsule`,
    backgroundColor: '#111827',
    webPreferences: {
      plugins: true,
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: true,
      allowRunningInsecureContent: false,
      partition: profileDir ? undefined : `persist:aster-${serviceName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
    }
  });
  win.webContents.on('render-process-gone', (_event, details) => {
    dialog.showMessageBox(win, {
      type: 'warning',
      title: 'Aster Capsule Renderer Restart Needed',
      message: 'The compatibility renderer stopped.',
      detail: JSON.stringify(details || {}, null, 2)
    }).catch(() => {});
  });
  win.loadURL(targetUrl);
}

app.whenReady().then(async () => {
  if (components && typeof components.whenReady === 'function') {
    try {
      await components.whenReady();
      console.log('Aster capsule components ready:', components.status ? components.status() : 'ready');
    } catch (err) {
      console.error('Aster capsule component setup failed:', err);
    }
  } else {
    console.log('Aster capsule components API not available; running without CastLabs component status.');
  }
  createWindow();
});

app.on('window-all-closed', () => app.quit());
