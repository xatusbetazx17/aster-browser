# Aster Browser for Windows

Two Windows paths are included:

1. `install_aster_windows.ps1` installs from source into `%LOCALAPPDATA%\AsterBrowser`, creates a private Python venv, installs requirements, and creates shortcuts.
2. `build_windows_exe.ps1` builds a PyInstaller executable. After that, `AsterBrowser.nsi` can be opened with NSIS to create `Aster-Browser-Setup.exe`.

PowerShell install. This creates a private Python runtime and installs PyQt6-WebEngine, so the user does not need Chrome or Chromium installed as the default browser:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1 -UseWinget
```

Executable build:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\build_windows_exe.ps1
```


## Certificate refresh

The installer calls `refresh_ca_trust_windows.ps1` by default. It uses Microsoft's Windows Update root certificate list and does not bypass HTTPS errors. To skip that step:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1 -NoRefreshCertificates
```

