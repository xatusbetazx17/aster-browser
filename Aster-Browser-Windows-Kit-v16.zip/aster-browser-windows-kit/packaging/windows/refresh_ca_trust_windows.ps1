<#
Refreshes Windows trusted root certificates using Microsoft's Windows Update
root certificate list. This never disables certificate validation and never
adds per-site browser exceptions.

Run from PowerShell:
  powershell -ExecutionPolicy Bypass -File .\packaging\windows\refresh_ca_trust_windows.ps1
#>
param(
    [switch]$CurrentUserOnly
)
$ErrorActionPreference = "Stop"
function Write-Step([string]$Message) { Write-Host "[Aster Windows CA] $Message" }

$TempDir = Join-Path $env:TEMP ("aster-ca-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null
$Sst = Join-Path $TempDir "windows-roots.sst"
try {
    Write-Step "Downloading Microsoft trusted root list with certutil."
    certutil.exe -generateSSTFromWU $Sst | Out-Null
    if (-not (Test-Path $Sst)) { throw "certutil did not create $Sst" }
    $certs = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
    $certs.Import($Sst)
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $storeLocation = if ($isAdmin -and -not $CurrentUserOnly) { "LocalMachine" } else { "CurrentUser" }
    Write-Step "Importing trusted roots into $storeLocation\\Root."
    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root", $storeLocation)
    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
    foreach ($cert in $certs) {
        try { $store.Add($cert) } catch { }
    }
    $store.Close()
    Write-Step "Done. HTTPS still validates normally; no certificate errors are bypassed."
} finally {
    Remove-Item -Recurse -Force $TempDir -ErrorAction SilentlyContinue
}
