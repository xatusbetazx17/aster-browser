param(
    [switch]$UseWinget,
    [string]$EcsVersion = "v42.0.0+wvcus",
    [string]$CapsuleDir = ""
)
$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
if (-not $CapsuleDir) { $CapsuleDir = Join-Path $Root "packaging\electron-drm-capsule" }
function Has-Command($Name) { try { Get-Command $Name -ErrorAction Stop | Out-Null; $true } catch { $false } }
if (-not (Has-Command node) -or -not (Has-Command npm)) {
    if ($UseWinget -and (Has-Command winget)) {
        winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
    } else {
        Write-Host "Install Node.js LTS or rerun with -UseWinget, then run this script again."
        exit 1
    }
}
Set-Location $CapsuleDir
npm install "https://github.com/castlabs/electron-releases#$EcsVersion" --save-dev --no-audit --fund=false
npm run check
Write-Host "Aster Chromium DRM Capsule installed. Set DRM mode to chromium_drm_capsule."
