<#
Installs Aster Browser on Windows from this source folder.
Run from PowerShell:
  powershell -ExecutionPolicy Bypass -File .\packaging\windows\install_aster_windows.ps1
#>
param(
    [string]$InstallRoot = "$env:LOCALAPPDATA\AsterBrowser",
    [switch]$NoShortcut,
    [switch]$UseWinget,
    [switch]$NoRefreshCertificates
)
$ErrorActionPreference = "Stop"

function Write-Step([string]$Message) { Write-Host "[Aster Windows] $Message" }

function Find-Python {
    $candidates = @(
        @{exe="py"; args=@("-3.12")},
        @{exe="py"; args=@("-3")},
        @{exe="python"; args=@()},
        @{exe="python3"; args=@()}
    )
    foreach ($candidate in $candidates) {
        $cmd = Get-Command $candidate.exe -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        try {
            $version = & $candidate.exe @($candidate.args) -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            if ($LASTEXITCODE -eq 0) {
                $parts = $version.Trim().Split('.')
                if ([int]$parts[0] -eq 3 -and [int]$parts[1] -ge 10) {
                    return @{exe=$candidate.exe; args=$candidate.args}
                }
            }
        } catch {}
    }
    return $null
}

$python = Find-Python
if (-not $python -and $UseWinget) {
    Write-Step "Python 3 was not found. Installing Python with winget."
    winget install --id Python.Python.3.12 -e --source winget
    $python = Find-Python
}
if (-not $python) {
    throw "Python 3.10+ was not found. Install Python from python.org or rerun with -UseWinget."
}

$SourceRoot = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$AppDir = Join-Path $InstallRoot "app"
$VenvDir = Join-Path $InstallRoot "runtime"
$StateDir = Join-Path $InstallRoot "state"
$Launcher = Join-Path $InstallRoot "AsterBrowser.bat"

Write-Step "Installing source to $AppDir"
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
if (Test-Path $AppDir) { Remove-Item -Recurse -Force $AppDir }
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
Copy-Item -Recurse -Force (Join-Path $SourceRoot "*") $AppDir

if (-not (Test-Path (Join-Path $VenvDir "Scripts\python.exe"))) {
    Write-Step "Creating private Python runtime"
    & $python.exe @($python.args) -m venv $VenvDir
}
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
if (-not $NoRefreshCertificates) {
    $RefreshScript = Join-Path $SourceRoot "packaging\windows\refresh_ca_trust_windows.ps1"
    if (Test-Path $RefreshScript) {
        Write-Step "Refreshing Windows trusted root certificates"
        powershell -ExecutionPolicy Bypass -File $RefreshScript
    }
}

Write-Step "Installing Python packages"
& $VenvPython -m pip install --upgrade pip wheel setuptools
& $VenvPython -m pip install -r (Join-Path $AppDir "requirements-lock.txt")

@"
@echo off
set "ASTER_PORTABLE=1"
set "ASTER_PORTABLE_ROOT=$StateDir"
set "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu-sandbox --enable-features=VaapiVideoDecoder"
cd /d "$AppDir"
"$VenvPython" "$AppDir\run_aster.py" %*
"@ | Set-Content -Encoding ASCII $Launcher

if (-not $NoShortcut) {
    Write-Step "Creating Start Menu and Desktop shortcuts"
    $Shell = New-Object -ComObject WScript.Shell
    $StartMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    foreach ($ShortcutPath in @((Join-Path $StartMenu "Aster Browser.lnk"), (Join-Path ([Environment]::GetFolderPath('Desktop')) "Aster Browser.lnk"))) {
        $Shortcut = $Shell.CreateShortcut($ShortcutPath)
        $Shortcut.TargetPath = $Launcher
        $Shortcut.WorkingDirectory = $AppDir
        $IconPath = Join-Path $AppDir "packaging\windows\aster.ico"
        if (Test-Path $IconPath) { $Shortcut.IconLocation = $IconPath }
        $Shortcut.Save()
    }
}

Write-Step "Done. Start Aster from the shortcut or run $Launcher"
