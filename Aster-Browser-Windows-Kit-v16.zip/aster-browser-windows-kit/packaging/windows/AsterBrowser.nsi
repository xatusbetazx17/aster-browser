; NSIS installer script. Build after running build_windows_exe.ps1.
!define APP_NAME "Aster Browser"
!define APP_EXE "AsterBrowser.exe"
!define COMPANY "Aster"
!define VERSION "15.0.0-merged"

Name "${APP_NAME}"
OutFile "Aster-Browser-Setup.exe"
InstallDir "$LOCALAPPDATA\AsterBrowser"
RequestExecutionLevel user

Page directory
Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "..\..\dist\AsterBrowser\*"
  CreateShortcut "$DESKTOP\Aster Browser.lnk" "$INSTDIR\${APP_EXE}"
  CreateDirectory "$SMPROGRAMS\Aster Browser"
  CreateShortcut "$SMPROGRAMS\Aster Browser\Aster Browser.lnk" "$INSTDIR\${APP_EXE}"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\Aster Browser.lnk"
  Delete "$SMPROGRAMS\Aster Browser\Aster Browser.lnk"
  RMDir "$SMPROGRAMS\Aster Browser"
  RMDir /r "$INSTDIR"
SectionEnd
