<#
Builds a Windows executable with PyInstaller. Run this on Windows after installing Python 3.10+.
The output is created under dist\AsterBrowser.
#>
param(
    [string]$Python = "python",
    [switch]$OneFile
)
$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$BuildVenv = Join-Path $Root "build\windows-venv"
if (-not (Test-Path (Join-Path $BuildVenv "Scripts\python.exe"))) {
    & $Python -m venv $BuildVenv
}
$Py = Join-Path $BuildVenv "Scripts\python.exe"
& $Py -m pip install --upgrade pip wheel setuptools pyinstaller
& $Py -m pip install -r (Join-Path $Root "requirements-lock.txt")
$Spec = Join-Path $PSScriptRoot "AsterBrowser.spec"
if ($OneFile) {
    & $Py -m PyInstaller --clean --noconfirm --onefile --name AsterBrowser (Join-Path $Root "run_aster.py") `
        --add-data "$(Join-Path $Root 'aster_browser');aster_browser" `
        --add-data "$(Join-Path $Root 'rules');rules" `
        --add-data "$(Join-Path $Root 'plugins');plugins" `
        --add-data "$(Join-Path $Root 'docs');docs"
} else {
    & $Py -m PyInstaller --clean --noconfirm $Spec
}
Write-Host "Windows executable build completed. Check: $Root\dist"
